﻿/********************************************************************************************************************************
Author		: P. Ashok Kumar
Date		: 22-June-2010
********************************************************************************************************************************
Revision History
********************************************************************************************************************************
Date							Name					    Purpose
-------------------------------------------------------------------------------------------------------------------------------
22-June-2010					P. Ashok Kumar				Added exception handling using core framework exception handler
22-Apr-2011                     T. Balamurugan              Get the Company Products and Linecard Mapped Company Products
'*******************************************************************************************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using SourceESB.BusinessLayer.Alerts;
using SourceESB.BusinessLayer.Company;
using SourceESB.BusinessLayer.Product;
using SourceESB.BusinessLayer.SolrIndex;

using SourceESB.CoreFramework.ExceptionHandler;
using SourceESB.CoreFramework.Utility;
using SourceESB.BusinessLayer.SearchModule;
using SourceESB.BusinessLayer.Personalization;

public partial class Company_CompProducts : System.Web.UI.Page
{
    Product objProduct = new Product();
    DataSet dsProduct = new DataSet();
    DataSet dsProductAll = new DataSet();
    static Dictionary<string, string> openWith = new Dictionary<string, string>();
    static Dictionary<string, string> currentData = new Dictionary<string, string>();
    static Dictionary<string, string> existData = new Dictionary<string, string>();

    static DataTable dtall = new DataTable();
    static DataTable dtall1 = new DataTable();
    string[] strAllPrd = new string[100];
    string a = string.Empty;
    public int qstUserID;
    public int iRowsAffected;
    //public int UserCompanyID = 0;
    public static int companyId;
    string Dictcheck = "F";
    string CompType = string.Empty;
    int rowcnt;//updated on 6th-july-2011 for Gemini issue:11120
    public static string SelCompName = string.Empty;
    public static string CleanCompName = string.Empty;

    int iComID;

    CompProdType CompProdMap = new CompProdType();
    Company CompObj = new Company();

    static Alert objAlert = new Alert();
    AlertTemplate AlertObj = new AlertTemplate(objAlert); 
    SearchCompanyDetail objcomp;

    SourceESBException objESBEx;

    static string ExistingProducts = string.Empty;  

    protected void Page_Load(object sender, EventArgs e)
    {
        Session["ChangeAuthStatusID"] = null;
        Session["ChangeDistAuthStatusID"] = null;

        // 0 Part Selected

        if (Convert.ToBoolean(Session["User"] != null))
        {


            if (Session["partcount"] != null)
            {
                HtmlContainerControl TempVar9 = (HtmlContainerControl)Master.FindControl("DivPartSelect1");
                TempVar9.Visible = false;
            }
            else
            {
                HtmlContainerControl TempVar9 = (HtmlContainerControl)Master.FindControl("DivPartSelect1");
                TempVar9.Visible = true;
            }
        }
        else
        {
            HtmlContainerControl TempVar9 = (HtmlContainerControl)Master.FindControl("DivPartSelect1");
            TempVar9.Visible = false;
        } 



        DataSet ds = new DataSet();

        trvAllProductTree.Attributes.Add("onclick", "OnTreeClick(event)");
        

        if (Session["cid"] != null)
        {
            companyId = Convert.ToInt32(Session["cid"].ToString());
            Session["cid"] = companyId.ToString();
            //UserCompanyID = companyId;

            //Call GetCompanyDetails Methods for retrieve and load in Dataset
            CompObj.CompanyID = Convert.ToInt32(companyId);
            ds = CompObj.GetCompany();
            if (ds != null)
            {
                CompType = ds.Tables[0].Rows[0]["CompanyType"].ToString();
                SelCompName = ds.Tables[0].Rows[0]["CompanyName"].ToString();

                if (ds.Tables[0].Rows[0]["CleanCompName"] != DBNull.Value)
                {
                    CleanCompName = ds.Tables[0].Rows[0]["CleanCompName"].ToString();
                }
                else
                {
                    CleanCompName = SelCompName;
                }

                lblcurrentproducts.Text = SelCompName + ": Current Products Selected";
            }
        }

        if (!Page.IsPostBack)
        {

            openWith.Clear();
            strbtncancel.Visible = false;

            pnlAllProductTree.Visible = false;
            btnAddEditProduct.Text = "ADD/EDIT PRODUCTS";

            PopulateRootLevel();
            trvProductType.ExpandAll();
            pnlAllProductTree.Visible = false;
            logindev.Visible = false;
            if (!CompType.Contains("M"))
            {
                if (trvProductType.Nodes.Count >= 1)
                {
                    strBtn.Visible = true;
                }
                else
                {
                    strBtn.Visible = false;
                }
            }


        }
        if (trvProductType.Nodes.Count == 0)
        {
            lblHeading.Text = ds.Tables[0].Rows[0]["CompanyName"].ToString() + ": ";
            if (!CompType.Contains("M"))
            {
                lblHeading.Text += "No product categories are displayed unless you are associated with a manufacturer(s). ";
            }
            lblStatus.Visible = true;
            pnlProductTree.Visible = false;   
        }


        if (Session["cid"] != null)
        {
            iComID = Convert.ToInt32(Session["cid"]);
        }


        UserCredentials ObjUserCre = (UserCredentials)Session["User"];
        //Check admin and Production user role
        if (!ObjUserCre.UserRoles.Contains("ADMIN") && !ObjUserCre.UserRoles.Contains("PRODUCTION"))
        {
            // Get the userRoles for assigned company
            List<UserRoleCompany> userRoles = ObjUserCre.ListUserRoleCompany.FindAll(delegate(UserRoleCompany urc) { return urc.UserCompanyID == iComID; });

            // Check for company admin role for company in userRole list
            UserRoleCompany selectedCompAdminRole = userRoles.Find(delegate(UserRoleCompany urc) { return urc.UserRole == "COMPANY ADMIN"; });

            // Read-only for Internal user roles - sales and sales manager
            if (selectedCompAdminRole == null && (ObjUserCre.UserRoles.Contains("INTERNAL SALES") || ObjUserCre.UserRoles.Contains("SALES") || ObjUserCre.UserRoles.Contains("SALES MANAGER")))
            {
                SetEnableControls(this.Page, false);
                //Set class to Disable the buttons                      
                tdBtnAddEdit.Attributes.Add("class", "buttonscompanydisable");
            }
            else if (userRoles != null)
            {               
                // If company admin role not in list then it'll check for external userRole for Read-only
                if (selectedCompAdminRole == null)
                {
                    UserRoleCompany selectedExternalRole = userRoles.Find(delegate(UserRoleCompany urc)
                    {
                        return urc.UserRole == "ADPROOF CONTACT" || urc.UserRole == "ADVERTISING CONTACT" || urc.UserRole == "COMPANY CONTACT" || urc.UserRole == "UPLOAD CONTACT";
                    });
                    if (selectedExternalRole != null)
                    {
                        SetEnableControls(this.Page, false);
                        //Set class to Disable the buttons                      
                        tdBtnAddEdit.Attributes.Add("class", "buttonscompanydisable");
                    }
                }
            }
        }
    }

    private void SetEnableControls(Control page, bool enable)
    {
        foreach (Control ctrl in page.Controls)
        {           
            if (ctrl is Button)
            {
                 //Check Entire Search Controls
                if (((Button)(ctrl)).ID != "btnCancel" && ((Button)(ctrl)).ID != "BtnSearchText"
                    && ((Button)(ctrl)).ID != "Button1" && ((Button)(ctrl)).ID != "Button2")
                {
                    ((Button)(ctrl)).Enabled = enable;
                }
            }

            if (ctrl.Controls.Count > 0)
            {
                // Use recursion to find all nested controls 
                SetEnableControls(ctrl, enable);
            }
        }
    }

    private void PopulateRootLevel()
    {
        trvProductType.Nodes.Clear();
        objProduct.ProductId = 0;
        objProduct.CompanyId = companyId;
        //dsProduct = objProduct.GetProductTypeView();
        //Get the Company Products and Linecard Mapped Company Products       
        
        //Previously Done
        //dsProduct = CompProdMap.GetProductTypeComp(0, companyId);                
        objcomp = new SearchCompanyDetail();
        objcomp.CompanyID = Convert.ToInt32(companyId);
        dsProduct = objcomp.GetSearchProductTypeComp(0, Convert.ToInt32(companyId));
        PopulateNodes(dsProduct, trvProductType.Nodes);
    }
    private void PopulateSubLevel(int parentid, TreeNode parentNode)
    {
        objProduct.ProductId = parentid;
        objProduct.CompanyId = Convert.ToInt32(companyId);
        //dsProduct = CompProdMap.GetProductTypeComp(parentid, companyId);
        objcomp = new SearchCompanyDetail();
        dsProduct = objcomp.GetSearchProductTypeComp(parentid, Convert.ToInt32(companyId));
        PopulateNodes(dsProduct, parentNode.ChildNodes);
        dtall = dsProduct.Tables[0];
        dtall1 = dtall;
    }
    private void PopulateAllRootLevel()
    {
        trvAllProductTree.Nodes.Clear();
        objProduct.ProductId = 0;
        objProduct.CompanyId = 0;
        //dsProductAll = objProduct.GetProductTypeView();
        //Get the Company Products and Linecard Mapped Company Products
        if (CompType.Contains("M"))
        {
            dsProductAll = CompProdMap.GetProductTypeComp(0, 0);
        }
        else if (CompType.Contains("D"))
        {
            dsProductAll = CompProdMap.GetProductTypeDist(0, companyId);
        }
        else
        {
            dsProductAll = CompProdMap.GetProductTypeComp(0, companyId);
        }
       
        PopulateAllNodes(dsProductAll, trvAllProductTree.Nodes);
    }
    private void PopulateAllSubLevel(int parentid, TreeNode parentNode)
    {
        objProduct.ProductId = parentid;
        objProduct.CompanyId = 0;
        //dsProductAll = objProduct.GetProductTypeView();
        //Get the Company Products and Linecard Mapped Company Products
        if (CompType.Contains("M"))
        {
            dsProductAll = CompProdMap.GetProductTypeComp(parentid, 0);
        }
        else if (CompType.Contains("D"))
        {
            dsProductAll = CompProdMap.GetProductTypeDist(parentid, companyId);
        }
        else
        {
            dsProductAll = CompProdMap.GetProductTypeComp(parentid, companyId);
        }
        
        PopulateAllNodes(dsProductAll, parentNode.ChildNodes);
    }
    protected void trvProductType_TreeNodePopulate(object sender, TreeNodeEventArgs e)
    {
        PopulateSubLevel(Int32.Parse(e.Node.Value), e.Node);
        Dictcheck = "F";
        foreach (KeyValuePair<string, string> kvp in openWith)
        {
            if (e.Node.Value == kvp.Key)
            {
                Dictcheck = "T";
                break;
            }
        }
        if (Dictcheck == "F")
        {
            openWith.Add(e.Node.Value, e.Node.Text);
        }
    }
    protected void trvAllProductTree_TreeNodePopulate(object sender, TreeNodeEventArgs e)
    {
        PopulateAllSubLevel(Int32.Parse(e.Node.Value), e.Node);
        foreach (KeyValuePair<string, string> kvp in openWith)
        {
            if (e.Node.Value == kvp.Key)
            {
                e.Node.Checked = true;
                break;
            }
        }
    }
    private void PopulateNodes(DataSet dsProduct, TreeNodeCollection nodes)
    {
        DataTable dt = new DataTable();
        dt = dsProduct.Tables[0];
        Dictcheck = "F";
        rowcnt = dt.Rows.Count;
        if (rowcnt > 0)
        {
            lblcurrentproducts.Visible = true;// updated on 6th-july-2011 for Gemini issue:11120
            lblselectproducts.Visible = true;//updated on 6th-july-2011 for Gemini issue:11120

        }
        foreach (DataRow dr in dsProduct.Tables[0].Rows)
        {
            DataRow dtrow = dtall.NewRow();
            TreeNode tn = new TreeNode();
            tn.Text = dr["TypeDescription"].ToString();
            tn.Value = dr["ProductTypeId"].ToString();

            nodes.Add(tn);

            //If node has child nodes, then enable on-demand populating
            tn.PopulateOnDemand = ((int)(dr["childnodecount"]) > 0);
            foreach (KeyValuePair<string, string> kvp in openWith)
            {
                if (tn.Value == kvp.Key)
                {
                    Dictcheck = "T";
                    break;
                }
            }
            if (Dictcheck == "F")
            {
                openWith.Add(tn.Value, tn.Text);
            }
        }
    }

    private void PopulateAllNodes(DataSet dsProductAll, TreeNodeCollection nodes)
    {
        DataTable dt = new DataTable();


        dt = dsProductAll.Tables[0];

        foreach (DataRow dr in dsProductAll.Tables[0].Rows)
        {
            TreeNode tn = new TreeNode();
            tn.Text = dr["TypeDescription"].ToString();
            tn.Value = dr["ProductTypeId"].ToString();
            foreach (KeyValuePair<string, string> kvp in openWith)
            {
                if (tn.Value == kvp.Key)
                {
                    tn.Checked = true;
                    break;
                }
                //else
                //{
                //    tn.Checked = false;
                //    break;
                //}
            }

            nodes.Add(tn);

            //If node has child nodes, then enable on-demand populating
            tn.PopulateOnDemand = ((int)(dr["childnodecount"]) > 0);
            //currentData.Add(tn.Value, tn.Text);
        }
    }
    protected void btnInsertUpdate_Click(object sender, EventArgs e)
    {

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        objProduct.CategoryId = Convert.ToInt32(hideCategory.Value);
        iRowsAffected = objProduct.DeleteProductCategory();
        Session["Message"] = "delete";
        Response.Redirect("ProductType.aspx", false);
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }
    protected void trvProductType_SelectedNodeChanged(object sender, EventArgs e)
    {
        // int productSelect = Convert.ToInt32(trvProductType.SelectedNode.Value);
        // EditProductType(productSelect);        
    }
    protected void trvAllProductTree_SelectedNodeChanged(object sender, EventArgs e)
    {
        trvAllProductTree.Focus();
    }
    private void EditProductType(int argProduct)
    {

    }
    protected void SelectNode(TreeNodeCollection tnc, string nodeToSelect)
    {
        foreach (TreeNode node in tnc)
        {
            if (node.Text == nodeToSelect)
            {
                node.Selected = true;

                break;
            }
            else if (node.ChildNodes.Count > 0)
            {
                SelectNode(node.ChildNodes, nodeToSelect);

            }
        }
    }

    private void SelectChecked(TreeNodeCollection tNodeList)
    {
        try
        {
            if (CompType.Contains("M"))
            {
                int iRowsAffected = 0;

                CompProdMap.CompanyID = companyId;
                CompProdMap.DeleteCompProdType();

                foreach (TreeNode tNode in tNodeList)
                {
                    if (tNode != null)
                    {
<<<<<<< .mine
                        CompProdMap.ProductTypeID = Convert.ToInt32(tNode.Value.ToString());                        
                        CompProdMap.CreatedBy = qstUserID;
                        iRowsAffected = CompProdMap.AddCompProdMapping();
                        currentData.Add(tNode.Value.ToString(), tNode.Text.ToString());
                    }
                    foreach (TreeNode tNodeChild in tNode.ChildNodes)
                    {
                        if (tNodeChild.Checked)
=======
                        if (tNode.Checked)
>>>>>>> .r3760
                        {
                            CompProdMap.ProductTypeID = Convert.ToInt32(tNode.Value.ToString());
                            CompProdMap.CreatedBy = qstUserID;
                            iRowsAffected = CompProdMap.AddCompProdMapping();
                            currentData.Add(tNode.Value.ToString(), tNode.Text.ToString());
                        }

                        MTypeAddEditProductRecursively(tNode);
                    }
                    
                }
                if (iRowsAffected > 0)
                {
                    logindev.Visible = true;
                    lblDisMsg.Visible = true;
                    lblDisMsg.Text = "Successfully mapped";
                }

            }
            //modify date 06-sep-11 
            else
            {
                CompProdMap.CompanyID = companyId;

                foreach (TreeNode tNode in tNodeList)
                {
                    if (tNode != null)
                    {
                        if (tNode.Checked == true)
                        {
                            CompProdMap.ProductTypeID = Convert.ToInt32(tNode.Value.ToString());
                            CompProdMap.CheckDistProdType();
                        }
                        else
                        {
                            CompProdMap.ProductTypeID = Convert.ToInt32(tNode.Value.ToString());
                            CompProdMap.CreatedBy = qstUserID;
                            currentData.Add(tNode.Value.ToString(), tNode.Text.ToString());
                            CompProdMap.DeleteCompProdType();
                        }

                        DTypeAddEditProductRecursively(tNode);
                    }
                }
                if (iRowsAffected > 0)
                {
                    logindev.Visible = true;
                    lblDisMsg.Visible = true;
                    lblDisMsg.Text = "Successfully mapped";
                }
            }
        }
        catch (Exception ex)
        {
            objESBEx = new SourceESBException(ex);
        }
    }

    private void MTypeAddEditProductRecursively(TreeNode tNode)
    {
        foreach (TreeNode tNodeChild in tNode.ChildNodes)
        {
            if (tNodeChild.Checked)
            {
                CompProdMap.ProductTypeID = Convert.ToInt32(tNodeChild.Value.ToString());
                CompProdMap.CreatedBy = qstUserID;
                iRowsAffected = CompProdMap.AddCompProdMapping();
                currentData.Add(tNodeChild.Value.ToString(), tNodeChild.Text.ToString());
            }
            MTypeAddEditProductRecursively(tNodeChild);
        }
    }

    private void DTypeAddEditProductRecursively(TreeNode tNode)
    {
        foreach (TreeNode tNodeChild in tNode.ChildNodes)
        {
            if (tNodeChild.Checked == true)
            {
                CompProdMap.ProductTypeID = Convert.ToInt32(tNodeChild.Value.ToString());
                CompProdMap.CheckDistProdType();
            }
            else
            {
                CompProdMap.ProductTypeID = Convert.ToInt32(tNodeChild.Value.ToString());
                CompProdMap.CreatedBy = qstUserID;
                currentData.Add(tNodeChild.Value.ToString(), tNodeChild.Text.ToString());
                CompProdMap.DeleteCompProdType();
            }
            DTypeAddEditProductRecursively(tNodeChild);
        }
    }

    protected void btnAddEditProduct_Click(object sender, EventArgs e)
    {
        lblStatus.Visible = false;
        pnlProductTree.Visible = true;
        DataSet dsProdAlert = new DataSet();
        DataSet dsProdAlert1 = new DataSet();

        if (btnAddEditProduct.Text.ToString() == "ADD/EDIT PRODUCTS")
        {
            pnlAllProductTree.Visible = true;
            trvAllProductTree.ExpandDepth = 0;
            trvAllProductTree.ShowLines = false;
            trvAllProductTree.ShowCheckBoxes = TreeNodeTypes.All;
            PopulateRootLevel();
            trvProductType.ExpandAll();
            PopulateAllRootLevel();
            trvAllProductTree.ExpandAll();
            btnAddEditProduct.Text = "SUBMIT";
            logindev.Visible = false;
            strbtncancel.Visible = true;
        }
        else if (btnAddEditProduct.Text.ToString() == "SUBMIT")
        {

            

            SelectChecked(trvAllProductTree.Nodes);

            //For Alert Purpose
            string NewProd = string.Empty;
            string nodeName;
            Boolean isLeaf = false;


            foreach (string key in currentData.Values)
            {
                if (!openWith.ContainsValue(key))
                {
                    nodeName = key.ToString();
                    isLeaf = IsNodeLeaf(nodeName);

                    if (isLeaf)
                    {
                        NewProd = NewProd + key.ToString() + ",";
                    }
                }                
            }

            if (NewProd.Length >= 1)
            {
                NewProd = NewProd.Substring(0, NewProd.Length - 1);
            }
            if (NewProd.ToString() != "")
            {
                dsProdAlert = CompObj.GetRegisteredUserAlert(companyId, Convert.ToInt32(MySourcePreferences.AlertFavCompNewProduct));
                for (int k = 0; k < dsProdAlert.Tables[0].Rows.Count; k++)
                {
                    AlertObj.UserName = (dsProdAlert.Tables[0].Rows[k]["FirstName"] != null ? dsProdAlert.Tables[0].Rows[k]["FirstName"].ToString() : "");
                    AlertObj.CompanyName = SelCompName.ToString();
                    AlertObj.CleanCompanyName = CleanCompName; 
                    AlertObj.Products = NewProd.ToString();
                    AlertObj.CompanyID = companyId.ToString();
                    AlertObj.CompanyTypeID = "2";
                    AlertObj.PageID = "product";
                    AlertObj.ToAddress = dsProdAlert.Tables[0].Rows[k]["EmailAddress"].ToString(); // this email id get from penton production email id's
                    AlertObj.UserRegID = dsProdAlert.Tables[0].Rows[k]["userregid"].ToString();
                    AlertObj.ProcessAlert(21);
                }

                //----------------------Start Company Info Change alert-------------------------

                if (AlertObj.IsActiveEdition() == true)
                {
                    dsProdAlert1 = CompObj.GetProductionRoleAlert();
                    for (int k = 0; k < dsProdAlert1.Tables[0].Rows.Count; k++)
                    {
                        AlertObj.CompanyInfoDesc = "Products";
                        AlertObj.CompanyInfo = NewProd.ToString();
                        AlertObj.CompanyID = companyId.ToString();
                        AlertObj.CompanyName = SelCompName.ToString();
                        AlertObj.ChangeInfo = "prods";
                        AlertObj.CompanyTypeID = "1";
                        AlertObj.PageID = "CompInfoChange";
                        AlertObj.ToAddress = dsProdAlert1.Tables[0].Rows[k]["EmailAddress"].ToString(); // this email id get from penton production email id's
                        AlertObj.UserRegID = dsProdAlert1.Tables[0].Rows[k]["userregid"].ToString();
                        AlertObj.ProcessAlert(35);

                    }
                }
            }
            //End of Alert

            openWith.Clear();
            currentData.Clear();
            PopulateRootLevel();
            trvProductType.ExpandAll();
            pnlAllProductTree.Visible = false;           
            btnAddEditProduct.Text = "ADD/EDIT PRODUCTS";
            strbtncancel.Visible = false;

            
        }
        if (trvProductType.Nodes.Count >= 1)
        {
            lblStatus.Visible = false;
            pnlProductTree.Visible = true;
        }
        else
        {
            lblStatus.Visible = true ;
            pnlProductTree.Visible = false;
        }

        //Calling Incremental update of SOLR Index
        IncrementalIndex.ImportDelta(false);
    }
    protected void trvAllProductTree_TreeNodeCheckChanged(object sender, TreeNodeEventArgs e)
    {
        //trvAllProductTree.PreRender += new EventHandler(trvProductType_SelectedNodeChanged);

        //string s = e.Node.ValuePath.ToString();

        //string[] strArray = s.Split('/');
        //foreach (string word in strArray)
        //{
        //    foreach (TreeNode tnode1 in trvAllProductTree.Nodes)
        //    {
        //        if (word.ToString() == tnode1.Value)
        //        {
        //            tnode1.Checked = true; 
        //        }
        //    }

        //}

    }

    protected void btnCancel_Click1(object sender, EventArgs e)
    {
        PopulateRootLevel();
        trvProductType.ExpandAll();
        pnlAllProductTree.Visible = false;
        btnAddEditProduct.Text = "ADD/EDIT PRODUCTS";
        strbtncancel.Visible = false;
    }


    //************************************************************************************
    //This method takes a treenode name as its parameter and determines if the node is
    //a parent or a leaf node.
    //***********************************************************************************
    private Boolean IsNodeLeaf(string nodeName)
    {
        Boolean isLeaf = false;
        TreeNode node = null;

        // Find the node specified by the user.
        node = SelectNodesRecursive(nodeName, trvAllProductTree);        
      
        //Check the rerturned node for children.
        //It it has nonoe it is a leaf.
        if (node != null)
        {
            node.Select();

            if (trvAllProductTree.SelectedNode.ChildNodes.Count == 0)
            {
                isLeaf = true;
            }
            else
            {
                isLeaf = false;
            }
        }


        return isLeaf;
    }

    private TreeNode SelectNodesRecursive(string searchText, TreeView Tv)
    {
 
        foreach (TreeNode tn in Tv.Nodes)
        {
            if (tn.Text == searchText)
            {
                return tn;
            }

            if (tn.ChildNodes.Count > 0)
            {
                foreach (TreeNode cTn in tn.ChildNodes)
                {
                    TreeNode childNode = SelectChildrenRecursive(cTn, searchText);
                    if (childNode != null)
                    {
                        return childNode;
                    }
                }
            }
        }

        return null;
    }


    private TreeNode SelectChildrenRecursive(TreeNode tn, string searchText)
    {
        TreeNode node = null;

        if (tn.Text == searchText)
        {
            return tn;            
        }
        
        if (tn.ChildNodes.Count > 0)
        {
            foreach (TreeNode tnC in tn.ChildNodes)
            {
                node = SelectChildrenRecursive(tnC, searchText);
                if (node != null)
                {
                    return node;
                }
            }

        }
        return null;
    } 
    
}
