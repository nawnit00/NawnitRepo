USE [SourceESB]
GO

/****** Object:  UserDefinedFunction [dbo].[ReturnArray]    Script Date: 06/01/2012 13:55:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReturnArray]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ReturnArray]
GO

USE [SourceESB]
GO

/****** Object:  UserDefinedFunction [dbo].[ReturnArray]    Script Date: 06/01/2012 13:55:37 ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   FUNCTION [dbo].[ReturnArray]
(
	@oString VARCHAR(MAX),
	@pPattern VARCHAR(10),
	@sDefault VARCHAR(10) = Null
)
RETURNS @Array TABLE
(
	[Array_id] INT IDENTITY(1, 1),
	[Array_data] VARCHAR(1000)
)
AS
/*
	This Function takes a comma seperated list and returns it in a temp table called @Array.
*/
BEGIN

--DECLARE	@oString varchar(max), @pPattern varchar(10),@sDefault varchar(10)
--SET @oString = NULL
--SET @pPattern = ','
--SET @sDefault = NULL

    	DECLARE
    		@Array_data [varchar](max),
    		@Location [int],
    		@Loop [bit]
    	SET @Array_data = ''
    	SET @Location = 0
    	SET @Loop = 1
    	
--DECLARE @Array TABLE
--(
--	[Array_id] [int] IDENTITY(1, 1),
--	[Array_data] varchar(1000)
--)

		IF @oString IS NOT NULL
    	WHILE @Loop <> 0
    		BEGIN
    			SET @Location = CharIndex(@pPattern, @oString, 1)
    			SET @Array_data = Replace(SubString(@oString, 1, @Location), @pPattern, '')
    			SET @oString = Stuff(@oString, 1, @Location, '')
    			IF @Location = 0
    				BEGIN
    					SET @Loop = 0
    					SET @Array_data = Replace(@oString, @pPattern, '')
    				END
				If @Array_data = '' Or @Array_data Is Null
					BEGIN
						SET @Array_data = @sDefault
					END
    			INSERT INTO @Array([Array_data])
    			VALUES(@Array_data)
    		END
    		
--SELECT * FROM @Array AS a     		
    	RETURN
END
GO


