
GO

/****** Object:  UserDefinedFunction [dbo].[RFQFavoriteContact]    Script Date: 11/02/2012 16:51:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RFQFavoriteContact]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RFQFavoriteContact]
GO

/****** Object:  UserDefinedFunction [dbo].[RFQFavoriteContact]    Script Date: 11/02/2012 16:51:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LALBAHADUR SINGH
-- Create date: 10/28/2012
-- Description:	TO GET FAVORITE CONTACT
-- =============================================
CREATE FUNCTION [dbo].[RFQFavoriteContact]
(                 
   @DistID INT,                
   @FavType INT,              
   @UserID INT  
)
RETURNS @Items table
(
	DistId int,
	Contact varchar(500) null,
	Phone varchar(100) null,
	Fax varchar(100) null,
	Email varchar(100) null
)
AS
BEGIN

	IF EXISTS (SELECT 1 FROM UserFavorites WHERE LEN(Email) <> 0 AND TypeID = @DistID AND UserID = @UserID AND FavType IN ( 1,2,3,4))       
	BEGIN               
		INSERT INTO @Items(DistId,Contact,Phone,Fax,Email)
		SELECT @DistID,Contact,'' as Phone,'' as Fax, Email FROM UserFavorites WHERE LEN(Email) <> 0 AND TypeID = @DistID AND UserID = @UserID AND FavType IN (1,2,3,4)              
	END              
	             
	IF (SELECT COUNT(*) FROM @Items) = 0            
	BEGIN              
		INSERT INTO @Items(DistId,Contact,Phone,Fax,Email)
		SELECT @DistID,LastName + ' ' + FirstName, Phone, Fax, EmailAddress FROM Usercontact UC 
		JOIN InventorySettings I ON UC.UserID = I.RFQCPID AND I.CompanyID = @DistID    
		JOIN [User] u on uc.UserID = u.UserID 
	END  
	            
RETURN 

END

GO


