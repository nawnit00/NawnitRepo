

/****** Object:  UserDefinedFunction [dbo].[GetSalesOrderActivationDate]    Script Date: 04/05/2013 15:15:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetSalesOrderActivationDate]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[GetSalesOrderActivationDate]
GO

/****** Object:  UserDefinedFunction [dbo].[GetSalesOrderActivationDate]    Script Date: 04/05/2013 15:15:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

  
  
 --------------------------------------------------------------------------      
 -- Created By : Parameswar Mal    
 -- Created On : 28 Feb 2013    
 -- Description : Get the new Activationdate of a old order (Activationdate + duration) of new Activationdate    
 --------------------------------------------------------------------------    
  
CREATE FUNCTION [dbo].[GetSalesOrderActivationDate]      
(      
    @AdOrderDetailsId INT    
 
)      
    Returns datetime      
AS      
BEGIN      
      
     
 DECLARE @duration INT    
 DECLARE @activationdate DATETIME    
 DECLARE @ReturnActivationDate DATETIME    
 SET @ReturnActivationDate=NULL    
  
    --select duration and ActivationDate    
  SELECT @duration= Duration,@activationdate=ActivationDate FROM AdOrderDetails     
  WHERE AdOrderDetailsId= @AdOrderDetailsId    
 -- AND OrderType=@ordertype    
  AND ActivationDate IS NOT NULL    
        
  -- check duration not in 0,-1    
  IF @duration  NOT IN (0,-1)    
  BEGIN    
  --add the duration in month of activationdate    
  SELECT @ReturnActivationDate=DATEADD(MONTH,@duration,@activationdate)     
  END    
  ELSE    
  BEGIN    
  -- select the activation date of old order    
   SELECT @ReturnActivationDate=@activationdate    
  END    
          
      RETURN @ReturnActivationDate       
 END  
 
 
 

GO

