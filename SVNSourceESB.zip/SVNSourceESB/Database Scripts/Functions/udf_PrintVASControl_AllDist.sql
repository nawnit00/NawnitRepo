GO

/****** Object:  UserDefinedFunction [dbo].[udf_PrintVASControl_AllDist]    Script Date: 02/08/2013 21:45:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udf_PrintVASControl_AllDist]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[udf_PrintVASControl_AllDist]
GO


/****** Object:  UserDefinedFunction [dbo].[udf_PrintVASControl_AllDist]    Script Date: 02/08/2013 21:45:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Lalbahadur Singh
-- Create date: 01-31-2013
-- Description:	To get all vendors which are located or have advertisement in that edition
-- select * from dbo.udf_PrintVASControl_AllDist(232)
-- =============================================
CREATE FUNCTION [dbo].[udf_PrintVASControl_AllDist]
(	
	@Edition INT
)
RETURNS @Tab1 TABLE 
(
	CompanyID INT, CompanyName VARCHAR(500)
)
AS
BEGIN

DECLARE @ZoneID INT, @CountryID INT, @RegionID INT
	
	-- Get the Editionid and ZoneId for the input Edition e.g. 230, 3 for 230
	 SELECT @ZoneID=E.RegionID FROM Editions E (NOLOCK)
			WHERE E.EditionID=@Edition and E.AdjobTypeID='P' 

	-- Get the CountryId for that Zone e.g. 197
	 SELECT @CountryID=CountryID FROM CountryZones (NOLOCK)
			WHERE ZoneID=@ZoneID and isactive=1

	---- Get the CountryName and Region Id for that Country e.g. United States, 1
	 SELECT --@CountryName=CountryName , 
	 @RegionID=RegionID FROM Country (NOLOCK) 
			WHERE CountryID=@CountryID
   
		--To get distributors who have created an advertised in the edition
	INSERT @Tab1 (CompanyID,CompanyName)  
		SELECT DISTINCT AO.CompanyID,ADC.CompanyName
		FROM AdOrderdetails AOD	(NOLOCK)  
						INNER JOIN ADdetails AD					(NOLOCK)	ON AD.adtypeid=AOD.ADtypeid and AD.Status=1			
						INNER JOIN Adorder AO					(NOLOCK)	ON AO.AdOrderid=AOD.AdOrderID and AO.StatusID IN (3,4,5) -- 3-Final, 4-Partial Complete, 5-Complete 
						INNER JOIN Salessectiontype SS			(NOLOCK)	ON SS.SectionID=AD.SectionID and SS.Status=1
						INNER JOIN SalesSizetype SST			(NOLOCK)	ON SST.AdjobTypeID='P' and SST.SizeTypeID=AOD.SizetypeId
						INNER JOIN company ADC					(NOLOCK)	ON  ADC.companyId=AO.CompanyID and ADC.isactive=1 
						INNER JOIN mstcompanystatus MCS			(NOLOCK)	ON MCS.companystatusID=ADC.CompanyStatusID and lower(ltrim(rtrim(MCS.Description)))='active'
						INNER JOIN AdorderdetailsregionEdition E(NOLOCK)	ON E.AdorderDetailsID=AOD.AdorderDetailsID and E.EditionID = @Edition
						WHERE (ltrim(rtrim(SS.SectionCode))= 'V') and IsNull(AOD.positiontitle,'') <> ''
	UNION		
		SELECT DISTINCT C.CompanyId,C.CompanyName 
		FROM Company C (NOLOCK)
						INNER JOIN CompanyLocations CL(NOLOCK) ON CL.CompanyID = C.CompanyID AND CL.Isactive = 1 AND CL.LocationStatusId = 1 AND CL.DoNotPublishIndicator = 0 AND CL.CountryID = @CountryID
						INNER JOIN ZipCode ZC(NOLOCK) ON zc.ZoneID = @ZoneID AND CL.Zip >= ZC.ZipFrom AND CL.Zip <= ZC.ZipTo AND ZC.CountryId = @CountryID
						INNER JOIN mstlocationstatus MLS(NOLOCK) ON MLS.locationstatusID = CL.locationStatusID AND MLS.isactive = 1 AND lower(ltrim(rtrim(MLS.Description))) = 'active'
						INNER JOIN MstCompanyStatus MS(NOLOCK) ON ms.companystatusid = C.companystatusid AND Lower(Ltrim(Rtrim(ms.description))) = 'active'
						WHERE C.isactive = 1  and Charindex('V', dbo.[Get_CompanyTypeName](C.CompanyID)) > 0
		order by companyName
	RETURN 
END




GO


