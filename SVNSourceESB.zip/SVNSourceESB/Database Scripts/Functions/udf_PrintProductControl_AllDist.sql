GO

/****** Object:  UserDefinedFunction [dbo].[udf_PrintProductControl_AllDist]    Script Date: 02/26/2013 21:02:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udf_PrintProductControl_AllDist]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[udf_PrintProductControl_AllDist]
GO

/****** Object:  UserDefinedFunction [dbo].[udf_PrintProductControl_AllDist]    Script Date: 02/26/2013 21:02:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Lalbahadur Singh
-- Create date: 01-31-2013
-- Description:	To get all distributors who are located or advertised in that edition
-- select * from dbo.udf_PrintProductControl_AllDist(236)
-- =============================================
CREATE FUNCTION [dbo].[udf_PrintProductControl_AllDist]
(	
	@Edition INT
)
RETURNS @Tab1 TABLE 
(
	CompanyID INT, CompanyName VARCHAR(500)
)
AS
BEGIN

DECLARE @ZoneID INT, @CountryID INT, @RegionID INT
	
	-- Get the Editionid and ZoneId for the input Edition e.g. 230, 3 for 230
	 SELECT @ZoneID=E.RegionID FROM Editions E (NOLOCK)
			WHERE E.EditionID=@Edition and E.AdjobTypeID='P' 

	-- Get the CountryId for that Zone e.g. 197
	 SELECT @CountryID=CountryID FROM CountryZones (NOLOCK)
			WHERE ZoneID=@ZoneID and isactive=1

	---- Get the CountryName and Region Id for that Country e.g. United States, 1
	 SELECT --@CountryName=CountryName , 
	 @RegionID=RegionID FROM Country (NOLOCK) 
			WHERE CountryID=@CountryID
   
	--To get distributors who have created an advertised in the edition and for 'P' section
		INSERT INTO @Tab1
			SELECT DISTINCT AO.CompanyID, ADC.CompanyName
			FROM AdOrderdetails AOD	(NOLOCK)  
				INNER JOIN ADdetails AD					(NOLOCK)	ON AD.adtypeid=AOD.ADtypeid and AD.Status=1			
				INNER JOIN Adorder AO					(NOLOCK)	ON AO.AdOrderid=AOD.AdOrderID and AO.StatusID IN (3,4,5) -- 3-Final, 4-Partial Complete, 5-Complete 
				INNER JOIN Salessectiontype SS			(NOLOCK)	ON SS.SectionID=AD.SectionID and SS.Status=1
				INNER JOIN SalesSizetype SST			(NOLOCK)	ON SST.AdjobTypeID='P' and SST.SizeTypeID=AOD.SizetypeId
				INNER JOIN company ADC					(NOLOCK)	ON  ADC.companyId=AO.CompanyID and ADC.isactive=1 
				INNER JOIN mstcompanystatus MCS			(NOLOCK)	ON MCS.companystatusID=ADC.CompanyStatusID and lower(ltrim(rtrim(MCS.Description)))='active'
				INNER JOIN AdorderdetailsregionEdition E(NOLOCK)	ON E.AdorderDetailsID=AOD.AdorderDetailsID and E.EditionID=@Edition
			WHERE IsNull(AOD.positiontitle,'') <> ''

		UNION

			--To get distributors located in that edition(region/zone)
			SELECT DISTINCT CT.CompanyID,CT.CompanyName
			FROM Company CT   (NOLOCK)
				INNER JOIN CompanyLocations CL			(NOLOCK)	ON  CL.CompanyID=CT.CompanyID AND CL.Isactive=1 AND CL.DoNotPublishIndicator = 0 AND CL.CountryID=@CountryID
				INNER JOIN ZipCode ZC					(NOLOCK)	ON zc.ZoneID = @ZoneID and CL.Zip >= ZC.ZipFrom and CL.Zip <=ZC.ZipTo AND ZC.CountryId = @CountryID
				INNER JOIN mstlocationstatus MLS		(NOLOCK)	ON MLS.locationstatusID=CL.locationStatusID and MLS.isactive=1 and lower(ltrim(rtrim(MLS.Description)))='active'			 
				INNER JOIN MstCompanyStatus MS			(NOLOCK)	ON MS.CompanyStatusID=CT.CompanyStatusID and lower(ltrim(rtrim(MS.Description)))='active'   
				INNER JOIN CompanyProductType CPT		(NOLOCK)	ON CPT.companyid  = CT.CompanyId and CPT.isActive = 1
				INNER JOIN ProductType PT				(NOLOCK)	ON PT.ProductTypeId  = CPT.ProductTypeID and PT.isActive = 1
				
				INNER JOIN regionAuthorization RA  (NOLOCK) on RA.DistID = CT.CompanyID AND RA.IsActive =1 and RA.publish = 1
				INNER JOIn Company mfr              (NOLOCK)    ON mfr.CompanyID = RA.mfrid
				INNER JOIN MstCompanyStatus MS1     (NOLOCK)    ON MS1.CompanyStatusID=mfr.CompanyStatusID AND LOWER(LTRIM(RTRIM(MS1.DESCRIPTION))) = 'active'
			
			WHERE CT.isactive=1  AND CHARINDEX('D',dbo.[Get_CompanyTypeName](CT.CompanyID)) >0
			ORDER BY CompanyName


	RETURN 
END



GO

