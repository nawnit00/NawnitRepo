
/****** Object:  UserDefinedFunction [dbo].[GetActiveSalesOrder]    Script Date: 02/28/2013 20:43:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetActiveSalesOrder]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[GetActiveSalesOrder]
GO


/****** Object:  UserDefinedFunction [dbo].[GetActiveSalesOrder]    Script Date: 02/28/2013 20:43:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



 
 --------------------------------------------------------------------------      
 -- Created By : Parameswar Mal    
 -- Created On : 28 Feb 2013    
 -- Description : Get the  ACTIVE saleorder ads
 --------------------------------------------------------------------------    
CREATE  FUNCTION [dbo].[GetActiveSalesOrder]    
(    
    @AdOrderId INT,  
    @SectionID   INT,    
    @PositionTitle BIGINT  
      
)    
    Returns INT   
AS    
BEGIN    
    DECLARE @ReturnValue INT  
      SET @ReturnValue=0  
      DECLARE @SectionCode VARCHAR(2) --type  
      SELECT @SectionCode = SectionCode FROM  SalesSectionType WHERE SectionID=@SectionID   
        
      DECLARE @CompanyID INT   
      SELECT @CompanyID=CompanyId FROM AdOrder WHERE AdOrderId=@AdOrderId    
        
     IF (Upper(@SectionCode) = 'M' OR Upper(@SectionCode) = 'X')            
      BEGIN   
        
     SELECT @ReturnValue =COUNT(*)  FROM  CompanyTypeMapping CT,Company C          
     WHERE C.CompanyId=CT.CompanyID   
       AND C.CompanyID =@PositionTitle  
       AND C.IsActive = 1   
       AND CT.CompanyTypeID=1  
       AND C.CompanyStatusID =1  
     
      END  
        
    ELSE IF (Upper(@SectionCode) = 'D')            
      BEGIN   
        
     SELECT @ReturnValue =COUNT(*)  FROM  CompanyTypeMapping CT,Company C          
     WHERE C.CompanyId=CT.CompanyID   
       AND C.CompanyID =@PositionTitle  
       AND C.IsActive = 1   
       AND CT.CompanyTypeID=2  
       AND C.CompanyStatusID =1  
    
      END  
        
       ELSE IF (Upper(@SectionCode) = 'V') --FOR PRODUCT TYPE CHECK  
       BEGIN   
        SELECT @ReturnValue =COUNT(*)           
   FROM              
   Company C              
   INNER JOIN VendorServiceMapping VSM              
   ON C.CompanyId = VSM.VendorID              
   INNER JOIN CompanyTypeMapping CT           
   ON CT.CompanyId = C.CompanyID            
   INNER JOIN ProductType PT            
   ON PT.ProductTypeId = VSM.ServiceID            
   WHERE              
   CT.CompanyTypeID=3              
   AND C.CompanyStatusID=1    
   AND C.IsActive = 1         
   AND C.CompanyID = @CompanyId            
      
         END  
        
      ELSE IF (Upper(@SectionCode) = 'P') --FOR PRODUCT TYPE CHECK  
       BEGIN   
          
           SELECT @ReturnValue =COUNT(*) FROM  Company C              
            INNER JOIN CompanyProductType CPT              
            ON C.CompanyId = CPT.CompanyID              
            INNER JOIN ProductType PT            
            ON PT.ProductTypeId = CPT.ProductTypeID            
            WHERE              
            C.CompanyID = @CompanyId            
            AND C.CompanyStatusID =1   
            AND C.IsActive = 1     
            AND CPT.IsActive = 1           
         END  
      ELSE  --FOR other section CHECK  
       BEGIN   
          
           SELECT @ReturnValue = -1           
         END  
   
    RETURN @ReturnValue  
      
    END  
  
  

GO


