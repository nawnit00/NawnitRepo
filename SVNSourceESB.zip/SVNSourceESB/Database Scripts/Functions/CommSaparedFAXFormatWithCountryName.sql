GO

/****** Object:  UserDefinedFunction [dbo].[CommSaparedFAXFormatWithCountryName]    Script Date: 02/11/2013 13:51:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CommSaparedFAXFormatWithCountryName]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CommSaparedFAXFormatWithCountryName]
GO

/****** Object:  UserDefinedFunction [dbo].[CommSaparedFAXFormatWithCountryName]    Script Date: 02/11/2013 13:51:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--Created by Lalbahadur on 12/21/2012 to add zip code ranges to find phone for distributors
CREATE FUNCTION [dbo].[CommSaparedFAXFormatWithCountryName] 
( 
	@ID INT,
	@ZoneID INT,
	@CountryID INT
)
RETURNS VARCHAR(8000)
AS
BEGIN

DECLARE @phones VARCHAR(MAX),@Phone VARCHAR(20),@CountryName VARCHAR(100),@ZipFrom Varchar(20),@ZipTo VARCHAR(20),@location int
Select @CountryName=CountryName from Country where CountryID=@CountryID

	SELECT @phones = ISNULL(@phones,'') +Replace(ISNULL('[FAX: '+ [dbo].[PhoneFormat](Replace(Replace(Replace(Replace(CL.Fax,'(',''),')',''),'-',''),',',''),@CountryName) +']'+'  ',''),'[FAX: ]','') 
	FROM CompanyLocations CL, ZipCode ZC, mstLocationStatus MLS  
	WHERE CL.companyid = @ID 
		AND CL.CountryID=@CountryID AND CL.Isactive=1
		AND ZC.ZoneID = @ZoneID and CL.Zip >= ZC.ZipFrom and CL.Zip <=ZC.ZipTo
		AND MLS.LocationStatusID=CL.LocationStatusID  
		AND LOWER(RTRIM(LTRIM(MLS.Description)))='active' 
		ORDER BY CL.LocationTypeID 

IF(@phones IS NULL)
BEGIN
	SELECT @phones = ISNULL(@phones,'') +Replace(ISNULL('[FAX: '+ [dbo].[PhoneFormat](Replace(Replace(Replace(Replace(Fax,'(',''),')',''),'-',''),',',''),@CountryName) +']'+'  ',''),'[FAX: ]','') 
	from CompanyLocations CL
	INNER JOIN mstLocationType MLT on MLT.LocationTypeID=CL.LocationTypeID
	INNER JOIN mstLocationStatus MLS on MLS.LocationStatusID=CL.LocationStatusID
	WHERE CL.companyid = @ID and CL.CountryID=@CountryID and lower(rtrim(ltrim(MLT.Description)))= 'headquarters' and lower(rtrim(ltrim(MLS.Description)))='active' and CL.Isactive=1 order by CL.LocationTypeID asc
END

RETURN @phones

END


GO


