GO

/****** Object:  UserDefinedFunction [dbo].[udf_IsCompanyHQLocated]    Script Date: 02/08/2013 21:41:56 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udf_IsCompanyHQLocated]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[udf_IsCompanyHQLocated]
GO


/****** Object:  UserDefinedFunction [dbo].[udf_IsCompanyHQLocated]    Script Date: 02/08/2013 21:41:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Lalbahadur Singh
-- Create date: 1/31/2013
-- Description:	To get a head quarter location of company is located in selected zone/region or not
-- =============================================
CREATE FUNCTION [dbo].[udf_IsCompanyHQLocated]
(
	@CompanyId INT,
	@CountryId INT,
	@ZoneId INT
)
RETURNS bit
AS
BEGIN
	declare @isHQLocated bit = 0
	
	IF EXISTS (SELECT 1 FROM Company C        
					LEFT JOIN CompanyLocations CL		ON CL.companyID=C.CompanyID and CL.CountryID=@CountryId
					INNER JOIN ZipCode ZC				ON ZC.ZoneID = @ZoneId and CL.Zip >= ZC.ZipFrom and CL.Zip <=ZC.ZipTo       
					INNER JOIN mstLocationStatus MLS	ON MLS.LocationStatusID=CL.LocationStatusID and LOWER(LTRIM(RTRIM(MLS.Description)))='active'
					WHERE C.CompanyID = @CompanyId and C.CompanyName IS NOT NULL AND C.CompanyName!='' and CL.LocationTypeID = 1)
	SET @isHQLocated = 1
	
	RETURN @isHQLocated
				
END

GO


