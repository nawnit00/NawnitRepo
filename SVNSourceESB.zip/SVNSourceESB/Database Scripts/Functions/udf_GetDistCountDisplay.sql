GO

/****** Object:  UserDefinedFunction [dbo].[udf_GetDistCountDisplay]    Script Date: 12/10/2012 14:19:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udf_GetDistCountDisplay]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[udf_GetDistCountDisplay]
GO

/****** Object:  UserDefinedFunction [dbo].[udf_GetDistCountDisplay]    Script Date: 12/10/2012 14:19:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

	-- Modified By	: Lalbahadur on 12/10/2012 to include only the distributors inheriting products of all published manufactures
	CREATE FUNCTION [dbo].[udf_GetDistCountDisplay]
	(      
		@CompanyID INT      
	)      
	RETURNS VARCHAR(100)      
	AS      

	--DECLARE @CompanyID INT = 144323

	BEGIN      
		DECLARE @countDisplay VARCHAR(100) = '('
		
		SELECT @countDisplay = 
			CASE 
				WHEN CAST(DPC.PartCount AS VARCHAR(10)) > 0 
					THEN '('+ CAST(DPC.PartCount AS VARCHAR(10))+' parts,' 
				ELSE
					''
			END
		FROM DistributorPartCount DPC(nolock)      
		WHERE DPC.DistID = @CompanyID 
		   
		SELECT @countDisplay = @countDisplay + 
			CASE 
				WHEN CAST(COUNT(*) AS VARCHAR(10)) =0 
					THEN ''  
				ELSE CAST(COUNT(*) AS VARCHAR(10)) + ' manufacturers,' 
			END
		FROM RegionAuthorization r(nolock)
		INNER JOIN company c(nolock)      
			ON r.mfrid = c.Companyid
		WHERE r.DistID=@CompanyID      
			AND c.isActive = 1 
			AND c.companystatusid IN(1,4)
			AND r.publish = 1
		   
		SELECT @countDisplay = @countDisplay + 
			CASE 
				WHEN CAST(COUNT(*) AS VARCHAR(10)) = 0 
					THEN ''  
				ELSE CAST(COUNT(*) AS VARCHAR(10)) + ' products,' 
			END 
		FROM CompanyProductType CPT (NOLOCK) 
		INNER JOIN ProductType PT (NOLOCK)
			ON CPT.ProductTypeID = PT.ProductTypeId 
			AND PT.IsActive = 1 
			AND PT.StatusID = 1   
			LEFT JOIN (Select Distinct PT.ProductTypeid from RegionAuthorization RA
				   INNER JOIN CompanyProductType CPT on RA.MfrID = CPT.CompanyID AND CPT.IsActive = 1
				   INNER JOIN ProductType PT on CPT.ProductTypeID = PT.ProducttypeID AND PT.IsActive = 1 AND PT.StatusID = 1
				   WHERE RA.DistID = @CompanyID and RA.Publish = 1 and RA.IsActive = 1) as PB on PB.ProductTypeID = PT.ProducttypeID
		WHERE CPT.CompanyID = @CompanyID 
			AND CPT.IsActive = 1 
			AND PT.TypeDescription <> 'Services'     
			AND PB.ProductTypeID is not null
			AND CPT.ProductTypeId NOT IN 
			(
				SELECT DISTINCT(PT.ParentId) 
				FROM CompanyProductType CPT (NOLOCK) 
				INNER JOIN ProductType PT (NOLOCK)
					ON CPT.ProductTypeID = PT.ProductTypeId 
					AND PT.IsActive = 1 
					AND PT.StatusID = 1     
					LEFT JOIN (Select Distinct PT.ProductTypeid from RegionAuthorization RA
				   INNER JOIN CompanyProductType CPT on RA.MfrID = CPT.CompanyID AND CPT.IsActive = 1
				   INNER JOIN ProductType PT on CPT.ProductTypeID = PT.ProducttypeID AND PT.IsActive = 1 AND PT.StatusID = 1
				   WHERE RA.DistID = @CompanyID and RA.Publish = 1 and RA.IsActive = 1) as PB on PB.ProductTypeID = PT.ProducttypeID
				WHERE CPT.IsActive =1 AND CPT.CompanyID=@CompanyId
				and PB.ProductTypeID is not null AND PT.TypeDescription<>'Services'
			) 
		    
		SELECT @countDisplay = @countDisplay + 
			CASE 
				WHEN CAST(COUNT(*) AS VARCHAR(10)) = 0 
					THEN ')'  
				ELSE CAST(COUNT(*) AS VARCHAR(10)) + ' services )' 
			END 
		FROM VendorServiceMapping vsm (nolock) 
		WHERE vsm.VendorID = @CompanyID      
			AND vsm.ServiceID NOT IN
			(
				SELECT DISTINCT(b.ParentId) 
				FROM VendorServiceMapping a(nolock)
				INNER JOIN  ProductType b(nolock)
					ON a.serviceID = b.producttypeid
				WHERE a.vendorid=@CompanyID
			) 

		SELECT @countDisplay = 
			CASE 
				WHEN @countDisplay='()' 
					THEN '' 
				ELSE  
					@countDisplay 
			END     


	--SELECT @countDisplay
		RETURN @countDisplay
	   
	END

GO


