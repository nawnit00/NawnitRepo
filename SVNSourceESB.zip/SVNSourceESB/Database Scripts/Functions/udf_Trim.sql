
/****** Object:  UserDefinedFunction [dbo].[udf_Trim]    Script Date: 07/23/2012 14:44:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udf_Trim]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[udf_Trim]
GO

USE [SourceESB]
GO

/****** Object:  UserDefinedFunction [dbo].[udf_Trim]    Script Date: 07/23/2012 14:44:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[udf_Trim](@string VARCHAR(MAX))
RETURNS VARCHAR(MAX)
BEGIN
RETURN LTRIM(RTRIM(@string))
END

GO


