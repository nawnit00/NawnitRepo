GO

/****** Object:  UserDefinedFunction [dbo].[udf_CheckAdOrderPrepaid]    Script Date: 04/10/2013 17:21:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udf_CheckAdOrderPrepaid]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[udf_CheckAdOrderPrepaid]
GO

/****** Object:  UserDefinedFunction [dbo].[udf_CheckAdOrderPrepaid]    Script Date: 04/10/2013 17:21:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Lalbahadur Singh
-- Create date: 04/10/2013
-- Description:	To get prepaid percentage for particular order
-- =============================================
create FUNCTION [dbo].[udf_CheckAdOrderPrepaid]
(
	@AdOrderId			INT,
	@AdType				CHAR(1)
)
    Returns bit
AS
BEGIN
	DECLARE @PrepaidDiscount MONEY
	set @PrepaidDiscount = 0
	declare @IsPrepaid bit
	set @IsPrepaid = 0

	IF @AdType = 'P'
	 BEGIN
		SELECT @PrepaidDiscount = ISNULL(MAX(PrepaidDiscountRate),0) FROM AdOrderRegionEdition
		WHERE AdOrderID = @AdOrderId AND ISNULL(EditionID,0) <> 0 AND ISNULL(RegionID,0) <> 0
	 END
	 ELSE
	 BEGIN
		SELECT @PrepaidDiscount = ISNULL(MAX(PrepaidDiscountRate),0) FROM AdOrderRegionEdition
		WHERE AdOrderID = @AdOrderId AND ISNULL(EditionID,0) = 0 AND ISNULL(RegionID,0) = 0
	 END
    
    IF ISNULL(@PrepaidDiscount,0) <> 0
    BEGIN
		SET @IsPrepaid = 1
    END

   
	-- Return the result of the function
	RETURN @IsPrepaid

END
GO


