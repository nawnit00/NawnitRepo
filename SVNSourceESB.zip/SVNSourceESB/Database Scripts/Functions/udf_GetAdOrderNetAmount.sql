GO

/****** Object:  UserDefinedFunction [dbo].[udf_GetAdOrderNetAmount]    Script Date: 03/15/2013 15:44:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udf_GetAdOrderNetAmount]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[udf_GetAdOrderNetAmount]
GO

/****** Object:  UserDefinedFunction [dbo].[udf_GetAdOrderNetAmount]    Script Date: 03/15/2013 15:44:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Lalbahadur Singh
-- Create date: 03/13/2013
-- Description:	To get netamount calculated by prepaid discount and dollar discount rate
-- =============================================
CREATE FUNCTION [dbo].[udf_GetAdOrderNetAmount]
(
	@AdOrderId			INT,
	@GrossPrice			MONEY,
	@ApplyDiscount		BIT,
	@DiscountRate		MONEY,
	@AdType				CHAR(1)
)
    Returns money
AS
BEGIN
	DECLARE @PrepaidDiscount MONEY
	set @PrepaidDiscount = 0

	IF @AdType = 'P'
	 BEGIN
		SELECT @PrepaidDiscount = ISNULL(MAX(PrepaidDiscountRate),0) FROM AdOrderRegionEdition
		WHERE AdOrderID = @AdOrderId AND ISNULL(EditionID,0) <> 0 AND ISNULL(RegionID,0) <> 0
	 END
	 ELSE
	 BEGIN
		SELECT @PrepaidDiscount = ISNULL(MAX(PrepaidDiscountRate),0) FROM AdOrderRegionEdition
		WHERE AdOrderID = @AdOrderId AND ISNULL(EditionID,0) = 0 AND ISNULL(RegionID,0) = 0
	 END
    
    IF ISNULL(@PrepaidDiscount,0) <> 0
    BEGIN
		SET @GrossPrice = @GrossPrice -(ISNULL(@PrepaidDiscount,0) * (@GrossPrice / 100))
    END

    IF @ApplyDiscount = 1
    BEGIN
        SET @GrossPrice = @GrossPrice -(ISNULL(@DiscountRate,0) * (@GrossPrice / 100))
    END
    
	-- Return the result of the function
	RETURN ISNULL(@GrossPrice,0)

END

GO


