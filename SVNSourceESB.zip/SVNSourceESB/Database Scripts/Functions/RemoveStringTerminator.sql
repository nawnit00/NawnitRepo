/****** Object:  UserDefinedFunction [dbo].[RemoveSpecialChars]    Script Date: 02/20/2013 09:56:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveStringTerminator]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RemoveStringTerminator]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*********** String Terminators (double quotes) need to be removed from any string that is used as a parameter in a Javascript function. **********/
/******* Ticket 25914 - Part Numbers with a ' or " cause the RFQ button on the Search Result page to not function. **********/

CREATE FUNCTION [dbo].[RemoveStringTerminator] ( @InputString VARCHAR(MAX) )
RETURNS VARCHAR(MAX)  
WITH SCHEMABINDING
BEGIN
	IF @InputString IS NULL
		RETURN NULL
	DECLARE @OutputString VARCHAR(8000)
	SET @OutputString = ''
	DECLARE @l INT
	SET @l = LEN(@InputString)
	DECLARE @p INT
	SET @p = 1
	WHILE @p <= @l
		BEGIN
			DECLARE @c INT
			SET @c = ASCII(SUBSTRING(@InputString, @p, 1))
			IF @c <> 34 /*double quote*/ AND @c <> 39 /*single quote*/
				SET @OutputString = @OutputString + CHAR(@c)
			SET @p = @p + 1
		END
	IF LEN(@OutputString) = 0
		RETURN NULL
	RETURN @OutputString
END

GO
