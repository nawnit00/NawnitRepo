/****** Object:  UserDefinedFunction [dbo].[Get_SalesPersonCodeByCompanyID]    Script Date: 07/25/2012 20:37:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Get_SalesPersonCodeByCompanyID]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[Get_SalesPersonCodeByCompanyID]
GO

/****** Object:  UserDefinedFunction [dbo].[Get_SalesPersonCodeByCompanyID]    Script Date: 07/25/2012 20:37:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/************************************************************************************************************  
Created By    : Nawnit Kumar
Created Date  : 25 July 2012
Updated By	  : 
Updated Date  : 
Description   : This Function returns Sales Person Code for given company id 
*************************************************************************************************************/          
CREATE FUNCTION [dbo].[Get_SalesPersonCodeByCompanyID]  
(  
 @CompanyID INT  
)  
RETURNS VARCHAR(25)
AS
BEGIN

	DECLARE @Spc VARCHAR(25)
    SELECT @Spc = (SELECT TOP 1 U.SalesPersonCode FROM dbo.SalesAssignments SA
        INNER JOIN [User] U ON SA.SalesPerson_ID = U.UserID 
        WHERE SA.Company_ID = @CompanyID AND SA.[Status] = 1) 
		
 RETURN @Spc
END

GO


