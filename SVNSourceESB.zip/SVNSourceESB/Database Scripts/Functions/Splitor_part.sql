GO

/****** Object:  UserDefinedFunction [dbo].[Splitor_part]    Script Date: 03/17/2012 19:11:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Splitor_part]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[Splitor_part]
GO

/****** Object:  UserDefinedFunction [dbo].[Splitor_part]    Script Date: 03/17/2012 19:11:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE FUNCTION [dbo].[Splitor_part](@String varchar(8000), @Delimiter char(1))
returns  varchar(8000)
as
begin

    DECLARE @listStrF VARCHAR(8000)
    DECLARE @listStr VARCHAR(8000)
    DECLARE @listStr1 VARCHAR(8000)
    declare @idx int
    declare @slice varchar(8000)
    declare @slice1 varchar(8000)
    declare @count int

         set @count=1
         set @listStr =''

         set @count=1
         set @listStr =''
    select @idx = 1
        if len(@String)<1 or @String is null  return  @listStr

    while @idx!= 0
    begin
        set @idx = charindex(@Delimiter,@String)

        if @idx!=0
                set @slice = left(@String,@idx - 1)
         else
                set @slice = @String


            if(len(@slice)>0)
               set @slice= 'Clean_PartNumber like ''%' + @slice + '%'''

   if   @idx!= 0   and  @slice <> ''

    begin
        set @listStr =@listStr  + @slice + ' or '
    end
   else
        set @listStr =@listStr  + @slice


        set @String = right(@String,len(@String) - @idx)
        set @count=@count+1
        if len(@String) = 0 break
    end

    set @listStrF ='( ' + @listStr + ')'

return       @listStrF

end

--select dbo.Splitor_part('s a',' ')

GO


