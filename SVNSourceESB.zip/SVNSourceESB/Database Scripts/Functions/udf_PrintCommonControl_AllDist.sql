GO

/****** Object:  UserDefinedFunction [dbo].[udf_PrintCommonControl_AllDist]    Script Date: 02/08/2013 21:47:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udf_PrintCommonControl_AllDist]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[udf_PrintCommonControl_AllDist]
GO


/****** Object:  UserDefinedFunction [dbo].[udf_PrintCommonControl_AllDist]    Script Date: 02/08/2013 21:47:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Lalbahadur Singh
-- Create date: 01-31-2013
-- Description:	To get all distributors from all section (Manufacture, Distributor, VAS, Product) which
-- are 
-- 1. authorized in manufacture section
-- 2. have advertisement in all sections
-- 3. located in that edition for all sections as well associated with at least one manufacture
-- to be used in distributor section
-- select * from dbo.udf_PrintCommonControl_AllDist(232)
-- =============================================
CREATE FUNCTION [dbo].[udf_PrintCommonControl_AllDist]
(	
	@Edition INT
)
RETURNS @Tab1 TABLE 
(
	CompanyID INT, CompanyName VARCHAR(500)
)
AS
BEGIN

DECLARE @ZoneID INT, @CountryID INT, @RegionID INT
	
	   
		--To get distributors who have created an advertised in the edition
	INSERT @Tab1 (CompanyID,CompanyName)  
			SELECT DISTINCT DistId, DistName as CompanyName FROM dbo.udf_PrintManufactureControl_AllMfrDist(@Edition)
		UNION
			SELECT * FROM udf_PrintProductControl_AllDist(@Edition)
		UNION
			SELECT * FROM udf_PrintVASControl_AllDist(@Edition) WHERE CHARINDEX('D', dbo.[Get_CompanyTypeName](CompanyID)) > 0
		UNION
			SELECT * FROM udf_PrintDistributorControl_AllDist(@Edition)
		order by CompanyName
	RETURN 
END



GO


