GO

/****** Object:  UserDefinedFunction [dbo].[GetRevisionIDForAd]    Script Date: 09/26/2012 17:02:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetRevisionIDForAd]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[GetRevisionIDForAd]
GO

/****** Object:  UserDefinedFunction [dbo].[GetRevisionIDForAd]    Script Date: 09/26/2012 17:02:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[GetRevisionIDForAd]           
(               
 @AdOrderDetailsId int,
 @EditionId int,
 @RegionId int
)          
RETURNS int           
AS           
BEGIN               

  declare @returnValue int
  
  declare @currRevisionId int
  declare @previousRevisionId int
  
  declare @counter int
  SET @counter = 1
		 
   ---Declare cursor for table -----
  DECLARE curTbAdOrderRegionEdition CURSOR FOR 
  SELECT distinct AdOrderRevisionId
  FROM AdOrderDetailsRegionEditionRevision 
  where AdOrderDetailsId = @AdOrderDetailsId
  and EditionId = @EditionId 
  and RegionId = @RegionId
  
  order by AdOrderRevisionId desc
  
  -----open table cursor--------
  OPEN curTbAdOrderRegionEdition
  
  FETCH NEXT FROM curTbAdOrderRegionEdition 
  INTO @currRevisionId
    
  SET @previousRevisionId = @currRevisionId  
  
  WHILE @@FETCH_STATUS = 0
  BEGIN    
 
	  if (@counter > 1)
	  begin 
		  if (@currRevisionId = @previousRevisionId - 1)    
		  begin
				SET @previousRevisionId = @currRevisionId
		  end
		  else
		  begin         
				break
		  end  
	  end
	  else
	  begin
	 
		SET @counter = 2
	  end
	  
  FETCH NEXT FROM curTbAdOrderRegionEdition 
  INTO @currRevisionId 
  
  END
  
  SET @returnValue = @previousRevisionId 
  
  ------close or deallocate the cursors----------
  CLOSE curTbAdOrderRegionEdition  
  DEALLOCATE curTbAdOrderRegionEdition
  
  return @returnValue
   
END

GO


