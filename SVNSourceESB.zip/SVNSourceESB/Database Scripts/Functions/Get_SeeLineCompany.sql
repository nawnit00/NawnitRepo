GO

/****** Object:  UserDefinedFunction [dbo].[Get_SeeLineCompany]    Script Date: 05/06/2012 22:32:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Get_SeeLineCompany]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[Get_SeeLineCompany]
GO

/****** Object:  UserDefinedFunction [dbo].[Get_SeeLineCompany]    Script Date: 05/06/2012 22:32:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE FUNCTION [dbo].[Get_SeeLineCompany]
(
    @CompanyID INT,
    @StatusID INT

)
RETURNS VARCHAR(1000)

AS

BEGIN
    DECLARE @IName VARCHAR(500)
    SET   @IName=''
    if @StatusID = 1
    begin
        SELECT  @IName = @IName + ISNULL(c.CompanyName,'')+', ' FROM Company c,Seeline S WHERE c.Companyid=s.SeelineID and S.TargetID=@CompanyID
    end
    else
    begin
        SELECT  @IName = @IName + ISNULL(c.CompanyName,'')+', ' FROM Company c,Seeline S WHERE s.SeeLineID = @CompanyID and s.TargetID = c.CompanyID
    end
    RETURN ISNULL(@IName,'')
END


GO
