GO

/****** Object:  UserDefinedFunction [dbo].[ufn_GetAdOrderDetailGrossAmount]    Script Date: 01/29/2012 18:59:03 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ufn_GetAdOrderDetailGrossAmount]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ufn_GetAdOrderDetailGrossAmount]
GO

GO

/****** Object:  UserDefinedFunction [dbo].[ufn_GetAdOrderDetailGrossAmount]    Script Date: 01/29/2012 18:59:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[ufn_GetAdOrderDetailGrossAmount] (@AdOrderDetailsID int)
RETURNS MONEY
AS
BEGIN
DECLARE @GrossAmount MONEY
SELECT @GrossAmount = dbo.ufn_SplitArrayLength(dbo.GetSalesOrderRegion(AdOrderDetailsId,OrderType), ',') * isnull(Price,0) FROM AdOrderDetails(nolock)
WHERE AdOrderDetailsID = @AdOrderDetailsID

RETURN @GrossAmount
END


GO
