
/****** Object:  UserDefinedFunction [dbo].[GetSalesOrderCurrentEditionID]    Script Date: 04/05/2013 13:40:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetSalesOrderCurrentEditionID]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[GetSalesOrderCurrentEditionID]
GO

/****** Object:  UserDefinedFunction [dbo].[GetSalesOrderCurrentEditionID]    Script Date: 04/05/2013 13:40:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 --------------------------------------------------------------------------        
 -- Created By : Parameswar Mal      
 -- Created On : 28 Feb 2013      
 -- Description : Get the Current EditionID
 --  Modify On : 5th April 2013   
   -- Description : Get the earliest open edition in given region
 --------------------------------------------------------------------------      
 CREATE FUNCTION [dbo].[GetSalesOrderCurrentEditionID]        
(        
     @RegionID INT     
)        
    RETURNS INT        
AS        
BEGIN        
    DECLARE @ReturnEditionID INT     
    DECLARE @ReturnYear DATETIME    
  
	   SELECT TOP 1 @ReturnYear =  [Year],@ReturnEditionID= EditionID 
	   FROM Editions e, MstEditionStatus es    
	   WHERE e.StatusID = es.StatusID    
	   AND es.StatusID <> 2  --2 Completed
	   AND RegionId =@RegionID
	   ORDER BY PublicationDate ASC
	  
	   RETURN ISNULL(@ReturnEditionID,0)      

    END   
    
GO

