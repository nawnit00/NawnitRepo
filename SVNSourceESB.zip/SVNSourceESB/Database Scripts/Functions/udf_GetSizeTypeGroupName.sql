/****** Object:  UserDefinedFunction [dbo].[udf_GetSizeTypeGroupName]    Script Date: 11/09/2012 14:38:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udf_GetSizeTypeGroupName]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[udf_GetSizeTypeGroupName]
GO

-- =============================================
-- Author:		Marcus Ruether
-- Create date: 11/9/2012
-- Description:	The business wants some "grouping" applied.  
-- I made this function as I didn't think it was worth the effort to make new tables to support this.
-- =============================================
CREATE FUNCTION [dbo].[udf_GetSizeTypeGroupName]
(
	@SizeTypeName VARCHAR(100), -- SalesSizeType.Description
	@SizeTypeId INT, --SalesSizeType.SizeTypeId
	@SectionID INT --SalesSectionType.Sectionid
)
RETURNS VARCHAR(100)
AS
BEGIN

	RETURN CASE
		WHEN 
			(@SizeTypeId = 11 AND @SectionID IN(18,22))
			THEN 'Banner'
		WHEN
			(@SizeTypeId = 11) OR --if it was a banner, would be caught above
			(@SizeTypeId = 12) OR 
			(@SizeTypeId = 13) OR 
			(@SizeTypeId = 20) OR 
			(@SizeTypeId = 21) OR 
			(@SizeTypeId = 25) 
			THEN 'Core' 
		WHEN
			(@SizeTypeId = 14) OR 
			(@SizeTypeId = 17) OR 
			(@SizeTypeId = 18) OR 
			(@SizeTypeId = 19) OR 
			(@SizeTypeId = 22) OR 
			(@SizeTypeId = 28) OR 
			(@SizeTypeId = 29)
			THEN 'Website Part Number'
		ELSE @SizeTypeName END

END

GO


