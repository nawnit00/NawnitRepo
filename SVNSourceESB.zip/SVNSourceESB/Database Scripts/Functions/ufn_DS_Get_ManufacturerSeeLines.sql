/****** Object:  UserDefinedFunction [dbo].[ufn_DS_Get_ManufacturerSeeLines]    Script Date: 06/28/2012 08:45:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ufn_DS_Get_ManufacturerSeeLines]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ufn_DS_Get_ManufacturerSeeLines]
GO

/****** Object:  UserDefinedFunction [dbo].[ufn_DS_Get_ManufacturerSeeLines]    Script Date: 06/28/2012 08:45:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/************************************************************************************************************  
Created By    : Deepti Singh
Created Date  : 21th-Dec-2011
Description   : This Function returns Also Known As values
*************************************************************************************************************/          
CREATE FUNCTION [dbo].[ufn_DS_Get_ManufacturerSeeLines]
(
	@ManufacturerID	INT
)
RETURNS VARCHAR (max) AS
--declare @ManufacturerID	INT = 144948

BEGIN
	DECLARE @SeeLines varchar(max) = ''
	SELECT @SeeLines = 
		Stuff
		(
			(
				SELECT ',' + aka
				FROM   
				(
						SELECT DISTINCT AlsoKnownAs as aka
						FROM SourceESB.dbo.lm_seeline_manufacturer
						where CompanyID = @ManufacturerID
					union
						select distinct BookName1 as aka
						from SourceESB.dbo.lm_seeline_manufacturer
						where CompanyID = @ManufacturerID
							and BookName1 IS NOT NULL 
							AND len(BookName1) > 0
					union
						select distinct BookName2 as aka
						from SourceESB.dbo.lm_seeline_manufacturer
						where CompanyID = @ManufacturerID
							and BookName2 IS NOT NULL 
							AND len(BookName2) > 0
				) a

				ORDER BY aka
				For XML PATH ('')
			),1,1,''
		) 
		
	RETURN @SeeLines
END

GO


