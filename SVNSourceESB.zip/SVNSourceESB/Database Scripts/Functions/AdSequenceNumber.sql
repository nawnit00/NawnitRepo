GO

/****** Object:  UserDefinedFunction [dbo].[AdSequenceNumber]    Script Date: 07/24/2012 13:22:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AdSequenceNumber]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[AdSequenceNumber]
GO

/****** Object:  UserDefinedFunction [dbo].[AdSequenceNumber]    Script Date: 07/24/2012 13:22:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		Aatish Agarwal
-- Create date: June-18-2012
-- Description:	Returns a number which can be used for sequencing the ads.
-- =============================================
CREATE FUNCTION [dbo].[AdSequenceNumber] 
(
      @SectionCode char(10),
    @OrderType  char(1)    
)
RETURNS INT
AS
BEGIN

DECLARE @AdSequenceNumber INT

SELECT @AdSequenceNumber = (CASE WHEN @OrderType = 'O'
                                             THEN
                                                      CASE  WHEN @SectionCode = 'M' THEN 1
                                                                  WHEN @SectionCode = 'P' THEN 2
                                                                  WHEN @SectionCode = 'V' THEN 3
                                                                  WHEN @SectionCode = 'D' THEN 4
                                                                  WHEN @SectionCode = 'X' THEN 5
                                                                  WHEN @SectionCode = 'E' THEN 6
                                                                  ELSE 7
                                                                  END
                                                ELSE
                                                      CASE WHEN @OrderType = 'P'
                                                      THEN
                                                            CASE  WHEN @SectionCode = 'S' THEN 11
                                                                        WHEN @SectionCode = 'M' THEN 12
                                                                        WHEN @SectionCode = 'P' THEN 13
                                                                        WHEN @SectionCode = 'V' THEN 14
                                                                        WHEN @SectionCode = 'D' THEN 15
                                                                        ELSE 16
                                                                        END                     
                                                      END                                             
                                                END
                                          )
      RETURN @AdSequenceNumber
      
END




GO


