GO

/****** Object:  UserDefinedFunction [dbo].[ufn_SplitArrayLength]    Script Date: 01/30/2012 23:18:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ufn_SplitArrayLength]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ufn_SplitArrayLength]
GO


/****** Object:  UserDefinedFunction [dbo].[ufn_SplitArrayLength]    Script Date: 01/30/2012 23:18:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE FUNCTION [dbo].[ufn_SplitArrayLength]
(
    @String varchar(8000), @Delimiter char(1)
)
returns int
as
begin
    declare @idx int
    declare @slice varchar(8000)
    declare @length int
    set @length = 0

    select @idx = 1
        if len(@String)<1 or @String is null
        begin
                set @length = 1
                return   @length
        end

    while @idx!= 0
    begin
        set @idx = charindex(@Delimiter,@String)
        if @idx!=0
            set @slice = left(@String,@idx - 1)
        else
            set @slice = @String

        if(len(@slice)>0)
          Set @length = @length + 1

        set @String = right(@String,len(@String) - @idx)
        if len(@String) = 0 break
    end
return       @length
end


GO
