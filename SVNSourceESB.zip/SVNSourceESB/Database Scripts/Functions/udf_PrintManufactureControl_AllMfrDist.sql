GO

/****** Object:  UserDefinedFunction [dbo].[udf_PrintManufactureControl_AllMfrDist]    Script Date: 02/08/2013 21:44:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udf_PrintManufactureControl_AllMfrDist]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[udf_PrintManufactureControl_AllMfrDist]
GO


/****** Object:  UserDefinedFunction [dbo].[udf_PrintManufactureControl_AllMfrDist]    Script Date: 02/08/2013 21:44:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Lalbahadur Singh
-- Create date: 01-31-2013
-- Description:	For manufacture section,To get all distributors who are located or athorized or advertised in that edition
-- select * from dbo.udf_PrintManufactureControl_AllMfrDist(232)
-- =============================================
CREATE FUNCTION [dbo].[udf_PrintManufactureControl_AllMfrDist] 
(	
	@Edition INT
)
RETURNS @Tab1 TABLE 
(
	MfrId INT, MfrName VARCHAR(500),DistId INT,DistName VARCHAR(500), Products VARCHAR(MAX)
)
AS
BEGIN

DECLARE @ZoneID INT, @CountryID INT, @RegionID INT
	
	-- Get the Editionid and ZoneId for the input Edition e.g. 230, 3 for 230
	 SELECT @ZoneID=E.RegionID FROM Editions E (NOLOCK)
			WHERE E.EditionID=@Edition and E.AdjobTypeID='P' 

	-- Get the CountryId for that Zone e.g. 197
	 SELECT @CountryID=CountryID FROM CountryZones (NOLOCK)
			WHERE ZoneID=@ZoneID and isactive=1

	---- Get the CountryName and Region Id for that Country e.g. United States, 1
	 SELECT @RegionID=RegionID FROM Country (NOLOCK) 
			WHERE CountryID=@CountryID
        
	DECLARE @TempMfrs TABLE
	(
		CompanyID INT,
		CompanyName VARCHAR(500),
		Products VARCHAR(MAX)
	)
	
	DECLARE @TempFinal TABLE
	(
		CompanyID INT,
		CompanyName VARCHAR(500),
		MfrId INT
	)
	
	INSERT @TempMfrs (CompanyID,CompanyName,Products)  
	SELECT DISTINCT CT.CompanyID,CT.CompanyName,'' as Products 
		FROM Company CT   
		INNER JOIN CompanyTypeMapping CTM ON CTM.CompanyID=CT.CompanyID  
		INNER JOIN mstCompanyType M ON M.CompanyTypeID=CTM.CompanyTypeID and CHARINDEX('M',dbo.[Get_CompanyTypeName](CT.CompanyID)) >0 
		INNER JOIN MstCompanyStatus MS ON MS.CompanyStatusID=CT.CompanyStatusID and LOWER(LTRIM(RTRIM(MS.Description)))='active'  
		WHERE CT.isactive=1

	UPDATE @TempMfrs
	SET Products =  [dbo].[Get_ProductsByManufacturer](CompanyId)

	
	--Authorized distributors for Mfrs in that edition
	INSERT @TempFinal (CompanyID,CompanyName,MfrId)  
	SELECT DISTINCT CT.CompanyID,CT.CompanyName,MfrID as MfrId--,'' as Advertiser
      FROM Company CT  
      INNER JOIN MstCompanyStatus MS (NOLOCK)   ON MS.CompanyStatusID= CT.CompanyStatusID and LOWER(LTRIM(RTRIM(MS.Description)))='active'   
      INNER JOIN regionAuthorization RA (NOLOCK) ON RA.DistID = CT.CompanyID and RA.IsActive = 1 and RA.Publish = 1
      INNER JOIN  RegionZoneStatus RS WITH (NOLOCK) ON RS.mfrdistid = RA.mfrdistid AND RS.ZoneID = @ZoneID and RS.RegionID = @RegionID AND (RS.AuthStatusID = 4 or (RS.AuthStatusID = 2 and CT.Trusted_Disty = 1))
      INNER JOIN Company mfr  (NOLOCK) ON mfr.CompanyID = RA.mfrid
      INNER JOIN MstCompanyStatus MS_MFR (NOLOCK) ON MS_MFR.CompanyStatusID=mfr.CompanyStatusID AND LOWER(LTRIM(RTRIM(MS_MFR.DESCRIPTION))) = 'active' 

	UNION
	--Advertised for Mfrs in that edition
	SELECT DISTINCT AO.CompanyID, ADC.CompanyName,AOD.PositionTitle as MfrId--, ADC.CompanyName as Advertiser
		from AdOrderdetails AOD (NOLOCK)
		INNER join ADdetails AD (NOLOCK) on AD.adtypeid=AOD.ADtypeid and AD.Status=1
		inner join Adorder AO (NOLOCK) on AO.AdOrderid=AOD.AdOrderID and AO.StatusID IN (3,4,5)
		iNNER JOIN Salessectiontype SS (NOLOCK) on SS.SectionID=AD.SectionID and SS.Status=1
		INNER JOIN SalesSizetype SST (NOLOCK) on SST.AdjobTypeID='P' and SST.SizeTypeID=AOD.SizetypeId
        inner join company ADC (NOLOCK) on  ADC.companyId=AO.CompanyID and ADC.isactive=1 
        INNER join mstcompanystatus MCS on MCS.companystatusID=ADC.CompanyStatusID and LOWER(LTRIM(RTRIM(MCS.Description)))='active'
        inner Join AdorderdetailsregionEdition E (NOLOCK) on E.AdorderDetailsID=AOD.AdorderDetailsID and E.EditionID = @Edition-- and E.regionID=@ZoneID
        Where (ltrim(rtrim(SS.SectionCode))= 'M') and IsNull(AOD.positiontitle,'') <> ''
    
    UNION
        --distributors located in that edition
     SELECT DISTINCT CT.CompanyID,CT.CompanyName, mfr.CompanyId as MfrId 
      FROM Company CT   (NOLOCK)
            INNER JOIN MstCompanyStatus MS ON MS.CompanyStatusID=CT.CompanyStatusID AND LOWER(LTRIM(RTRIM(MS.Description)))='active'  AND CT.IsActive =1
            INNER JOIN CompanyLocations CL (NOLOCK) ON  CL.CompanyID=CT.CompanyID AND CL.Isactive=1 AND CL.LocationStatusId = 1 AND CL.DoNotPublishIndicator = 0 AND CL.CountryID=@CountryID
            INNER JOIN ZipCode ZC (NOLOCK) ON zc.ZoneID = @ZoneID AND CL.Zip >= ZC.ZipFrom AND CL.Zip <=ZC.ZipTo  AND ZC.CountryId = @CountryID 
            INNER JOIN mstlocationstatus MLS (NOLOCK) on MLS.locationstatusID=CL.locationStatusID AND MLS.isactive=1 AND LOWER(LTRIM(RTRIM(MLS.Description)))='active'
            INNER JOIN regionAuthorization RA  (NOLOCK) on RA.DistID = CT.CompanyID AND RA.IsActive =1 and RA.publish = 1
            INNER JOIn Company mfr              (NOLOCK)    ON mfr.CompanyID = RA.mfrid
            INNER JOIN MstCompanyStatus MS1     (NOLOCK)    ON MS1.CompanyStatusID=mfr.CompanyStatusID AND LOWER(LTRIM(RTRIM(MS1.DESCRIPTION))) = 'active'
            WHERE CHARINDEX('D',dbo.[Get_CompanyTypeName](CT.CompanyID)) > 0


	
	INSERT INTO @Tab1 SELECT TM.CompanyId as MfrId, TM.CompanyName as MfrName,TF.CompanyId as DistId, TF.CompanyName as DistName,
	Products--, 
	--[dbo].[CommSaparedPhoneFormatWithCountryName](TF.CompanyId,@ZoneID, @CountryID) AS Phone 
	FROM @TempMfrs TM
	INNER JOIN @TempFinal TF
	ON TM.CompanyId = TF.MfrId
	ORDER BY MfrName,DistName

	RETURN 
END





GO


