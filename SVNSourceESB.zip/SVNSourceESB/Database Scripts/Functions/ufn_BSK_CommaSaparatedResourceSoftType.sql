/****** Object:  UserDefinedFunction [dbo].[ufn_BSK_CommaSaparatedResourceSoftType]    Script Date: 08/28/2012 11:19:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ufn_BSK_CommaSaparatedResourceSoftType]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ufn_BSK_CommaSaparatedResourceSoftType]
GO

/****** Object:  UserDefinedFunction [dbo].[ufn_BSK_CommaSaparatedResourceSoftType]    Script Date: 08/28/2012 11:19:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[ufn_BSK_CommaSaparatedResourceSoftType]
( 
	@ID INT
)
RETURNS VARCHAR(MAX)
AS

--DECLARE @ID INT = 171628
BEGIN

	DECLARE @listStr VARCHAR(MAX)
	SELECT @listStr = COALESCE(@listStr+'|' ,'') + 
		(
			SELECT 
				CASE 
					WHEN LTRIM(RTRIM(ISNULL(pr.ProductResourcesTitle,' ')))='' 
						THEN 'Software and Tools' 
					ELSE LTRIM(RTRIM(ISNULL(pr.ProductResourcesTitle,' '))) 
				END
				+ '~' + LTRIM(RTRIM(ISNULL(pr.ProductResourcesLink,' ')))+'|' 
			FROM ProductResources pr 
			WHERE pr.ResourcesType='soft'
				AND pr.ProductId = @ID 
			FOR XML PATH (''))

	RETURN @listStr
--SELECT @listStr
END

GO


