/****** Object:  UserDefinedFunction [dbo].[CreateList]    Script Date: 04/10/2013 12:37:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CreateList]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CreateList]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[CreateList](@PartNumber varchar(150))
RETURNS VARCHAR(1000) AS

BEGIN
   DECLARE @DisList varchar(1000)

   SELECT @DisList = COALESCE(@DisList + ', ', '') + DistributorName
   FROM vw_DistributorPartsSearch
   WHERE PartNumber = @PartNumber

   RETURN @DisList
END
GO


