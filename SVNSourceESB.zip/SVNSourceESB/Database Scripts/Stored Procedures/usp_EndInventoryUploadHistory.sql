/****** Object:  StoredProcedure [dbo].[usp_EndInventoryUploadHistory]    Script Date: 11/21/2012 14:37:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_EndInventoryUploadHistory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_EndInventoryUploadHistory]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_EndInventoryUploadHistory]
	@InventoryUploadHistoryId int,
	@MappingId int,
	@FileType varchar(50)
AS

--DECLARE	@InventoryUploadHistoryId INT = 18181, @MappingId INT = 18180, @FileType varchar(50) = '.csv'

BEGIN
	DECLARE @Errors VARCHAR(MAX) = '';

	UPDATE [InventoryUploadHistory]
		   SET 
			MappingId = @MappingId,
			FileType = @FileType
	WHERE InventoryUploadHistoryId = @InventoryUploadHistoryId;
    
	DECLARE @file_line_cnt INT = 0
	SELECT @file_line_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'FileLineCount';

	UPDATE h
	SET FileLineCount = @file_line_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
    
	DECLARE @upload_cnt INT = 0
	SELECT @upload_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'BulkInsertCount';

	UPDATE h
	SET FileInventoryCount = @upload_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @invalid_part_num_cnt INT = 0
	SELECT @invalid_part_num_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'InvalidPartNumberFieldCount';

	UPDATE h
	SET InvalidPartNumberFieldCount = @invalid_part_num_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId

	DECLARE @invalid_cnt INT = 0
	SELECT @invalid_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'InvalidQtyFieldCount';

	UPDATE h
	SET InvalidQtyFieldCount = @invalid_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId

	DECLARE @zero_qty_cnt INT = 0
	SELECT @zero_qty_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'ZeroQtyFieldCount';

	UPDATE h
	SET ZeroQtyFieldCount = @zero_qty_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId

	DECLARE @invalid_price_break_cnt INT = 0
	SELECT @invalid_price_break_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'InvalidPriceBreakFieldCount';

	UPDATE h
	SET InvalidPriceBreakFieldCount = @invalid_price_break_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @over_limit_cnt INT = 0
	SELECT @over_limit_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'OverLimitCount';

	UPDATE h
	SET OverLimitCount = @over_limit_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @duplicate_cnt INT = 0
	SELECT @duplicate_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'DuplicateRecordCount';

	UPDATE h
	SET DuplicateCount = @duplicate_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @updated_cnt INT = 0
	SELECT @updated_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'UpdatedCount';

	UPDATE h
	SET UpdatedCount = @updated_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @inserted_cnt INT = 0
	SELECT @inserted_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'InsertedCount';

	UPDATE h
	SET InsertedCount = @inserted_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @start DATETIME
	SELECT @start = MAX(CAST(tl.Message AS DATETIME))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId 
		AND tl.[Name] = 'Inventory Load Started';

	DECLARE @end DATETIME
	SELECT @end = MAX(CAST(tl.Message AS DATETIME))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId 
		AND tl.[Name] = 'Inventory Load Completed';

	UPDATE h
	SET ProcessTime = CONVERT(varchar,(@end - @start), 108)
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId

	SELECT 
		@Errors = COALESCE(@Errors + ', ', '') + [Message] 
	FROM
		InventoryUploadHistoryTraceLog
	WHERE	
		InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		IsError = 1
		
	IF LEN(@Errors) > 0
		BEGIN
			UPDATE [InventoryUploadHistory]
			SET 
				ErrorMessage = SUBSTRING(@Errors, 1, 8000),
				HasError = 1
			WHERE 
				InventoryUploadHistoryId = @InventoryUploadHistoryId;
		END
    
    
END

GO
