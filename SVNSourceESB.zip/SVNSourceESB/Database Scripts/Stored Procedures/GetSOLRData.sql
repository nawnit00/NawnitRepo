/****** Object:  StoredProcedure [dbo].[GetSOLRData]    Script Date: 02/26/2013 15:39:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetSOLRData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetSOLRData]
GO

CREATE PROCEDURE [dbo].[GetSOLRData] 
AS

BEGIN
	SELECT
	DPS.ID as Id, 
	DPS.PartNumber+'~'+CONVERT(varchar(10), DPS.ManufacturerId) as PartMfrId, 
	--DPS.PartNumber +  ' ' + ISNULL(DPS.ManufacturerName,'') as SearchTerm,
	DPS.ProductID As ProductID,
	DPS.PartNumber,
	DPS.Search_PartNumber,
	DPS.Search_MFR_Name,
	DPS.ManufacturerName,
	DPS.ManufacturerId,
	DPS.DistributorName,
	DPS.DistributorId,
	ISNULL(DPS.PartDescription, '') AS ProductDescription,
	DPS.ManufacturerCode As DistManufacturerCode,
	ISNULL(CONVERT(FLOAT, DPS.Price),0) AS PartPrice,
	ISNULL(CONVERT(FLOAT, DPS.PartQuantity),0) AS PartQuantity,
	ISNULL(DPS.QOHDisp,'') AS QOHDisp,
	DPS.PartUploadDate,
	ISNULL(DPS.PartDataSheet, '') as PartDataSheet,
	ISNULL(DPS.DatasheetLink, '') as PartDataSheetLink,
	DPS.PartSample,
	ISNULL(DPS.VideoFilePathLink, '') as VideoFilePathLink,
	ISNULL(DPS.ImageFilePathLink, '') as ImageFilePathLink,
	DPS.ProductTypeId,
	DPS.ProductTypeDesc as ProductType,
	DPS.ROHS,
	DPS.RFQCPID,
	DPS.Buy_Button,
	DPS.HasMfrLogoAd,
	ISNULL(SUBSTRING( (SELECT '| ' + PR.ProductResourcesTitle from ProductResources PR (NOLOCK) where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1 and PR.ResourcesType = 'APP' for XML Path ('')),3, 2000),'') as PartAppNotes,
	ISNULL(SUBSTRING( (SELECT '| ' + PR.ProductResourcesLink from ProductResources PR (NOLOCK)  where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1 and PR.ResourcesType = 'APP' for XML Path ('')),3, 2000),'') as PartAppNotesLink,
	ISNULL(SUBSTRING( (SELECT '| ' + PR.ProductResourcesTitle from ProductResources PR (NOLOCK) where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1 and PR.ResourcesType = 'Soft' for XML Path ('')),3, 2000),'') as PartSoftTool,
	ISNULL(SUBSTRING( (SELECT '| ' + PR.ProductResourcesLink from ProductResources PR (NOLOCK)  where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1 and PR.ResourcesType = 'Soft' for XML Path ('')),3, 2000),'') as PartSoftToolLink,
	ISNULL(UF.FavType, 0) As SolrMyFav,
	ISNULL(UF.UserID, 0) as UserID,
	DistLogo = Case When DPS.DistLogo IS null Then '' Else DPS.DistLogo End,
	DPS.CompanyLogo As CompanyLogo,
	DPS.DistributorPartID,
	CONVERT(Varchar(20), DPS.ManufacturerId)+'~'+ISNULL(DPS.ManufacturerName, 'MfrNotFound') AS Facet_Manufacturer,
	CONVERT(Varchar(20), DPS.ProductTypeId)+'~'+ISNULL(DPS.ProductTypeDesc,'ProductTypeNotFound') as Facet_ProductType,
	CONVERT(Varchar(20), DPS.DistributorId)+'~'+DPS.DistributorName as Facet_Distributor,
	ISNULL(RZS.MaxAuth, 0) as MaxAuth,

	(
	  Select cast(RegionID as varchar(15))+','
	From [dbo].[RegionAuthorization] reg_auth (nolock)
	inner join [dbo].[RegionZoneStatus] reg_zone_status (nolock) 
	on reg_zone_status.MfrDistID =  reg_auth.MfrDistID
	where reg_auth.MfrID = DPS.ManufacturerId
	and reg_auth.DistID = DPS.DistributorId
	group by reg_zone_status.MfrDistID,reg_zone_status.RegionID
	  For XML Path('') ) as RegionAuth,

	(
	  Select cast(COM_OWN.OwnershipID as varchar(15))+','
	from CompanyOwnerShipMapping COM_OWN (NOLOCK) 
	Where COM_OWN.CompanyID = DPS.DistributorId
	  For XML Path('') ) as CompanyOwnershipID,
	  
	   (
	  Select cast(C.RegionID as varchar(15))+','
	From CompanyLocations CL (nolock)
	inner join Country C (nolock)
	on C.CountryID = CL.CountryID
	where CL.CompanyID = DPS.DistributorId and LocationStatusID = 1 and CL.IsActive = 1
	group by CompanyID,C.RegionID
	  For XML Path('') ) as CountryRegionID,
	(
		Select cast(Spend.RegionID as varchar(15))+','
		From [dbo].[RegionAuthorization] reg_auth (nolock)
		left join (
			Select MfrID,DistID,RegionID,sum(Print_Amount+Online_Amount) as Total
			From [dbo].[DistMfrSpend] (nolock)
			group By MfrID,DistID,RegionID
			) as Spend
		ON reg_auth.MfrID = Spend.MfrID AND reg_auth.DistID = Spend.DistID 
		where 
		reg_auth.MfrID = DPS.ManufacturerId
		and reg_auth.DistID = DPS.DistributorId
		For XML Path('') ) as RegionSpend,

	(
	  Select cast(COM_OWN.OwnershipID as varchar(15))+','
	from CompanyOwnerShipMapping COM_OWN (NOLOCK) 
	Where COM_OWN.CompanyID = DPS.DistributorId
	  For XML Path('') ) as CompanyOwn,
	DPS.IsManufacturerProduct,
	ISNULL(DPS.ManufacturerSpend, 0) AS ManufacturerSpend
	From vw_DistributorPartsSearch AS DPS (NOLOCK) 
	Left Join RegionAuthorization RA (NOLOCK) ON RA.IsActive = 1 and RA.Publish = 1 and DPS.DistributorId = RA.DistID and DPS.ManufacturerId = RA.MfrID
	Left Join (            Select
							RZOS.MFRDistID,
						   MAX(case when (AuthStatusID  = 2 and C.Trusted_Disty=1) then 4 else AuthStatusID end) as MaxAuth,
							sum(Print_Amount+Online_Amount) as Total
						From
							RegionZoneStatus (nolock) RZOS,
							Company (nolock) C,
							RegionAuthorization (nolock) RA
						WHERE  RA.MfrDistID = RZOS.MfrDistID
							AND RA.DistID=C.CompanyID
						group By RZOS.MfrDistID)        as RZS ON RA.MfrDistID = RZS.MfrDistID
	Left Join UserFavorites UF (NOLOCK) ON UF.FavType = 3 and DPS.ProductId = UF.TypeID 
END

GO
