/****** Object:  StoredProcedure [dbo].[ReloadDistributorPartsClean]    Script Date: 01/18/2013 22:51:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReloadDistributorPartsClean]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[ReloadDistributorPartsClean]
GO

