/****** Object:  StoredProcedure [dbo].[usp_AddInventoryUploadHistory]    Script Date: 10/19/2012 10:00:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_AddInventoryUploadHistory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_AddInventoryUploadHistory]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Keeps track of when inventory was uploaded, and if there were any problems with the upload process.

Used by: 
InventoryUpload/InventoryUpload.cs

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
09.09.2012		Marcus Ruether		Created. 
MM.DD.YYYY		<developer name>		<Changes made.> 
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[usp_AddInventoryUploadHistory]
	@CompanyId int,
	@Vector varchar(5)
AS
BEGIN
	INSERT INTO [InventoryUploadHistory]
		   ([CompanyId]
		   ,[Vector]
		   ,[UploadDate])
	 VALUES
		   (@CompanyId
		   ,@Vector
		   ,GETDATE())
           
	 SELECT @@Identity
END

GO
