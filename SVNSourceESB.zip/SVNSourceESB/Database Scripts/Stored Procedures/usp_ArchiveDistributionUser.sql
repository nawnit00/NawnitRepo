/****** Object:  StoredProcedure [dbo].[usp_ArchiveDistributionUser]    Script Date: 02/21/2013 15:17:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_ArchiveDistributionUser]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_ArchiveDistributionUser]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_ArchiveDistributionUser]
AS
BEGIN

	SET IDENTITY_INSERT User_Archive ON

	INSERT INTO User_Archive
	(
		UserID,LoginName,LoginPassword,FirstName,LastName,IsActive,
		UserRegID,UserRecommendFlag,UserJobFunctionID,UserIndustryTypeID,
		Title,UserApprovalLevelID,PrimarySource,CreatedBy,CreatedOn,
		UpdatedBy,UpdatedOn,SalesPersonCode,SalesManagerID,Contact_ID,
		MigratedFrom,LastLogin
	)

	SELECT 
		UserID,LoginName,LoginPassword,FirstName,LastName,IsActive,
		UserRegID,UserRecommendFlag,UserJobFunctionID,UserIndustryTypeID,
		Title,UserApprovalLevelID,PrimarySource,CreatedBy,CreatedOn,
		UpdatedBy,UpdatedOn,SalesPersonCode,SalesManagerID,Contact_ID,
		MigratedFrom,LastLogin
	FROM [User] u
	WHERE u.FirstName = 'Distribution'
	AND u.UserID NOT IN
	(
		SELECT u.UserID
		FROM [User] u
		INNER JOIN UserRole ur
		ON u.UserID = ur.UserID
		INNER JOIN MstRole r
		ON ur.RoleID = r.RoleID
		AND r.RoleName = 'Company Admin'
		INNER JOIN UserContact uc
		ON u.UserID = uc.UserID
		INNER JOIN Company C
		ON uc.CompanyName = C.CompanyName
		WHERE u.FirstName = 'Distribution'
		GROUP BY u.UserID
	)

	SET IDENTITY_INSERT User_Archive OFF

	DELETE u
	FROM [User] u
	INNER JOIN User_Archive ua
		ON u.UserID = ua.UserID
END
GO
