/****** Object:  StoredProcedure [dbo].[usp_DeleteMfrRegionStatus]    Script Date: 01/17/2013 17:36:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_DeleteMfrRegionStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_DeleteMfrRegionStatus]
GO

-- Created By: Fathima
-- Created On: 16-11-2011
-- Purpose: Deleteing zone status and region auth thro line card page.
-- Sample: usp_DeleteMfrRegionStatus 130237,'144863'

CREATE proc [dbo].[usp_DeleteMfrRegionStatus](
	@DistId int,
	@MfrList varchar(500),
	@DeletedBy INT
)
as

-- Set Context to userId - used by change tracking trigger
SET CONTEXT_INFO @DeletedBy;

declare @str varchar(1000)

Begin Transaction
set @str = 'select DistId,MfrDistID into #tmp from RegionAuthorization where DistID = ' + cast(@DistId as varchar) + ' and MfrID in ( ' + @MfrList + ')'

set @str = @str + ' delete from RegionZoneStatus where MfrDistID in(select MfrDistID from #tmp)'
set @str = @str + ' delete from RegionAuthorization where MfrDistID in(select MfrDistID from #tmp)'

set @str = @str + 'DELETE FROM CompanyProductType   
WHERE CompanyID='+ cast(@DistId as varchar) + ' and ProductTypeId not in  
(select distinct(ProductTypeId) from CompanyProductType where companyid in  
(select mfrid from regionauthorization where distid=' + cast(@DistId as varchar) +')) '
exec(@str)

Commit Transaction
IF @@Error <> 0 
BEGIN 
ROLLBACK TRANSACTION 
RETURN @@Error 
END

GO

