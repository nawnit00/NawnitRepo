GO
/****** Object:  StoredProcedure [dbo].[usp_Export_Web_Log_Data]    Script Date: 12/12/2012 18:28:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Export_Web_Log_Data]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Export_Web_Log_Data]
GO

/****** Object:  StoredProcedure [dbo].[usp_Export_Web_Log_Data]    Script Date: 12/12/2012 18:28:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Lalit Mehta
-- Create date: Dec 12, 2012
-- Description:	Move data from WEB_LOG table to WEB_LOG_ARCHIVE table 
-- =============================================
CREATE PROCEDURE [dbo].[usp_Export_Web_Log_Data] 
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;
    insert into [dbo].[Web_Log_Archive](
      [Wplk_ID]
      ,[Log_Message]
      ,[Log_Timestamp]
      ,[Usr_ID]
      ,[Session_ID]
      ,[Region_ID]
      ,[Distributor_ID]
      ,[Manufacturer_ID]
      ,[Product_ID]
      ,[Product_Classification_ID]
      ,[Search_Name]
      ,[Search_Type]
      ,[Search_String]
      ,[Page_Number]
      ,[Page_Position]
      ,[List_By]
      ,[Vendor_Service_ID]
      ,[Vendor_ID]
      ,[Sort_By]
      ,[Result_Count]
      ,[User_Agent_Id]
      ,[REMOTE_ADDRESS]
      ,[City]
      ,[State]
      ,[Zip]
      ,[Country]
      ,[PRODUCT_NUMBER]
      ,[FILTER_BY])
SELECT [Wplk_ID]
      ,[Log_Message]
      ,[Log_Timestamp]
      ,[Usr_ID]
      ,[Session_ID]
      ,[Region_ID]
      ,[Distributor_ID]
      ,[Manufacturer_ID]
      ,[Product_ID]
      ,[Product_Classification_ID]
      ,[Search_Name]
      ,[Search_Type]
      ,[Search_String]
      ,[Page_Number]
      ,[Page_Position]
      ,[List_By]
      ,[Vendor_Service_ID]
      ,[Vendor_ID]
      ,[Sort_By]
      ,[Result_Count]
      ,[User_Agent_Id]
      ,[REMOTE_ADDRESS]
      ,[City]
      ,[State]
      ,[Zip]
      ,[Country]
      ,[PRODUCT_NUMBER]
      ,[FILTER_BY]
  FROM [dbo].[Web_Log]
  truncate table [dbo].[Web_Log]
END

GO
