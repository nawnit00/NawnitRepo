/****** Object:  StoredProcedure [dbo].[usp_SetUserLastLogin]    Script Date: 02/20/2013 13:12:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SetUserLastLogin]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_SetUserLastLogin]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_SetUserLastLogin]                    
	 @UserID INT
AS    
BEGIN

	UPDATE [User]
	SET LastLogin = GetDate()
	WHERE UserID = @UserID
			
END

GO
