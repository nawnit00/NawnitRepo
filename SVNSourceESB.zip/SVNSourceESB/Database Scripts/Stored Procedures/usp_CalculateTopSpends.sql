/****** Object:  StoredProcedure [dbo].[usp_CalculateTopSpends]    Script Date: 08/07/2012 17:37:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_CalculateTopSpends]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_CalculateTopSpends]
GO
/****** Object:  StoredProcedure [dbo].[usp_CalculateTopSpends]    Script Date: 08/07/2012 17:37:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================  
-- Author:  
-- Create date: 
-- Description: 
-- usp_CalculateTopSpends  
-- =============================================  
CREATE PROCEDURE [dbo].[usp_CalculateTopSpends]   
AS  
BEGIN  
   
 SET NOCOUNT ON;  
   
 TRUNCATE TABLE MFRSPEND   
 TRUNCATE TABLE DISTVENDORSPEND    
   
--========================================================================
-- MFR Section   
--========================================================================
  
 SELECT c.CompanyID AS MFRID,AOD.Price AS AMOUNT  into #mfrtemp 
 FROM AdOrder AO,  AdOrderDetails AOD, Company C, CompanyTypeMapping CT  
 WHERE   
 AO.AdOrderId = AOD.AdOrderId  
 AND AOD.PositionTitle = c.CompanyID  
 AND CT.CompanyID = C.CompanyID  
 AND CT.CompanyTypeID =1  
 AND AO.StatusId IN (3,4,5)  
AND  
(  
 AOD.OrderType in('P')  
 OR   
 (  
  AOD.OrderType in('O')  
  AND aod.ActivationDate <= GETDATE()  
  AND GETDATE()<=DATEADD(MM,AOD.Duration,AOD.ActivationDate)  
 )  
)   
 AND AO.OrderDate >  DATEADD(YEAR, -1,DATEADD(mm, DATEDIFF(mm, 0, GETDATE()), 0))   
 And C.IsActive = 1  

 
SELECT Distinct MFRID,sum(AMOUNT)as TotalAmount into #mfrtemp2 from #mfrtemp
GROUP BY MFRID
        
-- inserting values in DistPartsSpend table -- 
INSERT INTO [dbo].MFRSPEND(MfrID,AmountSpent) SELECT TOP 10 MFRID,TotalAmount FROM #mfrtemp2
ORDER BY TotalAmount DESC
    
DROP TABLE #mfrtemp 
DROP TABLE #mfrtemp2 
 
   

--=================================================================  
--   Distributor & Vendors (2: Distributor, 3: Vendors)   
--=================================================================  
  
SELECT  
  AO.CompanyId,  
  AOD.Price AS TotalAmount into #tmp1  
  FROM  
  AdOrder ao, AdOrderDetails aod,  
  Company C  
  WHERE  
        AO.AdOrderId = AOD.AdOrderId  
        And C.IsActive = 1 
        AND AO.CompanyId = C.CompanyID
        AND c.CompanyID in (SELECT Distinct ctm.CompanyID FROM Company com,CompanyTypeMapping ctm WHERE com.CompanyID = ctm.CompanyID AND ctm.CompanyTypeID in (2,3))  
        AND AO.StatusId in (3,4,5)  
        AND  
        (AOD.OrderType = 'P' OR (AOD.OrderType ='O'    
			AND aod.ActivationDate <= GETDATE()  
			AND GETDATE()<=DATEADD(MM,aod.Duration,aod.ActivationDate)  
			)  
		)  
        AND AO.OrderDate >  DATEADD(YEAR, -1,DATEADD(mm, DATEDIFF(mm, 0, GETDATE()), 0))  
 
        
	
	SELECT Distinct CompanyId,sum(TotalAmount)as TotalAmount into #tmp2 from #tmp1
    GROUP BY CompanyId
        
    -- inserting values in DistPartsSpend table -- 
    INSERT INTO [dbo].DISTVENDORSPEND(DistId,AmountSpent) SELECT TOP 10 CompanyId,TotalAmount FROM #tmp2
    ORDER BY TotalAmount DESC
    
    DROP TABLE #tmp1 
    DROP TABLE #tmp2 
    
        
  
   
END  

GO


