GO

/****** Object:  StoredProcedure [dbo].[usp_BSK_getSearchResultDesignResource_Count]    Script Date: 06/01/2012 14:08:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_BSK_getSearchResultDesignResource_Count]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_BSK_getSearchResultDesignResource_Count]
GO


/****** Object:  StoredProcedure [dbo].[usp_BSK_getSearchResultDesignResource_Count]    Script Date: 06/01/2012 14:08:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [dbo].[usp_BSK_getSearchResultDesignResource_Count]
    @SearchText	 VARCHAR(80),
	@ManufacturerIDs VARCHAR(MAX) = ''
AS

BEGIN

    DECLARE @IsEmptyManufacturerID VARCHAR(1) = '0'

    set transaction isolation level read uncommitted

	DECLARE @tmpSearchText TABLE
	(
		search_text varchar(200)
	)

	INSERT INTO @tmpSearchText
	SELECT array_data 
	FROM dbo.ReturnArray(@SearchText, ' ', NULL)

    IF(@ManufacturerIDs='')
    BEGIN
        SET @IsEmptyManufacturerID = 1
    END

	DECLARE @tmpManufacturer TABLE
	(
		manufacturer_id INT
	)

	INSERT INTO @tmpManufacturer
	SELECT array_data 
	FROM dbo.ReturnArray(@ManufacturerIDs, ',', NULL)



SELECT  COUNT(DISTINCT pd.ProductID)
    FROM
    (
		select distinct ProductID,ManufacturerID,SampleUrl,VideoFilePath,DataSheet,ImageFilePath,
			CASE WHEN ISNULL(DataSheet,'') <> '' 
				THEN DataSheet 
			ELSE
				CASE WHEN ISNULL(inv.MafSpecURL,'') <> '' 
					THEN inv.MafSpecURL 
				END 
			END AS DataSheetLink,
			(select 1 where exists(select count(ProductResourcesId) from ProductResources pr where pr.ResourcesType in ('app', 'soft') and pr.ProductId = product.ProductID group by pr.ProductId))as App_OR_Soft_Exists
		from product (nolock)
		inner join @tmpSearchText as tmp
			on Clean_PartNumber LIKE ('%' + tmp.search_text + '%')
		LEFT JOIN [dbo].[InventorySettings] inv 
			ON inv.CompanyID=ManufacturerID
	) as pd
	INNER JOIN [dbo].[Company] comp
		ON pd.ManufacturerID=comp.CompanyID
	LEFT OUTER JOIN @tmpManufacturer as tmp
		on comp.CompanyID = tmp.manufacturer_id
	WHERE comp.IsActive = '1'
		AND comp.CompanyStatusID='1'
		AND (tmp.manufacturer_id IS NOT NULL 
		 OR  @IsEmptyManufacturerID = '1'
		)
		AND (ISNULL(pd.SampleUrl, '') <> '' 
		 OR  ISNULL(pd.VideoFilePath,'') <> '' 
		 OR  ISNULL(pd.DataSheetLink,'') <> '' 
		 OR  ISNULL(pd.ImageFilePath,'') <> ''
		 OR  ISNULL(pd.App_OR_Soft_Exists,'') <> '' 
		)
END

GO


