GO

/****** Object:  StoredProcedure [dbo].[GetPreviousDayRFQs]    Script Date: 02/08/2013 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetPreviousDayRFQs]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetPreviousDayRFQs]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
		 
CREATE PROCEDURE [dbo].[GetPreviousDayRFQs]

AS
BEGIN

UPDATE RFQDetail SET ErrorMessage = ''  WHERE ErrorMessage = 'test'

SELECT rfq.RFQID, rfq.PartNumber, rfq.ManufacturerID, rfq.ManufacturerName, rfqdet.RFQDetailID, rfqdet.DistributorID, co.CompanyName, rfqdet.DistributorEmail, rfq.QuantityRequested, 
rfq.TargetPrice, rfq.CreatedBy, rfq.CreatedOn, rfq.IS_EXTERNAL, rfq.FirstName, rfq.LastName, rfq.Email, rfq.Company, rfqdet.ErrorMessage 
FROM RFQ rfq left Join
RFQDetail rfqdet ON rfqdet.RFQID = rfq.RFQID inner join
Company co on rfqdet.DistributorID = co.CompanyID
WHERE rfq.CreatedOn < CONVERT(VARCHAR(10), GETDATE(), 101) AND 
rfq.CreatedOn  > CONVERT(VARCHAR(10), DATEADD(d, -2, GETDATE()), 101) 

END
GO