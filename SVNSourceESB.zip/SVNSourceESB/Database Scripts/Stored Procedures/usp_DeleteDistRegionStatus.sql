USE [SourceESB]
GO
/****** Object:  StoredProcedure [dbo].[usp_DeleteDistRegionStatus]    Script Date: 12/07/2011 19:03:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_DeleteDistRegionStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_DeleteDistRegionStatus]
GO
/****** Object:  StoredProcedure [dbo].[usp_DeleteDistRegionStatus]    Script Date: 12/07/2011 19:03:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_DeleteDistRegionStatus]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- Created By: Fathima  
-- Created On: 05-12-2011  
-- Purpose: Deleteing zone status and region auth thro Distributor page.  
-- Sample: usp_DeleteDistRegionStatus 130237,''144863''  
  
CREATE proc [dbo].[usp_DeleteDistRegionStatus](@MfrId int,@DistList varchar(500))  
as  
declare @str varchar(1000)  
  
Begin Transaction  
set @str = ''select DistId,MfrDistID into #tmp from RegionAuthorization where MfrID = '' + cast(@MfrId as varchar) + '' and DistID in ( '' + @DistList + '')''  
  
set @str = @str + '' delete from RegionZoneStatus where MfrDistID in(select MfrDistID from #tmp)''  
set @str = @str + '' delete from RegionAuthorization where MfrDistID in(select MfrDistID from #tmp)''  
  
set @str = @str + ''DELETE FROM CompanyProductType     
WHERE CompanyID in (''+ @DistList + '') and ProductTypeId not in    
(select distinct(ProductTypeId) from CompanyProductType where companyid in    
(select mfrid from regionauthorization where distid in ('' + @DistList +''))) ''  
exec(@str)  
  
Commit Transaction  
IF @@Error <> 0   
BEGIN   
ROLLBACK TRANSACTION   
RETURN @@Error   
END  ' 
END
GO
