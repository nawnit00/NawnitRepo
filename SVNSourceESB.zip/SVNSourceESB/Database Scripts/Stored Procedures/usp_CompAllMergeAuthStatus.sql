USE [SourceESB]
GO

/****** Object:  StoredProcedure [dbo].[usp_CompAllMergeAuthStatus]    Script Date: 01/15/2013 21:56:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_CompAllMergeAuthStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_CompAllMergeAuthStatus]
GO

USE [SourceESB]
GO

/****** Object:  StoredProcedure [dbo].[usp_CompAllMergeAuthStatus]    Script Date: 01/15/2013 21:56:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


		/************************************************************************************************************    
		Created By    : LB Singh  
		Created Date  : 20-JUN-2012  
		Description   : Merging authorization status for distributors   
		-- Lalbahadur on 12/18/2012 to update active flag for exiting products when inserting new products
		-- Marcus Ruether on 1/15/2013 - Added MergedBy and set into CONTEXT_INFO so we have 
		*************************************************************************************************************/   
		CREATE proc [dbo].[usp_CompAllMergeAuthStatus]
		(
			@xmlCompIds varchar(max),
			@TargetCompanyId INT,
			@TargetCompName varchar(1000),
			@MergedBy INT
		)
		as
		 begin
		 SET NOCOUNT ON
		 
		 SET CONTEXT_INFO @MergedBy;
		 
		--declare @xmlCompIds varchar(max)
		--set @xmlCompIds = '<NewDataSet>
		--  <MergeComp>
		--	<Id>1</Id>
		--    <CompId>144855</CompId>
		--  </MergeComp>
		--   <MergeComp>
		--   <Id>2</Id>
		--    <CompId>144856</CompId>
		--  </MergeComp>
		--</NewDataSet>'

			DECLARE @l_index1 INT 
			declare @CompType varchar(10)
			declare @MExists     int
			declare @DExists     int
			declare @id int
			declare @nextId int
			declare @indx int
			declare @icount int
			declare @Sdist int
			declare @Sregionid int
			declare @Szoneid int
			declare @SAuthStatus int
			declare @SMfrId int
			declare @MfrDistId int
			declare @Tzoneid int
			declare @FinalIsUpdated bit
			declare @TAuthStatus int
			declare @IdunMached int
			declare @TempAuthStatus int
			
			declare @SAuthDate datetime
			declare @SDeniedDate datetime
			declare @TAuthDate datetime
			declare @TDeniedDate datetime
			declare @tempAuthDate datetime
			declare @tempDenyDate datetime
			declare @tempStatus datetime
		
		create table #TempProds
		(
			CompanyId int, 
			ProductTypeID int,
			--IsActive bit,
			--CreatedBy int,
			--CreatedOn datetime,
			CompanyName varchar(1000)
		)
		create table #FinalRegionZoneStatus
		(
			ID int identity(1,1), 
			MfrDistId int,
			MfrId int,
			DistId int,
			RegionId int,
			ZoneId int,
			AuthStatus int,
			Authorized_Date datetime,
			Denied_Date datetime
		)
		  
			create table #tmp  
			(  
				Id int,  
				CompId int  
			)  
			  
			 EXECUTE sp_xml_preparedocument @l_index1 OUTPUT, @xmlCompIds  
			  
			INSERT INTO #tmp (Id,CompId)  
			SELECT
				Id,  
				CompId  
			FROM OPENXML(@l_index1, 'NewDataSet/MergeComp', 2)  
				WITH  
				(Id int, CompId int)  
			  
			EXECUTE sp_xml_removedocument @l_index1  
				
			select @CompType=[dbo].[Get_CompanyTypeName](@TargetCompanyId)
		        
			SET @MExists = CHARINDEX('M', @CompType)
			SET @DExists = CHARINDEX('D', @CompType)
		    
			IF(@DExists >0)
			  BEGIN
			   print '-------Started: Process to merge auth status for companies of ''D'' Type-----------------'
		       		  
				SELECT * into #temp1 from #tmp 
				  
				IF (select COUNT(1) from #temp1)>1
				   begin
					while((select COUNT(1) from #temp1)>0)
					begin
						select top 1 @id = CompId from #temp1 order by Id
						
						select top 1 @nextId = d.CompId from (
						select top 2 Id,CompId from #temp1 order by Id
						) d
						order by id desc
						
						if @nextId != @id
						begin
							set @indx = 1
							
							--Source Table
							SELECT DISTINCT IDENTITY(int,1, 1) as ID,RA.mfrdistid,RA.mfrid, RA.distid, RS.AuthStatusID, RS.ZoneID, RS.RegionID,RS.Authorized_Date,RS.Denied_Date 
							into #temp1Source
							FROM 
							( select compid from #temp1
							)TMP  
							INNER JOIN dbo.RegionAuthorization RA ON RA.DistID = TMP.CompId
							INNER JOIN dbo.RegionZoneStatus RS ON RA.MfrDistID = RS.MfrDistID 
							WHERE  CHARINDEX('D',[dbo].[Get_CompanyTypeName](TMP.CompId)) > 0 AND RA.DistID = @id
							
							--Target Table
							SELECT DISTINCT IDENTITY(int,1, 1) as ID, RA.mfrdistid,RA.mfrid, RA.distid,RS.AuthStatusID, RS.ZoneID, RS.RegionID,RS.Authorized_Date,RS.Denied_Date  
							INTO #temp1Target
							FROM 
							( select compid from #temp1
							)TMP  
							INNER JOIN dbo.RegionAuthorization RA ON RA.DistID = TMP.CompId
							INNER JOIN dbo.RegionZoneStatus RS ON RA.MfrDistID = RS.MfrDistID 
							WHERE  CHARINDEX('D',[dbo].[Get_CompanyTypeName](TMP.CompId)) > 0 AND RA.DistID = @nextId
												
							select @icount = COUNT(1) from #temp1Source where MfrID = @id
							
							while(@indx <= @icount)
							begin
								set @Sdist = -1
								set @Sregionid = -1
								set @Szoneid = -1
								set @SAuthStatus = -1
								set @TAuthStatus = -1
								set @SAuthDate  = null
								set @SDeniedDate = null
								set @TAuthDate = null
								set @TDeniedDate = null
								set @tempAuthDate = null
								set @tempDenyDate = null
								select @Sdist = distid,@Sregionid = regionid,@Szoneid = zoneid, @SAuthStatus = AuthStatusID,@SMfrId = MfrID, @MfrDistId = MfrDistID,@SAuthDate=Authorized_Date,@SDeniedDate=Denied_Date  from #temp1Source where ID = @indx
								select @TAuthStatus = AuthStatusID,@TAuthDate=Authorized_Date,@TDeniedDate=Denied_Date from #temp1Target where MfrID = @SMfrId AND RegionID = @Sregionid AND ZoneID = @Szoneid
								
								if exists (select 1 from #temp1Target where MfrID = @SMfrId AND RegionID = @Sregionid AND ZoneID = @Szoneid) 		
								 begin	
									set @TempAuthStatus = dbo.[udf_MergingExistAuthStatus](@SAuthStatus,@TAuthStatus,0)
									if @TempAuthStatus = 4 or @TempAuthStatus = 3
									begin
										if @TempAuthStatus = @SAuthStatus
										 begin
											set @tempAuthDate = @SAuthDate
											set @tempDenyDate = @SDeniedDate
										 end
										else
										 begin
											set @tempAuthDate = @TAuthDate
											set @tempDenyDate = @TDeniedDate
										 end
									end
									  
									if exists (select 1 from #FinalRegionZoneStatus where MfrID = @SMfrId AND RegionID = @Sregionid AND ZoneID = @Szoneid) 
										update #FinalRegionZoneStatus
										set AuthStatus = @TempAuthStatus,Authorized_Date = @tempAuthDate, Denied_Date = @tempDenyDate
										where MfrID = @SMfrId AND RegionID = @Sregionid AND ZoneID = @Szoneid
									else
										insert into #FinalRegionZoneStatus(MfrDistId,MfrId,DistId,RegionId,ZoneId, AuthStatus,Authorized_Date,Denied_Date) 
										select @MfrDistID,@SMfrId,@Sdist,@Sregionid,@Szoneid, @TempAuthStatus,@tempAuthDate,@tempDenyDate
								 end
								else
								 begin
									
									select @TAuthStatus = AuthStatus,@TAuthDate=Authorized_Date,@TDeniedDate=Denied_Date from #FinalRegionZoneStatus where MfrID = @SMfrId AND RegionID = @Sregionid AND ZoneID = @Szoneid
									set @TempAuthStatus = dbo.[udf_MergingExistAuthStatus](@SAuthStatus,@TAuthStatus,0)
									
									if @TempAuthStatus = 4 or @TempAuthStatus = 3
									begin
										if @TempAuthStatus = @SAuthStatus
										 begin
											set @tempAuthDate = @SAuthDate
											set @tempDenyDate = @SDeniedDate
										 end
										else
										 begin
											set @tempAuthDate = @TAuthDate
											set @tempDenyDate = @TDeniedDate
										 end
									end
									
									if exists (select 1 from #FinalRegionZoneStatus where MfrID = @SMfrId AND RegionID = @Sregionid AND ZoneID = @Szoneid) 
										update #FinalRegionZoneStatus
										set AuthStatus =  @TempAuthStatus,Authorized_Date = @tempAuthDate, Denied_Date = @tempDenyDate
										where MfrID = @SMfrId AND RegionID = @Sregionid AND ZoneID = @Szoneid
									else
										insert into #FinalRegionZoneStatus(MfrDistId,MfrId,DistId,RegionId,ZoneId, AuthStatus,Authorized_Date,Denied_Date) 
										select @MfrDistID,@SMfrId,@Sdist,@Sregionid,@Szoneid, @TempAuthStatus,@tempAuthDate,@tempDenyDate
								 end
								
								set @indx = @indx + 1
							end
							if @icount > 0  and ((select COUNT(1) from #temp1Target)>0)
							begin
								print '-------Started: 1. Merging unmatched dist for companies of ''D'' Type-----------------'
								select distinct tt.* into #tmp1UnMatchedRecords from #temp1Target tt left join #temp1Source ts on ts.MfrID = tt.MfrID where ts.MfrID is null
								
								while((select COUNT(1) from #tmp1UnMatchedRecords)>0)
								begin
								
									 set @MfrDistId = -1
									 set @Sdist = -1
									 set @Sregionid = -1
									 set @Szoneid = -1
									 set @SAuthStatus = -1
									 set @SAuthDate  = null
									set @SDeniedDate = null
									set @TAuthDate = null
									set @TDeniedDate = null
									set @tempAuthDate = null
									set @tempDenyDate = null
									set @TAuthStatus = -1
								
									select top 1 @Sdist = DistID,@Sregionid = RegionID,@Szoneid = ZoneID, @SAuthStatus = AuthStatusID,@SMfrId = MfrID, @MfrDistId = MfrDistID,@SAuthDate=Authorized_Date,@SDeniedDate=Denied_Date  from #tmp1UnMatchedRecords order by MfrID
									
									if exists (select 1 from #FinalRegionZoneStatus where MfrId = @SMfrId AND RegionID = @Sregionid AND ZoneID = @Szoneid) 
									begin
										select @TAuthStatus = AuthStatus,@TAuthDate=Authorized_Date,@TDeniedDate=Denied_Date from #FinalRegionZoneStatus where MfrId = @SMfrId AND RegionID = @Sregionid AND ZoneID = @Szoneid
									
										set @TempAuthStatus = dbo.[udf_MergingExistAuthStatus](@SAuthStatus,@TAuthStatus,0)
										
										if @TempAuthStatus = 4 or @TempAuthStatus = 3
										begin
											if @TempAuthStatus = @SAuthStatus
											 begin
												set @tempAuthDate = @SAuthDate
												set @tempDenyDate = @SDeniedDate
											 end
											else
											 begin
												set @tempAuthDate = @TAuthDate
												set @tempDenyDate = @TDeniedDate
											 end
										end
									
										update #FinalRegionZoneStatus
										set AuthStatus =  @TempAuthStatus,Authorized_Date = @tempAuthDate, Denied_Date = @tempDenyDate
										where MfrId = @SMfrId AND RegionID = @Sregionid AND ZoneID = @Szoneid
									 end
									else
									 begin
										insert into #FinalRegionZoneStatus(MfrDistId,MfrId,DistId,RegionId,ZoneId, AuthStatus,Authorized_Date,Denied_Date) 
										select @MfrDistID,@SMfrId,@Sdist,@Sregionid,@Szoneid, @SAuthStatus,@SAuthDate,@SDeniedDate
									 end
										
										delete from #tmp1UnMatchedRecords where MfrId = @SMfrId AND RegionID = @Sregionid AND ZoneID = @Szoneid
								end
								IF OBJECT_ID('tempdb..#tmp1UnMatchedRecords') IS NOT NULL
									drop table #tmp1UnMatchedRecords
								print '-------End: 1. Merging unmatched dist for companies of ''D'' Type-----------------'
							end
							
							IF OBJECT_ID('tempdb..#temp1Source') IS NOT NULL
								drop table #temp1Source
							IF OBJECT_ID('tempdb..#temp1Target') IS NOT NULL
								drop table #temp1Target
						end
						
						
						DELETE FROM #temp1 WHERE compid = @id
					end
				   end ---End .....if (select COUNT(1) from #temp1)>1
				  else
				   begin
					   --if there is only single source company, then
					   select @id = CompId from #tmp
					   if CHARINDEX('D',[dbo].[Get_CompanyTypeName](@id)) > 0
					   begin
						insert into #FinalRegionZoneStatus(MfrDistId,MfrId,DistId,RegionId,ZoneId, AuthStatus,Authorized_Date,Denied_Date)
						select distinct RA.mfrdistid,RA.mfrid, RA.distid, RS.RegionID, RS.ZoneID, RS.AuthStatusID,rs.Authorized_Date,rs.Denied_Date
						FROM dbo.RegionAuthorization RA 
						INNER JOIN dbo.RegionZoneStatus RS ON RA.MfrDistID = RS.MfrDistID 
						WHERE RA.DistID = @id  
					   end
				   end
					
				-----Final merging auth status to target company
				IF((SELECT COUNT(1) FROM #FinalRegionZoneStatus)>0)
				 BEGIN
					 print '-------Started: Final merging auth status to target company of ''D'' Type-----------------'
					  --select * from #FinalRegionZoneStatus
					  while((SELECT COUNT(1) FROM #FinalRegionZoneStatus)>0)
						begin
							set @MfrDistId = -1
							set @Sdist = -1
							set @Sregionid = -1
							set @Szoneid = -1
							set @SAuthStatus = -1
							set @SAuthDate  = null
							set @SDeniedDate = null
							set @TAuthDate = null
							set @TDeniedDate = null
							set @tempAuthDate = null
							set @tempDenyDate = null
							set @TAuthStatus = -1
							
							select top 1 @id = ID, @MfrDistId=MfrDistId,@SMfrId=MfrId, @Sdist = DistId,@Sregionid = RegionID,@Szoneid = ZoneID, @SAuthStatus = AuthStatus,@SAuthDate=Authorized_Date,@SDeniedDate=Denied_Date from #FinalRegionZoneStatus order by ID
								
							if exists (SELECT 1
										FROM dbo.RegionAuthorization RA 
										INNER JOIN dbo.RegionZoneStatus RS ON RA.MfrDistID = RS.MfrDistID 
										WHERE RA.DistID = @TargetCompanyId and RA.MfrID = @SMfrId and RS.ZoneID = @Szoneid and  RS.RegionID = @Sregionid)
							begin
										SELECT distinct @TAuthStatus = RS.AuthStatusID,@TAuthDate=Authorized_Date,@TDeniedDate=Denied_Date FROM dbo.RegionAuthorization RA 
										INNER JOIN dbo.RegionZoneStatus RS ON RA.MfrDistID = RS.MfrDistID 
										WHERE RA.DistID = @TargetCompanyId and RA.MfrID = @SMfrId and RS.ZoneID = @Szoneid and  RS.RegionID = @Sregionid
										
										set @TempAuthStatus = dbo.[udf_MergingExistAuthStatus](@SAuthStatus,@TAuthStatus,1)
													
										if @TempAuthStatus = 4 or @TempAuthStatus = 3
										begin
											if @TempAuthStatus = @SAuthStatus
											 begin
												set @tempAuthDate = @SAuthDate
												set @tempDenyDate = @SDeniedDate
											 end
											else
											 begin
												set @tempAuthDate = @TAuthDate
												set @tempDenyDate = @TDeniedDate
											 end
										end
							
										update RegionZoneStatus
										set AuthStatusID = @TempAuthStatus, Authorized_Date = @tempAuthDate,Denied_Date = @tempDenyDate
										FROM dbo.RegionAuthorization RA 
										INNER JOIN dbo.RegionZoneStatus RS ON RA.MfrDistID = RS.MfrDistID 
										WHERE RA.DistID = @TargetCompanyId and RA.MfrID = @SMfrId and RS.ZoneID = @Szoneid and  RS.RegionID = @Sregionid
							
							end
							else
							 begin
								
								select @MfrDistId = MfrDistID from dbo.RegionAuthorization RA where RA.DistID = @TargetCompanyId and RA.MfrID = @SMfrId 
								
								Insert into dbo.RegionZoneStatus([MfrDistID],[RegionID],[ZoneID],[AuthStatusID],[Authorized_Date],[Denied_Date]) 
								Select @MfrDistId,@Sregionid,@Szoneid,@SAuthStatus,@SAuthDate,@SDeniedDate
							 end
							DELETE FROM #FinalRegionZoneStatus WHERE ID = @id
						
						end
					print '-------Ended: Final merging auth status to target company of ''D'' Type-----------------'		
				 end

				  IF OBJECT_ID('tempdb..#temp1') IS NOT NULL		
					DROP TABLE #temp1
					
				print '-------Ended: Process to merge auth status for companies of ''D'' Type-----------------'
					
				print '-------Started: Process to merge products for companies of ''D'' Type-----------------'
					
					INSERT INTO #TempProds(CompanyId,ProductTypeID,CompanyName)
					SELECT DISTINCT @TargetCompanyId,CPT.ProductTypeID,@TargetCompName 
					FROM  dbo.RegionAuthorization RA
					INNER JOIN CompanyProductType CPT on RA.MfrID = CPT.CompanyID
					WHERE RA.DistID = @TargetCompanyId and CPT.IsActive = 1 and CPT.ProductTypeID 
					NOT IN 
					(
						SELECT ProductTypeID FROM dbo.CompanyProductType WHERE CompanyID = @TargetCompanyId 
					)
					
					
					DECLARE @productId INT
					DECLARE crProducts CURSOR FOR SELECT DISTINCT CPT.ProductTypeID
														FROM  dbo.RegionAuthorization RA
														INNER JOIN CompanyProductType CPT on RA.MfrID = CPT.CompanyID
														WHERE RA.DistID = @TargetCompanyId and CPT.IsActive = 1 
					
						-- Open the Cursor
						OPEN crProducts

						FETCH NEXT FROM crProducts INTO @productId
						-- Check the fetch status. If a row was fetched, enter the loop
						WHILE @@FETCH_STATUS = 0
						BEGIN
									IF NOT EXISTS(SELECT 1 FROM CompanyProductType where ProductTypeID = @productId and CompanyID = @TargetCompanyId)
										INSERT INTO CompanyProductType(CompanyID,ProductTypeID,IsActive,CreatedBy,Createdon)
										select @TargetCompanyId,@productId,1,1,GETDATE()
									ELSE
										UPDATE CompanyProductType
										SET IsActive = 1
										WHERE ProductTypeID = @productId and CompanyID = @TargetCompanyId
										
					                
						   FETCH NEXT FROM crProducts INTO @productId
						END
					        
					 CLOSE crProducts
					 DEALLOCATE crProducts
 
					--INSERT INTO dbo.CompanyProductType(CompanyID,ProductTypeID,IsActive,CreatedBy,Createdon)
					--SELECT CompanyId,ProductTypeID,IsActive,CreatedBy,CreatedOn FROM #TempProds
					
				print '-------Started: Process to merge products for companies of ''D'' Type-----------------'
				
			   end  
		       
			IF(@MExists >0)
			   BEGIN
				print '-------Started: Process to merge auth status for companies of ''M'' Type-----------------'
		        
			   IF OBJECT_ID('tempdb..#FinalRegionZoneStatus') IS NOT NULL
				 delete from #FinalRegionZoneStatus
		        
				SELECT * into #temp from #tmp
		        
				IF (select COUNT(1) from #temp)>1
				   begin
					while((select COUNT(1) from #temp)>0)
					begin
						select top 1 @id = CompId from #temp order by Id
						
						select top 1 @nextId = d.CompId from (
						select top 2 Id,CompId from #temp order by Id
						) d
						order by id desc
						
						if @nextId != @id
						begin
							set @indx = 1
							
							--Source Table
							 if CHARINDEX('M',[dbo].[Get_CompanyTypeName](@id)) > 0 AND CHARINDEX('M',[dbo].[Get_CompanyTypeName](@nextId)) > 0
							 begin
								SELECT  IDENTITY(int,1, 1) as ID,RA.MfrDistID,RA.MfrID, RA.DistID,RS.AuthStatusID
								, RS.ZoneID, RS.RegionID ,RS.Authorized_Date,RS.Denied_Date
								into #tempSource
								FROM dbo.RegionAuthorization RA
								INNER JOIN dbo.RegionZoneStatus RS ON RA.MfrDistID = RS.MfrDistID 
								WHERE   MfrID = @id
							
								SELECT  IDENTITY(int,1, 1) as ID, RA.MfrDistID,RA.MfrID, RA.distid,RS.AuthStatusID
								, RS.ZoneID, RS.RegionID ,RS.Authorized_Date,RS.Denied_Date
								into #tempTarget
								FROM dbo.RegionAuthorization RA
								INNER JOIN dbo.RegionZoneStatus RS ON RA.MfrDistID = RS.MfrDistID 
								WHERE MfrID = @nextId
								
								select @icount = COUNT(1) from #tempSource where MfrID = @id
								
								while(@indx <= @icount)
								begin
									set @MfrDistId = -1
									set @Sdist = -1
									set @Sregionid = -1
									set @Szoneid = -1
									set @SAuthStatus = -1
									set @TAuthStatus = -1
									set @SAuthDate  = null
									set @SDeniedDate = null
									set @TAuthDate = null
									set @TDeniedDate = null
									set @tempAuthDate = null
									set @tempDenyDate = null
									 
									select @Sdist = DistID,@Sregionid = RegionID,@Szoneid = ZoneID, @SAuthStatus = AuthStatusID,@SMfrId = MfrID, @MfrDistId = MfrDistID,@SAuthDate=Authorized_Date,@SDeniedDate=Denied_Date  from #tempSource where ID = @indx
									select @TAuthStatus = AuthStatusID,@TAuthDate=Authorized_Date,@TDeniedDate=Denied_Date from #tempTarget where DistID = @Sdist AND RegionID = @Sregionid AND ZoneID = @Szoneid
									
									if exists (select 1 from #tempTarget where DistID = @Sdist AND RegionID = @Sregionid AND ZoneID = @Szoneid) 		
									 begin	
										set @TempAuthStatus = dbo.[udf_MergingExistAuthStatus](@SAuthStatus,@TAuthStatus,0)
									
											if @TempAuthStatus = 4 or @TempAuthStatus = 3
											begin
												if @TempAuthStatus = @SAuthStatus
												 begin
													set @tempAuthDate = @SAuthDate
													set @tempDenyDate = @SDeniedDate
												 end
												else
												 begin
													set @tempAuthDate = @TAuthDate
													set @tempDenyDate = @TDeniedDate
												 end
											end
											
										if exists (select 1 from #FinalRegionZoneStatus where DistID = @Sdist AND RegionID = @Sregionid AND ZoneID = @Szoneid) 
											update #FinalRegionZoneStatus
											set AuthStatus = @TempAuthStatus,Authorized_Date=@tempAuthDate,Denied_Date= @tempDenyDate
											where DistID = @Sdist AND RegionID = @Sregionid AND ZoneID = @Szoneid
										else
											insert into #FinalRegionZoneStatus(MfrDistId,MfrId,DistId,RegionId,ZoneId, AuthStatus,Authorized_Date,Denied_Date) 
											select @MfrDistID,@SMfrId,@Sdist,@Sregionid,@Szoneid, @TempAuthStatus,@tempAuthDate,@tempDenyDate
									 end
									else
									 begin
										select @TAuthStatus = AuthStatus,@TAuthDate=Authorized_Date,@TDeniedDate=Denied_Date from #FinalRegionZoneStatus where DistID = @Sdist AND RegionID = @Sregionid AND ZoneID = @Szoneid
										set @TempAuthStatus = dbo.[udf_MergingExistAuthStatus](@SAuthStatus,@TAuthStatus,0)
									
										if @TempAuthStatus = 4 or @TempAuthStatus = 3
										begin
											if @TempAuthStatus = @SAuthStatus
											 begin
												set @tempAuthDate = @SAuthDate
												set @tempDenyDate = @SDeniedDate
											 end
											else
											 begin
												set @tempAuthDate = @TAuthDate
												set @tempDenyDate = @TDeniedDate
											 end
										end
										
										if exists (select 1 from #FinalRegionZoneStatus where DistID = @Sdist AND RegionID = @Sregionid AND ZoneID = @Szoneid) 
											update #FinalRegionZoneStatus
											set AuthStatus =  @TempAuthStatus,Authorized_Date=@tempAuthDate,Denied_Date= @tempDenyDate
											where DistID = @Sdist AND RegionID = @Sregionid AND ZoneID = @Szoneid
										else
											insert into #FinalRegionZoneStatus(MfrDistId,MfrId,DistId,RegionId,ZoneId, AuthStatus,Authorized_Date,Denied_Date) 
											select @MfrDistID,@SMfrId,@Sdist,@Sregionid,@Szoneid, @TempAuthStatus,@tempAuthDate,@tempDenyDate
									 end
									
									set @indx = @indx + 1
								end
								
								if @icount > 0  and ((select COUNT(1) from #tempTarget)>0)
								begin
									print '-------Started: 1. Merging unmatched dist for companies of ''M'' Type-----------------'
									select tt.* into #tmpUnMatchedRecords from #tempTarget tt left join #tempSource ts on ts.DistID = tt.DistID where ts.DistID is null
									
									while((select COUNT(1) from #tmpUnMatchedRecords)>0)
									begin
									
										 set @MfrDistId = -1
										 set @Sdist = -1
										 set @Sregionid = -1
										 set @Szoneid = -1
										 set @SAuthStatus = -1
										 set @TAuthStatus = -1
										 set @SAuthDate  = null
										 set @SDeniedDate = null
										 set @TAuthDate = null
										 set @TDeniedDate = null
										 set @tempAuthDate = null
										 set @tempDenyDate = null
										select top 1 @Sdist = DistID,@Sregionid = RegionID,@Szoneid = ZoneID, @SAuthStatus = AuthStatusID,@SMfrId = MfrID, @MfrDistId = MfrDistID,@SAuthDate=Authorized_Date,@SDeniedDate=Denied_Date  from #tmpUnMatchedRecords order by DistID
										
										IF EXISTS (SELECT 1 FROM #FinalRegionZoneStatus where DistID = @Sdist AND RegionID = @Sregionid AND ZoneID = @Szoneid) 
										BEGIN
											SELECT @TAuthStatus=AuthStatus,@TAuthDate=Authorized_Date,@TDeniedDate=Denied_Date from #FinalRegionZoneStatus where DistID = @Sdist AND RegionID = @Sregionid AND ZoneID = @Szoneid
										
											set @TempAuthStatus = dbo.[udf_MergingExistAuthStatus](@SAuthStatus,@TAuthStatus,0)
											
											IF @TempAuthStatus = 4 or @TempAuthStatus = 3
											begin
												if @TempAuthStatus = @SAuthStatus
												 begin
													set @tempAuthDate = @SAuthDate
													set @tempDenyDate = @SDeniedDate
												 end
												else
												 begin
													set @tempAuthDate = @TAuthDate
													set @tempDenyDate = @TDeniedDate
												 end
											end
										
											update #FinalRegionZoneStatus
											set AuthStatus =  @TempAuthStatus,Authorized_Date=@tempAuthDate,Denied_Date=@tempDenyDate
											where DistID = @Sdist AND RegionID = @Sregionid AND ZoneID = @Szoneid
										END
										ELSE
										 BEGIN
											INSERT INTO #FinalRegionZoneStatus(MfrDistId,MfrId,DistId,RegionId,ZoneId, AuthStatus,Authorized_Date,Denied_Date) 
											SELECT @MfrDistID,@SMfrId,@Sdist,@Sregionid,@Szoneid, @SAuthStatus,@SAuthDate,@SDeniedDate
										 END
											
											delete from #tmpUnMatchedRecords where DistID = @Sdist AND RegionID = @Sregionid AND ZoneID = @Szoneid
									end
									IF OBJECT_ID('tempdb..#tmpUnMatchedRecords') IS NOT NULL
										drop table #tmpUnMatchedRecords
									print '-------End: 1. Merging unmatched dist for companies of ''M'' Type-----------------'
								end
								
								IF OBJECT_ID('tempdb..#tempSource') IS NOT NULL
									drop table #tempSource
								IF OBJECT_ID('tempdb..#tempTarget') IS NOT NULL
									drop table #tempTarget
							   end
						end
						
						
						DELETE FROM #temp WHERE compid = @id
					end
				   end ---End .....if (select COUNT(1) from #temp)>1
				  else
				   begin
					   print '--if there is only single source company, then'
					   select @id = CompId from #tmp 
					   if CHARINDEX('M',[dbo].[Get_CompanyTypeName](@id)) > 0
					   begin
						insert into #FinalRegionZoneStatus(MfrDistId,MfrId,DistId,RegionId,ZoneId, AuthStatus,Authorized_Date,Denied_Date)
						select distinct RA.mfrdistid,RA.mfrid, RA.distid, RS.RegionID, RS.ZoneID, RS.AuthStatusID,RS.Authorized_Date,RS.Denied_Date
						FROM dbo.RegionAuthorization RA 
						INNER JOIN dbo.RegionZoneStatus RS ON RA.MfrDistID = RS.MfrDistID 
						WHERE MfrID = @id  
					   end
				   end
					
				-----Final merging auth status to target company
				IF((SELECT COUNT(1) FROM #FinalRegionZoneStatus)>0)
				 BEGIN
					print '-------Started: Final merging auth status to target company of ''M'' Type-----------------'
						--select * from #FinalRegionZoneStatus
						while((SELECT COUNT(1) FROM #FinalRegionZoneStatus)>0)
						begin
							set @Sdist = -1
							set @Sregionid = -1
							set @Szoneid = -1
							set @SAuthStatus = -1
							set @TAuthStatus = -1
							set @SAuthDate  = null
							set @SDeniedDate = null
							set @TAuthDate = null
							set @TDeniedDate = null
							set @tempAuthDate = null
							set @tempDenyDate = null
							select top 1 @id = ID, @Sdist = DistId,@MfrDistId=MfrDistId,@Sregionid = RegionID,@Szoneid = ZoneID, @SAuthStatus = AuthStatus,@SAuthDate=Authorized_Date,@SDeniedDate=Denied_Date from #FinalRegionZoneStatus order by ID
								
							if exists (SELECT 1
										FROM dbo.RegionAuthorization RA 
										INNER JOIN dbo.RegionZoneStatus RS ON RA.MfrDistID = RS.MfrDistID 
										WHERE RA.mfrid = @TargetCompanyId and RA.DistID = @Sdist and RS.ZoneID = @Szoneid and  RS.RegionID = @Sregionid)
							begin
										SELECT distinct @TAuthStatus = RS.AuthStatusID,@TAuthDate=Authorized_Date,@TDeniedDate=Denied_Date FROM dbo.RegionAuthorization RA 
										INNER JOIN dbo.RegionZoneStatus RS ON RA.MfrDistID = RS.MfrDistID 
										WHERE RA.mfrid = @TargetCompanyId and RA.DistID = @Sdist and RS.ZoneID = @Szoneid and  RS.RegionID = @Sregionid
										
										set @TempAuthStatus = dbo.[udf_MergingExistAuthStatus](@SAuthStatus,@TAuthStatus,1)
										
										if @TempAuthStatus = 4 or @TempAuthStatus = 3
											begin
												if @TempAuthStatus = @SAuthStatus
												 begin
													set @tempAuthDate = @SAuthDate
													set @tempDenyDate = @SDeniedDate
												 end
												else
												 begin
													set @tempAuthDate = @TAuthDate
													set @tempDenyDate = @TDeniedDate
												 end
											end
								
										update RegionZoneStatus
										set AuthStatusID = @TempAuthStatus, Authorized_Date = @tempAuthDate,Denied_Date = @tempDenyDate
										FROM dbo.RegionAuthorization RA 
										INNER JOIN dbo.RegionZoneStatus RS ON RA.MfrDistID = RS.MfrDistID 
										WHERE RA.mfrid = @TargetCompanyId and RA.DistID = @Sdist and RS.ZoneID = @Szoneid and  RS.RegionID = @Sregionid
							
							end
							else
							 begin
								select @MfrDistId = MfrDistID from dbo.RegionAuthorization RA where RA.mfrid = @TargetCompanyId and RA.DistID = @Sdist
								
								Insert into dbo.RegionZoneStatus([MfrDistID],[RegionID],[ZoneID],[AuthStatusID],[Authorized_Date],[Denied_Date]) 
								Select @MfrDistId,@Sregionid,@Szoneid,@SAuthStatus,@SAuthDate,@SDeniedDate
							 end
							DELETE FROM #FinalRegionZoneStatus WHERE ID = @id
						
						end
						
					print '-------Ended: Final merging auth status to target company of ''M'' Type-----------------'		
				 end
								 
				IF OBJECT_ID('tempdb..#temp') IS NOT NULL
					DROP TABLE #temp
					
				print '-------Ended: Process to merge auth status for companies of ''M'' Type-----------------'	
				
				print '---------Started: Merging all products of source to target manufecturer''s distributors-------------------'
				
				DECLARE @dist INT
				DECLARE @prodId INT
				DECLARE @distName varchar(1000)
				
				
				DECLARE cr CURSOR FOR select DistId,CompanyName from dbo.RegionAuthorization ra INNER JOIN Company c on c.CompanyID = ra.DistID where MfrID = @TargetCompanyId

				-- Open the Cursor
				OPEN cr

				FETCH NEXT FROM cr INTO @dist,@distName
				-- Check the fetch status. If a row was fetched, enter the loop
				WHILE @@FETCH_STATUS = 0
				BEGIN
						INSERT INTO #TempProds(CompanyId,ProductTypeID,CompanyName)
						SELECT @dist,ProductTypeID,@distName FROM dbo.CompanyProductType CP
						WHERE CompanyID = @TargetCompanyId and cp.IsActive = 1 and cp.ProductTypeID 
						NOT IN 
						(
							SELECT ProductTypeID FROM dbo.CompanyProductType WHERE CompanyID = @dist 
						)
						
						DECLARE crProducts CURSOR FOR SELECT DISTINCT CP.ProductTypeID
														FROM dbo.CompanyProductType CP
														WHERE CP.CompanyID = @TargetCompanyId and cp.IsActive = 1 
					
						-- Open the Cursor
						OPEN crProducts

						FETCH NEXT FROM crProducts INTO @prodId
						-- Check the fetch status. If a row was fetched, enter the loop
						WHILE @@FETCH_STATUS = 0
						BEGIN
									IF NOT EXISTS(SELECT 1 FROM CompanyProductType where ProductTypeID = @prodId and CompanyID = @dist)
										INSERT INTO CompanyProductType(CompanyID,ProductTypeID,IsActive,CreatedBy,Createdon)
										select @dist,@prodId,1,1,GETDATE()
									ELSE
										UPDATE CompanyProductType
										SET IsActive = 1
										WHERE ProductTypeID = @prodId and CompanyID = @dist
										
					                
						   FETCH NEXT FROM crProducts INTO @prodId
						END
					        
					 CLOSE crProducts
					 DEALLOCATE crProducts
						
							
				   FETCH NEXT FROM cr INTO @dist,@distName
				END
		                
			   CLOSE cr
			   DEALLOCATE cr
				
				print '---------Ended: Merging all products of source to target manufecturer''s distributors-------------------'
				
			   end     
		  
		    
			IF OBJECT_ID('tempdb..#FinalRegionZoneStatus') IS NOT NULL
				drop table #FinalRegionZoneStatus
				
			IF OBJECT_ID('tempdb..#tmp') IS NOT NULL
				drop table #tmp
			
			select distinct cpt.CompanyID,cpt.CompanyName,cpt.ProductTypeID,pt.TypeDescription from #TempProds cpt
			INNER JOIN ProductType pt on pt.ProductTypeId = cpt.ProductTypeID 
			order by cpt.CompanyID
			
			IF OBJECT_ID('tempdb..#TempProds') IS NOT NULL
				drop table #TempProds
				
		 END

		---------------------------------------------------------------------------------


GO

