GO

/****** Object:  StoredProcedure [dbo].[usp_CopyOrderToRevision]    Script Date: 07/16/2012 22:33:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_CopyOrderToRevision]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_CopyOrderToRevision]
GO

/****** Object:  StoredProcedure [dbo].[usp_CopyOrderToRevision]    Script Date: 07/16/2012 22:33:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



--*****************************************************************************************************                        
--*   Stored Procedure  : [usp_CopyOrderToRevision]                      
--*   Description  : Copy The Order Details To Revison Tables                       
--*   Author   : Aatish Agarwal                  
--*   Creation Date  : 07/16/2012
--*****************************************************************************************************  
     
CREATE PROCEDURE [dbo].[usp_CopyOrderToRevision]
(               
 @OrderId INT                      
)                                                  
AS                                                  
BEGIN                                                  
SET NOCOUNT ON          

  DECLARE @AdOrderRevisionId INT   
  
	   
		 
			INSERT INTO AdOrderRevision VALUES(@OrderId,1,GETDATE())    
			SET @AdOrderRevisionId = SCOPE_IDENTITY()     										
				
			--Adding All Existing Ads To AdOrderDetailsRevision			
			INSERT INTO AdOrderDetailsRevision(AdOrderDetailsId,AdOrderId,SectionID,SizeTypeID,AdTypeID,LogoIndicator,PositionTitle,Comments, Price, ApplyDiscount,CompIndicator,CompCode,Duration,ActivationDate, LastUpdatedBy, OrderType,RateCardId,OrderRegionId,AdOrderRevisionId) 
			SELECT AOD.AdOrderDetailsId,AOD.AdOrderId,AOD.SectionID,AOD.SizeTypeID,AOD.AdTypeID,AOD.LogoIndicator, AOD.PositionTitle,AOD.Comments, AOD.Price, AOD.ApplyDiscount,AOD.CompIndicator, AOD.CompCode,AOD.Duration, AOD.ActivationDate, AOD.LastUpdatedBy, AOD.OrderType,AOD.RateCardId,AOD.OrderRegionId,@AdOrderRevisionId  
			FROM AdOrderDetails AOD WHERE AdOrderId = @OrderId AND AOD.AdOrderDetailsId NOT IN(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @OrderId AND AdOrderRevisionId = @AdOrderRevisionId)
			
			--Adding All Existing Ads To AdOrderDetailsRegionEditionRevision	
			INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId, EditionID, RegionID, PriorityDate, AdOrderRevisionId, OnlineMonth, OnlineYear) 			
			SELECT R.AdOrderDetailsId, R.EditionID, R.RegionID, R.PriorityDate, @AdOrderRevisionId, R.OnlineMonth, R.OnlineYear 
			FROM AdOrderDetailsRegionEdition R WHERE AdOrderDetailsId   IN
			(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @OrderId)
			AND R.AdOrderDetailsId NOT IN(SELECT AdOrderDetailsId FROM AdOrderDetailsRegionEditionRevision WHERE AdOrderDetailsId IN
			(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @OrderId) AND AdOrderRevisionId = @AdOrderRevisionId)
				
		                 
END


GO


