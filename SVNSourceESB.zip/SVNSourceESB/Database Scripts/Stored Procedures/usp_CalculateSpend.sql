GO

/****** Object:  StoredProcedure [dbo].[usp_CalculateSpend]    Script Date: 01/08/2013 16:55:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_CalculateSpend]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_CalculateSpend]
GO

/****** Object:  StoredProcedure [dbo].[usp_CalculateSpend]    Script Date: 01/08/2013 16:55:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




		-- =============================================
		-- Author:        Lalit Mehta, Mohit Garg
		-- Create date: Mar 18, 2012; Mar 24, 2012
		-- Description:    Get total money spent by Distributors for Manufacturer and Product ads (both online and print)
		-- =============================================
		CREATE PROCEDURE [dbo].[usp_CalculateSpend]
		AS
		BEGIN
			-- SET NOCOUNT ON added to prevent extra result sets from
			-- interfering with SELECT statements.
			SET NOCOUNT ON;

			-- get 10 last closed print editions
			SELECT
				top 10 EditionID, RegionID into #tblEdition
			FROM
				Editions e, MstEditionStatus es
			WHERE
				e.StatusID = es.StatusID
				and es.Description = 'Complete'
			ORDER BY PublicationDate DESC
		    
		/****
		This SP Creating Three Different Tables for Different Spents
		1. Distributor Parts  Spend		    [DistPartsSpend]
		2. Distributor Manufacturer Spend	[DistMfrSpend]
		3. Distributors Product Type Spend  [DistProdTypeSpend]
		****/    
		    

		/**** 1. Starts Distributor Parts Spend ****/

			-- Part - Online Amount for US/Canada Regions only
			select
				 ra.MfrID,
				 ra.DistID,
				 c.RegionID RegionID,
				 aodre.RegionID as ZoneID,
				 0 as Print_Amount,
				 sum(aod.Price) as Online_Amount,
				 NULL as Priority_Date into #PartDistAmount
			from
				 AdOrder ao, AdOrderDetails aod,
				 AdOrderDetailsRegionEdition aodre,
				 SalesSectionType sst, RegionAuthorization ra,Country c,CountryZones cz
			where
				ao.AdOrderId = aod.AdOrderId
				and aod.SectionID = sst.SectionID
				and sst.SectionCode in ('M','X')
				and ao.StatusId in (3,4,5)
				and aod.ActivationDate <= GETDATE()
				and GETDATE()<=DATEADD(MM,aod.Duration,aod.ActivationDate)
				and aod.OrderType = 'O'
				and aodre.RegionID <> 0
				and aod.AdOrderDetailsId = aodre.AdOrderDetailsId
				and ao.CompanyId = ra.DistID
				and aod.PositionTitle = ra.MfrID
				and aodre.RegionID = cz.ZoneID
				and cz.CountryID = c.CountryID
				and c.RegionID in (1,2)
			group by ra.MfrID, ra.DistID, c.RegionID, aodre.RegionID  
		    
		    UNION
		    
		    -- Part - Online Amount for Non US/Canada Regions
		    select
				 ra.MfrID,
				 ra.DistID,
				 aodregxf.RegionID,
				 0 as ZoneID,
				 0 as Print_Amount,
				 sum(aodregxf.Price) as Online_Amount,
				 NULL as Priority_Date
			from
				 AdOrder ao, AdOrderDetails aod,
				 AdOrderDetails_Regions_Xref aodregxf,
				 SalesSectionType sst, RegionAuthorization ra
			where
				ao.AdOrderId = aod.AdOrderId
				and aod.SectionID = sst.SectionID
				and sst.SectionCode in ('M','X')
				and ao.StatusId in (3,4,5)
				and aod.ActivationDate <= GETDATE()
				and GETDATE()<=DATEADD(MM,aod.Duration,aod.ActivationDate)
				and aod.OrderType = 'O'
				and aodregxf.RegionID not in (1,2)
				and aod.AdOrderDetailsId = aodregxf.AdOrderDetailsId
				and ao.CompanyId = ra.DistID
				and aod.PositionTitle = ra.MfrID
			group by ra.MfrID, ra.DistID, aodregxf.RegionID  
			
			UNION
		    
			-- Print Amount
			select
				 ra.MfrID,
				 ra.DistID,
				 c.RegionID RegionID,
				 aodre.RegionID as ZoneID,
				 sum(aod.price) as Print_Amount,
				 0 as  Online_Amount,
				 max(aodre.prioritydate) as Priority_Date
			from
				 AdOrder ao, AdOrderDetails aod,
				 AdOrderDetailsRegionEdition aodre,
				 SalesSectionType sst, RegionAuthorization ra,Country c,CountryZones cz,
				 #tblEdition t
			where
				ao.AdOrderId = aod.AdOrderId
				and aod.SectionID = sst.SectionID
				and sst.SectionCode in ('M','X')
				and ao.StatusId in (3,4,5)
				and aod.OrderType = 'P'
				and aodre.RegionID <> 0
				and aod.AdOrderDetailsId = aodre.AdOrderDetailsId
				and ao.CompanyId = ra.DistID
				and aod.PositionTitle = ra.MfrID
				and t.EditionID = aodre.EditionID
				and aodre.RegionID = cz.ZoneID
				and cz.CountryID = c.CountryID
			group by ra.MfrID, ra.DistID, c.RegionID, aodre.RegionID 
			
			-- truncate table --
			TRUNCATE TABLE [dbo].[DistPartsSpend]

			-- inserting values in DistPartsSpend table --      
			insert into [dbo].[DistPartsSpend] select MfrID, DistID,
				 RegionID, ZoneID, sum(Online_Amount), sum(Print_Amount),max(Priority_Date) from #PartDistAmount
			group by MfrID, DistID, RegionID, ZoneID


		drop table #PartDistAmount
		/****  Ends Distributor Parts Spend ****/


		/*************************************************************************************************************************/


		/**** 2. Starts Distributor Manufacturer Spend ****/

			-- Mfr - Online Amount
			select
				 ra.MfrID,
				 ra.DistID,
				 c.RegionID RegionID,
				 aodre.RegionID as ZoneID,
				 0 as Print_Amount,
				 sum(aod.Price) as Online_Amount,
				 NULL as Priority_Date into #MfrDistAmount
			from
				 AdOrder ao, AdOrderDetails aod,
				 AdOrderDetailsRegionEdition aodre,
				 SalesSectionType sst, RegionAuthorization ra,Country c,CountryZones cz
			where
				ao.AdOrderId = aod.AdOrderId
				and aod.SectionID = sst.SectionID
				and sst.SectionCode in ('M')
				and ao.StatusId in (3,4,5)
				and aod.ActivationDate <= GETDATE()
				and GETDATE()<=DATEADD(MM,aod.Duration,aod.ActivationDate)
				and aod.OrderType = 'O'
				and aodre.RegionID <> 0
				and aod.AdOrderDetailsId = aodre.AdOrderDetailsId
				and ao.CompanyId = ra.DistID
				and aod.PositionTitle = ra.MfrID
				and aodre.RegionID = cz.ZoneID
				and cz.CountryID = c.CountryID
			group by ra.MfrID, ra.DistID, c.RegionID, aodre.RegionID  
		    
		    UNION
		    
		    -- Mfr - Online Amount for Non US/Canada Regions
		    select 
				ra.MfrID,
				ra.DistID,
				aodregxf.RegionID RegionID,
				0 as ZoneID,
				0 as Print_Amount,
				sum(aodregxf.Price) as Online_Amount,
				NULL as Priority_Date
			from
				AdOrder ao, AdOrderDetails aod,
				AdOrderDetails_Regions_Xref aodregxf, 
				SalesSectionType sst, RegionAuthorization ra
			where
				ao.AdOrderId = aod.AdOrderId
				and aod.SectionID = sst.SectionID
				and sst.SectionCode in ('M')
				and ao.StatusId in (3,4,5)
				and aod.ActivationDate <= GETDATE()
				and GETDATE()<=DATEADD(MM,aod.Duration,aod.ActivationDate)
				and aod.OrderType = 'O'
				--and (aod.OrderRegionId not like '%1%' or aod.OrderRegionId not like '%2%' )
				and aodregxf.RegionId not in (1,2)
				and aod.AdOrderDetailsId = aodregxf.AdOrderDetailsId
				and ao.CompanyId = ra.DistID
				and aod.PositionTitle = ra.MfrID
				--and aod.PositionTitle = 101376
			group by ra.MfrID, ra.DistID, RegionID, aodregxf.AdOrderDetailsId
  		    
		    UNION
		    
			-- Mfr - Print Amount
			select
				 ra.MfrID,
				 ra.DistID,
				 c.RegionID RegionID,
				 aodre.RegionID as ZoneID,
				 sum(aod.price) as Print_Amount,
				 0 as  Online_Amount,
				 max(aodre.prioritydate) as Priority_Date
			from
				 AdOrder ao, AdOrderDetails aod,
				 AdOrderDetailsRegionEdition aodre,
				 SalesSectionType sst, RegionAuthorization ra,Country c,CountryZones cz,
				 #tblEdition t
			where
				ao.AdOrderId = aod.AdOrderId
				and aod.SectionID = sst.SectionID
				and sst.SectionCode in ('M')
				and ao.StatusId in (3,4,5)
				and aod.OrderType = 'P'
				and aodre.RegionID <> 0
				and aod.AdOrderDetailsId = aodre.AdOrderDetailsId
				and ao.CompanyId = ra.DistID
				and aod.PositionTitle = ra.MfrID
				and t.EditionID = aodre.EditionID
				and aodre.RegionID = cz.ZoneID
				and cz.CountryID = c.CountryID
		   group by ra.MfrID, ra.DistID, c.RegionID, aodre.RegionID 
			
			-- truncate table --
			TRUNCATE TABLE [dbo].[DistMfrSpend]
			
			-- inserting values in DistMfrSpend table --      
			insert into [dbo].[DistMfrSpend] select MfrID, DistID,
				 RegionID, ZoneID, sum(Online_Amount), sum(Print_Amount),max(Priority_Date) from #MfrDistAmount
			group by MfrID, DistID, RegionID, ZoneID


		drop table #MfrDistAmount 
		/****  Ends Distributor Manufacturer Spend ****/


		/*************************************************************************************************************************/


		/**** 3. Starts Distributors Product Type Spent ****/

		-- ProductType Amount
		 -- ProductType - Online Amount
			select
				 aod.PositionTitle as ProductTypeId,
				 ao.CompanyId as DistId,
				 c.RegionID RegionID,
				 aodre.RegionID as ZoneID,
				 sum(aod.Price) as Online_Amount,   -- ProductType - Online Amount
				 0 as Print_Amount,
				 NULL as Priority_Date into #ProdTypeAmount
			from
				 AdOrder ao, AdOrderDetails aod,
				 AdOrderDetailsRegionEdition aodre,
				 SalesSectionType sst,Country c,CountryZones cz,
				 (select distinct companyid from CompanyTypeMapping where companytypeid in (2,3))as ctm
			where
				ao.AdOrderId = aod.AdOrderId
				and ao.CompanyId = ctm.CompanyID
				and aod.SectionID = sst.SectionID
				and aod.AdOrderDetailsId = aodre.AdOrderDetailsId
				and sst.SectionCode in ('P','S','V')
				and ao.StatusId in (3,4,5)
				and aod.ActivationDate <= GETDATE()
				and GETDATE()<=DATEADD(MM,aod.Duration,aod.ActivationDate)
				and aod.OrderType = 'O'
				and aodre.RegionID <> 0
				and aod.Price > 0 and aod.PositionTitle is not null and aod.PositionTitle > 0
				and aodre.RegionID = cz.ZoneID
				and cz.CountryID = c.CountryID
			group by aod.PositionTitle, ao.CompanyId, c.RegionID ,aodre.RegionID
			Union
			-- ProductType - Online Amount - Non US/Canada
			select 
				aod.PositionTitle as ProductTypeId,
				ao.CompanyId as DistId,
				aodregxf.RegionID as RegionID,
				0 as ZoneID,
				sum(aodregxf.Price) as Online_Amount, 
				0 as Print_Amount, 
				NULL as Priority_Date
			from
				AdOrder ao, AdOrderDetails aod,
				AdOrderDetails_Regions_Xref aodregxf, 
				SalesSectionType sst
			where
				ao.AdOrderId = aod.AdOrderId
				and aod.SectionID = sst.SectionID
				and sst.SectionCode in ('P','S','V')
				and ao.StatusId in (3,4,5)
				and aod.ActivationDate <= GETDATE()
				and GETDATE()<=DATEADD(MM,aod.Duration,aod.ActivationDate)
				and aod.OrderType = 'O'
				--and (aod.OrderRegionId not like '%1%' or aod.OrderRegionId not like '%2%' )
				and aodregxf.RegionId not in (1,2)
				and aod.AdOrderDetailsId = aodregxf.AdOrderDetailsId
			group by aod.PositionTitle, ao.CompanyId, aodregxf.RegionID 
			Union
			-- ProductType - Print Amount
			select
				 aod.PositionTitle as ProductTypeId,
				 ao.CompanyId as DistId,
				 c.RegionID RegionID,
				 aodre.RegionID as ZoneID,
				 0 as Online_Amount,
				 sum(aod.price) as Print_Amount,             -- ProductType - Print Amount
				 max(aodre.prioritydate) as Priority_Date
			from
				 AdOrder ao, AdOrderDetails aod,
				 AdOrderDetailsRegionEdition aodre,
				 SalesSectionType sst, #tblEdition t,Country c,CountryZones cz,
				 (select distinct companyid from CompanyTypeMapping where companytypeid in (2,3))as ctm
			where
				ao.AdOrderId = aod.AdOrderId
				and aod.SectionID = sst.SectionID
				and aod.AdOrderDetailsId = aodre.AdOrderDetailsId
				and t.EditionID = aodre.EditionID
				and ao.CompanyId = ctm.companyId
				and sst.SectionCode in ('P','V')
				and ao.StatusId in (3,4,5)
				and aod.OrderType = 'P'
				and aodre.RegionID <> 0
				and aod.Price > 0 and aod.PositionTitle is not null and aod.PositionTitle > 0
				and aodre.RegionID = cz.ZoneID
				and cz.CountryID = c.CountryID	
			group by aod.PositionTitle, ao.CompanyId, c.RegionID, aodre.RegionID ;

			-- truncate table --
			TRUNCATE TABLE [dbo].[DistProdTypeSpend]
			
			-- inserting values in DistProdTypeSpend table --  
			insert into [dbo].[DistProdTypeSpend] select ProductTypeId, DistId, RegionID,
				ZoneID, sum(Online_Amount), sum(Print_Amount),max(Priority_Date) from #ProdTypeAmount
			group by ProductTypeId, DistId, RegionID,ZoneID

		drop table #tblEdition
		drop table #ProdTypeAmount
		/**** Ends Distributors Product Type Spent ****/


		END

GO


