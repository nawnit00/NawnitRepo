GO

/****** Object:  StoredProcedure [dbo].[usp_GetAdDetails]    Script Date: 08/08/2012 20:30:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAdDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAdDetails]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetAdDetails]    Script Date: 08/08/2012 20:30:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-------------------------------------------------------------------
-- Name   : SATHEESH KUMAR .S
-- Description  : Get AD list
-- Arguments    : ORDER ID
-- Returns      : Returns Advertisement list
-------------------------------------------------------------------
-- Modified By  : Kiran Sangoi
-- Description  : Added logic to use AifFlag Flags on  AdDetails
-- Modify Date  : Nov. 28 2011
-- Modified By	: Lalbahadur on 8/6/2012 to order by ad sequence number
-------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetAdDetails]
(
 @AdOrderId INT
)
AS
BEGIN
    set transaction isolation level read uncommitted

SELECT A.OrderType,A.AdOrderId,
	A.AdOrderDetailsId,
	ADE.AdTypeId,
	ADE.AdTypeDescription,
	S.SECTIONID,
	S.DESCRIPTION as Sectiondescription,
	A.AdOrderDetailsId,
	(CASE WHEN dbo.GetPositionTitle(A.PositionTitle,A.SectionID) = '-' THEN S.Description +' '+SZ.Description +' '
				 ELSE S.Description +' '+SZ.Description +' at '+ dbo.GetPositionTitle(A.PositionTitle,A.SectionID) END) 
				 AS SizeSectionPosition,
	AD.AIF_PrintInstruction,A.AIF_Instruction,
	A.AIF_Url
 FROM  AdOrderDetails A
   INNER JOIN AdOrder AD ON A.AdOrderId=AD.AdOrderId
   INNER JOIN SalesSectionType S ON A.SectionID=S.SectionID
   INNER JOIN SalesSizeType SZ ON A.SizeTypeID=SZ.SizeTypeID
   INNER JOIN AdDetails ADE ON ADE.AdTypeID  = A.AdTypeID  AND ADE.AifFlag = 1
   LEFT JOIN PremiumListing PL ON PL.AdOrderId=AD.AdOrderId and PL.AdOrderDetailsId=A.AdOrderDetailsId
  WHERE  A.AdOrderId =@AdOrderId AND A.OrderType ='O'
  ORDER BY dbo.AdSequenceNumber(S.SectionCode, A.ordertype) , S.SectionCode ASC, dbo.GetPositionTitle(A.PositionTitle,A.SectionID) ASC,  A.AdOrderDetailsId DESC 
END

GO


