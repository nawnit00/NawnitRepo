/****** Object:  StoredProcedure [dbo].[usp_AddCompanyVerification]    Script Date: 10/16/2012 11:26:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_AddCompanyVerificationRequest]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_AddCompanyVerificationRequest]
GO

/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Adds all the company verification requests to be sent

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
10.16.2012		Marcus Ruether		Created. 
MM.DD.YYYY		<developer name>		<Changes made.> 
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE usp_AddCompanyVerificationRequest
	@AlertId int,
	@RequestedByUserId int,
	@VerifyByDate DATETIME,
	@Year int, -- used by Manufacturer alert
	@EditionId int, -- used by distributor/vendor alert
	@CompanyIds VARCHAR(MAX), -- comma delimited list of company IDs who should receive this request.
	@VerifiedCompanyIds VARCHAR(MAX)
AS
BEGIN
	
	DECLARE @tblCompanyIds TABLE (CompanyId INT) ;	
	INSERT INTO @tblCompanyIds (CompanyId)
	SELECT distinct items FROM dbo.Split(@CompanyIds, ',');
	
	DECLARE @tblVerifiedCompanyIds TABLE (CompanyId INT) ;
	INSERT INTO @tblVerifiedCompanyIds (CompanyId)
	SELECT distinct items FROM dbo.Split(@VerifiedCompanyIds, ',')
	
	DECLARE @CompanyVerificationRequestID INT = 0;
	DECLARE @RequestNumber INT = 0; 
	
	DECLARE @CurrentDate DATETIME = GETDATE();
	
	IF @Year = 0
		BEGIN
			SET @Year = NULL;
		END
	IF @EditionId = 0 
		BEGIN
			SET @EditionId = NULL;
		END
	

	SET @RequestNumber = (SELECT COUNT(*) + 1 
						  FROM CompanyVerificationRequest 
						  WHERE 
						  (EditionId = @EditionId AND @Year IS NULL)
						  OR
						  ([Year] = @Year AND @EditionID IS NULL)
						  );

	-- insert companyVerificationRequest parent record that groups the CompanyVerifications tother
	INSERT INTO CompanyVerificationRequest (AlertId, RequestedDate, RequestedById, VerifyByDate, [Year], EditionId, RequestNumber)
	VALUES (@AlertId, @CurrentDate, @RequestedByUserId, @VerifyByDate, @Year, @EditionId, @RequestNumber)
	
	SET @CompanyVerificationRequestID = @@Identity;	
	
	-- insert companyVerifications
	INSERT INTO CompanyVerification (CompanyVerificationRequestId, CompanyId)
	SELECT @CompanyVerificationRequestID, CompanyID FROM
	@tblCompanyIds;
	
	
	
	IF (SELECT COUNT(*) FROM @tblVerifiedCompanyIds) > 0
		BEGIN
			UPDATE v 
				SET v.VerifiedById = @RequestedByUserId,
				v.VerifiedDate = @CurrentDate
			FROM 
			CompanyVerification v INNER JOIN
			@tblVerifiedCompanyIds c on v.companyid = c.companyid
		END
	
	SELECT @CompanyVerificationRequestID;	
END
GO
