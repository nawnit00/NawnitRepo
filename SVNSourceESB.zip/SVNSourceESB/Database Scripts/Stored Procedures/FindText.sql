USE [SourceESB]
GO

/****** Object:  StoredProcedure [dbo].[FindText]    Script Date: 06/13/2012 11:21:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FindText]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[FindText]
GO

USE [SourceESB]
GO

/****** Object:  StoredProcedure [dbo].[FindText]    Script Date: 06/13/2012 11:21:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[FindText]

(
    @find_text varchar(8000)
)

AS
SELECT * FROM sys.sql_modules WHERE definition LIKE '%' + @find_text + '%'

GO


