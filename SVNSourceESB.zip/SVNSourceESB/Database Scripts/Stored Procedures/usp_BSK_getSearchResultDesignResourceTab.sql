GO

/****** Object:  StoredProcedure [dbo].[usp_BSK_getSearchResultDesignResourceTab]    Script Date: 02/28/2013 21:03:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_BSK_getSearchResultDesignResourceTab]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_BSK_getSearchResultDesignResourceTab]
GO

/****** Object:  StoredProcedure [dbo].[usp_BSK_getSearchResultDesignResourceTab]    Script Date: 02/28/2013 21:03:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--Updated		  : LB on 2/28/2013 - To get manufactures order by name in facets and added facets with fullname to be used in more facets
CREATE PROCEDURE [dbo].[usp_BSK_getSearchResultDesignResourceTab]  
@SearchText  VARCHAR(80) = '',  
@ManufacturerIDs VARCHAR(MAX) = ''  
AS  

BEGIN  
	DECLARE @IsEmptyManufacturerID VARCHAR(1) = '0'  

	set transaction isolation level read uncommitted  

	DECLARE @tmpSearchText TABLE  
	(  
	search_text varchar(200)  
	)  

	INSERT INTO @tmpSearchText  
	SELECT array_data  
	FROM dbo.ReturnArray(@SearchText, ' ', NULL)  

	IF(@ManufacturerIDs='')  
	BEGIN  
	SET @IsEmptyManufacturerID = 1  
	END  

	DECLARE @tmpManufacturer TABLE  
	(  
	manufacturer_id INT  
	)  

	INSERT INTO @tmpManufacturer  
	SELECT array_data  
	FROM dbo.ReturnArray(@ManufacturerIDs, ',', NULL)  


	IF OBJECT_ID(N'tempdb..#TEMPDR', N'U') IS NOT NULL  
	DROP TABLE #TEMPDR  

	select * into #TEMPDR from  
	(  
	SELECT  DISTINCT prod.PartNumber,prod.ProductID, prod.Description as TypeDescription,  
	comp.CompanyName AS ManufacturerName,comp.CompanyID,  
	CASE WHEN ISNULL(prod.DataSheet,'') <> '' AND ISNULL(prod.DataSheetTitle,'')<> ''  
				THEN prod.DataSheetTitle  
		  WHEN ISNULL(prod.DataSheet,'') <> '' AND ISNULL(prod.DataSheetTitle,'')= ''  
				THEN 'Data Sheet'
		  WHEN ISNULL(inv.MafSpecURL,'') <> '' AND ISNULL(inv.MafSpecTitle,'')<> ''  
				THEN inv.MafSpecTitle 
		  WHEN ISNULL(inv.MafSpecURL,'') <> '' AND ISNULL(inv.MafSpecTitle,'') = ''  
				THEN 'Spec Sheet'
		 ELSE ''  
	END AS DataSheetTitle,
	CASE WHEN ISNULL(prod.DataSheet,'') <> ''  
	 THEN prod.DataSheet  
	ELSE  
	 CASE WHEN ISNULL(inv.MafSpecURL,'') <> ''  
	  THEN inv.MafSpecURL  
	 END  
	END AS DataSheetLink,  
	dbo.ufn_BSK_CommaSaparatedResourceAppType (prod.ProductID) AS AppNote,  
	dbo.ufn_BSK_CommaSaparatedResourceSoftType (prod.ProductID) AS Software,  
	prod.SampleUrl,prod.VideoFilePath,prod.ImageFilePath,MatchOrder ,prod.ProductType
	FROM (  
	  select distinct pd.*,  
	   CASE WHEN pd.Clean_PartNumber LIKE search_term.items  
		THEN '1'  
	   ELSE  
		CASE WHEN pd.Clean_PartNumber LIKE search_term.items + '_%'  
		 THEN '2'  
		ELSE  
		 CASE WHEN pd.Clean_PartNumber LIKE '_%' + search_term.items + '%'  
		  THEN '3'  
		 END  
		END  
	   END AS MatchOrder  
	  FROM  
	  (  

	   select PartNumber,ProductID, Description,  
		DataSheet,DataSheetTitle,SampleUrl,VideoFilePath,ImageFilePath,  
		Clean_PartNumber,P.ManufacturerID,pt.TypeDescription AS  ProductType
	   from product as p (nolock)
		 --added for Type description product type
			 LEFT JOIN productType_XRF ptx ON ptx.MfrProdTypeCode=P.ProductType
			LEFT JOIN ProductType pt  ON pt.ProductTypeId=ptx.ProductTypeID
			inner join @tmpSearchText as tmp  
		on p.Clean_PartNumber LIKE ('%' + tmp.search_text + '%')  

	  ) pd  
	  outer apply (SELECT * FROM Split(@SearchText,' ')) AS search_term  
		where  
		 (CASE WHEN pd.Clean_PartNumber LIKE search_term.items  
		THEN '1'  
	   ELSE  
		CASE WHEN pd.Clean_PartNumber LIKE search_term.items + '_%'  
		 THEN '2'  
		ELSE  
		 CASE WHEN pd.Clean_PartNumber LIKE '_%' + search_term.items + '%'  
		  THEN '3'  
		 END  
		END  
	   END  
	   ) <> 0  
	  ) prod  
	 INNER JOIN [dbo].[Company] comp  
	 ON prod.ManufacturerID=comp.CompanyID  
	 LEFT OUTER JOIN @tmpManufacturer as tmp  
	 on comp.CompanyID = tmp.manufacturer_id  
	 LEFT JOIN [dbo].[InventorySettings] inv  
	 ON inv.CompanyID=prod.ManufacturerID  
	 

	 
	 WHERE comp.IsActive='1'  
	 AND comp.CompanyStatusID='1'  
	 AND (tmp.manufacturer_id IS NOT NULL OR @IsEmptyManufacturerID = '1')  

	 ) as PrimaryResults  
	where (ISNULL(SampleUrl, '') <> '' OR ISNULL(VideoFilePath,'') <> ''  
	OR ISNULL(DataSheetLink,'') <> '' OR ISNULL(ImageFilePath,'') <> '' OR ISNULL(AppNote,'') <> ''  
	OR ISNULL(Software,'') <> '')  
	ORDER BY MatchOrder, PartNumber, ManufacturerName  


	IF OBJECT_ID(N'tempdb..#TEMP', N'U') IS NOT NULL  
	DROP TABLE #TEMP  
	select a.PartNumber, min(a.MatchOrder) orders,count(a.MatchOrder) counts  
	into #TEMP  
	from #TEMPDR a  
	group by a.PartNumber  

	IF OBJECT_ID(N'tempdb..#TEMPDR2', N'U') IS NOT NULL  
	DROP TABLE #TEMPDR2  
	select a.PartNumber, ProductID, TypeDescription, ManufacturerName, CompanyID,  
	DataSheetTitle, DataSheetLink, AppNote, Software, SampleURL, VideoFilePath, ImageFilePath, MatchOrder,ProductType
	into #TEMPDR2  
	from #TEMPDR a  
	join #TEMP b  
	on a.PartNumber=b.PartNumber  
	and a.matchorder=b.orders  
	ORDER BY MatchOrder,a.PartNumber, ManufacturerName DESC  

	select PartNumber, ProductID, TypeDescription, ManufacturerName, CompanyID,  
	DataSheetTitle, DataSheetLink, AppNote, Software, SampleURL, VideoFilePath, ImageFilePath, MatchOrder,ProductType
	from #TEMPDR2  

	--FACET MANUFACTURER [START]  
	SELECT  DISTINCT comp.CompanyID AS FacetValue,  
	'<span title='''+comp.ManufacturerName+'''>'+  
	CASE WHEN LEN(comp.ManufacturerName) > 16  
	 THEN SUBSTRING(comp.ManufacturerName,0,16)+ '...'  
	ELSE comp.ManufacturerName  
	END +  
	'</span>' AS FacetKey,  
	comp.ManufacturerName as CompanyName,  
	COUNT(comp.ManufacturerName) AS CountCompany  
	FROM #TEMPDR2 as comp  

	GROUP BY comp.ManufacturerName, comp.CompanyID  
	ORDER BY ManufacturerName --ORDER BY CountCompany DESC  
	  
	--FACET MANUFACTURER [END]  
	
	--FULL FACET MANUFACTURER [START]  
	SELECT  DISTINCT comp.CompanyID AS FacetValue,  
	'<span title='''+comp.ManufacturerName+'''>'+ ManufacturerName +  
	'</span>' AS FacetKey,  
	comp.ManufacturerName as CompanyName,  
	COUNT(comp.ManufacturerName) AS CountCompany  
	FROM #TEMPDR2 as comp  

	GROUP BY comp.ManufacturerName, comp.CompanyID  
	ORDER BY ManufacturerName   
	--FACET MANUFACTURER [END]  

	DROP TABLE #TEMPDR  
	DROP TABLE #TEMPDR2  
	DROP TABLE #TEMP  


END  
    

GO
