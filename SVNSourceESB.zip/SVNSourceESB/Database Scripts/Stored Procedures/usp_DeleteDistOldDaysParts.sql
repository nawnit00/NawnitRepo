/****** Object:  StoredProcedure [dbo].[usp_DeleteDistOldDaysParts]    Script Date: 10/17/2012 14:39:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_DeleteDistOldDaysParts]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_DeleteDistOldDaysParts]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_DeleteDistOldDaysParts]
	@OldDays int
AS
--DECLARE @OldDays int = 35

WHILE EXISTS ( SELECT top 1 InvID FROM DistributorParts WHERE Uploaded < dateadd(day,-@OldDays,GetDate()))
BEGIN
	DELETE TOP (10000)
	FROM DistributorParts
	WHERE Uploaded < dateadd(day,-@OldDays,GetDate())

	EXEC usp_AddInventoryUploadHistoryTraceLog 0, 'OldPartsDeleteCountFromScheduledTask', @@ROWCOUNT, 0
END

GO
