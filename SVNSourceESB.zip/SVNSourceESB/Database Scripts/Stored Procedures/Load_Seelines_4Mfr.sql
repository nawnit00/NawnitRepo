/****** Object:  StoredProcedure [dbo].[Load_Seelines_4Mfr]    Script Date: 06/28/2012 08:58:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Load_Seelines_4Mfr]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Load_Seelines_4Mfr]
GO

/****** Object:  StoredProcedure [dbo].[Load_Seelines_4Mfr]    Script Date: 06/28/2012 08:58:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:        Lalit Mehta
-- Create date: Jan 31, 2012
-- Description:    Load Seeline for Manufacturers
-- =============================================
CREATE PROCEDURE [dbo].[Load_Seelines_4Mfr]
AS
BEGIN
    TRUNCATE TABLE MFRAlsoKnownAs

    INSERT INTO MFRAlsoKnownAs
    SELECT 
        c.CompanyID,dbo.ufn_DS_Get_ManufacturerSeeLines(c.CompanyID) as AlsoKnownAs
    FROM
        Company c
        inner join CompanyTypeMapping ctm
			on c.companyID = ctm.CompanyID
			and Ctm.CompanyTypeID = 1
    SET NOCOUNT ON;
END



GO


