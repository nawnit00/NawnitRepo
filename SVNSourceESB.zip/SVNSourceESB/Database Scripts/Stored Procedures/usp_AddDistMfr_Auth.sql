/****** Object:  StoredProcedure [dbo].[usp_AddDistMfr_Auth]    Script Date: 01/17/2013 10:29:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_AddDistMfr_Auth]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_AddDistMfr_Auth]
GO

--------------------------------------------------------------------------------------------------------------
-- Created By : Fathima
-- Created On : 10-Nov-2011
-- Description : Adding manufacturer for Distributor as Authorized Mfr.
-- Arguments :
-- Returns  : None
-- Sample : [usp_AddDistMfr_Auth] 'merge three',130237,1
-- Lalbahadur on 12/18/2012 to update active flag for exiting products when inserting new products
--01.15.2013		Marcus Ruether		Set CONTEXT_INFO TO @CreatedBy userid - this is used in a change trigger to track who made a change
--------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[usp_AddDistMfr_Auth]
(
    @MfrName varchar(100),
    @DistId int,
    @CreatedBy int
)
as

SET CONTEXT_INFO @CreatedBy;

declare @MfrId int
declare @MfrDistId int

Begin Transaction
if	(select CompanyId from Company with(nolock) where CompanyName = LTRIM(RTRIM(@MfrName))) > 0
begin
set @MfrId = (select CompanyId from Company with(nolock) where CompanyName = LTRIM(RTRIM(@MfrName)) and IsActive =1)
if (select COUNT(MfrDistId) from RegionAuthorization with(nolock) where DistID = @DistId and MfrID = @MfrId) > 0
Raiserror('Already Exists',16,-1)

else
Begin
 --Inserting new record in RegionAuthorization table

insert into RegionAuthorization (MfrID,DistID,CreatedBy,CreatedOn,IsActive,Publish)
values (@MfrId,@DistId,@CreatedBy,GETDATE(),1,1)
set @MfrDistId = (select MfrDistId from RegionAuthorization with(nolock) where DistID = @DistId and MfrID = @MfrId)

--Inserting new records in RegionZoneStatus table
--SELECT RegionID,RegionName,Rank,replace(regionname, ' ', '') as newregionname FROM Region with(nolock) WHERE isActive=1 Order By Rank

select
    COUNT(zoneId) as ZoneCnt,
    C.RegionID
    into #tmpZ
from
    CountryZones Z with(nolock)
    inner join Country C with(nolock) on C.CountryID =Z.CountryID
    inner join Region R with(nolock) on R.RegionID = C.RegionID
where
    C.RegionID not in(0,2)
group by
    C.RegionID

insert into RegionZoneStatus (MfrDistID,RegionID,ZoneID,AuthStatusID)
select
    @MfrDistId,
    C.RegionID,
    ZoneID,
    1
from
    CountryZones Z with(nolock)
    inner join Country C with(nolock) on C.CountryID =Z.CountryID
    inner join #tmpZ R on R.RegionID = C.RegionID
union
select
    @MfrDistId,
    C.RegionID,
    CountryID as ZoneId,
    1
from
    Country C with(nolock)
where
    RegionID not in (select RegionID from #tmpZ)
    and RegionID not in (0,2)
union
select
    @MfrDistId,
    RegionID,
    10,
    1
from
    Region with(nolock)
where
    RegionID not in (select RegionID from #tmpZ)
    and RegionID != 0 and RegionName = 'Canada'

select
    @DistID as CompanyID,
    ProductTypeID,
    IsActive,
    CreatedBy,
    GetDate() as Createdon
    into #TempProds
from
    CompanyProductType
where
    companyid=@MfrId
    and IsActive = 1
    and ProductTypeID not in
        (select ProductTypeID from CompanyProductType where companyid=@DistID)

DECLARE @productId INT
DECLARE crProducts CURSOR FOR select distinct ProductTypeID from CompanyProductType where companyid = @MfrId and IsActive = 1

	-- Open the Cursor
	OPEN crProducts

	FETCH NEXT FROM crProducts INTO @productId
	-- Check the fetch status. If a row was fetched, enter the loop
	WHILE @@FETCH_STATUS = 0
	BEGIN
				IF NOT EXISTS(SELECT 1 FROM CompanyProductType where ProductTypeID = @productId and CompanyID = @DistId)
					INSERT INTO CompanyProductType(CompanyID,ProductTypeID,IsActive,CreatedBy,Createdon)
					select @DistID,@productId,1,1,GETDATE()
				ELSE
					UPDATE CompanyProductType
					SET IsActive = 1
					WHERE ProductTypeID = @productId and CompanyID = @DistId
					
                
	   FETCH NEXT FROM crProducts INTO @productId
	END
        
 CLOSE crProducts
 DEALLOCATE crProducts
			 
select cpt.ProductTypeID,TypeDescription,@MfrId as MfrId from #TempProds cpt
INNER JOIN ProductType pt on pt.ProductTypeId = cpt.ProductTypeID
select @MfrId

End
End
else
Raiserror('Not Valid',16,-1)

Commit Transaction
IF @@Error <> 0
BEGIN
ROLLBACK TRANSACTION
RETURN @@Error
END



GO

