/****** Object:  StoredProcedure [dbo].[usp_GetAcceptableFileTypes]    Script Date: 01/28/2013 14:40:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAcceptableFileTypes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAcceptableFileTypes]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetAcceptableFileTypes]
AS

SELECT *
FROM FileType ft
WHERE ft.IsIgnored = 0
ORDER BY ft.FileType

GO
