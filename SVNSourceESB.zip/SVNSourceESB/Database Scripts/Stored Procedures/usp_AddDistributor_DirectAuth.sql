/****** Object:  StoredProcedure [dbo].[usp_AddDistributor_DirectAuth]    Script Date: 01/16/2013 22:58:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_AddDistributor_DirectAuth]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_AddDistributor_DirectAuth]
GO

/*------------------------------------------------------------------------------------------------------------------------------------------   
History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
11.30.2011		Fathima				Created
01.15.2013		Marcus Ruether		Set CONTEXT_INFO to CreatedBy id to be used in logging trigger
									Added check to only insert records that don't already exist.
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[usp_AddDistributor_DirectAuth]
(
    @DistName varchar(100),
    @MfrId int,
    @CreatedBy int,
    @UserRole varchar(10)
)
as

SET CONTEXT_INFO @CreatedBy;

declare @DistId int
declare @MfrDistId int
declare @IsAlreadyExist bit
declare @IsUpdated bit
SET @IsUpdated = 0
SET @IsAlreadyExist = 0
Begin Transaction
    if(select CompanyId from Company with(nolock) where CompanyName = LTRIM(RTRIM(@DistName))) > 0
    begin
    set @DistId = (select CompanyId from Company with(nolock) where CompanyName = LTRIM(RTRIM(@DistName)) and IsActive =1)

    select
        COUNT(zoneId) as ZoneCnt,
        C.RegionID into #tmpZ
    from
        CountryZones Z with(nolock)
        inner join Country C with(nolock) on C.CountryID =Z.CountryID
        inner join Region R with(nolock) on R.RegionID = C.RegionID
    where
        C.RegionID not in(0,2)
    group by C.RegionID

    IF(SELECT COUNT(MfrDistId) FROM RegionAuthorization WITH(NOLOCK) WHERE DistID = @DistId and MfrID = @MfrId) > 0
    BEGIN
        IF(UPPER(@UserRole)='INTERNAL')
        BEGIN
            SET @IsAlreadyExist = 1
        END
        ELSE
        BEGIN
            IF(SELECT COUNT(*) FROM RegionZoneStatus rz with(nolock)
                    INNER JOIN RegionAuthorization ra with(nolock)
                        ON rz.MfrDistID = ra.MfrDistID
                            AND (rz.AuthStatusID=2 OR rz.AuthStatusID=4 AND UPPER(@UserRole)='EXTERNAL')
                WHERE MfrID = @mfrID AND DistID = @DistId )>= (SELECT COUNT(*) FROM #tmpZ)
            BEGIN
                SET @IsAlreadyExist=1
            END
            ELSE
            BEGIN
                SET @MfrDistId = (select MfrDistId from RegionAuthorization with(nolock) where DistID = @DistId and MfrID = @MfrId)

                UPDATE RegionZoneStatus SET
                    AuthStatusID=4
                WHERE MfrDistID=@MfrDistId
                select @DistId

                SET @IsUpdated = 1
            END
        END
    END
    ELSE
    BEGIN
        SET @IsAlreadyExist = 0
    END

    if(@IsAlreadyExist = 1)
    Raiserror('Already Exists',16,-1)
    else
    Begin
        IF (@IsUpdated = 0)
        BEGIN
            --Inserting new record in RegionAuthorization table

            insert into RegionAuthorization(MfrID,DistID,CreatedBy,CreatedOn,IsActive,Publish)
            values(@MfrId,@DistId,@CreatedBy,GETDATE(),1,1)

            set @MfrDistId = (select MfrDistId from RegionAuthorization with(nolock) where DistID = @DistId and MfrID = @MfrId)

            --Inserting new records in RegionZoneStatus table

            insert into RegionZoneStatus (MfrDistID,RegionID,ZoneID,AuthStatusID)
            select
                @MfrDistId,
                C.RegionID,
                ZoneID,4
            from
                CountryZones Z with(nolock)
                inner join Country C with(nolock) on C.CountryID =Z.CountryID
                inner join #tmpZ R on R.RegionID = C.RegionID
            union
            select
                @MfrDistId,
                C.RegionID,
                CountryID as ZoneId,
                4
            from
                Country C with(nolock)
            where
                RegionID not in (select RegionID from #tmpZ)
                and RegionID not in (0,2)
            union
            select
                @MfrDistId,
                RegionID,
                10,
                4
            from
                Region with(nolock)
            where
                RegionID not in (select RegionID from #tmpZ)
                and RegionID != 0
                and RegionName = 'Canada'

            select
                @DistID as CompanyID,
                ProductTypeID,
                IsActive,
                CreatedBy,
                GetDate() as Createdon
             into #TempProds
            from CompanyProductType
            where
                companyid=@MfrId
                and ProductTypeID
                    not in(select ProductTypeID from CompanyProductType where companyid=@DistID)

			INSERT INTO CompanyProductType(CompanyID,ProductTypeID,IsActive,CreatedBy,Createdon)       
			SELECT * FROM #TempProds

            select CompanyID,cpt.ProductTypeID,TypeDescription from #TempProds cpt
			INNER JOIN ProductType pt on pt.ProductTypeId = cpt.ProductTypeID
			SELECT @DistId AS DistId
        END
    End
End
else
Raiserror('Not Valid',16,-1)

Commit Transaction
IF @@Error <> 0
BEGIN
ROLLBACK TRANSACTION
RETURN @@Error
END


GO

