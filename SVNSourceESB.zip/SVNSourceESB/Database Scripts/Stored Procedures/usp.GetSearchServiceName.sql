GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchServiceName]    Script Date: 05/17/2012 17:08:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchServiceName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchServiceName]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchServiceName]    Script Date: 05/17/2012 17:08:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetSearchServiceName]
(
    @product_type_id INT,
    @service_name VARCHAR(100)
)

AS

--DECLARE @product_type_id INT = 168, @service_name VARCHAR(100) = 'powerboardassemblyinstallation'
IF EXISTS (
    SELECT pt.ProductTypeId, pt.TypeDescription AS ServiceName
    FROM dbo.ProductType AS pt
    WHERE pt.ProductTypeId = @product_type_id
)
BEGIN
    SELECT pt.ProductTypeId, pt.TypeDescription AS ServiceName
    FROM dbo.ProductType AS pt
    WHERE pt.ProductTypeId = @product_type_id
END
ELSE
BEGIN
    SELECT TOP 1 pt.ProductTypeId, pt.TypeDescription AS ServiceName
    FROM dbo.ProductType AS pt
    WHERE pt.IsServices = 1
        AND pt.IsActive = 1
        AND pt.StatusID = 1
        AND dbo.RemoveSpecialCharacter(pt.TypeDescription) = @service_name
    ORDER BY pt.TypeDescription
END

GO

