UPDATE ao
SET OverwriteDiscountFlag = 1
--SELECT COUNT(DISTINCT ao.AdOrderId)
FROM dbo.AdOrder AS ao
INNER JOIN dbo.AdOrderDetails AS aod
	ON ao.AdOrderId = aod.AdOrderId
WHERE ao.OverwriteDiscountFlag = 0