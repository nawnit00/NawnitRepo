If NOT 
(
	SELECT ISNULL(ft.IsDisplayed, 1)
	FROM FileType ft
	WHERE ft.FileType = '.dat'
) = 0
BEGIN
	UPDATE FileType
	SET IsDisplayed = 0
	WHERE FileType = '.dat'
END

If NOT 
(
	SELECT ISNULL(ft.IsIgnored, 1)
	FROM FileType ft
	WHERE ft.FileType = '.dat'
) = 0
BEGIN
	UPDATE FileType
	SET IsIgnored = 0
	WHERE FileType = '.dat'
END

If NOT 
(
	SELECT ISNULL(ft.IsDisplayed, 0)
	FROM FileType ft
	WHERE ft.FileType = '.xls'
) = 1
BEGIN
	UPDATE FileType
	SET IsDisplayed = 1
	WHERE FileType = '.xls'
END

If NOT 
(
	SELECT ISNULL(ft.IsIgnored, 1)
	FROM FileType ft
	WHERE ft.FileType = '.xls'
) = 0
BEGIN
	UPDATE FileType
	SET IsIgnored = 0
	WHERE FileType = '.xls'
END

If NOT 
(
	SELECT ISNULL(ft.IsDisplayed, 0)
	FROM FileType ft
	WHERE ft.FileType = '.csv'
) = 1
BEGIN
	UPDATE FileType
	SET IsDisplayed = 1
	WHERE FileType = '.csv'
END

If NOT 
(
	SELECT ISNULL(ft.IsIgnored, 1)
	FROM FileType ft
	WHERE ft.FileType = '.csv'
) = 0
BEGIN
	UPDATE FileType
	SET IsIgnored = 0
	WHERE FileType = '.csv '
END

If NOT 
(
	SELECT ISNULL(ft.IsDisplayed, 0)
	FROM FileType ft
	WHERE ft.FileType = '.txt'
) = 1
BEGIN
	UPDATE FileType
	SET IsDisplayed = 1
	WHERE FileType = '.txt'
END

If NOT 
(
	SELECT ISNULL(ft.IsIgnored, 1)
	FROM FileType ft
	WHERE ft.FileType = '.txt'
) = 0
BEGIN
	UPDATE FileType
	SET IsIgnored = 0
	WHERE FileType = '.txt'
END

If NOT 
(
	SELECT ISNULL(ft.IsDisplayed, 0)
	FROM FileType ft
	WHERE ft.FileType = '.xlsx'
) = 1
BEGIN
	UPDATE FileType
	SET IsDisplayed = 1
	WHERE FileType = '.xlsx'
END

If NOT 
(
	SELECT ISNULL(ft.IsIgnored, 1)
	FROM FileType ft
	WHERE ft.FileType = '.xlsx'
) = 0
BEGIN
	UPDATE FileType
	SET IsIgnored = 0
	WHERE FileType = '.xlsx '
END

If NOT EXISTS 
(
	SELECT *
	FROM FileType ft
	WHERE ft.FileType = '.1'
)
BEGIN
	INSERT INTO FileType
	(FileType, IsDisplayed, IsIgnored) VALUES
	('.1', 0, 0)
END

If NOT EXISTS 
(
	SELECT *
	FROM FileType ft
	WHERE ft.FileType = ''
)
BEGIN
	INSERT INTO FileType
	(FileType, IsDisplayed, IsIgnored) VALUES
	('', 0, 0)
END

If NOT EXISTS 
(
	SELECT *
	FROM FileType ft
	WHERE ft.FileType = '.jpg'
)
BEGIN
	INSERT INTO FileType
	(FileType, IsDisplayed, IsIgnored) VALUES
	('.jpg', 0, 1)
END

If NOT EXISTS 
(
	SELECT *
	FROM FileType ft
	WHERE ft.FileType = '.png'
)
BEGIN
	INSERT INTO FileType
	(FileType, IsDisplayed, IsIgnored) VALUES
	('.png', 0, 1)
END

If NOT EXISTS 
(
	SELECT *
	FROM FileType ft
	WHERE ft.FileType = '.gif'
)
BEGIN
	INSERT INTO FileType
	(FileType, IsDisplayed, IsIgnored) VALUES
	('.gif', 0, 1)
END

If NOT EXISTS 
(
	SELECT *
	FROM FileType ft
	WHERE ft.FileType = '.bmp'
)
BEGIN
	INSERT INTO FileType
	(FileType, IsDisplayed, IsIgnored) VALUES
	('.bmp', 0, 1)
END

IF NOT EXISTS (
	SELECT *
	FROM InventoryMapping im
	WHERE im.CompanyID = 105266
	AND im.FileType = ''
)
BEGIN
	IF EXISTS (
		SELECT *
		FROM InventoryMapping im
		WHERE im.CompanyID = 105266
		AND im.FileType = '.txt'
	)
	BEGIN
		INSERT INTO InventoryMapping
		(
			[CompanyID],
			[ManufacturerCode],
			[MCLength],
			[PartNumber],
			[PNLength],
			[Prefix],
			[PxLength],
			[Description],
			[DCLength],
			[QtyOnHand],
			[QOHLength],
			[Price],
			[PLength],
			[RoHS],
			[RLength],
			[SkipRows],
			[FileType],
			[IsDelimiter],
			[Delimiter],
			[TextQualifier],
			[RowLimit],
			[SheetOrTable],
			[AllowZeroQOH],
			[DeleteOLD],
			[InvEmail],
			[BatchCode],
			[BCLength],
			[BreakLevel1],
			[BL1Length],
			[Price1],
			[Pr1Length],
			[BreakLevel2],
			[BL2Length],
			[Price2],
			[Pr2Length],
			[BreakLevel3],
			[BL3Length],
			[Price3],
			[Pr3Length],
			[BreakLevel4],
			[BL4Length],
			[Price4],
			[Pr4Length],
			[BreakLevel5],
			[BL5Length],
			[Price5],
			[Pr5Length],
			[BreakLevel6],
			[BL6Length],
			[Price6],
			[Pr6Length],
			[BreakLevel7],
			[BL7Length],
			[Price7],
			[Pr7Length],
			[BreakLevel8],
			[BL8Length],
			[Price8],
			[Pr8Length],
			[BreakLevel9],
			[BL9Length],
			[Price9],
			[Pr9Length],
			[BreakLevel10],
			[BL10Length],
			[Price10],
			[Pr10Length],
			[CreatedBy],
			[CreatedOn],
			[FieldCount],
			[IsQtyTextQualified]
		)
		SELECT 
			im.[CompanyID],
			im.[ManufacturerCode],
			im.[MCLength],
			im.[PartNumber],
			im.[PNLength],
			im.[Prefix],
			im.[PxLength],
			im.[Description],
			im.[DCLength],
			im.[QtyOnHand],
			im.[QOHLength],
			im.[Price],
			im.[PLength],
			im.[RoHS],
			im.[RLength],
			im.[SkipRows],
			'',
			im.[IsDelimiter],
			im.[Delimiter],
			im.[TextQualifier],
			im.[RowLimit],
			im.[SheetOrTable],
			im.[AllowZeroQOH],
			im.[DeleteOLD],
			im.[InvEmail],
			im.[BatchCode],
			im.[BCLength],
			im.[BreakLevel1],
			im.[BL1Length],
			im.[Price1],
			im.[Pr1Length],
			im.[BreakLevel2],
			im.[BL2Length],
			im.[Price2],
			im.[Pr2Length],
			im.[BreakLevel3],
			im.[BL3Length],
			im.[Price3],
			im.[Pr3Length],
			im.[BreakLevel4],
			im.[BL4Length],
			im.[Price4],
			im.[Pr4Length],
			im.[BreakLevel5],
			im.[BL5Length],
			im.[Price5],
			im.[Pr5Length],
			im.[BreakLevel6],
			im.[BL6Length],
			im.[Price6],
			im.[Pr6Length],
			im.[BreakLevel7],
			im.[BL7Length],
			im.[Price7],
			im.[Pr7Length],
			im.[BreakLevel8],
			im.[BL8Length],
			im.[Price8],
			im.[Pr8Length],
			im.[BreakLevel9],
			im.[BL9Length],
			im.[Price9],
			im.[Pr9Length],
			im.[BreakLevel10],
			im.[BL10Length],
			im.[Price10],
			im.[Pr10Length],
			89226,
			GETDATE(),
			im.[FieldCount],
			im.[IsQtyTextQualified]
		FROM InventoryMapping im
		WHERE im.CompanyID = 105266
		AND im.FileType = '.txt'
		
	END
END

IF NOT EXISTS (
	SELECT *
	FROM InventoryMapping im
	WHERE im.CompanyID = 101118
	AND im.FileType = ''
)
BEGIN
	IF EXISTS (
		SELECT *
		FROM InventoryMapping im
		WHERE im.CompanyID = 101118
		AND im.FileType = '.txt'
	)
	BEGIN
		INSERT INTO InventoryMapping
		(
			[CompanyID],
			[ManufacturerCode],
			[MCLength],
			[PartNumber],
			[PNLength],
			[Prefix],
			[PxLength],
			[Description],
			[DCLength],
			[QtyOnHand],
			[QOHLength],
			[Price],
			[PLength],
			[RoHS],
			[RLength],
			[SkipRows],
			[FileType],
			[IsDelimiter],
			[Delimiter],
			[TextQualifier],
			[RowLimit],
			[SheetOrTable],
			[AllowZeroQOH],
			[DeleteOLD],
			[InvEmail],
			[BatchCode],
			[BCLength],
			[BreakLevel1],
			[BL1Length],
			[Price1],
			[Pr1Length],
			[BreakLevel2],
			[BL2Length],
			[Price2],
			[Pr2Length],
			[BreakLevel3],
			[BL3Length],
			[Price3],
			[Pr3Length],
			[BreakLevel4],
			[BL4Length],
			[Price4],
			[Pr4Length],
			[BreakLevel5],
			[BL5Length],
			[Price5],
			[Pr5Length],
			[BreakLevel6],
			[BL6Length],
			[Price6],
			[Pr6Length],
			[BreakLevel7],
			[BL7Length],
			[Price7],
			[Pr7Length],
			[BreakLevel8],
			[BL8Length],
			[Price8],
			[Pr8Length],
			[BreakLevel9],
			[BL9Length],
			[Price9],
			[Pr9Length],
			[BreakLevel10],
			[BL10Length],
			[Price10],
			[Pr10Length],
			[CreatedBy],
			[CreatedOn],
			[FieldCount],
			[IsQtyTextQualified]
		)
		SELECT 
			im.[CompanyID],
			im.[ManufacturerCode],
			im.[MCLength],
			im.[PartNumber],
			im.[PNLength],
			im.[Prefix],
			im.[PxLength],
			im.[Description],
			im.[DCLength],
			im.[QtyOnHand],
			im.[QOHLength],
			im.[Price],
			im.[PLength],
			im.[RoHS],
			im.[RLength],
			im.[SkipRows],
			'',
			im.[IsDelimiter],
			im.[Delimiter],
			im.[TextQualifier],
			im.[RowLimit],
			im.[SheetOrTable],
			im.[AllowZeroQOH],
			im.[DeleteOLD],
			im.[InvEmail],
			im.[BatchCode],
			im.[BCLength],
			im.[BreakLevel1],
			im.[BL1Length],
			im.[Price1],
			im.[Pr1Length],
			im.[BreakLevel2],
			im.[BL2Length],
			im.[Price2],
			im.[Pr2Length],
			im.[BreakLevel3],
			im.[BL3Length],
			im.[Price3],
			im.[Pr3Length],
			im.[BreakLevel4],
			im.[BL4Length],
			im.[Price4],
			im.[Pr4Length],
			im.[BreakLevel5],
			im.[BL5Length],
			im.[Price5],
			im.[Pr5Length],
			im.[BreakLevel6],
			im.[BL6Length],
			im.[Price6],
			im.[Pr6Length],
			im.[BreakLevel7],
			im.[BL7Length],
			im.[Price7],
			im.[Pr7Length],
			im.[BreakLevel8],
			im.[BL8Length],
			im.[Price8],
			im.[Pr8Length],
			im.[BreakLevel9],
			im.[BL9Length],
			im.[Price9],
			im.[Pr9Length],
			im.[BreakLevel10],
			im.[BL10Length],
			im.[Price10],
			im.[Pr10Length],
			89226,
			GETDATE(),
			im.[FieldCount],
			im.[IsQtyTextQualified]
		FROM InventoryMapping im
		WHERE im.CompanyID = 101118
		AND im.FileType = '.txt'
		
	END
END

IF NOT EXISTS (
	SELECT *
	FROM InventoryMapping im
	WHERE im.CompanyID = 102217
	AND im.FileType = '.1'
)
BEGIN
	IF EXISTS (
		SELECT *
		FROM InventoryMapping im
		WHERE im.CompanyID = 102217
		AND im.FileType = '.txt'
	)
	BEGIN
		INSERT INTO InventoryMapping
		(
			[CompanyID],
			[ManufacturerCode],
			[MCLength],
			[PartNumber],
			[PNLength],
			[Prefix],
			[PxLength],
			[Description],
			[DCLength],
			[QtyOnHand],
			[QOHLength],
			[Price],
			[PLength],
			[RoHS],
			[RLength],
			[SkipRows],
			[FileType],
			[IsDelimiter],
			[Delimiter],
			[TextQualifier],
			[RowLimit],
			[SheetOrTable],
			[AllowZeroQOH],
			[DeleteOLD],
			[InvEmail],
			[BatchCode],
			[BCLength],
			[BreakLevel1],
			[BL1Length],
			[Price1],
			[Pr1Length],
			[BreakLevel2],
			[BL2Length],
			[Price2],
			[Pr2Length],
			[BreakLevel3],
			[BL3Length],
			[Price3],
			[Pr3Length],
			[BreakLevel4],
			[BL4Length],
			[Price4],
			[Pr4Length],
			[BreakLevel5],
			[BL5Length],
			[Price5],
			[Pr5Length],
			[BreakLevel6],
			[BL6Length],
			[Price6],
			[Pr6Length],
			[BreakLevel7],
			[BL7Length],
			[Price7],
			[Pr7Length],
			[BreakLevel8],
			[BL8Length],
			[Price8],
			[Pr8Length],
			[BreakLevel9],
			[BL9Length],
			[Price9],
			[Pr9Length],
			[BreakLevel10],
			[BL10Length],
			[Price10],
			[Pr10Length],
			[CreatedBy],
			[CreatedOn],
			[FieldCount],
			[IsQtyTextQualified]
		)
		SELECT 
			im.[CompanyID],
			im.[ManufacturerCode],
			im.[MCLength],
			im.[PartNumber],
			im.[PNLength],
			im.[Prefix],
			im.[PxLength],
			im.[Description],
			im.[DCLength],
			im.[QtyOnHand],
			im.[QOHLength],
			im.[Price],
			im.[PLength],
			im.[RoHS],
			im.[RLength],
			im.[SkipRows],
			'.1',
			im.[IsDelimiter],
			im.[Delimiter],
			im.[TextQualifier],
			im.[RowLimit],
			im.[SheetOrTable],
			im.[AllowZeroQOH],
			im.[DeleteOLD],
			im.[InvEmail],
			im.[BatchCode],
			im.[BCLength],
			im.[BreakLevel1],
			im.[BL1Length],
			im.[Price1],
			im.[Pr1Length],
			im.[BreakLevel2],
			im.[BL2Length],
			im.[Price2],
			im.[Pr2Length],
			im.[BreakLevel3],
			im.[BL3Length],
			im.[Price3],
			im.[Pr3Length],
			im.[BreakLevel4],
			im.[BL4Length],
			im.[Price4],
			im.[Pr4Length],
			im.[BreakLevel5],
			im.[BL5Length],
			im.[Price5],
			im.[Pr5Length],
			im.[BreakLevel6],
			im.[BL6Length],
			im.[Price6],
			im.[Pr6Length],
			im.[BreakLevel7],
			im.[BL7Length],
			im.[Price7],
			im.[Pr7Length],
			im.[BreakLevel8],
			im.[BL8Length],
			im.[Price8],
			im.[Pr8Length],
			im.[BreakLevel9],
			im.[BL9Length],
			im.[Price9],
			im.[Pr9Length],
			im.[BreakLevel10],
			im.[BL10Length],
			im.[Price10],
			im.[Pr10Length],
			89226,
			GETDATE(),
			im.[FieldCount],
			im.[IsQtyTextQualified]
		FROM InventoryMapping im
		WHERE im.CompanyID = 102217
		AND im.FileType = '.txt'
		
	END
END

IF NOT EXISTS (
	SELECT *
	FROM InventoryMapping im
	WHERE im.CompanyID = 100001
	AND im.FileType = ''
)
BEGIN
	IF EXISTS (
		SELECT *
		FROM InventoryMapping im
		WHERE im.CompanyID = 100001
		AND im.FileType = '.txt'
	)
	BEGIN
		INSERT INTO InventoryMapping
		(
			[CompanyID],
			[ManufacturerCode],
			[MCLength],
			[PartNumber],
			[PNLength],
			[Prefix],
			[PxLength],
			[Description],
			[DCLength],
			[QtyOnHand],
			[QOHLength],
			[Price],
			[PLength],
			[RoHS],
			[RLength],
			[SkipRows],
			[FileType],
			[IsDelimiter],
			[Delimiter],
			[TextQualifier],
			[RowLimit],
			[SheetOrTable],
			[AllowZeroQOH],
			[DeleteOLD],
			[InvEmail],
			[BatchCode],
			[BCLength],
			[BreakLevel1],
			[BL1Length],
			[Price1],
			[Pr1Length],
			[BreakLevel2],
			[BL2Length],
			[Price2],
			[Pr2Length],
			[BreakLevel3],
			[BL3Length],
			[Price3],
			[Pr3Length],
			[BreakLevel4],
			[BL4Length],
			[Price4],
			[Pr4Length],
			[BreakLevel5],
			[BL5Length],
			[Price5],
			[Pr5Length],
			[BreakLevel6],
			[BL6Length],
			[Price6],
			[Pr6Length],
			[BreakLevel7],
			[BL7Length],
			[Price7],
			[Pr7Length],
			[BreakLevel8],
			[BL8Length],
			[Price8],
			[Pr8Length],
			[BreakLevel9],
			[BL9Length],
			[Price9],
			[Pr9Length],
			[BreakLevel10],
			[BL10Length],
			[Price10],
			[Pr10Length],
			[CreatedBy],
			[CreatedOn],
			[FieldCount],
			[IsQtyTextQualified]
		)
		SELECT 
			im.[CompanyID],
			im.[ManufacturerCode],
			im.[MCLength],
			im.[PartNumber],
			im.[PNLength],
			im.[Prefix],
			im.[PxLength],
			im.[Description],
			im.[DCLength],
			im.[QtyOnHand],
			im.[QOHLength],
			im.[Price],
			im.[PLength],
			im.[RoHS],
			im.[RLength],
			im.[SkipRows],
			'',
			im.[IsDelimiter],
			im.[Delimiter],
			im.[TextQualifier],
			im.[RowLimit],
			im.[SheetOrTable],
			im.[AllowZeroQOH],
			im.[DeleteOLD],
			im.[InvEmail],
			im.[BatchCode],
			im.[BCLength],
			im.[BreakLevel1],
			im.[BL1Length],
			im.[Price1],
			im.[Pr1Length],
			im.[BreakLevel2],
			im.[BL2Length],
			im.[Price2],
			im.[Pr2Length],
			im.[BreakLevel3],
			im.[BL3Length],
			im.[Price3],
			im.[Pr3Length],
			im.[BreakLevel4],
			im.[BL4Length],
			im.[Price4],
			im.[Pr4Length],
			im.[BreakLevel5],
			im.[BL5Length],
			im.[Price5],
			im.[Pr5Length],
			im.[BreakLevel6],
			im.[BL6Length],
			im.[Price6],
			im.[Pr6Length],
			im.[BreakLevel7],
			im.[BL7Length],
			im.[Price7],
			im.[Pr7Length],
			im.[BreakLevel8],
			im.[BL8Length],
			im.[Price8],
			im.[Pr8Length],
			im.[BreakLevel9],
			im.[BL9Length],
			im.[Price9],
			im.[Pr9Length],
			im.[BreakLevel10],
			im.[BL10Length],
			im.[Price10],
			im.[Pr10Length],
			89226,
			GETDATE(),
			im.[FieldCount],
			im.[IsQtyTextQualified]
		FROM InventoryMapping im
		WHERE im.CompanyID = 100001
		AND im.FileType = '.txt'
		
	END
END