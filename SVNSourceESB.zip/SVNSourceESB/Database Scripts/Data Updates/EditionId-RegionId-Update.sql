--Editions Script main can be done like this
update AdOrderDetailsRegionEdition  set EditionID = 0 
from AdOrderDetailsRegionEdition ADR, AdOrderDetails AD
where ADR.AdOrderDetailsId = AD.AdOrderDetailsId and ADR.EditionID IS NULL and      
      AD.OrderType = 'O'

--Editions for Revision Table
UPDATE AdOrderDetailsRegionEditionRevision  SET EditionID = 0
      FROM AdOrderDetailsRegionEditionRevision ADR 
      INNER JOIN AdOrderDetailsRevision AD ON ADR.AdOrderDetailsId = AD.AdOrderDetailsId 
      and ADR.AdOrderRevisionId = AD.AdOrderRevisionId
      and ADR.EditionID IS NULL and AD.OrderType = 'O'

--Canada Script main 
update AdOrderDetails set OrderRegionId = case when OrderRegionId = '' THEN '2' 
      ELSE CASE WHEN OrderRegionId = '1' THEN '1,2' END END 
      from AdorderDetails AD, AdOrderDetailsRegionEdition ADR where ADR.AdOrderDetailsId = AD.AdOrderDetailsId and RegionID = 10
      and AD.OrderType = 'O'
      
--Canada Script Revision Table
update AdOrderDetailsRevision set OrderRegionId = case when OrderRegionId = '' THEN '2' ELSE CASE WHEN OrderRegionId = '1' THEN '1,2' END END
from AdOrderDetailsRevision ADR
INNER JOIN AdOrderDetailsRegionEditionRevision ADRE on ADR.AdOrderDetailsId = ADRE.AdOrderDetailsId and ADR.AdOrderRevisionId = ADRE.AdOrderRevisionId
and ADRE.RegionID = 10  and ADR.OrderType = 'O'
