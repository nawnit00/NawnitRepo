IF EXISTS
(
	SELECT *
	FROM FileType ft
	WHERE ft.FileType = '.dbf'
)
BEGIN
	DELETE FileType
	WHERE FileType = '.dbf'
END
GO

IF NOT EXISTS
(
	SELECT *
	FROM FileType ft
	WHERE ft.FileType = '.dat'
)
BEGIN
	INSERT INTO FileType (FileType)
	VALUES( '.dat')
END
GO