--/****** Object:  Table [ManufacturerCode_XRF]    Script Date: 03/04/2013 10:33:34 ******/

-- THIS FIRST STEP IS ONLY NEEDED ONCE< THEN IT SHOULD BE REMOVED
DELETE xrf
FROM ManufacturerCode_XRF xrf
WHERE xrf.DistributorId IN (108830, 135192)
	AND xrf.ManufacturerCode = 'ALPHA'
	AND xrf.ManufacturerId <> (100322)

DECLARE @tmpMfrCode TABLE
(
	DistributorId INT,
	ManufacturerId INT,
	ManufacturerCode VARCHAR(250)
)

INSERT INTO @tmpMfrCode
SELECT xrf.DistributorId, xrf.ManufacturerCode, xrf.ManufacturerId
FROM ManufacturerCode_XRF xrf
GROUP BY xrf.DistributorId, xrf.ManufacturerCode, xrf.ManufacturerId
HAVING COUNT(*) > 1

DECLARE @tmpExcludeMfrCode TABLE
(
	ManufacturerCodeId INT
)

INSERT INTO @tmpExcludeMfrCode
SELECT MIN(xrf.ManufacturerCodeId)
FROM ManufacturerCode_XRF xrf
INNER JOIN @tmpMfrCode t
	ON xrf.DistributorId = t.DistributorId
	AND xrf.ManufacturerId = t.ManufacturerId
	AND xrf.ManufacturerCode = t.ManufacturerCode
GROUP BY xrf.DistributorId, xrf.ManufacturerId, xrf.ManufacturerCode

DELETE xrf
--SELECT *
FROM ManufacturerCode_XRF xrf
INNER JOIN @tmpMfrCode t
	ON xrf.DistributorId = t.DistributorId
	AND xrf.ManufacturerId = t.ManufacturerId
	AND xrf.ManufacturerCode = t.ManufacturerCode
LEFT OUTER JOIN @tmpExcludeMfrCode ex
	ON xrf.ManufacturerCodeId = ex.ManufacturerCodeId
WHERE ex.ManufacturerCodeId IS NULL

DECLARE @tmpMfrCode2 TABLE
(
	DistributorId INT,
	ManufacturerCode VARCHAR(250)
)

INSERT INTO @tmpMfrCode2
SELECT xrf.DistributorId, xrf.ManufacturerCode
FROM ManufacturerCode_XRF xrf
INNER JOIN Company D
	ON xrf.DistributorId = D.CompanyID
INNER JOIN Company M
	ON xrf.ManufacturerId = M.CompanyID
GROUP BY xrf.DistributorId, xrf.ManufacturerCode
HAVING COUNT(*) > 1

DECLARE @tmpExcludeMfrCode2 TABLE
(
	ManufacturerCodeId INT
)
INSERT INTO @tmpExcludeMfrCode2
SELECT DISTINCT xrf.ManufacturerCodeId
FROM ManufacturerCode_XRF xrf
INNER JOIN @tmpMfrCode t
	ON xrf.DistributorId = t.DistributorId
	AND xrf.ManufacturerId = t.ManufacturerId
	AND xrf.ManufacturerCode = t.ManufacturerCode

DELETE xrf
--SELECT xrf.*, D.IsActive, D.CompanyStatusID, M.IsActive, M.CompanyStatusID
FROM ManufacturerCode_XRF xrf
INNER JOIN Company D
	ON xrf.DistributorId = D.CompanyID
INNER JOIN Company M
	ON xrf.ManufacturerId = M.CompanyID
INNER JOIN @tmpMfrCode2 t2
	ON xrf.DistributorId = t2.DistributorId
	AND xrf.ManufacturerCode = t2.ManufacturerCode
LEFT OUTER JOIN @tmpExcludeMfrCode2 ex2
	ON xrf.ManufacturerCodeId = ex2.ManufacturerCodeId
WHERE ex2.ManufacturerCodeId IS NULL
	AND M.CompanyStatusID = 2
--ORDER BY xrf.DistributorId, xrf.ManufacturerCode

/****** Object:  Index [IX_ManuCode_DistributorID]    Script Date: 03/04/2013 10:33:34 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[ManufacturerCode_XRF]') AND name = N'IX_ManuCode_DistributorID')
DROP INDEX [IX_ManuCode_DistributorID] ON [dbo].[ManufacturerCode_XRF] WITH ( ONLINE = OFF )
GO

CREATE UNIQUE NONCLUSTERED INDEX [IX_ManuCode_DistributorID] ON [dbo].[ManufacturerCode_XRF] 
(
	[DistributorId] ASC,
	[ManufacturerCode] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
