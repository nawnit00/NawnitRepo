IF NOT EXISTS(SELECT * FROM Menu WHERE MenuName = 'Inventory Upload History New Parts')
BEGIN
	DECLARE @MaxMenuId Int
	SELECT @MaxMenuId = MAX(MenuId)+1 
	FROM Menu   

	INSERT INTO Menu (MenuID, MenuParentID, MenuName, MenuUrl, MenuLevel, MenuOrder, MenuType, MenuIsActive, SuperAdminVisible,BreadCrumLevel,VisibleInMenu,ShowInSiteMap)
	VALUES (@MaxMenuId, 12,	'Inventory Upload History New Parts',	'~/Reports/Crystalrptviewer.aspx?rpt=InventoryUploadHistoryNew',40,5,'C',1,1,3,0,1)
	
	INSERT INTO Privilege (PrivilegeRoleTypeID,PrivilegeMenuID, PrivilegeIsActive) VALUES (1, @MaxMenuId, 1)		

	INSERT INTO ReportTypeMapping VALUES (1, @MaxMenuId)
END
