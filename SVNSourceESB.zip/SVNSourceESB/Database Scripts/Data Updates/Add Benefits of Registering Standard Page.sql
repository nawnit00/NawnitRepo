IF NOT EXISTS (
	SELECT *
	FROM StandardPages sp
	WHERE sp.PageName = 'Benefits of Registering'
)
BEGIN
	EXEC dbo.usp_AddStandardPages 'Benefits of Registering', '<p>   <strong>Register for your free SourceESB.com account to:</strong></p>  <ul>   <li>    Send single or multiple RFQ&#39;s</li>   <li>    Use the &quot;NEW&quot; Multiple Part Search Feature</li>   <li>    Save your favorite companies</li>   <li>    Save your Bill of Materials for future use</li>   <li>    and much more!</li>  </ul>  <p>   <a href="../Users/UserRegistration.aspx">Register</a> here.</p>',
	  	1, 'None', 89226, 'benefitsofregistering'
END