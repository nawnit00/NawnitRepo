IF (SELECT @@SERVERNAME) IN ('KSOPDEVSQL02', 'KSOPTESTSQL02')
BEGIN

	DECLARE @tmpUsers TABLE
	(
		user_id INT,
		first_name VARCHAR(100),
		last_name VARCHAR(100)
	)

	INSERT INTO @tmpUsers
	SELECT u.UserID, u.FirstName, u.LastName
	FROM [User] u
	WHERE (u.FirstName = 'Coleen' AND u.LastName = 'Batten')
		OR (u.FirstName = 'Bill' AND u.LastName = 'Baumann')
		OR (u.FirstName = 'Don' AND u.LastName = 'Bolick')
		OR (u.FirstName = 'Tina' AND u.LastName = 'Cavano')
		OR (u.FirstName = 'Christina' AND u.LastName = 'Cavano')
		OR (u.FirstName = 'Pamela' AND u.LastName = 'D''Aliesio')
		OR (u.FirstName = 'John' AND u.LastName = 'Mangiola')
		OR (u.FirstName = 'Molly' AND u.LastName = 'O Spring')
		OR (u.FirstName = 'Kathy' AND u.LastName = 'Perrin')
		OR (u.FirstName = 'Molly' AND u.LastName = 'Spring')
		OR (u.FirstName = 'Casey' AND u.LastName = 'Sparks')
		OR (u.FirstName = 'Jann' AND u.LastName = 'Weeden')
	ORDER BY u.LastName
	
	DELETE ur
	FROM @tmpUsers tmpU
	INNER JOIN [User] u
		ON tmpU.user_id = u.UserID
	INNER JOIN UserRole ur
		ON U.UserID = ur.UserID
	--Do NOT delete Salesperson role because it will effect report paramter population
	WHERE ur.RoleID <> 7
END