DECLARE @menuID INT = 0

SELECT @menuID = m.MenuID
FROM dbo.Menu AS m
WHERE m.MenuName = 'Distributors with Inventory Button'

IF @menuID = 0
BEGIN
	SELECT @menuID = m.MenuID + 1
	FROM dbo.Menu AS m
	ORDER BY m.MenuID DESC

	INSERT INTO dbo.Menu (MenuID, MenuParentID, MenuName,MenuUrl, MenuLevel, MenuOrder,MenuType, MenuIsActive,SuperAdminVisible, 
							BreadCrumLevel,VisibleInMenu, ShowInSiteMap,SiteMapLevel, CompanyTypeAccess,MenuHeadUrl, ButtonText)
	VALUES  (@menuID, 12,	'Distributors with Inventory Button', '~/Reports/Crystalrptviewer.aspx?rpt=DistributorsWithInventoryButtonRpt',	40,	5,	'C',	1,	1,	3,	0,	1,	NULL,	NULL,	NULL,	NULL)

	INSERT INTO dbo.ReportTypeMapping (ReportTypeID, ReportID)
	VALUES  (1, @menuID)

	INSERT INTO dbo.Privilege (PrivilegeRoleTypeID,PrivilegeMenuID,PrivilegeIsActive, CompanyTypeID)
	VALUES(1, @menuID, 1, NULL)
	INSERT INTO dbo.Privilege (PrivilegeRoleTypeID,PrivilegeMenuID,PrivilegeIsActive, CompanyTypeID)
	VALUES(3, @menuID, 1, NULL)
	INSERT INTO dbo.Privilege (PrivilegeRoleTypeID,PrivilegeMenuID,PrivilegeIsActive, CompanyTypeID)
	VALUES(4, @menuID, 1, NULL)
	INSERT INTO dbo.Privilege (PrivilegeRoleTypeID,PrivilegeMenuID,PrivilegeIsActive, CompanyTypeID)
	VALUES(5, @menuID, 1, NULL)
	INSERT INTO dbo.Privilege (PrivilegeRoleTypeID,PrivilegeMenuID,PrivilegeIsActive, CompanyTypeID)
	VALUES(7, @menuID, 1, NULL)
	INSERT INTO dbo.Privilege (PrivilegeRoleTypeID,PrivilegeMenuID,PrivilegeIsActive, CompanyTypeID)
	VALUES(8, @menuID, 1, NULL)
	INSERT INTO dbo.Privilege (PrivilegeRoleTypeID,PrivilegeMenuID,PrivilegeIsActive, CompanyTypeID)
	VALUES(9, @menuID, 1, NULL)
	INSERT INTO dbo.Privilege (PrivilegeRoleTypeID,PrivilegeMenuID,PrivilegeIsActive, CompanyTypeID)
	VALUES(10, @menuID, 1, NULL)
	INSERT INTO dbo.Privilege (PrivilegeRoleTypeID,PrivilegeMenuID,PrivilegeIsActive, CompanyTypeID)
	VALUES(11, @menuID, 1, NULL)
	INSERT INTO dbo.Privilege (PrivilegeRoleTypeID,PrivilegeMenuID,PrivilegeIsActive, CompanyTypeID)
	VALUES(12, @menuID, 1, NULL)
	INSERT INTO dbo.Privilege (PrivilegeRoleTypeID,PrivilegeMenuID,PrivilegeIsActive, CompanyTypeID)
	VALUES(13, @menuID, 1, NULL)
END


