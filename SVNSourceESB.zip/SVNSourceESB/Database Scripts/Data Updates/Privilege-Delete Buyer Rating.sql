DELETE p
from privilege as p
where p.PrivilegeMenuID = 7