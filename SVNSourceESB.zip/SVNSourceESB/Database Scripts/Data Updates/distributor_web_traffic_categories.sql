if not exists (select * from  distributor_web_traffic_categories DWTC where 
DWTC.category = 'Make Favorite')

begin	
	insert into distributor_web_traffic_categories values (19, 'Make Favorite')
end


