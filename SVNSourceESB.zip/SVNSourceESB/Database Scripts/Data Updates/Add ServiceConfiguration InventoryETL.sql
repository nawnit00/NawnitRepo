IF NOT EXISTS 
(
	SELECT *
	FROM dbo.ServiceConfiguration AS sc
	WHERE sc.ServiceName = 'InventoryETL'
		AND sc.ConfigurationName = 'ProcessInventory'
)

INSERT INTO dbo.ServiceConfiguration (ServiceName, ConfigurationName,ConfigurationValue)
VALUES  ( 'InventoryETL','ProcessInventory','True')

GO
