-- SalesSizeType Table -------------------------------------------------------------------------------------------------------------------- 
		UPDATE SalesSizeType SET [Description] = 'Enhanced Listing' WHERE [Description] = 'Core' and SizeCodeName = 'P' and MSGCode = 'PKG';
		UPDATE SalesSizeType SET [Description] = 'Manufacturer Logo' WHERE [Description] = 'Manufacaturer Logo'
		GO
-------------------------------------------------------------------------------------------------------------------------------------------
