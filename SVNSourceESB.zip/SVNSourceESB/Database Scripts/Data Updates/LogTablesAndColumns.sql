
truncate table MstLogTable;
GO

truncate table MstLogTableColumns;
GO


-- MstLogTable Table ----------------------------------------------------------------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM dbo.MstLogTable WHERE LogTableName = 'CompanyLocations')
BEGIN
	INSERT INTO dbo.MstLogTable VALUES ('CompanyLocations')
	DECLARE @CompanyLocationsLogTableId INT = SCOPE_IDENTITY()  
	
	INSERT INTO dbo.MstLogTableColumns
	SELECT @CompanyLocationsLogTableId, items 
	FROM dbo.split('LocationId,CompanyID,LocationStatusID,Address1,Address2,City,StateID,Zip,RegionID,CountryID,DoNotPublishIndicator,LocationTypeID,PrimaryLocationIndicator,Phone,Phone2,Fax,Fax2,EMail,Comments,IsActive,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn,TollFreeNo', ',')
END

GO

IF NOT EXISTS(SELECT * FROM dbo.MstLogTable WHERE LogTableName = 'Company')
BEGIN
	INSERT INTO dbo.MstLogTable VALUES ('Company')
	DECLARE @CompanyLogTableId INT = SCOPE_IDENTITY()  
	 
	INSERT INTO dbo.MstLogTableColumns
	SELECT @CompanyLogTableId, items 
	FROM dbo.split('CompanyId,CompanyName,CompanyDescription,Abbreviation,CompanyStatusID,CompanyLogo,Address,City,StateID,CountryID,Zip,EMail,SICCode,NAICSCode,BookName,URL,AssocLogos1,AssocLogos2,AssocLogos3,AssocLogos4,AssocLogos5,SearchName,ProductLine,SpecialHandling,SpecialHandlingInstruction,Comment,Advertiser,SalesPerson,InactivationTimestamp,ApprovedTimeStamp,IsActive,SeeLine,AllowInventoryUpload,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn,AssocLogos6,Trusted_Disty,NoAuthClaims,MSGIDNo,EstYearID,NoOfEmployyes,keywords,SeeLineID,BrandCode,Verified,Clean_CompanyName,Clean_BookName,Clean_keywords', ',')
END 

GO

IF NOT EXISTS(SELECT * FROM dbo.MstLogTable WHERE LogTableName = 'CompanyProductType')
BEGIN
	INSERT INTO dbo.MstLogTable VALUES ('CompanyProductType')
	DECLARE @CompanyProductTypeLogTableId INT = SCOPE_IDENTITY()  
	 
	INSERT INTO dbo.MstLogTableColumns
	SELECT @CompanyProductTypeLogTableId, items 
	FROM dbo.split('CompProdTypeID,CompanyID,ProductTypeID,IsApproved,IsActive,CreatedOn,CreatedBy,UpdatedOn,UpdatedBy', ',')
END 

GO

IF NOT EXISTS(SELECT * FROM dbo.MstLogTable WHERE LogTableName = 'VendorServiceMapping')
BEGIN
	INSERT INTO dbo.MstLogTable VALUES ('VendorServiceMapping')
	DECLARE @VendorServiceMappingLogTableId INT = SCOPE_IDENTITY()  
	 
	INSERT INTO dbo.MstLogTableColumns
	SELECT @VendorServiceMappingLogTableId, items 
	FROM dbo.split('VSMID,VendorID,ServiceID,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn', ',')
END 

GO

IF NOT EXISTS(SELECT * FROM dbo.MstLogTable WHERE LogTableName = 'RegionAuthorization')
BEGIN
	INSERT INTO dbo.MstLogTable VALUES ('RegionAuthorization')
	DECLARE @RegionAuthorizationLogTableId INT = SCOPE_IDENTITY()  
	 
	INSERT INTO dbo.MstLogTableColumns
	SELECT @RegionAuthorizationLogTableId, items 
	FROM dbo.split('MfrDistID,MfrID,DistID,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn,IsActive,Publish', ',')
END 

GO

IF NOT EXISTS(SELECT * FROM dbo.MstLogTable WHERE LogTableName = 'RegionZoneStatus')
BEGIN
	INSERT INTO dbo.MstLogTable VALUES ('RegionZoneStatus')
	DECLARE @RegionZoneStatusLogTableId INT = SCOPE_IDENTITY()  
	 
	INSERT INTO dbo.MstLogTableColumns
	SELECT @RegionZoneStatusLogTableId, items 
	FROM dbo.split('ZoneKeyID,MfrDistID,RegionID,ZoneID,AuthStatusID,Authorized_Date,Denied_Date,Online_Amount,Print_Amount', ',')
END 

IF NOT EXISTS(SELECT * FROM dbo.MstLogTable WHERE LogTableName = 'Reps')
BEGIN
	INSERT INTO dbo.MstLogTable VALUES ('Reps')
	DECLARE @RepsLogTableId INT = SCOPE_IDENTITY()  
	 
	INSERT INTO dbo.MstLogTableColumns
	SELECT @RepsLogTableId, items 
	FROM dbo.split('RepID,CompanyID,ContactName,Address,City,StateID,CountryID,Zip,Phone,Fax,Email,Website,IsActive,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn', ',')
END 

IF NOT EXISTS(SELECT * FROM dbo.MstLogTable WHERE LogTableName = 'CompanyOwnershipMapping')
BEGIN
	INSERT INTO dbo.MstLogTable VALUES ('CompanyOwnershipMapping')
	DECLARE @CompanyOwnershipMappingLogTableId INT = SCOPE_IDENTITY()  
	 
	INSERT INTO dbo.MstLogTableColumns
	SELECT @CompanyOwnershipMappingLogTableId, items 
	FROM dbo.split('COSMAPID,CompanyID,OwnershipID,ISOCertified,ISORegistered', ',')
END 

IF NOT EXISTS(SELECT * FROM dbo.MstLogTable WHERE LogTableName = 'CompanyTypeMapping')
BEGIN
	INSERT INTO dbo.MstLogTable VALUES ('CompanyTypeMapping')
	DECLARE @CompanyTypeMappingLogTableId INT = SCOPE_IDENTITY()  
	 
	INSERT INTO dbo.MstLogTableColumns
	SELECT @CompanyTypeMappingLogTableId, items 
	FROM dbo.split('CTMID,CompanyID,CompanyTypeID', ',')
END 
------------


