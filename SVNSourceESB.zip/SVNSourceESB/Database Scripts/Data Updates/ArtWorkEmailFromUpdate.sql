GO

IF NOT EXISTS (SELECT * FROM [INFORMATION_SCHEMA].[COLUMNS]
		WHERE TABLE_NAME = 'Alerts' AND COLUMN_NAME = 'EmailFromAddress')
	BEGIN
		ALTER TABLE Alerts ADD EmailFromAddress varchar(100);
	END

GO

UPDATE Alerts SET EmailFromAddress = 'ESBArt@sourceesb.com' WHERE AlertID IN (29,30,31,32,33);

GO