--Changes the value of ReportTypeID  Ticket #23259
declare @type_id int

select @type_id = rtm.ReportTypeID
from ReportTypeMapping rtm
inner join Menu m 
	on m.MenuID = rtm.ReportID
where m.MenuName = 'Online Sales Report'

if @type_id <> 3
begin
PRINT 'INSIDE IF STMT'
	update ReportTypeMapping
	set ReportTypeID = 3
	FROM ReportTypeMapping rtm
	INNER JOIN Menu m 
		on m.MenuID = rtm.ReportID
	where m.MenuName = 'Online Sales Report'
end
else
begin
	PRINT 'Rtype = 3'
end

if not exists (select  *  from Menu m
inner join ReportTypeMapping rtm  on m.MenuID = rtm.ReportID 
Where m.MenuName = 'Advertiser Order breakup revenue' 
AND rtm.ReportTypeID = 2
)
begin
insert into ReportTypeMapping (ReportID, ReportTypeID)
select  m.MenuID , 2
from Menu m
Where m.MenuName = 'Advertiser Order breakup revenue' 
end

