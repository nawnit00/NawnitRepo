/****** Object:  View [dbo].[vw_distributor_part_stats]    Script Date: 01/16/2012 12:56:00 ******/
IF EXISTS ( SELECT  *
            FROM    sys.views
            WHERE   object_id = OBJECT_ID(N'[dbo].[vw_distributor_part_stats]') ) 
   DROP VIEW [dbo].[vw_distributor_part_stats]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_distributor_part_stats]
AS
	SELECT   dp.DistID, d.CompanyName,
		MIN(dp.Uploaded) AS oldest_part,
		MAX(dp.Uploaded) AS newest_part,
		CASE InvS.deleteOLDInv 
			WHEN 1 THEN 'Yes'
			ELSE 'No'
		END AS purge_old_inventory,
		CASE 
			WHEN InvS.AllowZeroQOH = 1 THEN 'Yes'
			ELSE 'No'
		END AS show_zero_quantity,
		CASE InvS.donotpub 
			WHEN 0 THEN 'Yes'
			ELSE 'No'
		END AS show_in_search,
		SUM
		(
			CASE 
				WHEN smx.manufacturercodeid IS NOT NULL THEN 1
				ELSE 0
			END
		) AS parts_with_manufacturer,
		SUM
		(
			CASE dp.QtyOnHand 
				WHEN 0 THEN 1
				ELSE 0
			END
		) AS zero_quantity_parts,
		COUNT(*) AS total_parts,
		InvS.MaxRecords AS limit
	FROM dbo.DistributorParts AS dp (NOLOCK)
	INNER JOIN dbo.Company AS d (NOLOCK)
		ON dp.DistID = d.CompanyID
	INNER JOIN dbo.InventorySettings AS InvS (NOLOCK)
		ON d.CompanyID = InvS.CompanyID
	LEFT OUTER JOIN dbo.ManufacturerCode_XRF AS smx (NOLOCK)
		ON dp.DistID = smx.DistributorId
		AND dp.ManufacturerCode = smx.ManufacturerCode
	GROUP BY dp.DistID, d.CompanyName, InvS.DeleteOLDInv, InvS.AllowZeroQOH, InvS.DoNotPub, InvS.MaxRecords  

GO
