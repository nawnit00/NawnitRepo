/****** Object:  StoredProcedure [dbo].[ReloadDistributorPartsClean]    Script Date: 01/18/2013 22:51:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReloadDistributorPartsClean]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[ReloadDistributorPartsClean]
GO

/****** Object:  StoredProcedure [dbo].[usp_EndInventoryUploadHistory]    Script Date: 11/21/2012 14:37:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_EndInventoryUploadHistory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_EndInventoryUploadHistory]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_EndInventoryUploadHistory]
	@InventoryUploadHistoryId int,
	@MappingId int,
	@FileType varchar(50)
AS

--DECLARE	@InventoryUploadHistoryId INT = 18181, @MappingId INT = 18180, @FileType varchar(50) = '.csv'

BEGIN
	DECLARE @Errors VARCHAR(MAX) = '';

	UPDATE [InventoryUploadHistory]
		   SET 
			MappingId = @MappingId,
			FileType = @FileType
	WHERE InventoryUploadHistoryId = @InventoryUploadHistoryId;
    
	DECLARE @file_line_cnt INT = 0
	SELECT @file_line_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'FileLineCount';

	UPDATE h
	SET FileLineCount = @file_line_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
    
	DECLARE @upload_cnt INT = 0
	SELECT @upload_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'BulkInsertCount';

	UPDATE h
	SET FileInventoryCount = @upload_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @invalid_part_num_cnt INT = 0
	SELECT @invalid_part_num_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'InvalidPartNumberFieldCount';

	UPDATE h
	SET InvalidPartNumberFieldCount = @invalid_part_num_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId

	DECLARE @invalid_cnt INT = 0
	SELECT @invalid_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'InvalidQtyFieldCount';

	UPDATE h
	SET InvalidQtyFieldCount = @invalid_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId

	DECLARE @zero_qty_cnt INT = 0
	SELECT @zero_qty_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'ZeroQtyFieldCount';

	UPDATE h
	SET ZeroQtyFieldCount = @zero_qty_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId

	DECLARE @invalid_price_break_cnt INT = 0
	SELECT @invalid_price_break_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'InvalidPriceBreakFieldCount';

	UPDATE h
	SET InvalidPriceBreakFieldCount = @invalid_price_break_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @over_limit_cnt INT = 0
	SELECT @over_limit_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'OverLimitCount';

	UPDATE h
	SET OverLimitCount = @over_limit_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @duplicate_cnt INT = 0
	SELECT @duplicate_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'DuplicateRecordCount';

	UPDATE h
	SET DuplicateCount = @duplicate_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @updated_cnt INT = 0
	SELECT @updated_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'UpdatedCount';

	UPDATE h
	SET UpdatedCount = @updated_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @inserted_cnt INT = 0
	SELECT @inserted_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'InsertedCount';

	UPDATE h
	SET InsertedCount = @inserted_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @start DATETIME
	SELECT @start = MAX(CAST(tl.Message AS DATETIME))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId 
		AND tl.[Name] = 'Inventory Load Started';

	DECLARE @end DATETIME
	SELECT @end = MAX(CAST(tl.Message AS DATETIME))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId 
		AND tl.[Name] = 'Inventory Load Completed';

	UPDATE h
	SET ProcessTime = CONVERT(varchar,(@end - @start), 108)
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId

	SELECT 
		@Errors = COALESCE(@Errors + ', ', '') + [Message] 
	FROM
		InventoryUploadHistoryTraceLog
	WHERE	
		InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		IsError = 1
		
	IF LEN(@Errors) > 0
		BEGIN
			UPDATE [InventoryUploadHistory]
			SET 
				ErrorMessage = SUBSTRING(@Errors, 1, 8000),
				HasError = 1
			WHERE 
				InventoryUploadHistoryId = @InventoryUploadHistoryId;
		END
    
    
END

GO

/****** Object:  StoredProcedure [dbo].[usp_GetAllPartSearchDistOrder]    Script Date: 03/01/2013 12:35:03 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAllPartSearchDistOrder]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAllPartSearchDistOrder]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[usp_GetAllPartSearchDistOrder]
    @REGIONID varchar(100) = '',
    @IsFilterByRegion VARCHAR(10) = '0',
    @Preferences VARCHAR(MAX) = '', -- Comma seperated list of [MstCompanyOwnership] Ids
    @Distributors VARCHAR(MAX) = '', -- Comma Seperated list of Distributor CompanyIds
    @PriceMin DECIMAL = -1,
    @PriceMax DECIMAL = -1,
    @Quantity INT = 0,
    @Authorized BIT = 0, -- If zero, ignore, if 1 then restrict to authorized distributors only    
    @MFRID1 varchar(100) = '',
    @PARTID1 varchar(100) = '',
    @MFRID2 varchar(100) = '',
    @PARTID2 varchar(100) = '',
    @MFRID3 varchar(100) = '',
    @PARTID3 varchar(100) = '',
    @MFRID4 varchar(100) = '',
    @PARTID4 varchar(100) = '',
    @MFRID5 varchar(100) = '',
    @PARTID5 varchar(100) = '',
    @MFRID6 varchar(100) = '',
    @PARTID6 varchar(100) = '',
    @MFRID7 varchar(100) = '',
    @PARTID7 varchar(100) = '',
    @MFRID8 varchar(100) = '',
    @PARTID8 varchar(100) = '',
    @MFRID9 varchar(100) = '',
    @PARTID9 varchar(100) = '',
    @MFRID10 varchar(100) = '',
    @PARTID10 varchar(100) = ''
AS
BEGIN

--DECLARE    @REGIONID varchar(100) = '1',
--    @IsFilterByRegion VARCHAR(10) = '0',
--    @Preferences VARCHAR(MAX) = '', -- Comma seperated list of [MstCompanyOwnership] Ids
--    @Distributors VARCHAR(MAX) = '', -- Comma Seperated list of Distributor CompanyIds
--    @PriceMin DECIMAL = -1,
--    @PriceMax DECIMAL = -1,
--    @Quantity INT = -1,
--    @Authorized BIT = 0, -- If zero, ignore, if 1 then restrict to authorized distributors only    
--    @MFRID1 varchar(100) = '0',
--    @PARTID1 varchar(100) = 'BC546B,126',
--    @MFRID2 varchar(100) = '',
--    @PARTID2 varchar(100) = '',
--    @MFRID3 varchar(100) = '',
--    @PARTID3 varchar(100) = '',
--    @MFRID4 varchar(100) = '',
--    @PARTID4 varchar(100) = '',
--    @MFRID5 varchar(100) = '',
--    @PARTID5 varchar(100) = '',
--    @MFRID6 varchar(100) = '',
--    @PARTID6 varchar(100) = '',
--    @MFRID7 varchar(100) = '',
--    @PARTID7 varchar(100) = '',
--    @MFRID8 varchar(100) = '',
--    @PARTID8 varchar(100) = '',
--    @MFRID9 varchar(100) = '',
--    @PARTID9 varchar(100) = '',
--    @MFRID10 varchar(100) = '',
--    @PARTID10 varchar(100) = ''

    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;
    set transaction isolation level read uncommitted
    
    DECLARE @tblMfrPart TABLE 
    (MrfId INT, 
    PartNumber VARCHAR(250), --part numbers are the full part number with no cleaning
    SortOrder INT)

    IF (ISNULL(@MFRID1, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID1,dbo.RemoveSpecialCharacter(@PARTID1),1);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID1,@PARTID1,@DISTIDS1,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID2, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID2,dbo.RemoveSpecialCharacter(@PARTID2),2);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID2,@PARTID2,@DISTIDS2,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID3, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID3,dbo.RemoveSpecialCharacter(@PARTID3),3);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID3,@PARTID3,@DISTIDS3,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID4, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID4,dbo.RemoveSpecialCharacter(@PARTID4),4);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID4,@PARTID4,@DISTIDS4,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID5, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID5,dbo.RemoveSpecialCharacter(@PARTID5),5);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID5,@PARTID5,@DISTIDS5,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID6, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID6,dbo.RemoveSpecialCharacter(@PARTID6),6);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID6,@PARTID6,@DISTIDS6,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID7, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID7,dbo.RemoveSpecialCharacter(@PARTID7),7);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID7,@PARTID7,@DISTIDS7,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID8, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID8,dbo.RemoveSpecialCharacter(@PARTID8),8);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID8,@PARTID8,@DISTIDS8,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID9, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID9,dbo.RemoveSpecialCharacter(@PARTID9),9);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID9,@PARTID9,@DISTIDS9,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID10, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID10,dbo.RemoveSpecialCharacter(@PARTID10),10);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID10,@PARTID10,@DISTIDS10,@IsFilterByRegion
    END
    
	-- START 
    
    DECLARE @RegionQuery VARCHAR(3000)=''
    
    IF(ISNULL(@REGIONID, '') = '') BEGIN SET @REGIONID = '1' END
	
	DECLARE @tblRegionIds TABLE 
	(
		RegionID INT
	)
	INSERT INTO @tblRegionIds
	SELECT array_data 
	FROM dbo.ReturnArray(@REGIONID, ',', NULL)
        
	IF OBJECT_ID(N'tempdb..#temp', N'U') IS NOT NULL   
		DROP TABLE #temp  

    CREATE TABLE #temp 
    (
		MfrId INT, 
		ManufacturerCode VARCHAR(50),
		PartNumber varchar(200),
		SearchPartNumber VARCHAR(200),
		DistributorId INT,
		DistributorName varchar(200), 
		DistLogo varchar(100),
		PartUploadDate DATETIME,
		PartQuantity INT,
		QOHDisp VARCHAR(10),
		Price DECIMAL(18,2),
		DoNotPub BIT,
		RFQCPID INT,
		Buy_Button INT,
		DistributorPartID INT,
        ROHS INT,
        IsManufacturerProduct BIT,
        CountryRegionID VARCHAR(1000),
		MaxAuth int, 
		Total money,
		CompanyAttributes VARCHAR(500),
		SortOrder INT
	)

    --GET EVERYTHING - We will apply the filters in steps below to make it cleaner and in most cases faster
    INSERT INTO #temp
    SELECT
        mp.MrfId as MfrId,
        dp.ManufacturerCode,
        dp.PartNumber as PartNum,
        dp.Search_PartNumber AS SearchPartNumber,
        dp.DistributorId AS DistributorId,
        dp.DistributorName,
        ISNULL(dp.DistLogo, '') AS DistLogo,
        dp.PartUploadDate,
        CAST(CONVERT(DECIMAL(24, 12), CONVERT(FLOAT, ISNULL(PartQuantity, 0))) AS INT) AS PartQuantity, -- This conversion is needed to handle quantities that imported in scientific notation
        dp.QOHDisp,
        ISNULL(Price, 0) AS Price,
        dp.DoNotPub,
        dp.RFQCPID,
        dp.Buy_Button,
        dp.DistributorPartID,
        dp.ROHS,
        dp.IsManufacturerProduct,
        NULL,  -- will update this with a different statment below
        ISNULL(RZS.MaxAuth, 0) AS MaxAuth,
        ISNULL(Spend.Total, 0) AS Total,
        ISNULL(dbo.Get_SearchCompanyOwn(dp.DistributorId), '') as CompanyAttributes,
        mp.SortOrder
    FROM @tblMfrPart AS mp 
	INNER JOIN DistributorPartsSearch1 AS dp WITH(NOLOCK)
		ON dp.Search_PartNumber = mp.PartNumber 
		AND dp.ManufacturerId = mp.MrfId 
	LEFT OUTER JOIN RegionAuthorization AS RA WITH(NOLOCK) 
		ON dp.DistributorId = RA.DistID 
		AND RA.MfrId = mp.MrfId 
	LEFT OUTER JOIN
	(
		SELECT RZOS.MFRDistID, 
			MAX(
				CASE WHEN (AuthStatusID  = 2 AND C.Trusted_Disty = 1) 
					THEN 4 
				ELSE AuthStatusID 
				END
			) AS MaxAuth
        FROM  RegionZoneStatus AS RZOS WITH(NOLOCK) 
        INNER JOIN RegionAuthorization AS  RA WITH(NOLOCK) 
			ON RZOS.MfrDistID = RA.MfrDistID 
		INNER JOIN Company AS C WITH(NOLOCK) 
			ON RA.DistID = C.CompanyID
		 -- limit it to just the manufacturers specified to increase performance
		INNER JOIN @tblMfrPart AS t
			ON RA.MfrID = t.MrfId
		INNER JOIN @tblRegionIds AS r
			ON RZOS.RegionID = r.RegionID
        GROUP BY RZOS.MfrDistID
    ) AS RZS 
		ON RA.MfrDistID = RZS.MfrDistID 
	LEFT OUTER JOIN
	(
		SELECT MfrID, DistID, SUM(Print_Amount+Online_Amount) as Total
		FROM DistPartsSpend AS dps WITH(NOLOCK) 
		 -- limit it to just the manufacturers specified to increase performance
		INNER JOIN @tblMfrPart AS t
			ON dps.MfrID = t.MrfId
		INNER JOIN @tblRegionIds AS r
			ON dps.RegionID = r.RegionID
		GROUP BY MfrID,DistID
	  ) AS Spend 
          ON RA.MfrID = Spend.MfrID 
          AND RA.DistID = Spend.DistID
    ORDER BY  mp.SortOrder, CASE WHEN MaxAuth = 4 THEN 1 ELSE 0 END DESC, Total DESC, DistributorName
        
    
    -- PREFRENCES FILTER
    IF (LEN(@Preferences) > 0)
		BEGIN
			DECLARE @tblPreferences TABLE 
			(
				OwnershipID INT
			)
			INSERT INTO @tblPreferences
			SELECT array_data 
			FROM dbo.ReturnArray(@Preferences, ',', NULL)

			-- Get all the distributors with the preferences (attribute ids) selected
			DECLARE @tblDistWithPreferences TABLE 
			(
				CompanyID INT
			)
			INSERT INTO @tblDistWithPreferences
			SELECT DISTINCT DistributorId  
			FROM #temp AS t 
			INNER JOIN CompanyOwnerShipMapping AS cosm (NOLOCK) 
				ON cosm.CompanyID = t.DistributorId 
			INNER JOIN @tblPreferences AS p
				ON cosm.OwnershipID = p.OwnershipID
			
			-- Remove all records from the temp table where distributorid does not exist in distributor list got above.
			DELETE t
			FROM #temp AS t 
			LEFT OUTER JOIN @tblDistWithPreferences p
				ON t.DistributorId = p.CompanyID
			WHERE p.CompanyID IS NULL
		END
		
		
    -- DISTRIBUTOR FILTER
    IF (LEN(@Distributors) > 0)
		BEGIN
			DECLARE @tblDistributors TABLE (DistributorId INT)
			INSERT INTO @tblDistributors
			SELECT array_data 
			FROM dbo.ReturnArray(@Distributors, ',', NULL)
			
			DELETE t
			FROM #temp AS t
			LEFT OUTER JOIN @tblDistributors d
				ON t.DistributorId = d.DistributorId
			WHERE d.DistributorId IS NULL
		END
	
	--NOTE: Any changes to the statements that populate the following three temp tables
	--		may also need to be made to the stored procedure GetSOLRData
				
	DECLARE @tblCountryRegionID TABLE 
	(
		RegionId INT,
		MfrId INT,
		DistributorId INT
	)
	
	DECLARE @tblRegionAuth TABLE 
	(
		RegionId INT,
		MfrId INT,
		DistributorId INT
	)
	
	DECLARE @tblRegionSpend TABLE 
	(
		RegionId INT,
		MfrId INT,
		DistributorId INT
	)	
	
	-- CountryRegionID
	INSERT INTO @tblCountryRegionID
	SELECT DISTINCT C.RegionID, t.MfrId, t.DistributorId
	FROM #temp t 
	INNER JOIN CompanyLocations AS CL (NOLOCK) 
		ON t.DistributorId = CL.CompanyID 
		AND CL.IsActive = 1
	INNER JOIN Country AS C (NOLOCK) 
		ON C.CountryID = CL.CountryID
	INNER JOIN @tblRegionIds AS r
		ON C.RegionID = r.RegionID
	WHERE LocationStatusID = 1 
	
	UPDATE t 
		SET t.CountryRegionID = 
		(
			SELECT CAST(cr.RegionId AS VARCHAR(15))+','
			FROM @tblCountryRegionID AS cr
			WHERE t.DistributorId = cr.DistributorId 
				AND t.MfrId = cr.MfrId
			For XML Path('') 
		)
	FROM #temp t
	  
	IF (LEN(@REGIONID) > 0 AND @IsFilterByRegion = '1')
		BEGIN
			--region table defined and filled near top of procedure -- @tblRegionIds (RegionId)	

			--  RegionAuth
			INSERT INTO @tblRegionAuth
			SELECT DISTINCT reg_zone_status.RegionID, t.MfrId, t.DistributorId
			FROM #temp AS t 
			INNER JOIN [dbo].[RegionAuthorization] AS reg_auth (NOLOCK) 
				ON t.MfrId = reg_auth.MfrID 
				AND reg_auth.DistID = t.DistributorId 
			INNER JOIN [dbo].[RegionZoneStatus] AS reg_zone_status (NOLOCK) 
				ON reg_zone_status.MfrDistID =  reg_auth.MfrDistID
			INNER JOIN @tblRegionIds AS r
				ON reg_zone_status.RegionID = r.RegionID


			-- RegionSpend
			INSERT INTO @tblRegionSpend
			SELECT DISTINCT Spend.RegionID, t.MfrId, t.DistributorId
			FROM #temp AS t 
			INNER JOIN [dbo].[RegionAuthorization] AS reg_auth (NOLOCK) 
				ON t.MfrId = reg_auth.MfrID
				AND reg_auth.DistID = t.DistributorId 
			INNER JOIN 
			(
				SELECT MfrID,DistID,RegionID,SUM(Print_Amount+Online_Amount) as Total
				FROM [dbo].[DistMfrSpend] AS dms (nolock)
				-- limit it to just the manufacturers specified to increase performance
				INNER JOIN @tblMfrPart AS t
					ON dms.MfrID = t.MrfId
				GROUP BY dms.MfrID,dms.DistID,dms.RegionID
			) AS Spend 
				ON reg_auth.MfrID = Spend.MfrID 
				AND reg_auth.DistID = Spend.DistID 
			INNER JOIN @tblRegionIds AS r
				ON Spend.RegionID = r.RegionID

			DELETE t 
			FROM #temp AS t 
			LEFT OUTER JOIN
				(
					SELECT RegionId, MfrId, DistributorId FROM @tblCountryRegionID
						UNION
					SELECT RegionId, MfrId, DistributorId FROM @tblRegionAuth
						UNION
					SELECT RegionId, MfrId, DistributorId FROM @tblRegionSpend
				) AS m
					ON t.MfrId = m.MfrId 
					AND t.DistributorId = m.DistributorId
			WHERE m.RegionId IS NULL
		END

	IF (@PriceMin > 0)
		BEGIN
			DELETE FROM #temp WHERE Price <= @PriceMin;
		END
		
	IF (@PriceMax > 0)
		BEGIN
			DELETE FROM #temp WHERE Price >= @PriceMax;
		END
		
	IF (@Quantity > 0)
		BEGIN
			DELETE FROM #temp WHERE PartQuantity < @Quantity;
		END
		
	IF (@Authorized = 1)
		BEGIN
			DELETE FROM #temp WHERE MaxAuth <> 4;
		END
		
			
    SELECT *
	FROM #temp
END

GO

/****** Object:  StoredProcedure [dbo].[usp_GetAllUsers]    Script Date: 06/29/2012 17:09:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAllUsers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAllUsers]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetAllUsers] --0,50,'UR.UserID','1111','1',0,'True'                
(                    
   @startIndex  int,                    
   @pageSize  int,                    
   @searchBy  varchar(30),                    
   @searchText  VarChar(max),                    
   @userID   VarChar(30),                    
   @totalUsers  int OUTPUT,              
   @startsWith  VarChar(20)          
)                    
AS                    
--DECLARE @startIndex INT = 0
--      , @pageSize INT = 100
--      , @searchBy VARCHAR(30) = 'UserRegID'
--      , @searchText VARCHAR(MAX) = '100089226'
--      , @userID VARCHAR(30) = 89226
--      , @totalUsers INT = 0
--      , @startsWith VARCHAR(20) = 'True'
BEGIN
	SET NOCOUNT ON
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	                 
	DECLARE @strBuildSQL VARCHAR(MAX)
		  , @upperBound INT
		  , @strCriteria VARCHAR(MAX)
		  , @StrOrderBy VARCHAR(50)            
	                 
	IF @startIndex < 1 
	   SET @startIndex = 1                    
	ELSE 
	   SET @startIndex = @startIndex + 1                            

	SET @searchText = RTRIM(LTRIM(@searchText))    
	        
	IF (@startswith = 'True') 
	   SET @searchText = @searchText + '%'               
	ELSE 
	   SET @searchText = '%' + @searchText + '%'               
	               
	IF @pageSize < 1 
	   SET @pageSize = 1                 
	SET @upperBound = @startIndex + @pageSize                    
	 
	DECLARE @tempSearchText VARCHAR(MAX)
	                
	IF (@searchBy = 'FirstName') 
	BEGIN                       
		SELECT ur.UserID, ur.LoginName AS UserName, ur.LastName, ur.FirstName, ur.UserRegID                       
		FROM (
			SELECT ROW_NUMBER() OVER(ORDER BY u.LastName, u.FirstName) AS rowNumber, u.*                      
			FROM dbo.[User] AS u
			WHERE u.FirstName LIKE @searchText
				AND u.LoginName <> 'SUPERADMIN'
		) AS ur
		WHERE ur.rowNumber >= @startIndex
			AND ur.rowNumber <  @upperBound
		ORDER BY ur.LastName, ur.FirstName

		SELECT @totalUsers = COUNT(*)
		FROM dbo.[User] AS u
		WHERE u.FirstName LIKE @searchText
			AND u.LoginName <> 'SUPERADMIN'
	END                    
	ELSE 
	BEGIN
		IF (@searchBy = 'LastName') 
		BEGIN                               
			SELECT ur.UserID, ur.LoginName AS UserName, ur.LastName, ur.FirstName, ur.UserRegID                       
			FROM (
				SELECT ROW_NUMBER() OVER(ORDER BY u.LastName, u.FirstName) AS rowNumber, u.*                      
				FROM dbo.[User] AS u
				WHERE u.LastName LIKE @searchText
					AND u.LoginName <> 'SUPERADMIN'
			) AS ur
			WHERE ur.rowNumber >= @startIndex
				AND ur.rowNumber <  @upperBound
			ORDER BY ur.LastName, ur.FirstName

			SELECT @totalUsers = COUNT(*)
			FROM dbo.[User] AS u
			WHERE u.LastName LIKE @searchText
				AND u.LoginName <> 'SUPERADMIN'
		END                    
		ELSE 
		BEGIN
			IF (@searchBy = 'UserRegID') 
			BEGIN     
				SELECT ur.UserID,ur.LoginName AS UserName, ur.LastName, ur.FirstName, ur.UserRegID                       
				FROM (
					SELECT ROW_NUMBER() OVER(ORDER BY u.LastName, u.FirstName) AS rowNumber, u.*                      
					FROM dbo.[User] AS u
					WHERE u.UserRegID LIKE @searchText
						AND u.LoginName <> 'SUPERADMIN'
				) AS ur
				WHERE ur.rowNumber >= @startIndex
					AND ur.rowNumber <  @upperBound
				ORDER BY ur.LastName, ur.FirstName

				SELECT @totalUsers = COUNT(*)
				FROM dbo.[User] AS u
				LEFT JOIN dbo.UserContact AS uc
					ON u.UserID = uc.UserID
					AND u.LoginName <> 'SUPERADMIN'
				WHERE u.UserRegID LIKE @searchText
			END                    
			ELSE 
			BEGIN
				IF (@searchBy = 'CompanyName') 
				BEGIN     
					SELECT ur.UserID,ur.LoginName AS UserName, ur.LastName, ur.FirstName, ur.UserRegID                       
					FROM (
						SELECT ROW_NUMBER() OVER(ORDER BY u.LastName, u.FirstName) AS rowNumber, u.*                      
						FROM dbo.[User] AS u
						LEFT OUTER JOIN dbo.UserContact AS uc
							ON u.UserID = uc.UserID
						WHERE uc.CompanyName LIKE @searchText
							AND u.LoginName <> 'SUPERADMIN'
					) AS ur
					WHERE ur.rowNumber >= @startIndex
						AND ur.rowNumber <  @upperBound
					ORDER BY ur.LastName, ur.FirstName

					SELECT @totalUsers = COUNT(*)
					FROM dbo.[User] AS u
					LEFT OUTER JOIN dbo.UserContact AS uc
						ON u.UserID = uc.UserID
					WHERE uc.CompanyName LIKE @searchText
						AND u.LoginName <> 'SUPERADMIN'
				END                    
				ELSE
				BEGIN
					IF (@searchBy = 'EmailAddress') 
					BEGIN
						SELECT ur.UserID,ur.LoginName AS UserName, ur.LastName, ur.FirstName, ur.UserRegID                       
						FROM (
							SELECT ROW_NUMBER() OVER(ORDER BY u.LastName, u.FirstName) AS rowNumber, u.*                      
							FROM dbo.[User] AS u
							LEFT OUTER JOIN dbo.UserContact AS uc
								ON u.UserID = uc.UserID
							WHERE uc.EmailAddress LIKE @searchText
								AND u.LoginName <> 'SUPERADMIN'
						) AS ur
						WHERE ur.rowNumber >= @startIndex
							AND ur.rowNumber <  @upperBound
						ORDER BY ur.LastName, ur.FirstName

						SELECT @totalUsers = COUNT(*)
						FROM dbo.[User] AS u
						LEFT OUTER JOIN dbo.UserContact AS uc
							ON u.UserID = uc.UserID
						WHERE uc.EmailAddress LIKE @searchText
							AND u.LoginName <> 'SUPERADMIN'
					END
					ELSE
					BEGIN
						IF (LEN(@searchText) = 0) 
						BEGIN                      
							SET   @totalUsers = 0                
						
							SELECT UserID, LastName, FirstName, '' AS Country
							FROM   [User]
							WHERE  UserID = 0                
						END
					END                        
				END
			END
		END
	END     

--SELECT @totalUsers
END

GO
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------


/****** Object:  StoredProcedure [dbo].[usp_GetCompanyAdOrderInfo]    Script Date: 08/21/2012 14:33:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetCompanyAdOrderInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetCompanyAdOrderInfo]
GO


/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Get all ACTIVE ad order informaion for the given company ID
(The alert should NOT be sent if the order status is Complete - Gemini 26110)


Used by: 
Ad change alert

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
08.21.2013		Fred Cunningham		Created. 
04.05.2013		Marcus Ruether		The alert should NOT be sent if the order status is Complete - Gemini 26110
------------------------------------------------------------------------------------------------------------------------------------------*/
Create PROCEDURE [dbo].[usp_GetCompanyAdOrderInfo]
(
	@CompanyID int
)
AS	

BEGIN
  
  SELECT AO.SalesPersonId, 
         SP.FirstName + ' ' + SP.LastName AS 'SalesPerson', 
         UC.EmailAddress, 
         ADV.CompanyID AS 'AdvertisingCompanyID', 
         ADV.CompanyName AS 'AdvertisingCompanyName', 
         AOD.OrderType, 
         AO.AdOrderNumber, 
         E.HeadingTitle, 
         MFR.CompanyId AS 'ManufatureCompanyID', 
         MFR.CompanyName AS 'ManufatureCompanyName',
         S.Description as OrderStatus
    FROM AdOrder AO
         INNER JOIN [User] SP ON AO.SalesPersonId = SP.UserID
         INNER JOIN UserContact UC ON SP.UserID = UC.UserID
         INNER JOIN AdOrderDetails AOD ON AO.AdOrderId = AOD.AdOrderId
         INNER JOIN AdOrderDetailsRegionEdition AODRE ON AOD.AdOrderDetailsId = AODRE.AdOrderDetailsId
         INNER JOIN Editions E ON AODRE.EditionID = E.EditionID
         INNER JOIN Company MFR ON AOD.PositionTitle = MFR.CompanyID
         INNER JOIN Company ADV ON AO.CompanyId = ADV.CompanyID
         INNER JOIN MstOrderStatus S ON S.StatusID = AO.StatusId
   WHERE AO.CompanyId = @CompanyID
   AND S.Description NOT LIKE 'complete'
ORDER BY AO.SalesPersonId

END
GO




-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetDistUnderMfr]    Script Date: 01/22/2013 15:44:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetDistUnderMfr]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetDistUnderMfr]
GO

/*------------------------------------------------------------------------------------------------------------------------------------------   
History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
MM.DD.YYYY		<developer name>		Created. 
01.22.2013		Marcus RUether			Added productId for buy button sort - Gemini 25183
										Changed sort order from part number to distributor name - Gemini 25183
02.08.2013		Marcus Ruether			Looks like I overwrote Aequor changes for ticket 25126 on 1/17/2013 with my changes on 1/22/2013.  
										Adding those fixes back in.
02.13.2013		Marcus Ruether			Changed sort order to PartNumber, DistributorName - Gemini 25780
------------------------------------------------------------------------------------------------------------------------------------------*/

----------------------------------                
----TEST           
--DECLARE @companyID int              
--DECLARE @partNumber varchar(100)              
--DECLARE @type int              
              
--SET @companyID = 103840          
--SET @partNumber = 'GT-NE6H1925T' --'xyz12345' --'MF1345-987C'              
--SET @type = 1               
-- --exec usp_GetDistUnderMfr '103840','GT-NE6H1925T',1
------------------------------------                

CREATE PROCEDURE [dbo].[usp_GetDistUnderMfr] 
(                  
   @companyID int,                
   @partNumber varchar(100),                
   @type int            
)
AS                  

BEGIN           
	SET @partNumber = dbo.RemoveSpecialChars(@partNumber)

	IF (LEN(@companyID) <= 5)  
	BEGIN  
		SELECT @companyID = Company_ID FROM dbo.Company_IMAPMDV_XRF WHERE Manufacturer_ID = @companyID   
	END  
	                
	SELECT           
		c.CompanyID as ManufacturerId,          
		c.CompanyName as ManufacturerName,          
		c.CompanyLogo,          
		mc.DistributorID,          
		c1.CompanyName as DistributorName,          
		mc.ManufacturerCode,          
		dp.PartNumber,          
		dp.QtyOnHand as Qty,          
		dp.Uploaded as LastupdatedOn,    
		dp.ROHS,      
		'RFQCPID' = 
			CASE             
				WHEN i.RFQCPID <> 0 THEN 'Send RFQ'             
			ELSE ''            
			END,            
		'RFQCPEmail' = 
			CASE             
				WHEN i.RFQCPID = 0 THEN ''             
			ELSE uc.EmailAddress            
			END,          
		'BuyPentonExpire' = 
			CASE          
				WHEN (i.BuyPentonExpire >= GETDATE() AND i.BuyPentonURL1 <> '') THEN 'Buy'            
			ELSE ''            
			END,            
		i.BuyPentonURL1,            
		'BuyPentonURL2' = 
			CASE             
				WHEN (i.BuyPentonURL2 = 1) THEN dp.PartNumber            
				WHEN (i.BuyPentonURL2 = 2) THEN dp.PartNumber            
				WHEN (i.BuyPentonURL2 = 3) THEN dp.ManufacturerCode            
				WHEN (i.BuyPentonURL2 = 4) THEN ISNULL(c.CompanyName, dp.ManufacturerCode)            
			ELSE ''            
			END,            
		i.BuyPentonURL3,            
		'BuyPentonURL4' = 
			CASE             
				WHEN (i.BuyPentonURL4 = 1) THEN dp.PartNumber            
				WHEN (i.BuyPentonURL4 = 2) THEN dp.PartNumber            
				WHEN (i.BuyPentonURL4 = 3) THEN dp.ManufacturerCode            
				WHEN (i.BuyPentonURL4 = 4) THEN ISNULL(c.CompanyName, dp.ManufacturerCode)            
			ELSE ''            
			END,             
		i.BuyPentonURL5,
		mc.ManufacturerId,
		ISNULL(P.ProductId, 0) AS ProductId         
	FROM dbo.Company c          
	INNER JOIN dbo.ManufacturerCode_XRF mc          
		ON c.CompanyID = ManufacturerID          
	INNER JOIN dbo.RegionAuthorization ra          
		ON mc.ManufacturerID = ra.MfrID 
		AND mc.DistributorID = ra.DistID          
	INNER JOIN (
		SELECT MfrDistID, MAX(AuthStatusID) AS AuthStatus
		FROM dbo.RegionZoneStatus 
		WHERE AuthStatusID in (4,2) 
		GROUP BY MFRDistId
	) rz     
		ON ra.MfrDistID = rz.MfrDistID       
	INNER JOIN dbo.DistributorPartsStatic dp          
		ON mc.DistributorID = dp.DistID 
		AND mc.ManufacturerCode = dp.ManufacturerCode          
	INNER JOIN dbo.InventorySettings i          
		ON mc.DistributorID = i.CompanyID 
	INNER JOIN dbo.Company c1          
		ON mc.DistributorID = c1.CompanyID        
	LEFT OUTER JOIN dbo.UserContact uc    
		ON i.RFQCPID = uc.UserID    
	LEFT OUTER JOIN Product P
		ON dp.PartNumber = P.PartNumber 
		AND mc.ManufacturerId = P.ManufacturerID
		AND ISNULL(P.IsActive, 1) = 1     
	WHERE c.CompanyID = @companyID 
		AND c.CompanyStatusID = 1          
		AND mc.IsActive = 1          
		AND dp.Search_PartNumber LIKE @partNumber + '%' 
		AND dp.Status = 'Active'          
		AND c1.CompanyStatusID = 1          
		AND ((uc.EmailAddress IS NOT NULL) OR (i.BuyPentonExpire >= GETDATE() AND i.BuyPentonURL1 <> ''))
		AND (rz.authstatus = 4 OR (rz.authstatus = 2 AND c1.Trusted_Disty = 1))
	ORDER BY dp.PartNumber, c1.CompanyName
END
  
GO

/****** Object:  StoredProcedure [dbo].[usp_GetDistUnderMfrCount]    Script Date: 01/17/2013 00:46:26 ******/
IF EXISTS ( SELECT  * FROM    sys.objects WHERE   object_id = OBJECT_ID(N'[dbo].[usp_GetDistUnderMfrCount]') AND type IN (N'P', N'PC') ) 
   DROP PROCEDURE [dbo].[usp_GetDistUnderMfrCount]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetDistUnderMfrCount]
(
	@companyID INT, 
	@partNumber VARCHAR(100), 
	@type INT
)
AS 
BEGIN      
----------------------------------    
--TEST    
--DECLARE @companyID int    
--DECLARE @partNumber varchar(100)    
--DECLARE @type int    
    
--SET @companyID = 105 --4    
--SET @partNumber = '767163100JTR' --'MF1345-987C'    
--SET @type = 1  
-- exec usp_GetDistUnderMfrCount '102453','2644',1  
----------------------------------  

	SET @partNumber = dbo.RemoveSpecialChars(@partNumber)

	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
 
	IF (LEN(@companyID) <= 5) 
	BEGIN
	  SELECT    @companyID = Company_ID
	  FROM      dbo.Company_IMAPMDV_XRF
	  WHERE     Manufacturer_ID = @companyID	
	END

  
	SELECT COUNT(DISTINCT a.PartNumber) MatchCount
	FROM   
	(
		SELECT dp.PartNumber
		FROM   dbo.Company c
		INNER JOIN dbo.ManufacturerCode_XRF mc
			ON c.CompanyID = ManufacturerID
		INNER JOIN dbo.RegionAuthorization ra
			ON mc.ManufacturerID = ra.MfrID
			AND mc.DistributorID = ra.DistID
		INNER JOIN 
		(
			SELECT MfrDistID, MAX(AuthStatusID) AuthStatus
			FROM   dbo.RegionZoneStatus
			WHERE  AuthStatusID IN (4,2)
			GROUP BY MFRDistId
		) rz
			ON ra.MfrDistID = rz.MfrDistID
		INNER JOIN dbo.DistributorPartsStatic dp
			ON mc.DistributorID = dp.DistID
			AND mc.ManufacturerCode = dp.ManufacturerCode
		INNER JOIN dbo.InventorySettings i
			ON mc.DistributorID = i.CompanyID
		INNER JOIN dbo.Company c1
			ON mc.DistributorID = c1.CompanyID
		LEFT OUTER JOIN dbo.UserContact uc
			ON i.RFQCPID = uc.UserID
		WHERE  c.CompanyID = @companyID
			AND c.CompanyStatusID = 1
			AND mc.IsActive = 1
			AND dp.Search_PartNumber LIKE @partNumber + '%'
			AND dp.Status = 'Active'
			AND c1.CompanyStatusID = 1
			AND ((uc.EmailAddress IS NOT NULL) OR (i.BuyPentonExpire >= GETDATE() AND i.BuyPentonURL1 <> ''))
			AND (rz.authstatus = 4 OR (rz.authstatus = 2 AND c1.Trusted_Disty = 1))
	) a

END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistinctPartMfrCodeXRF]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistinctPartMfrCodeXRF]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistinctPartMfrCodeXRF]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistinctPartMfrCodeXRF]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	----------------------------------------
	-- BUSINESS RULE (Gemini 25312):
	-- We need to get a common PartNumber to display for companies when the "Search_PartNumber" is the same.
	-- It was decided to use the partnumber of the distributor who is paying the most amount of money for the
	-- "Common" name
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_DistinctPartMfrCodeXRF','';
	TRUNCATE TABLE tmp_Load_DistinctPartMfrCodeXRF

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Drop Indexes on tmp_Load_DistinctPartMfrCodeXRF','';

	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistinctPartMfrCodeXRF]') AND name = N'IDX_DistinctPartMfrCodeXRF_Search_PartNumber')
	BEGIN
		DROP INDEX IDX_DistinctPartMfrCodeXRF_Search_PartNumber ON [dbo].tmp_Load_DistinctPartMfrCodeXRF WITH ( ONLINE = OFF )
	END

	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistinctPartMfrCodeXRF]') AND name = N'IX_Distributorid_Manufacturerid')
	BEGIN
		DROP INDEX [IX_Distributorid_Manufacturerid] ON [dbo].[tmp_Load_DistinctPartMfrCodeXRF]  WITH ( ONLINE = OFF )
	END
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_DistinctPartMfrCodeXRF','';

	INSERT INTO tmp_Load_DistinctPartMfrCodeXRF
	SELECT distinct clean.Search_PartNumber, xrf.DistributorId, xrf.ManufacturerId, xrf.ManufacturerCode
	FROM 
		vw_DistinctMfrCodeXRF xrf WITH(NOLOCK) INNER JOIN
		DistributorParts dp WITH(NOLOCK) on xrf.DistributorId = dp.DistID and xrf.ManufacturerCode = dp.ManufacturerCode INNER JOIN
		DistributorParts_Clean clean WITH(NOLOCK) ON dp.PartNumber = clean.PartNumber
		--WHERE dp.PartNumber IN ('BC546B126','BC546B,126','"BC546B,126"','BC546B.126','MAX705CSA','MAX705CSA+')
		
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Build Indexes on tmp_Load_DistinctPartMfrCodeXRF','';
		
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistinctPartMfrCodeXRF]') AND name = N'IDX_DistinctPartMfrCodeXRF_Search_PartNumber')
	BEGIN
		CREATE NONCLUSTERED INDEX [IDX_DistinctPartMfrCodeXRF_Search_PartNumber] ON tmp_Load_DistinctPartMfrCodeXRF 
		(
			[Search_PartNumber] ASC,
			DistributorId ASC,
			ManufacturerCode ASC
		)
	END

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistinctPartMfrCodeXRF]') AND name = N'IX_Distributorid_Manufacturerid')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_Distributorid_Manufacturerid] ON [dbo].[tmp_Load_DistinctPartMfrCodeXRF] 
		(
			  [DistributorId] ASC,
			  [ManufacturerId] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	END

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into tmp_Load_DistinctPartMfrCodeXRF','';
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistProduct]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistProduct]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistProduct]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistProduct]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
		--PRINT 'Get all records from Product table that match to DistributorParts table'
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_DistProduct','';
	TRUNCATE TABLE tmp_Load_DistProduct

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_DistProduct','';
	INSERT INTO tmp_Load_DistProduct
	SELECT DISTINCT p.PartNumber
	FROM Product p WITH (NOLOCK)
	INNER JOIN DistributorPartsStatic_Cache dp WITH (NOLOCK)
		ON p.PartNumber = dp.PartNumber 
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorParts_Clean]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorParts_Clean]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorParts_Clean]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorParts_Clean]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ActionText VARCHAR(100) = '';
	
	DECLARE @ProcessId INT = (SELECT TOP 1 ProcessId FROM MstProcess WHERE ProcessName = 'usp_Load_SearchCache');
	
	DECLARE @ProcessLogId INT = 0;
	
	INSERT INTO ProcessLog VALUES (@ProcessId, GETDATE());
	
	SET @ProcessLogId = @@IDENTITY;
	
	DECLARE @StartTime DATETIME = (GETDATE());
	
	SET @ActionText = 'Begin usp_Load_SearchCache at ' + CAST(@StartTime AS VARCHAR);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, @ActionText, '';
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into DistributorParts_Clean','';

	----------------------------------------
	-- Add into the DistibutorParts_Clean table all new partnumbers
	INSERT INTO DistributorParts_Clean
	SELECT
		pn.PartNumber,
		UPPER(dbo.RemoveSpecialChars(pn.PartNumber)) AS Search_PartNumber
	FROM
		(
			SELECT 
				DISTINCT dp.partnumber 
			FROM 
				Distributorparts dp WITH(NOLOCK) LEFT JOIN
				DistributorParts_Clean clean WITH(NOLOCK) ON dp.PartNumber = clean.PartNumber
			WHERE clean.partNumber IS NULL --28 seconds
		) pn
	

	INSERT INTO DistributorParts_Clean
	SELECT 
		pn.PartNumber,
		UPPER(dbo.RemoveSpecialChars(pn.PartNumber)) AS Search_PartNumber
	FROM
		(
			SELECT 
				DISTINCT p.PartNumber 
			FROM
				Product p WITH (NOLOCK) INNER JOIN
				Company c  WITH(NOLOCK) on p.ManufacturerID = c.CompanyId AND c.CompanyStatusID = 1 LEFT JOIN
				DistributorParts_Clean clean  WITH(NOLOCK) ON p.PartNumber = clean.PartNumber
			WHERE clean.partNumber IS NULL
		) pn
	
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorParts_Clean','';
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsLoad]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsLoad]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsLoad]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsLoad]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate DistributorPartsLoad','';										
	TRUNCATE TABLE DistributorPartsLoad

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Begin Insert into DistributorPartsLoad','';										
	--PRINT 'Get all records from DistributorParts table'
	INSERT INTO DistributorPartsLoad
		(DistID
		,PartNumber
		,ManufacturerID
		,PartUploadDate
		,PartQuantity
		,Price
		,Price1
		,DistributorPartID
		,ROHS
		,IsManufacturerProduct
		,Search_PartNumber
	)
	
	SELECT dp.DistID
		,dp.PartNumber
		,ISNULL(MFRC.ManufacturerId, 0) as ManufacturerId
		,MAX(dp.Uploaded) as PartUploadDate
		,SUM(ISNULL(dp.QtyOnHand,0)) as PartQuantity
		,MAX(ISNULL(dp.Price,0)) As Price
		,MAX(ISNULL(dp.Price1,0)) As Price1
		,MAX(dp.InvID) As DistributorPartID
		,dp.ROHS
		,dp.IsManufacturerProduct
		,dp.Search_PartNumber
	FROM DistributorPartsStatic_Cache dp  WITH (NOLOCK)
	LEFT OUTER JOIN ManufacturerCode_XRF MFRC WITH (NOLOCK)
		ON dp.DistID = MFRC.DistributorId
		AND dp.ManufacturerCode = MFRC.ManufacturerCode
		AND (MFRC.IsActive IS NULL OR MFRC.IsActive = 1)
	GROUP BY dp.DistID,ManufacturerId,dp.PartNumber,dp.ROHS,dp.IsManufacturerProduct,dp.Search_PartNumber

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsLoad','';										
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsSearch1]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsSearch1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsSearch1]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsSearch1]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCore'
		ORDER BY pl.LogDate DESC
	);
	---------------------------------------------
	-- DistributorPartsSearch1 -------------------
	-- Queries that need parts data to match that from solr will be executed against DistributorPartsSearch1
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Dropping Indexes on DistributorPartsSearch1','';
	
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch1]') AND name = N'IX_DistributorPartSearch1_PartNumber_ManufacturerId')
		BEGIN
			DROP INDEX [IX_DistributorPartSearch1_PartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch1] WITH ( ONLINE = OFF )	
		END
	
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch1]') AND name = N'IX_DistributorPartSearch1_PartNumber_ManufacturerId')
		BEGIN
			DROP INDEX [IX_DistributorPartSearch1_PartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch1] WITH ( ONLINE = OFF )	
		END
		
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch1]') AND name = N'IX_DistributorPartSearch1_SearchPartNumber_ManufacturerId')
		BEGIN
			DROP INDEX [IX_DistributorPartSearch1_SearchPartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch1] WITH ( ONLINE = OFF )	
		END
	SET IDENTITY_INSERT [DistributorPartsSearch1] ON
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finished Dropping Indexes on DistributorPartsSearch1','';
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate DistributorPartsSearch1','';
	
	TRUNCATE TABLE dbo.DistributorPartsSearch1
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Begin Insert into DistributorPartsSearch1','';
	INSERT INTO dbo.DistributorPartsSearch1 ( [ID],[DistributorId],[DistributorName],[Search_Dist_Name],[DistLogo],[PartNumber],[Search_PartNumber],[ManufacturerCode]
		  ,[ManufacturerId],[ManufacturerName],[Search_MFR_Name],[CompanyLogo],[PartUploadDate],[ProductId],[PartDescription]
		  ,[PartQuantity],[QOHDisp],[Price],[PartDataSheet],[DatasheetLink],[PartSample],[VideoFilePathLink],[ImageFilePathLink]
		  ,[DoNotPub],[ProductTypeId],[ProductTypeDesc],[RFQCPID],[Buy_Button],[DistributorPartID],[ROHS],[HasMfrLogoAd],[IsManufacturerProduct],[ManufacturerSpend] )
	SELECT [ID],[DistributorId],[DistributorName],[Search_Dist_Name],[DistLogo],[PartNumber],[Search_PartNumber],[ManufacturerCode]
		  ,[ManufacturerId],[ManufacturerName],[Search_MFR_Name],[CompanyLogo],[PartUploadDate],[ProductId],[PartDescription]
		  ,[PartQuantity],[QOHDisp],[Price],[PartDataSheet],[DatasheetLink],[PartSample],[VideoFilePathLink],[ImageFilePathLink]
		  ,[DoNotPub],[ProductTypeId],[ProductTypeDesc],[RFQCPID],[Buy_Button],[DistributorPartID],[ROHS],[HasMfrLogoAd],[IsManufacturerProduct],[ManufacturerSpend]
	  FROM [SourceESB].[dbo].[DistributorPartsSearch2]
	  
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsSearch1','';
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Creating Indexes on DistributorPartsSearch1','';
	SET IDENTITY_INSERT [DistributorPartsSearch1] OFF

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch1]') AND name = N'IX_DistributorPartID')
	CREATE NONCLUSTERED INDEX [IX_DistributorPartID] ON [dbo].[DistributorPartsSearch1] 
	(	[DistributorPartID] ASC )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		Set NoCount OFF;

	/****** Object:  Index [IX_DistributorPartSearch1_PartNumber_ManufacturerId]    Script Date: 02/04/2013 13:28:12 ******/
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch1]') AND name = N'IX_DistributorPartSearch1_PartNumber_ManufacturerId')
	CREATE NONCLUSTERED INDEX [IX_DistributorPartSearch1_PartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch1] 
	(
		[PartNumber] ASC,
		[ManufacturerId] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		
	/****** Object:  Index [IX_DistributorPartSearch1_SearchPartNumber_ManufacturerId]    Script Date: 03/05/2013 09:38:24 ******/
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch1]') AND name = N'IX_DistributorPartSearch1_SearchPartNumber_ManufacturerId')
	CREATE NONCLUSTERED INDEX [IX_DistributorPartSearch1_SearchPartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch1] 
	(
		  [Search_PartNumber] ASC,
		  [ManufacturerId] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finished Creating Indexes on DistributorPartsSearch1','';
	
	DECLARE @EndTime DATETIME = (GETDATE());
	
	DECLARE @ActionText VARCHAR(100) = 'END usp_Load_SearchCore at ' + CAST(@EndTime AS VARCHAR);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, @ActionText, '';	
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsSearch2]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsSearch2]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsSearch2]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsSearch2]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate DistributorPartsSearch2','';	
	TRUNCATE TABLE DistributorPartsSearch2;
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into DistributorPartsSearch2','';	
	INSERT INTO DistributorPartsSearch2
	(
		[DistributorId],
		[DistributorName],
		[Search_Dist_Name],
		[DistLogo],
		[PartNumber],
		[Search_PartNumber],
		[ManufacturerId],
		[ManufacturerName],
		[Search_MFR_Name],
		[CompanyLogo],
		[PartUploadDate],
		[ProductId],
		[PartDescription],
		[PartQuantity],
		[QOHDisp],
		[Price],
		[PartDataSheet],
		[DatasheetLink],
		[PartSample],
		[VideoFilePathLink],
		[ImageFilePathLink],
		[DoNotPub],
		[ProductTypeId],
		[ProductTypeDesc],
		[RFQCPID],
		[Buy_Button],
		[DistributorPartID],
		[ROHS],
		[HasMfrLogoAd],
		[IsManufacturerProduct],
		ManufacturerSpend
	)

      SELECT ISNULL(Dist.DistID , 0) AS DistributorId
                  ,C.CompanyName AS DistributorName
                  ,C.Clean_CompanyName AS Search_Dist_Name
                  ,C.CompanyLogo AS DistLogo
                  ,Dist.PartNumber
                  ,Dist.Search_PartNumber
                  ,Dist.ManufacturerId
                  ,ISNULL(C1. CompanyName, 'zzunknown') AS ManufacturerName
                  ,dbo.RemoveSpecialChars(C1.Clean_CompanyName) AS Search_MFR_Name
                  ,C1.CompanyLogo AS CompanyLogo
                  ,Dist.PartUploadDate
                  ,P.ProductID AS ProductId
                  ,ISNULL(P.Description, d.PartDescription) AS PartDescription
                  ,ISNULL(Dist.PartQuantity, 0)
                  ,ISNULL(InS.QOHDisp, 0) as QOHDisp
                  ,CASE WHEN (ISNULL(Dist.Price,0) = 0 AND ISNULL(Dist.Price1,0) <> 0)
                        THEN Dist.Price1
                  ELSE Dist.Price
                  END AS Price
                  ,CASE WHEN ISNULL(P.DataSheet,'') <> '' AND ISNULL(P.DataSheetTitle,'')<> ''  
                          THEN P.DataSheetTitle  
                          ELSE
                              CASE WHEN ISNULL(Ins1.MafSpecURL,'') <> '' AND ISNULL(Ins1.MafSpecTitle,'')<> ''  
                                     THEN Ins1.MafSpecTitle ELSE 'Data Sheet'  
                              END  
                  END AS PartDataSheet  
                  ,CASE WHEN ISNULL(P.DataSheet,'') <> ''  
                          THEN P.DataSheet  
                          ELSE  
                              CASE WHEN ISNULL(Ins1.MafSpecURL,'') <> ''  
                                     THEN Ins1.MafSpecURL  
                              END  
                  END AS DatasheetLink 
                  ,P.SampleUrl AS PartSample
                  ,P.VideoFilePath AS VideoFilePathLink
                  ,P.ImageFilePath AS ImageFilePathLink
                  ,ISNULL(Ins.DoNotPub, 0) as DoNotPub
                  ,ISNULL(PT.ProductTypeId, 0) AS ProductTypeId
                  ,ISNULL(PT.TypeDescription, '') AS ProductTypeDesc
                  ,ISNULL(Ins.RFQCPID, 0) AS RFQCPID
                  ,CASE 
                        WHEN Ins.BuyPentonExpire >= GETDATE() 
                              AND Ins.BuyPentonURL1 IS NOT NULL 
                              AND Ins.BuyPentonURL1 <> '' THEN 1 
                        ELSE 0 
                  END AS Buy_Button
                  ,Dist.DistributorPartID
                  ,CASE Dist.ROHS
                        WHEN 'TRUE' THEN 1 
                        WHEN 'YES' THEN 1
                        WHEN 'Y' THEN 1
                        ELSE 0
                  END AS ROHS
                  ,0 AS HasMFRLogoAd
				  ,Dist.IsManufacturerProduct
				  ,ISNULL(MfrSpend.AmountSpent, 0) AS ManufacturerSpend
      FROM DistributorPartsLoad as Dist
      INNER JOIN Company C
            ON Dist.DistID = C.CompanyID
            AND C.isActive = 1 
            AND C.companystatusid in(1,4)
      INNER JOIN InventorySettings Ins
            ON Dist.DistID = Ins.CompanyID
            AND ISNULL(Ins.DoNotPub, 0) = 0
      LEFT OUTER JOIN Company C1
            ON Dist.ManufacturerId = C1.CompanyID
            AND ISNULL(C1.IsActive, 1) = 1 
      LEFT OUTER JOIN Product P
            ON Dist.PartNumber = P.PartNumber 
            AND Dist.ManufacturerId = P.ManufacturerID
            AND ISNULL(P.IsActive, 1) = 1 
      LEFT OUTER JOIN productType_XRF PT_X
            ON P.ManufacturerID = PT_X.ManufacturerID 
            AND P.ProductType = PT_X.MfrProdTypeCode
      LEFT OUTER JOIN ProductType PT
            ON PT_X.ProductTypeID = PT.ProductTypeId
            AND ISNULL(PT.IsActive,1) = 1
      LEFT OUTER JOIN InventorySettings Ins1
            ON Dist.ManufacturerID = Ins1.CompanyID
      LEFT JOIN ManufacturerPartDescription d
            ON dist.PartNumber = d.PartNumber
            AND Dist.DistID = d.DistributorId
      LEFT JOIN MfrSpend on Dist.ManufacturerID = MfrSpend.MfrID
      
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsSearch2','';	

	DECLARE @EndTime DATETIME = (GETDATE());

	DECLARE @ActionText VARCHAR(100) = 'END usp_Load_SearchCache at ' + CAST(@EndTime AS VARCHAR);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, @ActionText, '';
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsStatic]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsStatic]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsStatic]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsStatic]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ActionText VARCHAR(100) = '';
	
	DECLARE @ProcessId INT = (SELECT TOP 1 ProcessId FROM MstProcess WHERE ProcessName = 'usp_Load_SearchCore');
	
	DECLARE @ProcessLogId INT = 0;
	
	INSERT INTO ProcessLog VALUES (@ProcessId, GETDATE());
	
	SET @ProcessLogId = @@IDENTITY;
	
	DECLARE @StartTime DATETIME = (GETDATE());
	
	SET @ActionText = 'Begin usp_Load_SearchCore at ' + CAST(@StartTime AS VARCHAR);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, @ActionText, '';
	
	---------------------------------------------
	-- DistributorPartsStatic -------------------
	
	-- Queries that would be using the DistributorParts table for display on the web will instead use this table so it matches the 
	-- results from the last solr load.

	
	--EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Dropping Indexes on DistributorPartsStatic','';

	--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Uploaded_1]') AND type = 'D')
	--BEGIN
	--	ALTER TABLE [dbo].[DistributorPartsStatic] DROP CONSTRAINT [DF_DistributorPartsStatic_Uploaded_1]
	--END

	--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Status_1]') AND type = 'D')
	--BEGIN
	--	ALTER TABLE [dbo].[DistributorPartsStatic] DROP CONSTRAINT [DF_DistributorPartsStatic_Status_1]
	--END

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_PartNumber')
	--	DROP INDEX [IDX_PartNumber] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_DistID_ManCode')
	--	DROP INDEX [IDX_DistID_ManCode] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_DistID_PartNumber_ManuCode_BatchCode')
	--	DROP INDEX [IX_DistID_PartNumber_ManuCode_BatchCode] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_DistID_Uploaded_InvID')
	--	DROP INDEX [IX_DistID_Uploaded_InvID] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_InventoryUpload')
	--	DROP INDEX [IX_InventoryUpload] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_PartNumber_ManuCode_BatchCode')
	--	DROP INDEX [IX_PartNumber_ManuCode_BatchCode] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_PartNumber_ManuCode_DistID')
	--	DROP INDEX [IDX_PartNumber_ManuCode_DistID] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )
		
	--EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finished Dropping Indexes on DistributorPartsStatic','';
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate DistributorPartsStatic','';
		
	TRUNCATE TABLE [DistributorPartsStatic];
	
	IF NOT EXISTS(SELECT * FROM sys.columns 
				WHERE Name = N'MfrID' and Object_ID = Object_ID(N'DistributorPartsStatic'))    
	BEGIN
		ALTER TABLE DistributorPartsStatic ADD MfrID INT NULL;
	END

	SET IDENTITY_INSERT [DistributorPartsStatic] ON
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Begin Insert into DistributorPartsStatic','';

	INSERT INTO [DistributorPartsStatic] (
	   [ManufacturerCode]
      ,[PartNumber]
      ,[Description]
      ,[QtyOnHand]
      ,[Price]
      ,[ROHS]
      ,[BatchCode]
      ,[BreakLevel1]
      ,[Price1]
      ,[BreakLevel2]
      ,[Price2]
      ,[BreakLevel3]
      ,[Price3]
      ,[BreakLevel4]
      ,[Price4]
      ,[BreakLevel5]
      ,[Price5]
      ,[BreakLevel6]
      ,[Price6]
      ,[BreakLevel7]
      ,[Price7]
      ,[BreakLevel8]
      ,[Price8]
      ,[BreakLevel9]
      ,[Price9]
      ,[BreakLevel10]
      ,[Price10]
      ,[DistID]
      ,[Uploaded]
      ,[InvID]
      ,[Status]
      ,[IsManufacturerProduct]
      ,[Search_PartNumber]
      )
	SELECT 
	   [ManufacturerCode]
      ,[PartNumber]
      ,[Description]
      ,[QtyOnHand]
      ,[Price]
      ,[ROHS]
      ,[BatchCode]
      ,[BreakLevel1]
      ,[Price1]
      ,[BreakLevel2]
      ,[Price2]
      ,[BreakLevel3]
      ,[Price3]
      ,[BreakLevel4]
      ,[Price4]
      ,[BreakLevel5]
      ,[Price5]
      ,[BreakLevel6]
      ,[Price6]
      ,[BreakLevel7]
      ,[Price7]
      ,[BreakLevel8]
      ,[Price8]
      ,[BreakLevel9]
      ,[Price9]
      ,[BreakLevel10]
      ,[Price10]
      ,[DistID]
      ,[Uploaded]
      ,[InvID]
      ,[Status]
      ,[IsManufacturerProduct]
      ,[Search_PartNumber]
      FROM [DistributorPartsStatic_Cache]
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsStatic','';
	
	SET IDENTITY_INSERT [DistributorPartsStatic] OFF
	
	--EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Creating Indexes on DistributorPartsStatic','';
	
	--IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Uploaded_1]') AND type = 'D')
	--BEGIN
	--	ALTER TABLE [dbo].[DistributorPartsStatic] ADD  CONSTRAINT [DF_DistributorPartsStatic_Uploaded_1]  DEFAULT (GETDATE()) FOR [Uploaded]
	--END

	--IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Status_1]') AND type = 'D')
	--BEGIN
	--	ALTER TABLE [dbo].[DistributorPartsStatic] ADD  CONSTRAINT [DF_DistributorPartsStatic_Status_1]  DEFAULT ('Active') FOR [Status]
	--END

	--IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_PartNumber')
	--	CREATE NONCLUSTERED INDEX [IDX_PartNumber] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		[Status] ASC,
	--		[PartNumber] ASC
	--	)
	--	INCLUDE ( [ManufacturerCode],
	--	[DistID]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--IF  NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_DistID_ManCode')
	--	CREATE NONCLUSTERED INDEX [IDX_DistID_ManCode] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		[DistID] ASC,
	--		[ManufacturerCode] ASC
	--	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--IF  NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_DistID_PartNumber_ManuCode_BatchCode')
	--	CREATE NONCLUSTERED INDEX [IX_DistID_PartNumber_ManuCode_BatchCode] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		[DistID] ASC,
	--		[ManufacturerCode] ASC,
	--		[PartNumber] ASC,
	--		[BatchCode] ASC
	--	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--IF  NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_DistID_Uploaded_InvID')
	--	CREATE NONCLUSTERED INDEX [IX_DistID_Uploaded_InvID] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		[DistID]
	--	)
	--	INCLUDE ([Uploaded],[InvID]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_InventoryUpload')
	--	CREATE NONCLUSTERED INDEX [IX_InventoryUpload] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		[DistID]
	--	)
	--	INCLUDE ([ManufacturerCode],[PartNumber],[QtyOnHand],[BatchCode],[Uploaded],[InvID])
	--	WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_PartNumber_ManuCode_BatchCode')
	--	CREATE NONCLUSTERED INDEX [IX_PartNumber_ManuCode_BatchCode] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		  [ManufacturerCode] ASC,
	--		  [PartNumber] ASC,
	--		  [BatchCode] ASC
	--	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_PartNumber_ManuCode_DistID')
	--	CREATE NONCLUSTERED INDEX [IDX_PartNumber_ManuCode_DistID] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		[PartNumber]
	--	)
	--	INCLUDE ([ManufacturerCode],[DistID])
	--	WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		

	--EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finished Creating Indexes on DistributorPartsStatic','';
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsStatic_Cache]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsStatic_Cache]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsStatic_Cache]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsStatic_Cache]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	---------------------------------------------
	-- DistributorPartsStatic_Cache -------------------
	
	-- Queries that would be using the DistributorParts table for display on the web will instead use this table so it matches the 
	-- results from the last solr load.
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate DistributorPartsStatic_Cache','';
	TRUNCATE TABLE DistributorPartsStatic_Cache

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'DROP INDEX and CONSTRAINTS ON DistributorPartsStatic_Cache','';
	
	SET IDENTITY_INSERT [DistributorPartsStatic_Cache] ON

	IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Cache_Uploaded_1]') AND type = 'D')
	BEGIN
		ALTER TABLE [dbo].[DistributorPartsStatic_Cache] DROP CONSTRAINT [DF_DistributorPartsStatic_Cache_Uploaded_1]
	END

	IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Cache_Status_1]') AND type = 'D')
	BEGIN
		ALTER TABLE [dbo].[DistributorPartsStatic_Cache] DROP CONSTRAINT [DF_DistributorPartsStatic_Cache_Status_1]
	END

	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IDX_PartNumber_ManuCode_DistID')
		DROP INDEX [IDX_PartNumber_ManuCode_DistID] ON [dbo].[DistributorPartsStatic_Cache] WITH ( ONLINE = OFF )

	IF NOT EXISTS(SELECT * FROM sys.columns 
				WHERE Name = N'MfrID' and Object_ID = Object_ID(N'DistributorPartsStatic_Cache'))    
	BEGIN
		ALTER TABLE DistributorPartsStatic_Cache ADD MfrID INT NULL;
	END

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into DistributorPartsStatic_Cache','';								
	INSERT INTO DistributorPartsStatic_Cache(
		[ManufacturerCode],
		[PartNumber],
		[Description],[QtyOnHand],[Price],[ROHS],[BatchCode],
		[BreakLevel1],[Price1],[BreakLevel2],[Price2],[BreakLevel3],[Price3],[BreakLevel4],[Price4],[BreakLevel5],[Price5],
		[BreakLevel6],[Price6],[BreakLevel7],[Price7],[BreakLevel8],[Price8],[BreakLevel9],[Price9],[BreakLevel10],[Price10],
		dp.[DistID],[Uploaded],[InvID],[Status],[Search_PartNumber])
	SELECT 
		dp.[ManufacturerCode],
		UPPER(dbo.RemoveStringTerminator(ISNULL(pn.Common_PartNumber, ''))),
		[Description],
		[QtyOnHand],
		[Price],
		[ROHS],
		[BatchCode],
		[BreakLevel1],[Price1],[BreakLevel2],[Price2],[BreakLevel3],[Price3],[BreakLevel4],[Price4],[BreakLevel5],[Price5],
		[BreakLevel6],[Price6],[BreakLevel7],[Price7],[BreakLevel8],[Price8],[BreakLevel9],[Price9],[BreakLevel10],[Price10],
		[DistID],
		[Uploaded],
		[InvID],
		[Status],
		clean.Search_PartNumber
	FROM 
		DistributorParts dp WITH (NOLOCK) INNER JOIN
		DistributorParts_Clean clean WITH(NOLOCK) ON dp.partNumber = clean.partnumber LEFT JOIN
		tmp_Load_DistinctPartMfrCodeXRF xrf WITH (NOLOCK) ON dp.ManufacturerCode = xrf.ManufacturerCode
												AND dp.DistID = xrf.DistributorId
												AND clean.Search_PartNumber = xrf.Search_PartNumber LEFT JOIN
		tmp_Load_PartNumber_CommonName pn on clean.Search_PartNumber = pn.Search_PartNumber 
										AND (ISNULL(xrf.ManufacturerId,0) = pn.ManufacturerId)
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsStatic_Cache from DistributorParts','';										
	--WHERE dp.PartNumber IN ('BC546B126','BC546B,126','"BC546B,126"','BC546B.126','MAX705CSA','MAX705CSA+')
	
	SET IDENTITY_INSERT [DistributorPartsStatic_Cache] ON
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsStatic_CacheFromtmp_Load_Product]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsStatic_CacheFromtmp_Load_Product]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsStatic_CacheFromtmp_Load_Product]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsStatic_CacheFromtmp_Load_Product]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	SET IDENTITY_INSERT [DistributorPartsStatic_Cache] ON

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Start Insert into DistributorPartsStatic_Cache from tmp_Load_Product (Mfr Products)','';	
	INSERT INTO DistributorPartsStatic_Cache([ManufacturerCode],[PartNumber],[DistID],[Uploaded],[QtyOnHand],[Price],[Price1], [ROHS], [InvID],[Status], [IsManufacturerProduct], [Search_PartNumber])
		SELECT MAX(xrf.ManufacturerCode), pn.Common_PartNumber,p.[DistID],p.PartUploadDate,0,0,0,0,p.DistributorPartID,'Active', 1, pn.Search_PartNumber
		FROM tmp_Load_Product p 
		INNER JOIN DistributorParts_Clean clean WITH (NOLOCK) 
			ON p.PartNumber = clean.PartNumber 
		INNER JOIN tmp_Load_PartNumber_CommonName pn 
			ON clean.Search_PartNumber = pn.Search_PartNumber AND pn.ManufacturerId = p.ManufacturerID
		LEFT OUTER JOIN tmp_Load_DistinctPartMfrCodeXRF xrf 
			ON p.DistID = xrf.DistributorId
			AND p.ManufacturerID = xrf.ManufacturerId 
		GROUP BY p.DistID, p.ManufacturerID, pn.Common_PartNumber, p.PartUploadDate, p.DistributorPartID,  pn.Search_PartNumber
		          
		--	tmp_Load_DistinctPartMfrCodeXRF xrf WITH (NOLOCK) ON dp.ManufacturerCode = xrf.ManufacturerCode
		--										AND dp.DistID = xrf.DistributorId
		--										AND clean.Search_PartNumber = xrf.Search_PartNumber LEFT JOIN
												
		--Search_PartNumber VARCHAR(250),
		--DistributorId INT,
		--ManufacturerId INT,
		--ManufacturerCode VARCHAR(256)
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'CREATE INDEX and CONSTRAINTS ON DistributorPartsStatic_Cache','';	
	
	SET IDENTITY_INSERT [DistributorPartsStatic_Cache] OFF
	
	IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Cache_Uploaded_1]') AND type = 'D')
	BEGIN
		ALTER TABLE [dbo].[DistributorPartsStatic_Cache] ADD  CONSTRAINT [DF_DistributorPartsStatic_Cache_Uploaded_1]  DEFAULT (GETDATE()) FOR [Uploaded]
	END

	IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Cache_Status_1]') AND type = 'D')
	BEGIN
		ALTER TABLE [dbo].[DistributorPartsStatic_Cache] ADD  CONSTRAINT [DF_DistributorPartsStatic_Cache_Status_1]  DEFAULT ('Active') FOR [Status]
	END

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IDX_PartNumber_ManuCode_DistID')
		CREATE NONCLUSTERED INDEX [IDX_PartNumber_ManuCode_DistID] ON [dbo].[DistributorPartsStatic_Cache] 
		(
			[PartNumber]
		)
		INCLUDE ([ManufacturerCode],[DistID])
		WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsStatic_Cache from tmp_Load_Product (Mfr Products)','';	
END
GO

/****** Object:  StoredProcedure [dbo].[USP_Load_intoDistributorPartSearch]    Script Date: 01/08/2013 10:53:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_Load_intoDistributorPartSearch]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[USP_Load_intoDistributorPartSearch]
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_MfrDist]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_MfrDist]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_MfrDist]
GO


CREATE PROCEDURE [dbo].[usp_Load_MfrDist]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	--PRINT 'Get all authorized distributor records for Manufacturers with Products'
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_MfrDist','';
	TRUNCATE TABLE tmp_Load_MfrDist

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Begin Insert into tmp_Load_MfrDist','';								
	INSERT INTO tmp_Load_MfrDist
	SELECT ra.MfrID, ra.DistID
	FROM RegionAuthorization ra WITH (NOLOCK)
	INNER JOIN RegionZoneStatus rzs WITH (NOLOCK)
		ON ra.MfrDistID = rzs.MfrDistID
		AND rzs.AuthStatusID = 4
	WHERE ra.IsActive = 1
	AND ra.Publish = 1
	AND ra.MfrID IN (
		SELECT DISTINCT p.ManufacturerID
		FROM tmp_Load_MfrProduct m
		INNER JOIN Product p
		ON m.PartNumber = p.PartNumber
	)
	GROUP BY ra.MfrID, ra.DistID

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into tmp_Load_MfrDist','';								
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_MfrProduct]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_MfrProduct]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_MfrProduct]
GO


CREATE PROCEDURE [dbo].[usp_Load_MfrProduct]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);

	--PRINT 'Get all records from Product table that do NOT match to DistributorParts table'
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_MfrProduct','';
	TRUNCATE TABLE tmp_Load_MfrProduct

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_MfrProduct','';
	INSERT INTO tmp_Load_MfrProduct
	SELECT DISTINCT p.PartNumber
	FROM Product p

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Delete tmp_Load_DistProduct from tmp_Load_MfrProduct','';
	DELETE mp
	FROM tmp_Load_MfrProduct mp
	INNER JOIN tmp_Load_DistProduct dp
		ON mp.PartNumber = dp.PartNumber
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_PartNumber_CommonName]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_PartNumber_CommonName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_PartNumber_CommonName]
GO


CREATE PROCEDURE [dbo].[usp_Load_PartNumber_CommonName]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_PartNumber_CommonName','';
	TRUNCATE TABLE tmp_Load_PartNumber_CommonName

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Drop Indexes on tmp_Load_PartNumber_CommonName','';
	
	--Used in in insert into DistributorPartsStatic_Cache to give part numbers a common name
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_CommonName]') AND name = N'IDX_Search_PartNumber')
	BEGIN
		DROP INDEX IDX_Search_PartNumber ON dbo.tmp_Load_PartNumber_CommonName WITH ( ONLINE = OFF )
	END

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_PartNumber_CommonName','';

	--Used in in insert into DistributorPartsStatic_Cache to give part numbers a common name
	INSERT INTO tmp_Load_PartNumber_CommonName 
	SELECT DISTINCT --Original_PartNumbers.PartNumber AS PartNumber, 
	b.PartNumber AS Common_PartNumber, b.Search_PartNumber, b.ManufacturerId
	FROM
	(
		SELECT a.PartNumber, a.Search_PartNumber, a.ManufacturerId, ROW_NUMBER () OVER (PARTITION BY a.Search_PartNumber, a.ManufacturerId ORDER BY a.DistAdSpend DESC) AS GroupPosition
		FROM
		(
			SELECT dp.PartNumber, Search_PartNumber, dp.ManufacturerId, dp.DistAdSpend
			FROM
			tmp_Load_PartNumber_SearchPartNumber dp WITH (NOLOCK)
		) a
	) b 
	LEFT JOIN
	tmp_Load_PartNumber_SearchPartNumber Original_PartNumbers ON b.Search_PartNumber = Original_PartNumbers.Search_PartNumber 
														AND b.ManufacturerId = Original_PartNumbers.ManufacturerId
	WHERE GroupPosition = 1

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Build Indexes on tmp_Load_PartNumber_CommonName','';


	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_CommonName]') AND name = N'IDX_Search_PartNumber')
	BEGIN
		CREATE INDEX IDX_Search_PartNumber ON tmp_Load_PartNumber_CommonName (Search_PartNumber, ManufacturerId);
	END
					
	--select * from tmp_Load_PartNumber_CommonName

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into tmp_Load_PartNumber_CommonName','';
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_PartNumber_SearchPartNumber]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_PartNumber_SearchPartNumber]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_PartNumber_SearchPartNumber]
GO


CREATE PROCEDURE [dbo].[usp_Load_PartNumber_SearchPartNumber]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_PartNumber_SearchPartNumber','';
	TRUNCATE TABLE tmp_Load_PartNumber_SearchPartNumber
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Drop Indexes on tmp_Load_PartNumber_SearchPartNumber','';

	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_SearchPartNumber]') AND name = N'IDX_PartNumber_SearchPartNumber')
	BEGIN
		DROP INDEX IDX_PartNumber_SearchPartNumber ON dbo.tmp_Load_PartNumber_SearchPartNumber WITH ( ONLINE = OFF )
	END
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_PartNumber_SearchPartNumber','';

	INSERT INTO tmp_Load_PartNumber_SearchPartNumber
	SELECT DISTINCT 
		PartNumber,
		Search_PartNumber,
		Spend,
		ManufacturerId
	FROM
	(
		SELECT PartNumber, Search_PartNumber, Spend, ManufacturerId
		FROM
		(
			SELECT -- Distributors
				dp.PartNumber,
				clean.Search_PartNumber,
				AdSpendRollUp.Spend,
				ISNULL(xrf.ManufacturerId, 0) AS ManufacturerId
			FROM
				DistributorParts dp WITH (NOLOCK) LEFT JOIN
				DistributorParts_Clean clean WITH(NOLOCK) on dp.partnumber = clean.partnumber LEFT JOIN
				tmp_Load_DistinctPartMfrCodeXRF xrf WITH (NOLOCK) ON dp.ManufacturerCode = xrf.ManufacturerCode 
														AND dp.DistID = xrf.DistributorId
														AND xrf.Search_PartNumber = clean.Search_PartNumber LEFT JOIN
				Company mfr ON xrf.ManufacturerId = mfr.CompanyID AND mfr.CompanyStatusID = 1 LEFT JOIN --active
				-- We just want some credible Distributor, those who spend money tend to be more credible. We'll use their description of the part for all other disty's
				(SELECT SUM(Online_Amount) as Spend, DistID FROM
				  dbo.DistPartsSpend s WITH (NOLOCK)
				  GROUP BY DistID   
				) AdSpendRollUp ON dp.DistID = AdSpendRollUp.DistId
				--where dp.PartNumber IN ('BC546B126','BC546B,126','�BC546B,126�','BC546B.126','MAX705CSA','MAX705CSA+') 
			UNION
		SELECT -- Manufacturers
			p.PartNumber,
			UPPER(dbo.RemoveSpecialChars(p.PartNumber)) AS Search_PartNumber,
			0,
			p.ManufacturerID
		FROM
			Product p WITH (NOLOCK) INNER JOIN
			Company c on p.ManufacturerID = c.CompanyId AND c.CompanyStatusID = 1 --active
		--WHERE p.PartNumber IN ('BC546B126','BC546B,126','"BC546B,126"','BC546B.126','MAX705CSA','MAX705CSA+')
		) a 
	) b
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Build Indexes on tmp_Load_PartNumber_SearchPartNumber','';
	
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_SearchPartNumber]') AND name = N'IDX_PartNumber_SearchPartNumber')
	BEGIN
		CREATE INDEX IDX_PartNumber_SearchPartNumber ON tmp_Load_PartNumber_SearchPartNumber (Search_PartNumber, ManufacturerId)
	END

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into tmp_Load_PartNumber_SearchPartNumber','';
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_Product]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_Product]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_Product]
GO


CREATE PROCEDURE [dbo].[usp_Load_Product]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	--PRINT 'Roll up all records that do NOT match to DistributorParts table and add authorizated distributors'
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_Product','';
	TRUNCATE TABLE tmp_Load_Product

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Drop indexes on tmp_Load_Product','';
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_Product]') AND name = N'IX_PartNumber')
	BEGIN
		DROP INDEX [IX_PartNumber] ON [dbo].[tmp_Load_Product] 
	END

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Reseed tmp_Load_Product to avoid identity conflict in DistributorPartsStatic_Cache','';
	DECLARE @seed INT = (
		SELECT MAX(InvID) + 1
		FROM dbo.DistributorPartsStatic_Cache AS dpsc
	)

	DBCC CHECKIDENT (tmp_Load_Product, RESEED, @seed)

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_Product','';								
	INSERT INTO tmp_Load_Product
	(DistID, ManufacturerID, PartNumber, PartUploadDate)
	SELECT md.DistributorID, md.ManufacturerID, mp.PartNumber,
		COALESCE(p.CreatedOn, p.LastUpdatedOn, GETDATE()) AS PartUploadDate
	FROM tmp_Load_MfrDist md
	INNER JOIN Product p WITH (NOLOCK)
		ON md.ManufacturerID = p.ManufacturerID
	INNER JOIN tmp_Load_MfrProduct mp WITH (NOLOCK)
		ON p.PartNumber = mp.PartNumber

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Create indexes on tmp_Load_Product','';
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_Product]') AND name = N'IX_PartNumber')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_PartNumber] ON [dbo].[tmp_Load_Product] 
		(
			  [PartNumber] ASC
		)WITH (STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	END
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_ReloadDistributorParts_Clean]    Script Date: 01/18/2013 22:51:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_ReloadDistributorParts_Clean]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[usp_Load_ReloadDistributorParts_Clean]
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_ReloadDistributorParts_Clean]    Script Date: 01/18/2013 22:51:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

  CREATE PROCEDURE [dbo].[usp_Load_ReloadDistributorParts_Clean]  
  AS          
        
  BEGIN          
		TRUNCATE TABLE dbo.DistributorParts_Clean

		INSERT INTO dbo.DistributorParts_Clean
		SELECT dps.PartNumber, dbo.RemoveSpecialCharacter(dps.PartNumber) 
		FROM dbo.DistributorPartsSearch2 AS dps
		WHERE dps.PartNumber IS NOT NULL 
			AND LEN(dps.PartNumber) > 2
		GROUP BY dps.PartNumber
  END 
  
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_SearchCache]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_SearchCache]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_SearchCache]
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_SearchCore]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_SearchCore]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_SearchCore]
GO

/****** Object:  StoredProcedure [dbo].[usp_Process_CompanyProductType_ChangeQue]    Script Date: 03/25/2013 13:55:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Process_CompanyProductType_ChangeQue]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Process_CompanyProductType_ChangeQue]
GO


/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Intended to be a scheduled process.  Triggers were added to many company related tables to log changes.  The processing inside of them
caused some functions in the admin to run very slow.  The trigger is still in place, but now just does an insert, and the processing
functionlity to find the diffs is now in this procedure.  Purpose is to log only fields that have had a value change.

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
03.22.2013		Marcus Ruether		Created. 
MM.DD.YYYY		<developer name>		<Changes made.> 
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[usp_Process_CompanyProductType_ChangeQue]
AS
BEGIN

	DECLARE @CurrentPrimaryKeyId INT;

	DECLARE @LogTableColumnId INT;
	DECLARE @ColumnName VARCHAR(MAX);
	
	DECLARE @NewSql NVARCHAR(1000);
	DECLARE @OldSQL NVARCHAR(1000);
	DECLARE @NewValue VARCHAR(100);
	DECLARE @OldValue VARCHAR(100);
	DECLARE @RecordDescription VARCHAR(256);
	DECLARE @UserId INT;
	DECLARE @ProcessLogId INT;
	DECLARE @UpdateTime DATETIME;
	
	
	-- Change Events
	DECLARE CUR_PROCESSLOGIDS CURSOR FOR
	SELECT DISTINCT ProcessLogId FROM CompanyProductType_ChangeQue WITH(NOLOCK)
	
	OPEN CUR_PROCESSLOGIDS;
	
	FETCH NEXT FROM CUR_PROCESSLOGIDS INTO @ProcessLogId;
	
	WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @UserId = (SELECT TOP 1 UserId FROM CompanyProductType_ChangeQue q WHERE q.ProcessLogId = @ProcessLogId);
			SET @UpdateTime = (SELECT TOP 1 DateLogged FROM CompanyProductType_ChangeQue q WHERE q.ProcessLogId = @ProcessLogId);
		
			SELECT * 
			INTO #DELETED_CACHE
			FROM CompanyProductType_ChangeQue q WITH(NOLOCK)
			
			WHERE
				q.ProcessLogId = @ProcessLogId AND
				q.IsInsert = 0;
				
			SELECT * 
			INTO #INSERTED_CACHE
			FROM CompanyProductType_ChangeQue q WITH(NOLOCK)
			WHERE
				q.ProcessLogId = @ProcessLogId AND
				q.IsInsert = 1;	
	
			DECLARE @action as VARCHAR(6);
			SET @action = 'INSERT'; -- Set Action to Insert by default.
			IF (EXISTS(SELECT * FROM #DELETED_CACHE) AND EXISTS(SELECT * FROM #INSERTED_CACHE))
				BEGIN
					SET @action = 'UPDATE';
				END
			ELSE IF (EXISTS(SELECT * FROM #DELETED_CACHE) AND NOT EXISTS(SELECT * FROM #INSERTED_CACHE))
				BEGIN
					SET @action = 'DELETE';
				END

			DECLARE @CompanyId INT = 0;
			
			
			--Run through affected records
			
			--put these into temp tables so the can by accessed by dynamic sql
			--not the best, but only I could think of to make this generic.
			SELECT *
			INTO #inserted
			FROM #INSERTED_CACHE
			
			SELECT * 
			INTO #deleted
			FROM #DELETED_CACHE
			
			DECLARE CUR_MSTLOGTABLECOLUMNS CURSOR FOR
			SELECT LogTableColumnId, ColumnName
			FROM 
				MstLogTableColumns c INNER JOIN
				MstLogTable t ON c.LogTableId = t.LogTableId
			WHERE
				t.LogTableName = 'CompanyProductType'
			
			
			DECLARE CUR_AFFECTED_RECORDS CURSOR FOR
			SELECT CompProdTypeID FROM #INSERTED_CACHE
				UNION
			SELECT CompProdTypeID From #DELETED_CACHE
			
			OPEN CUR_AFFECTED_RECORDS;
			
			FETCH NEXT FROM CUR_AFFECTED_RECORDS INTO @CurrentPrimaryKeyId;
			
			WHILE @@FETCH_STATUS = 0
				BEGIN
				
						IF @action = 'DELETE'
							BEGIN
						SET @CompanyId = (SELECT TOP 1 CompanyId FROM #DELETED_CACHE where CompProdTypeID = @CurrentPrimaryKeyId);
						SET @RecordDescription = (SELECT TOP 1 TypeDescription FROM
												#DELETED_CACHE m INNER JOIN 
												ProductType p on m.ProductTypeID = p.ProductTypeId
												WHERE m.CompProdTypeID = @CurrentPrimaryKeyId);
					END
				ELSE
					BEGIN
						SET @CompanyId = (SELECT TOP 1 CompanyId FROM #INSERTED_CACHE where CompProdTypeID = @CurrentPrimaryKeyId);
						SET @RecordDescription = (SELECT TOP 1 TypeDescription FROM
												#INSERTED_CACHE m INNER JOIN 
												ProductType p on m.ProductTypeID = p.ProductTypeId
												WHERE m.CompProdTypeID = @CurrentPrimaryKeyId);
						END
			
					OPEN CUR_MSTLOGTABLECOLUMNS;
					
					FETCH NEXT FROM CUR_MSTLOGTABLECOLUMNS INTO @LogTableColumnId, @ColumnName;
					
					WHILE @@FETCH_STATUS = 0
						BEGIN
					SET @NewSql = N'(SELECT TOP 1 @NewValue = LEFT(CAST(' + @ColumnName + N' AS VARCHAR(100)), 100) FROM #inserted WHERE CompProdTypeID = ' + CAST(@CurrentPrimaryKeyId AS VARCHAR(100)) + N')';
					SET @OldSql = N'(SELECT TOP 1 @OldValue = LEFT(CAST(' + @ColumnName + N' AS VARCHAR(100)), 100) FROM #deleted WHERE CompProdTypeID = ' + CAST(@CurrentPrimaryKeyId AS VARCHAR(100)) + N')';
						
							EXEC sp_executesql 
								@statement = @NewSql,
								@parameters = N'@NewValue VARCHAR(100) OUTPUT',
								@NewValue = @NewValue OUTPUT 
							EXEC sp_executesql 
								@statement = @OldSql,
								@parameters = N'@OldValue VARCHAR(100) OUTPUT',
								@OldValue = @OldValue OUTPUT 	
							print @ColumnName + ' || New = ' + ISNULL(CAST(@NewValue AS VARCHAR(100)), '') + ' Old = ' + ISNULL(CAST(@OldValue AS VARCHAR(100)), '');
							IF ISNULL(CAST(@NewValue AS VARCHAR(100)), '') <> ISNULL(CAST(@OldValue AS VARCHAR(100)), '')
							BEGIN
								INSERT INTO UpdateLog (
									PrimaryKey, 
									LogTableColumnId, 
									NewValue, 
									OldValue,
									ChangeDate, 
									CompanyId, 
									[Action],
									RecordDescription,
									UserId
								)
								VALUES (
									@CurrentPrimaryKeyId, 
									@LogTableColumnId,
									@NewValue,
									@OldValue,
									@UpdateTime,
									@CompanyId,
									@action,
									@RecordDescription,
									@UserId
								)
							END
							
							FETCH NEXT FROM CUR_MSTLOGTABLECOLUMNS INTO @LogTableColumnId, @ColumnName;
						END
						
					CLOSE CUR_MSTLOGTABLECOLUMNS; --reset the cursor
					
					FETCH NEXT FROM CUR_AFFECTED_RECORDS INTO @CurrentPrimaryKeyId;
					
				END -- END CUR_AFFECTED_RECORDS
				
			DEALLOCATE CUR_MSTLOGTABLECOLUMNS;
			
			CLOSE CUR_AFFECTED_RECORDS;
			DEALLOCATE CUR_AFFECTED_RECORDS;
			
			IF OBJECT_ID('tempdb..#inserted') IS NOT NULL
			BEGIN
				DROP TABLE #inserted;	
			END
			
			IF OBJECT_ID('tempdb..#INSERTED_CACHE') IS NOT NULL
			BEGIN
				DROP TABLE #INSERTED_CACHE;	
			END
			
			IF OBJECT_ID('tempdb..#deleted') IS NOT NULL
			BEGIN
				DROP TABLE #deleted;	
			END
			
			IF OBJECT_ID('tempdb..#DELETED_CACHE') IS NOT NULL
			BEGIN
				DROP TABLE #DELETED_CACHE;	
			END
			
			DELETE FROM CompanyProductType_ChangeQue
			WHERE ProcessLogId = @ProcessLogId
				
			FETCH NEXT FROM CUR_PROCESSLOGIDS INTO @ProcessLogId;
		END -- END CUR_PROCESSLOGIDS
	
	CLOSE CUR_PROCESSLOGIDS;
	DEALLOCATE CUR_PROCESSLOGIDS;	

END

GO





-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_Process_RegionZoneStatus_ChangeQue]    Script Date: 03/25/2013 13:55:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Process_RegionZoneStatus_ChangeQue]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Process_RegionZoneStatus_ChangeQue]
GO


/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Intended to be a scheduled process.  Triggers were added to many company related tables to log changes.  The processing inside of them
caused some functions in the admin to run very slow.  The trigger is still in place, but now just does an insert, and the processing
functionlity to find the diffs is now in this procedure.  Purpose is to log only fields that have had a value change.

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
03.22.2013		Marcus Ruether		Created. 
MM.DD.YYYY		<developer name>		<Changes made.> 
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[usp_Process_RegionZoneStatus_ChangeQue]
AS
BEGIN

	DECLARE @CurrentPrimaryKeyId INT;

	DECLARE @LogTableColumnId INT;
	DECLARE @ColumnName VARCHAR(MAX);
	
	DECLARE @NewSql NVARCHAR(1000);
	DECLARE @OldSQL NVARCHAR(1000);
	DECLARE @NewValue VARCHAR(100);
	DECLARE @OldValue VARCHAR(100);
	DECLARE @RecordDescription VARCHAR(256);
	DECLARE @UserId INT;
	DECLARE @ProcessLogId INT;
	DECLARE @UpdateTime DATETIME;
	
	
	-- Change Events
	DECLARE CUR_PROCESSLOGIDS CURSOR FOR
	SELECT DISTINCT ProcessLogId FROM RegionZoneStatus_ChangeQue WITH(NOLOCK)
	
	OPEN CUR_PROCESSLOGIDS;
	
	FETCH NEXT FROM CUR_PROCESSLOGIDS INTO @ProcessLogId;
	
	WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @UserId = (SELECT TOP 1 UserId FROM RegionZoneStatus_ChangeQue q WHERE q.ProcessLogId = @ProcessLogId);
			SET @UpdateTime = (SELECT TOP 1 DateLogged FROM RegionZoneStatus_ChangeQue q WHERE q.ProcessLogId = @ProcessLogId);
		
			SELECT * 
			INTO #DELETED_CACHE
			FROM RegionZoneStatus_ChangeQue q WITH(NOLOCK)
			
			WHERE
				q.ProcessLogId = @ProcessLogId AND
				q.IsInsert = 0;
				
			SELECT * 
			INTO #INSERTED_CACHE
			FROM RegionZoneStatus_ChangeQue q WITH(NOLOCK)
			WHERE
				q.ProcessLogId = @ProcessLogId AND
				q.IsInsert = 1;	
	
			DECLARE @action as VARCHAR(6);
			SET @action = 'INSERT'; -- Set Action to Insert by default.
			IF (EXISTS(SELECT * FROM #DELETED_CACHE) AND EXISTS(SELECT * FROM #INSERTED_CACHE))
				BEGIN
					SET @action = 'UPDATE';
				END
			ELSE IF (EXISTS(SELECT * FROM #DELETED_CACHE) AND NOT EXISTS(SELECT * FROM #INSERTED_CACHE))
				BEGIN
					SET @action = 'DELETE';
				END

			DECLARE @CompanyId INT = 0;
			
			
			--Run through affected records
			
			--put these into temp tables so the can by accessed by dynamic sql
			--not the best, but only I could think of to make this generic.
			SELECT *
			INTO #inserted
			FROM #INSERTED_CACHE
			
			SELECT * 
			INTO #deleted
			FROM #DELETED_CACHE
			
			DECLARE CUR_MSTLOGTABLECOLUMNS CURSOR FOR
			SELECT LogTableColumnId, ColumnName
			FROM 
				MstLogTableColumns c INNER JOIN
				MstLogTable t ON c.LogTableId = t.LogTableId
			WHERE
				t.LogTableName = 'RegionZoneStatus'
			
			
			DECLARE CUR_AFFECTED_RECORDS CURSOR FOR
			SELECT ZoneKeyID FROM #INSERTED_CACHE
				UNION
			SELECT ZoneKeyID From #DELETED_CACHE
			
			OPEN CUR_AFFECTED_RECORDS;
			
			FETCH NEXT FROM CUR_AFFECTED_RECORDS INTO @CurrentPrimaryKeyId;
			
			WHILE @@FETCH_STATUS = 0
				BEGIN
			
					IF @action = 'DELETE'
						BEGIN
							SET @CompanyId = (SELECT TOP 1 ra.DistID FROM #DELETED_CACHE d INNER JOIN RegionAuthorization ra on d.MfrDistID = ra.MfrDistID WHERE d.ZoneKeyId = @CurrentPrimaryKeyId);
							SET @RecordDescription = (SELECT TOP 1 ISNULL(cmp.CompanyName + ' - ', '') + ISNULL(rg.RegionName, '') + ' - ' + ISNULL(ISNULL(z.ZoneName, c.CountryName), '')
														FROM #DELETED_CACHE r INNER JOIN
														Region rg on r.RegionID = rg.RegionID LEFT JOIN
														RegionAuthorization ra on r.MfrDistID = ra.MfrDistID LEFT JOIN
														--RegionAuthorization may have been deleted before this record is deleted.  Try to pull from previous log.
														UpdateLog ul ON ra.MfrDistID IS NULL AND r.MfrDistID = ISNULL(ul.NewValue, ul.OldValue) AND ul.LogTableColumnId = 92 LEFT JOIN-- 92 = RegionAuthorization.MfrDistID
														UpdateLog ul1 on ul.PrimaryKey = ul1.PrimaryKey and ul.ChangeDate = ul1.ChangeDate and ul.LogTableColumnId = 93 LEFT JOIN -- 92 = RegionAuthorization.MfrDistID
														Company cmp ON ISNULL(ra.MfrID, ISNULL(ul1.NewValue, ul1.OldValue)) = cmp.CompanyID LEFT JOIN
														CountryZones z on r.ZoneID = z.ZoneID AND rg.RegionID IN ('1','2') LEFT JOIN
														Country c ON r.ZoneID = c.CountryID AND rg.RegionID NOT IN ('1','2')
														WHERE r.ZoneKeyId = @CurrentPrimaryKeyId)
						END
					ELSE
						BEGIN
							SET @CompanyId = (SELECT TOP 1 ra.DistID FROM #INSERTED_CACHE i INNER JOIN RegionAuthorization ra on i.MfrDistID = ra.MfrDistID WHERE i.ZoneKeyId = @CurrentPrimaryKeyId);
							SET @RecordDescription = (SELECT TOP 1 ISNULL(cmp.CompanyName + ' - ', '') + ISNULL(rg.RegionName, '') + ' - ' + ISNULL(ISNULL(z.ZoneName, c.CountryName), '')
														FROM #INSERTED_CACHE r INNER JOIN
														Region rg on r.RegionID = rg.RegionID LEFT JOIN
														RegionAuthorization ra on r.MfrDistID = ra.MfrDistID LEFT JOIN
														Company cmp ON ra.MfrID = cmp.CompanyID LEFT JOIN 
														CountryZones z on r.ZoneID = z.ZoneID AND rg.RegionID IN ('1','2') LEFT JOIN
														Country c ON r.ZoneID = c.CountryID AND rg.RegionID NOT IN ('1','2')
														WHERE r.ZoneKeyId = @CurrentPrimaryKeyId)
						END
			
					OPEN CUR_MSTLOGTABLECOLUMNS;
					
					FETCH NEXT FROM CUR_MSTLOGTABLECOLUMNS INTO @LogTableColumnId, @ColumnName;
					
					WHILE @@FETCH_STATUS = 0
						BEGIN
							SET @NewSql = N'(SELECT TOP 1 @NewValue = LEFT(CAST(' + @ColumnName + N' AS VARCHAR(100)), 100) FROM #inserted WHERE ZoneKeyID = ' + CAST(@CurrentPrimaryKeyId AS VARCHAR(100)) + N')';
							SET @OldSql = N'(SELECT TOP 1 @OldValue = LEFT(CAST(' + @ColumnName + N' AS VARCHAR(100)), 100) FROM #deleted WHERE ZoneKeyID = ' + CAST(@CurrentPrimaryKeyId AS VARCHAR(100)) + N')';
						
							EXEC sp_executesql 
								@statement = @NewSql,
								@parameters = N'@NewValue VARCHAR(100) OUTPUT',
								@NewValue = @NewValue OUTPUT 
							EXEC sp_executesql 
								@statement = @OldSql,
								@parameters = N'@OldValue VARCHAR(100) OUTPUT',
								@OldValue = @OldValue OUTPUT 	
							print @ColumnName + ' || New = ' + ISNULL(CAST(@NewValue AS VARCHAR(100)), '') + ' Old = ' + ISNULL(CAST(@OldValue AS VARCHAR(100)), '');
							IF ISNULL(CAST(@NewValue AS VARCHAR(100)), '') <> ISNULL(CAST(@OldValue AS VARCHAR(100)), '')
							BEGIN
								INSERT INTO UpdateLog (
									PrimaryKey, 
									LogTableColumnId, 
									NewValue, 
									OldValue,
									ChangeDate, 
									CompanyId, 
									[Action],
									RecordDescription,
									UserId
								)
								VALUES (
									@CurrentPrimaryKeyId, 
									@LogTableColumnId,
									@NewValue,
									@OldValue,
									@UpdateTime,
									@CompanyId,
									@action,
									@RecordDescription,
									@UserId
								)
							END
							
							FETCH NEXT FROM CUR_MSTLOGTABLECOLUMNS INTO @LogTableColumnId, @ColumnName;
						END
						
					CLOSE CUR_MSTLOGTABLECOLUMNS; --reset the cursor
					
					FETCH NEXT FROM CUR_AFFECTED_RECORDS INTO @CurrentPrimaryKeyId;
					
				END -- END CUR_AFFECTED_RECORDS
				
			DEALLOCATE CUR_MSTLOGTABLECOLUMNS;
			
			CLOSE CUR_AFFECTED_RECORDS;
			DEALLOCATE CUR_AFFECTED_RECORDS;
			
			IF OBJECT_ID('tempdb..#inserted') IS NOT NULL
			BEGIN
				DROP TABLE #inserted;	
			END
			
			IF OBJECT_ID('tempdb..#INSERTED_CACHE') IS NOT NULL
			BEGIN
				DROP TABLE #INSERTED_CACHE;	
			END
			
			IF OBJECT_ID('tempdb..#deleted') IS NOT NULL
			BEGIN
				DROP TABLE #deleted;	
			END
			
			IF OBJECT_ID('tempdb..#DELETED_CACHE') IS NOT NULL
			BEGIN
				DROP TABLE #DELETED_CACHE;	
			END
			
			DELETE FROM RegionZoneStatus_ChangeQue
			WHERE ProcessLogId = @ProcessLogId
			
			FETCH NEXT FROM CUR_PROCESSLOGIDS INTO @ProcessLogId;
		END -- END CUR_PROCESSLOGIDS
	
	CLOSE CUR_PROCESSLOGIDS;
	DEALLOCATE CUR_PROCESSLOGIDS;	

END

GO


-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------




/****** Object:  StoredProcedure [dbo].[usp_ProcessInventoryUpload_RejectPriceBreak]    Script Date: 03/22/2013 08:46:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_ProcessInventoryUpload_RejectPriceBreak]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_ProcessInventoryUpload_RejectPriceBreak]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_ProcessInventoryUpload_RejectPriceBreak]
(
	@InventoryUploadHistoryId INT
)
AS
--DECLARE @InventoryUploadHistoryId INT = 18177

BEGIN
	--PRINT 'Log non-numeric Price/Break records in Reject table'
	INSERT INTO dbo.InventoryUploadHistoryReject 
		(InventoryUploadHistoryID,RejectReason,ManufacturerCode,Prefix,PartNumber,Description,QtyOnHand, Price,RoHS, BatchCode,
		   BreakLevel1,Price1,BreakLevel2,Price2,BreakLevel3,Price3,BreakLevel4,Price4,BreakLevel5,Price5,
		   BreakLevel6,Price6,BreakLevel7,Price7,BreakLevel8,Price8,BreakLevel9,Price9,BreakLevel10,Price10, InventoryID)
	SELECT @InventoryUploadHistoryId, 'Invalid Price/Break',  tmpI.ManufacturerCode, tmpI.Prefix, tmpI.PartNumber,
			tmpI.Description, tmpI.QtyOnHand, tmpI.Price,tmpI.RoHS, tmpI.BatchCode, 
			tmpI.BreakLevel1,tmpI.Price1, tmpI.BreakLevel2, tmpI.Price2,tmpI.BreakLevel3, tmpI.Price3, tmpI.BreakLevel4,tmpI.Price4, 
			tmpI.BreakLevel5, tmpI.Price5,tmpI.BreakLevel6, tmpI.Price6, tmpI.BreakLevel7,tmpI.Price7, tmpI.BreakLevel8, tmpI.Price8,
			tmpI.BreakLevel9, tmpI.Price9, tmpI.BreakLevel10,tmpI.Price10, tmpI.InventoryID
	FROM tmpInventoryUpload tmpI
	WHERE (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price)) = '' THEN 1
			WHEN tmpI.Price IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price) = 0 THEN 0
			WHEN tmpI.Price10 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price) <= 0) AND (LEN(tmpI.Price) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price) > 0) AND (LEN(LEFT(tmpI.Price, CHARINDEX('.', tmpI.Price) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.BreakLevel1)) = '' THEN 1
			WHEN tmpI.BreakLevel1 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.BreakLevel1) = 0 THEN 0
			WHEN tmpI.BreakLevel1 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.BreakLevel1 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.BreakLevel1) <= 0) AND (LEN(tmpI.BreakLevel1) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.BreakLevel1) > 0) AND (LEN(LEFT(tmpI.BreakLevel1, CHARINDEX('.', tmpI.BreakLevel1) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.Price1)) = '' THEN 1
				WHEN tmpI.Price1 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.Price1) = 0 THEN 0
				WHEN tmpI.Price1 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.Price1 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.Price1) <= 0) AND (LEN(tmpI.Price1) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.Price1) > 0) AND (LEN(LEFT(tmpI.Price1, CHARINDEX('.', tmpI.Price1) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel2)) = '' THEN 1
				WHEN tmpI.BreakLevel2 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel2) = 0 THEN 0
				WHEN tmpI.BreakLevel2 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel2 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel2) <= 0) AND (LEN(tmpI.BreakLevel2) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel2) > 0) AND (LEN(LEFT(tmpI.BreakLevel2, CHARINDEX('.', tmpI.BreakLevel2) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price2)) = '' THEN 1
			WHEN tmpI.Price2 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price2) = 0 THEN 0
			WHEN tmpI.Price2 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price2 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price2) <= 0) AND (LEN(tmpI.Price2) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price2) > 0) AND (LEN(LEFT(tmpI.Price2, CHARINDEX('.', tmpI.Price2) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel3)) = '' THEN 1
				WHEN tmpI.BreakLevel3 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel3) = 0 THEN 0
				WHEN tmpI.BreakLevel3 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel3 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel3) <= 0) AND (LEN(tmpI.BreakLevel3) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel3) > 0) AND (LEN(LEFT(tmpI.BreakLevel3, CHARINDEX('.', tmpI.BreakLevel3) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price3)) = '' THEN 1
			WHEN tmpI.Price3 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price3) = 0 THEN 0
			WHEN tmpI.Price3 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price3 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price3) <= 0) AND (LEN(tmpI.Price3) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price3) > 0) AND (LEN(LEFT(tmpI.Price3, CHARINDEX('.', tmpI.Price3) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel4)) = '' THEN 1
				WHEN tmpI.BreakLevel4 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel4) = 0 THEN 0
				WHEN tmpI.BreakLevel4 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel4 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel4) <= 0) AND (LEN(tmpI.BreakLevel4) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel4) > 0) AND (LEN(LEFT(tmpI.BreakLevel4, CHARINDEX('.', tmpI.BreakLevel4) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price4)) = '' THEN 1
			WHEN tmpI.Price4 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price4) = 0 THEN 0
			WHEN tmpI.Price4 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price4 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price4) <= 0) AND (LEN(tmpI.Price4) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price4) > 0) AND (LEN(LEFT(tmpI.Price4, CHARINDEX('.', tmpI.Price4) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0		
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel5)) = '' THEN 1
				WHEN tmpI.BreakLevel5 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel5) = 0 THEN 0
				WHEN tmpI.BreakLevel5 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel5 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel5) <= 0) AND (LEN(tmpI.BreakLevel5) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel5) > 0) AND (LEN(LEFT(tmpI.BreakLevel5, CHARINDEX('.', tmpI.BreakLevel5) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price5)) = '' THEN 1
			WHEN tmpI.Price5 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price5) = 0 THEN 0
			WHEN tmpI.Price5 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price5 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price5) <= 0) AND (LEN(tmpI.Price5) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price5) > 0) AND (LEN(LEFT(tmpI.Price5, CHARINDEX('.', tmpI.Price5) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel6)) = '' THEN 1
				WHEN tmpI.BreakLevel6 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel6) = 0 THEN 0
				WHEN tmpI.BreakLevel6 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel6 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel6) <= 0) AND (LEN(tmpI.BreakLevel6) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel6) > 0) AND (LEN(LEFT(tmpI.BreakLevel6, CHARINDEX('.', tmpI.BreakLevel6) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price6)) = '' THEN 1
			WHEN tmpI.Price6 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price6) = 0 THEN 0
			WHEN tmpI.Price6 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price6 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price6) <= 0) AND (LEN(tmpI.Price6) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price6) > 0) AND (LEN(LEFT(tmpI.Price6, CHARINDEX('.', tmpI.Price6) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel7)) = '' THEN 1
				WHEN tmpI.BreakLevel7 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel7) = 0 THEN 0
				WHEN tmpI.BreakLevel7 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel7 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel7) <= 0) AND (LEN(tmpI.BreakLevel7) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel7) > 0) AND (LEN(LEFT(tmpI.BreakLevel7, CHARINDEX('.', tmpI.BreakLevel7) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price7)) = '' THEN 1
			WHEN tmpI.Price7 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price7) = 0 THEN 0
			WHEN tmpI.Price7 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price7 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price7) <= 0) AND (LEN(tmpI.Price7) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price7) > 0) AND (LEN(LEFT(tmpI.Price7, CHARINDEX('.', tmpI.Price7) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel8)) = '' THEN 1
				WHEN tmpI.BreakLevel8 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel8) = 0 THEN 0
				WHEN tmpI.BreakLevel8 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel8 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel8) <= 0) AND (LEN(tmpI.BreakLevel8) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel8) > 0) AND (LEN(LEFT(tmpI.BreakLevel8, CHARINDEX('.', tmpI.BreakLevel8) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price8)) = '' THEN 1
			WHEN tmpI.Price8 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price8) = 0 THEN 0
			WHEN tmpI.Price8 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price8 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price8) <= 0) AND (LEN(tmpI.Price8) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price8) > 0) AND (LEN(LEFT(tmpI.Price8, CHARINDEX('.', tmpI.Price8) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel9)) = '' THEN 1
				WHEN tmpI.BreakLevel9 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel9) = 0 THEN 0
				WHEN tmpI.BreakLevel9 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel9 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel9) <= 0) AND (LEN(tmpI.BreakLevel9) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel9) > 0) AND (LEN(LEFT(tmpI.BreakLevel9, CHARINDEX('.', tmpI.BreakLevel9) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price9)) = '' THEN 1
			WHEN tmpI.Price9 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price9) = 0 THEN 0
			WHEN tmpI.Price9 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price9 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price9) <= 0) AND (LEN(tmpI.Price9) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price9) > 0) AND (LEN(LEFT(tmpI.Price9, CHARINDEX('.', tmpI.Price9) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel10)) = '' THEN 1
				WHEN tmpI.BreakLevel10 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel10) = 0 THEN 0
				WHEN tmpI.BreakLevel10 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel10 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel10) <= 0) AND (LEN(tmpI.BreakLevel10) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel10) > 0) AND (LEN(LEFT(tmpI.BreakLevel10, CHARINDEX('.', tmpI.BreakLevel10) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price10)) = '' THEN 1
			WHEN tmpI.Price10 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price10) = 0 THEN 0
			WHEN tmpI.Price10 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price10 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price10) <= 0) AND (LEN(tmpI.Price10) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price10) > 0) AND (LEN(LEFT(tmpI.Price10, CHARINDEX('.', tmpI.Price10) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0					
		
	--PRINT 'Remove non-numeric Price/Break records from tmp'
	DELETE tmpI
	FROM tmpInventoryUpload tmpI
	WHERE (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price)) = '' THEN 1
			WHEN tmpI.Price IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price) = 0 THEN 0
			WHEN tmpI.Price10 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price) <= 0) AND (LEN(tmpI.Price) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price) > 0) AND (LEN(LEFT(tmpI.Price, CHARINDEX('.', tmpI.Price) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.BreakLevel1)) = '' THEN 1
			WHEN tmpI.BreakLevel1 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.BreakLevel1) = 0 THEN 0
			WHEN tmpI.BreakLevel1 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.BreakLevel1 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.BreakLevel1) <= 0) AND (LEN(tmpI.BreakLevel1) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.BreakLevel1) > 0) AND (LEN(LEFT(tmpI.BreakLevel1, CHARINDEX('.', tmpI.BreakLevel1) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.Price1)) = '' THEN 1
				WHEN tmpI.Price1 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.Price1) = 0 THEN 0
				WHEN tmpI.Price1 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.Price1 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.Price1) <= 0) AND (LEN(tmpI.Price1) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.Price1) > 0) AND (LEN(LEFT(tmpI.Price1, CHARINDEX('.', tmpI.Price1) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel2)) = '' THEN 1
				WHEN tmpI.BreakLevel2 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel2) = 0 THEN 0
				WHEN tmpI.BreakLevel2 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel2 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel2) <= 0) AND (LEN(tmpI.BreakLevel2) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel2) > 0) AND (LEN(LEFT(tmpI.BreakLevel2, CHARINDEX('.', tmpI.BreakLevel2) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price2)) = '' THEN 1
			WHEN tmpI.Price2 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price2) = 0 THEN 0
			WHEN tmpI.Price2 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price2 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price2) <= 0) AND (LEN(tmpI.Price2) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price2) > 0) AND (LEN(LEFT(tmpI.Price2, CHARINDEX('.', tmpI.Price2) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel3)) = '' THEN 1
				WHEN tmpI.BreakLevel3 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel3) = 0 THEN 0
				WHEN tmpI.BreakLevel3 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel3 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel3) <= 0) AND (LEN(tmpI.BreakLevel3) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel3) > 0) AND (LEN(LEFT(tmpI.BreakLevel3, CHARINDEX('.', tmpI.BreakLevel3) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price3)) = '' THEN 1
			WHEN tmpI.Price3 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price3) = 0 THEN 0
			WHEN tmpI.Price3 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price3 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price3) <= 0) AND (LEN(tmpI.Price3) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price3) > 0) AND (LEN(LEFT(tmpI.Price3, CHARINDEX('.', tmpI.Price3) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel4)) = '' THEN 1
				WHEN tmpI.BreakLevel4 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel4) = 0 THEN 0
				WHEN tmpI.BreakLevel4 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel4 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel4) <= 0) AND (LEN(tmpI.BreakLevel4) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel4) > 0) AND (LEN(LEFT(tmpI.BreakLevel4, CHARINDEX('.', tmpI.BreakLevel4) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price4)) = '' THEN 1
			WHEN tmpI.Price4 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price4) = 0 THEN 0
			WHEN tmpI.Price4 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price4 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price4) <= 0) AND (LEN(tmpI.Price4) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price4) > 0) AND (LEN(LEFT(tmpI.Price4, CHARINDEX('.', tmpI.Price4) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0		
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel5)) = '' THEN 1
				WHEN tmpI.BreakLevel5 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel5) = 0 THEN 0
				WHEN tmpI.BreakLevel5 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel5 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel5) <= 0) AND (LEN(tmpI.BreakLevel5) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel5) > 0) AND (LEN(LEFT(tmpI.BreakLevel5, CHARINDEX('.', tmpI.BreakLevel5) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price5)) = '' THEN 1
			WHEN tmpI.Price5 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price5) = 0 THEN 0
			WHEN tmpI.Price5 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price5 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price5) <= 0) AND (LEN(tmpI.Price5) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price5) > 0) AND (LEN(LEFT(tmpI.Price5, CHARINDEX('.', tmpI.Price5) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel6)) = '' THEN 1
				WHEN tmpI.BreakLevel6 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel6) = 0 THEN 0
				WHEN tmpI.BreakLevel6 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel6 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel6) <= 0) AND (LEN(tmpI.BreakLevel6) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel6) > 0) AND (LEN(LEFT(tmpI.BreakLevel6, CHARINDEX('.', tmpI.BreakLevel6) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price6)) = '' THEN 1
			WHEN tmpI.Price6 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price6) = 0 THEN 0
			WHEN tmpI.Price6 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price6 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price6) <= 0) AND (LEN(tmpI.Price6) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price6) > 0) AND (LEN(LEFT(tmpI.Price6, CHARINDEX('.', tmpI.Price6) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel7)) = '' THEN 1
				WHEN tmpI.BreakLevel7 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel7) = 0 THEN 0
				WHEN tmpI.BreakLevel7 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel7 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel7) <= 0) AND (LEN(tmpI.BreakLevel7) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel7) > 0) AND (LEN(LEFT(tmpI.BreakLevel7, CHARINDEX('.', tmpI.BreakLevel7) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price7)) = '' THEN 1
			WHEN tmpI.Price7 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price7) = 0 THEN 0
			WHEN tmpI.Price7 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price7 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price7) <= 0) AND (LEN(tmpI.Price7) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price7) > 0) AND (LEN(LEFT(tmpI.Price7, CHARINDEX('.', tmpI.Price7) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel8)) = '' THEN 1
				WHEN tmpI.BreakLevel8 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel8) = 0 THEN 0
				WHEN tmpI.BreakLevel8 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel8 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel8) <= 0) AND (LEN(tmpI.BreakLevel8) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel8) > 0) AND (LEN(LEFT(tmpI.BreakLevel8, CHARINDEX('.', tmpI.BreakLevel8) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price8)) = '' THEN 1
			WHEN tmpI.Price8 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price8) = 0 THEN 0
			WHEN tmpI.Price8 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price8 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price8) <= 0) AND (LEN(tmpI.Price8) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price8) > 0) AND (LEN(LEFT(tmpI.Price8, CHARINDEX('.', tmpI.Price8) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel9)) = '' THEN 1
				WHEN tmpI.BreakLevel9 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel9) = 0 THEN 0
				WHEN tmpI.BreakLevel9 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel9 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel9) <= 0) AND (LEN(tmpI.BreakLevel9) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel9) > 0) AND (LEN(LEFT(tmpI.BreakLevel9, CHARINDEX('.', tmpI.BreakLevel9) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price9)) = '' THEN 1
			WHEN tmpI.Price9 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price9) = 0 THEN 0
			WHEN tmpI.Price9 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price9 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price9) <= 0) AND (LEN(tmpI.Price9) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price9) > 0) AND (LEN(LEFT(tmpI.Price9, CHARINDEX('.', tmpI.Price9) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0
	OR (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.BreakLevel10)) = '' THEN 1
				WHEN tmpI.BreakLevel10 IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.BreakLevel10) = 0 THEN 0
				WHEN tmpI.BreakLevel10 LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.BreakLevel10 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel10) <= 0) AND (LEN(tmpI.BreakLevel10) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.BreakLevel10) > 0) AND (LEN(LEFT(tmpI.BreakLevel10, CHARINDEX('.', tmpI.BreakLevel10) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0
	OR (
		CASE 
			WHEN RTRIM(LTRIM(tmpI.Price10)) = '' THEN 1
			WHEN tmpI.Price10 IS NULL THEN 1
			WHEN ISNUMERIC(tmpI.Price10) = 0 THEN 0
			WHEN tmpI.Price10 LIKE '%[^-+. 0-9]%' THEN 0
			WHEN CAST(tmpI.Price10 AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
			WHEN (CHARINDEX('.', tmpI.Price10) <= 0) AND (LEN(tmpI.Price10) > 12) THEN 0
			WHEN (CHARINDEX('.', tmpI.Price10) > 0) AND (LEN(LEFT(tmpI.Price10, CHARINDEX('.', tmpI.Price10) - 1)) > 12) THEN 0
			ELSE 1
		END
	) = 0							

	-- Log the number of records deleted for invalid price/break fields
	EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'InvalidPriceBreakFieldCount', @@ROWCOUNT, 0
END
GO

/****** Object:  StoredProcedure [dbo].[usp_ProcessInventoryUpload]    Script Date: 01/23/2013 14:29:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_ProcessInventoryUpload]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_ProcessInventoryUpload]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_ProcessInventoryUpload]
(
	@CompanyId INT,
	@InventoryUploadHistoryId INT,
	@FileType CHAR(5)
)
AS

--DECLARE @CompanyId INT = 144697, @InventoryUploadHistoryId INT = 18177, @FileType CHAR(5)='.csv'

BEGIN
	SET NOCOUNT OFF

	DECLARE @updatedCount INT = 0;
	DECLARE @insertedCount INT = 0;
	DECLARE @updatedCountGroup INT = 0;
	DECLARE @insertedCountGroup INT = 0;
	DECLARE @iterationCount INT = 0;
	DECLARE @textHolder AS VARCHAR(MAX) = '';
	DECLARE @maxRecords INT 
	DECLARE @uploadDateTimeStamp DATETIME = GETDATE()

	DECLARE @SQL VARCHAR(MAX)
	
	--PRINT 'Set all NULL values on keys to empty string for performance increase'
	UPDATE dp
	SET PartNumber = ''
	FROM DistributorParts dp
	WHERE dp.PartNumber IS NULL
	
	UPDATE dp
	SET ManufacturerCode = ''
	FROM DistributorParts dp
	WHERE dp.ManufacturerCode IS NULL

	UPDATE dp
	SET BatchCode = ''
	FROM DistributorParts dp
	WHERE dp.BatchCode IS NULL

	UPDATE dp
	SET BatchCode = ''
	FROM DistributorParts dp
	WHERE dp.BatchCode = '0'
		
	UPDATE tmpI
	SET PartNumber = ''
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.PartNumber IS NULL
		
	UPDATE tmpI
	SET Prefix = ''
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.Prefix IS NULL
	
	UPDATE tmpI
	SET ManufacturerCode = ''
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.ManufacturerCode IS NULL
	
	UPDATE tmpI
	SET ManufacturerCode = LEFT(tmpI.ManufacturerCode, 50)
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.ManufacturerCode IS NULL

	UPDATE tmpI
	SET BatchCode = ''
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.BatchCode IS NULL

	UPDATE tmpI
	SET BatchCode = ''
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.BatchCode = '0'
	
	--PRINT 'Remove white space from composite key fields to match more accurately'
	UPDATE tmpI
	SET ManufacturerCode = LEFT(LTRIM(RTRIM([ManufacturerCode])), 50), 
		PartNumber = LEFT(LTRIM(RTRIM([PartNumber])), 250), 
		BatchCode = LEFT(LTRIM(RTRIM(tmpI.[BatchCode])), 50),
		Prefix = LEFT(LTRIM(RTRIM(tmpI.Prefix)), 250)
	FROM tmpInventoryUpload tmpI

	--PRINT 'Remove non-numeric , character from QOH field because it makes casting to numeric fail'
	UPDATE tmpI
	SET QtyOnHand = REPLACE(RTRIM(LTRIM(tmpI.QtyOnHand)), ',', '')
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.QtyOnHand LIKE ('%,%')
	
	--PRINT 'Remove non-numeric characters from QOH field'
	UPDATE tmpI
	SET QtyOnHand = ''
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.QtyOnHand IN ('-','+','.', ',') 
	
	--PRINT 'Update Prefix to concatenate with PartNumber'
	UPDATE tmpI
	SET PartNumber = tmpI.Prefix + tmpI.PartNumber
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.Prefix <> ''

	-- Log the number of records with concatenated part numbers
	EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'PrefixAddedToPartNumberFieldCount', @@ROWCOUNT, 0
				
	--PRINT 'Remove Part Numbers 2 characters or less from tmp'
	INSERT INTO dbo.InventoryUploadHistoryReject 
		(InventoryUploadHistoryID,RejectReason,ManufacturerCode,Prefix,PartNumber,Description,QtyOnHand, Price,RoHS, BatchCode,
		   BreakLevel1,Price1,BreakLevel2,Price2,BreakLevel3,Price3,BreakLevel4,Price4,BreakLevel5,Price5,
		   BreakLevel6,Price6,BreakLevel7,Price7,BreakLevel8,Price8,BreakLevel9,Price9,BreakLevel10,Price10, InventoryID)
	SELECT @InventoryUploadHistoryId, 'Invalid Part Number',  tmpI.ManufacturerCode, tmpI.Prefix, tmpI.PartNumber,tmpI.Description, tmpI.QtyOnHand, 
			tmpI.Price, tmpI.RoHS, tmpI.BatchCode, tmpI.BreakLevel1,tmpI.Price1, tmpI.BreakLevel2, tmpI.Price2,tmpI.BreakLevel3, tmpI.Price3, 
			tmpI.BreakLevel4,tmpI.Price4, tmpI.BreakLevel5, tmpI.Price5,tmpI.BreakLevel6, tmpI.Price6, tmpI.BreakLevel7,tmpI.Price7, 
			tmpI.BreakLevel8, tmpI.Price8,tmpI.BreakLevel9, tmpI.Price9, tmpI.BreakLevel10,tmpI.Price10, tmpI.InventoryID
	FROM tmpInventoryUpload tmpI
	WHERE LEN(tmpI.PartNumber) <= 2
	
	DELETE tmpI
	FROM tmpInventoryUpload tmpI
	WHERE LEN(tmpI.PartNumber) <= 2

	-- Log the number of records deleted from invalid part number
	EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'InvalidPartNumberFieldCount', @@ROWCOUNT, 0

	--PRINT 'Remove non-numeric QOH records from tmp'
	INSERT INTO dbo.InventoryUploadHistoryReject 
		(InventoryUploadHistoryID,RejectReason,ManufacturerCode,Prefix,PartNumber,Description,QtyOnHand, Price,RoHS, BatchCode,
		   BreakLevel1,Price1,BreakLevel2,Price2,BreakLevel3,Price3,BreakLevel4,Price4,BreakLevel5,Price5,
		   BreakLevel6,Price6,BreakLevel7,Price7,BreakLevel8,Price8,BreakLevel9,Price9,BreakLevel10,Price10, InventoryID)
	SELECT @InventoryUploadHistoryId, 'Invalid Quantity',  tmpI.ManufacturerCode, tmpI.Prefix, tmpI.PartNumber,tmpI.Description, tmpI.QtyOnHand, 
			tmpI.Price, tmpI.RoHS, tmpI.BatchCode, tmpI.BreakLevel1,tmpI.Price1, tmpI.BreakLevel2, tmpI.Price2,tmpI.BreakLevel3, tmpI.Price3, 
			tmpI.BreakLevel4,tmpI.Price4, tmpI.BreakLevel5, tmpI.Price5,tmpI.BreakLevel6, tmpI.Price6, tmpI.BreakLevel7,tmpI.Price7, 
			tmpI.BreakLevel8, tmpI.Price8,tmpI.BreakLevel9, tmpI.Price9, tmpI.BreakLevel10,tmpI.Price10, tmpI.InventoryID
	FROM tmpInventoryUpload tmpI
	WHERE (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.QtyOnHand)) = '' THEN 1
				WHEN tmpI.QtyOnHand IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.QtyOnHand) = 0 THEN 0
				WHEN tmpI.QtyOnHand LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.QtyOnHand AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.QtyOnHand) <= 0) AND (LEN(tmpI.QtyOnHand) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.QtyOnHand) > 0) AND (LEN(LEFT(tmpI.QtyOnHand, CHARINDEX('.', tmpI.QtyOnHand) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0

	DELETE tmpI
	FROM tmpInventoryUpload tmpI
	WHERE (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.QtyOnHand)) = '' THEN 1
				WHEN tmpI.QtyOnHand IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.QtyOnHand) = 0 THEN 0
				WHEN tmpI.QtyOnHand LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.QtyOnHand AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.QtyOnHand) <= 0) AND (LEN(tmpI.QtyOnHand) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.QtyOnHand) > 0) AND (LEN(LEFT(tmpI.QtyOnHand, CHARINDEX('.', tmpI.QtyOnHand) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0

	-- Log the number of records deleted from invalid quantity
	EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'InvalidQtyFieldCount', @@ROWCOUNT, 0
	

	-- Check Zero QOH field. If set, remove 0 QOH records. Otherwise, delete existing records that have zero QOH
	IF (
		SELECT InvS.AllowZeroQOH
		FROM InventorySettings InvS
		WHERE InvS.CompanyID = @CompanyId
	) = 0
	BEGIN
		--PRINT 'Remove zero quantity records'
		DELETE dp
		FROM DistributorParts dp
		INNER JOIN tmpInventoryUpload tmpI
			ON dp.PartNumber = tmpI.PartNumber
			AND dp.ManufacturerCode = tmpI.ManufacturerCode
			AND dp.BatchCode = tmpI.BatchCode
		WHERE dp.DistID = @CompanyId
			AND CAST(CAST(LTRIM(RTRIM(tmpI.QtyOnHand)) AS FLOAT) AS INT) <= 0

		INSERT INTO dbo.InventoryUploadHistoryReject 
			(InventoryUploadHistoryID,RejectReason,ManufacturerCode,Prefix,PartNumber,Description,QtyOnHand, Price,RoHS, BatchCode,
			   BreakLevel1,Price1,BreakLevel2,Price2,BreakLevel3,Price3,BreakLevel4,Price4,BreakLevel5,Price5,
			   BreakLevel6,Price6,BreakLevel7,Price7,BreakLevel8,Price8,BreakLevel9,Price9,BreakLevel10,Price10, InventoryID)
		SELECT @InventoryUploadHistoryId, 'Zero Quantity',  tmpI.ManufacturerCode, tmpI.Prefix, tmpI.PartNumber,tmpI.Description, tmpI.QtyOnHand, 
				tmpI.Price, tmpI.RoHS, tmpI.BatchCode, tmpI.BreakLevel1,tmpI.Price1, tmpI.BreakLevel2, tmpI.Price2,tmpI.BreakLevel3, tmpI.Price3, 
				tmpI.BreakLevel4,tmpI.Price4, tmpI.BreakLevel5, tmpI.Price5,tmpI.BreakLevel6, tmpI.Price6, tmpI.BreakLevel7,tmpI.Price7, 
				tmpI.BreakLevel8, tmpI.Price8,tmpI.BreakLevel9, tmpI.Price9, tmpI.BreakLevel10,tmpI.Price10, tmpI.InventoryID
		FROM tmpInventoryUpload tmpI
		WHERE ISNULL(CAST(CAST(LTRIM(RTRIM(tmpI.QtyOnHand)) AS FLOAT) AS INT),0) <= 0

		DELETE tmpI
		FROM tmpInventoryUpload tmpI
		WHERE ISNULL(CAST(CAST(LTRIM(RTRIM(tmpI.QtyOnHand)) AS FLOAT) AS INT), 0) <= 0

		-- Log the number of 0 QOH records deleted.
		EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'ZeroQtyFieldCount', @@ROWCOUNT, 0
	END

	--PRINT 'Remove non-numeric Price/Break records from tmp'
	EXEC dbo.usp_ProcessInventoryUpload_RejectPriceBreak @InventoryUploadHistoryID

	--PRINT 'Remove duplicate records'
	TRUNCATE TABLE dbo.tmpInventoryUpload_DUP

	INSERT INTO dbo.tmpInventoryUpload_DUP(PartNumber,ManufacturerCode,BatchCode,QtyOnHand,InventoryID)
		SELECT tmpI.PartNumber,tmpI.ManufacturerCode,tmpI.BatchCode, SUM(CAST(CAST(LTRIM(RTRIM([QtyOnHand])) AS FLOAT) AS INT)), MAX(InventoryID) AS InventoryID
		FROM tmpInventoryUpload tmpI WITH(NOLOCK)
		GROUP BY tmpI.PartNumber,tmpI.ManufacturerCode,tmpI.BatchCode
		HAVING COUNT(*) > 1

	UPDATE t
	SET QtyOnHand = td.QtyOnHand
	FROM dbo.tmpInventoryUpload AS t
	INNER JOIN dbo.tmpInventoryUpload_DUP AS td
		ON t.InventoryID = td.InventoryID
		
	DELETE tmpI
	FROM tmpInventoryUpload tmpI
	INNER JOIN dbo.tmpInventoryUpload_DUP AS tmpD
		ON tmpI.PartNumber = tmpD.PartNumber
		AND tmpI.ManufacturerCode = tmpD.ManufacturerCode
		AND tmpI.BatchCode = tmpD.BatchCode	
		AND tmpI.InventoryID <> tmpD.InventoryID
			
	--Log the number of records that are duplicates.
	EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'DuplicateRecordCount', @@ROWCOUNT, 0

	DECLARE @insertRecordCount INT
	SELECT @insertRecordCount = COUNT(*)
	FROM DistributorParts dp (NOLOCK)
	WHERE dp.DistID = @CompanyId
		AND DATEADD(dd, DATEDIFF(dd, 0, dp.Uploaded), 0) = DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0)

	SELECT @insertRecordCount =  @insertRecordCount + COUNT(*)
	FROM
	(
		SELECT tmpI.PartNumber, tmpI.ManufacturerCode, tmpI.BatchCode
		FROM tmpInventoryUpload tmpI WITH(NOLOCK)
		WHERE tmpI.PartNumber + '|' + tmpI.ManufacturerCode NOT IN
		(
			SELECT DISTINCT tmpI.PartNumber + '|' + tmpI.ManufacturerCode
			FROM tmpInventoryUpload tmpI
			GROUP BY tmpI.PartNumber, tmpI.ManufacturerCode
			HAVING COUNT (*) > 1
		)				
		GROUP BY tmpI.PartNumber, tmpI.ManufacturerCode, tmpI.BatchCode
		HAVING COUNT (*) = 1
	) as tmp

	SELECT @insertRecordCount = @insertRecordCount + COUNT(*)
	FROM
	(
		SELECT tmpI.PartNumber, tmpI.ManufacturerCode
		FROM tmpInventoryUpload tmpI WITH(NOLOCK)
		GROUP BY tmpI.PartNumber, tmpI.ManufacturerCode
		HAVING COUNT (*) > 1
	) as tmp

	TRUNCATE TABLE tmpInventoryUpload_INS
	WHILE 1 = 1 
	BEGIN
		SET @iterationCount = @iterationCount + 1
		TRUNCATE TABLE tmpInventoryUpload_LA
		INSERT INTO tmpInventoryUpload_LA
		SELECT TOP 10000 
			[ManufacturerCode],[PartNumber],[Description],[QtyOnHand],[Price],[RoHS],[BatchCode],
			[BreakLevel1],[Price1],[BreakLevel2],[Price2],[BreakLevel3],[Price3],[BreakLevel4],[Price4],[BreakLevel5],[Price5],
			[BreakLevel6],[Price6],[BreakLevel7],[Price7],[BreakLevel8],[Price8],[BreakLevel9],[Price9],[BreakLevel10],[Price10],
			[InventoryID]
		FROM tmpInventoryUpload tmpI

		--PRINT 'Store existing records that match'
		TRUNCATE TABLE tmpInventoryUpload_UPD

		INSERT INTO tmpInventoryUpload_UPD
		SELECT dp.PartNumber, dp.ManufacturerCode, dp.BatchCode 
		FROM DistributorParts dp WITH(NOLOCK, INDEX(IX_DistID_PartNumber_ManuCode_BatchCode))
		INNER JOIN tmpInventoryUpload_LA tmpI WITH(NOLOCK)
			ON dp.PartNumber = tmpI.PartNumber
			AND dp.ManufacturerCode = tmpI.ManufacturerCode
			AND dp.BatchCode = tmpI.BatchCode
		WHERE dp.DistID = @CompanyId
		GROUP BY dp.ManufacturerCode, dp.PartNumber, dp.BatchCode 

		--PRINT 'Delete existing matches'
		DELETE dp
		FROM DistributorParts dp
		INNER JOIN tmpInventoryUpload_LA tmpI WITH(NOLOCK)
			ON dp.PartNumber = tmpI.PartNumber
			AND dp.ManufacturerCode = tmpI.ManufacturerCode
			AND dp.BatchCode = tmpI.BatchCode
		WHERE dp.DistID = @CompanyId

		--PRINT 'Insert Existing matches'
		INSERT INTO DistributorParts
		(
			[ManufacturerCode] ,
			[PartNumber] ,
			[Description],
			[QtyOnHand],
			[Price],
			[ROHS] ,
			[BatchCode] ,
			[BreakLevel1],
			[Price1],
			[BreakLevel2],
			[Price2],
			[BreakLevel3],
			[Price3],
			[BreakLevel4],
			[Price4],
			[BreakLevel5],
			[Price5],
			[BreakLevel6],
			[Price6],
			[BreakLevel7],
			[Price7],
			[BreakLevel8],
			[Price8],
			[BreakLevel9],
			[Price9],
			[BreakLevel10],
			[Price10],
			[DistID]
		)
		SELECT 
			LEFT(LTRIM(RTRIM(tmpI.[ManufacturerCode])), 50) ,
			UPPER(LEFT(LTRIM(RTRIM(tmpI.[PartNumber])), 250)) ,

			CASE 
				WHEN [Description] IS NOT NULL AND [Description] <> '0' 
					THEN LTRIM(RTRIM([Description]))
			END,
			
			CAST(CAST(LTRIM(RTRIM([QtyOnHand])) AS FLOAT) AS INT),
			CAST(LTRIM(RTRIM([Price])) AS FLOAT),

			CASE LEFT(LTRIM(RTRIM([ROHS])), 50)
				WHEN 'Yes' THEN 'True'
				WHEN 'Y' THEN 'True'
				ELSE 'False'
			END,

			CASE 
				WHEN tmpI.[BatchCode] IS NOT NULL AND tmpI.[BatchCode] <> '0' 
					THEN LEFT(LTRIM(RTRIM(tmpI.[BatchCode])), 50)
			END,
			CASE 
				WHEN [BreakLevel1] IS NOT NULL AND [BreakLevel1] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel1])) AS INT)
			END,
			CASE 
				WHEN [Price1] IS NOT NULL AND [Price1] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price1])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel2] IS NOT NULL AND [BreakLevel2] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel2])) AS INT)
			END,
			CASE 
				WHEN [Price2] IS NOT NULL AND [Price2] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price2])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel3] IS NOT NULL AND [BreakLevel3] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel3])) AS INT)
			END,
			CASE 
				WHEN [Price3] IS NOT NULL AND [Price3] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price3])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel4] IS NOT NULL AND [BreakLevel4] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel4])) AS INT)
			END,
			CASE 
				WHEN [Price4] IS NOT NULL AND [Price4] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price4])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel5] IS NOT NULL AND [BreakLevel5] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel5])) AS INT)
			END,
			CASE 
				WHEN [Price5] IS NOT NULL AND [Price5] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price5])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel6] IS NOT NULL AND [BreakLevel6] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel6])) AS INT)
			END,
			CASE 
				WHEN [Price6] IS NOT NULL AND [Price6] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price6])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel7] IS NOT NULL AND [BreakLevel7] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel7])) AS INT)
			END,
			CASE 
				WHEN [Price7] IS NOT NULL AND [Price7] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price7])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel8] IS NOT NULL AND [BreakLevel8] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel8])) AS INT)
			END,
			CASE 
				WHEN [Price8] IS NOT NULL AND [Price8] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price8])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel9] IS NOT NULL AND [BreakLevel9] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel9])) AS INT)
			END,
			CASE 
				WHEN [Price9] IS NOT NULL AND [Price9] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price9])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel10] IS NOT NULL AND [BreakLevel10] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel10])) AS INT)
			END,
			CASE 
				WHEN [Price10] IS NOT NULL AND [Price10] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price10])) AS FLOAT)
			END,
			@CompanyId
		FROM tmpInventoryUpload_UPD dp WITH(NOLOCK)
		INNER JOIN tmpInventoryUpload_LA tmpI WITH(NOLOCK)
			ON dp.PartNumber = tmpI.PartNumber
			AND dp.ManufacturerCode = tmpI.ManufacturerCode
			AND dp.BatchCode = tmpI.BatchCode
		
		SET @updatedCountGroup = @@ROWCOUNT
		SET @updatedCount = @updatedCount + @updatedCountGroup
		SET @textHolder = 'UpdatedCount Group ' + CAST(@iterationCount AS VARCHAR(50)) --can't concate string and pass into sp at the same time

		-- Log the number of records updated (meaning an existing match was found, that match was deleted and the new data was inserted).
		EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, @textHolder, @updatedCountGroup, 0

		--PRINT 'Delete existing matches from temp table'
		DELETE tmpInventoryUpload_LA
		FROM tmpInventoryUpload_UPD dp WITH(NOLOCK)
		INNER JOIN tmpInventoryUpload_LA tmpLA
			ON dp.PartNumber = tmpLA.PartNumber
			AND dp.ManufacturerCode = tmpLA.ManufacturerCode
			AND dp.BatchCode = tmpLA.BatchCode
	
		--PRINT 'Insert clean data'
		INSERT INTO dbo.tmpInventoryUpload_INS 
		(
			ManufacturerCode,PartNumber,Description,QtyOnHand, Price,RoHS, BatchCode,
			BreakLevel1, Price1,BreakLevel2, Price2,BreakLevel3, Price3,BreakLevel4, Price4,BreakLevel5, Price5,
			BreakLevel6, Price6,BreakLevel7, Price7,BreakLevel8, Price8,BreakLevel9, Price9,BreakLevel10,Price10,
			InventoryID
		)
		SELECT 
			LEFT(LTRIM(RTRIM([ManufacturerCode])), 50) ,
			UPPER(LEFT(LTRIM(RTRIM([PartNumber])), 250)) ,

			CASE 
				WHEN [Description] IS NOT NULL AND [Description] <> '0' 
					THEN LTRIM(RTRIM([Description]))
			END,
			
			CAST(CAST(LTRIM(RTRIM([QtyOnHand])) AS FLOAT) AS INT),
			CAST(LTRIM(RTRIM([Price])) AS FLOAT),

			CASE LEFT(LTRIM(RTRIM([ROHS])), 50)
				WHEN 'Yes' THEN 'True'
				WHEN 'Y' THEN 'True'
				ELSE 'False'
			END,

			CASE 
				WHEN [BatchCode] IS NOT NULL AND [BatchCode] <> '0' 
					THEN LEFT(LTRIM(RTRIM([BatchCode])), 50)
			END,
			CASE 
				WHEN [BreakLevel1] IS NOT NULL AND [BreakLevel1] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel1])) AS INT)
			END,
			CASE 
				WHEN [Price1] IS NOT NULL AND [Price1] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price1])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel2] IS NOT NULL AND [BreakLevel2] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel2])) AS INT)
			END,
			CASE 
				WHEN [Price2] IS NOT NULL AND [Price2] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price2])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel3] IS NOT NULL AND [BreakLevel3] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel3])) AS INT)
			END,
			CASE 
				WHEN [Price3] IS NOT NULL AND [Price3] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price3])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel4] IS NOT NULL AND [BreakLevel4] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel4])) AS INT)
			END,
			CASE 
				WHEN [Price4] IS NOT NULL AND [Price4] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price4])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel5] IS NOT NULL AND [BreakLevel5] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel5])) AS INT)
			END,
			CASE 
				WHEN [Price5] IS NOT NULL AND [Price5] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price5])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel6] IS NOT NULL AND [BreakLevel6] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel6])) AS INT)
			END,
			CASE 
				WHEN [Price6] IS NOT NULL AND [Price6] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price6])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel7] IS NOT NULL AND [BreakLevel7] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel7])) AS INT)
			END,
			CASE 
				WHEN [Price7] IS NOT NULL AND [Price7] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price7])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel8] IS NOT NULL AND [BreakLevel8] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel8])) AS INT)
			END,
			CASE 
				WHEN [Price8] IS NOT NULL AND [Price8] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price8])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel9] IS NOT NULL AND [BreakLevel9] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel9])) AS INT)
			END,
			CASE 
				WHEN [Price9] IS NOT NULL AND [Price9] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price9])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel10] IS NOT NULL AND [BreakLevel10] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel10])) AS INT)
			END,
			CASE 
				WHEN [Price10] IS NOT NULL AND [Price10] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price10])) AS FLOAT)
			END,
			InventoryID
		FROM tmpInventoryUpload_LA WITH(NOLOCK)
		
		--PRINT 'Delete the part from table in memory'
		DELETE FROM tmpInventoryUpload_LA

		--PRINT 'Delete the part from table in memory'
		DELETE tmpInventoryUpload
		WHERE InventoryID IN
		(SELECT TOP 10000 InventoryID FROM tmpInventoryUpload)

		DECLARE @tmpRowCount INT = @@ROWCOUNT				            
		PRINT CAST(@tmpRowCount AS VARCHAR(10)) + ' records updated'

		SET @updatedCountGroup = 0;

		IF @tmpRowCount < 10000
			BREAK
	END

	SELECT @maxRecords = InvS.MaxRecords
	FROM InventorySettings InvS
	WHERE InvS.CompanyID = @CompanyId
	
	IF (@insertRecordCount > @maxRecords)
	BEGIN
		--PRINT 'Remove more than max rows from tmp'
		DELETE 
		FROM tmpInventoryUpload_INS
		WHERE InventoryID IN (
			SELECT TOP (@insertRecordCount - @maxRecords) InventoryID 
			FROM tmpInventoryUpload_INS WITH(NOLOCK)
			ORDER BY InventoryID DESC
		)
			
		-- Log the number of records deleted from being over the max inventory threshhold.
		EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'OverLimitCount', @@ROWCOUNT, 0
	END

	SET @iterationCount = 0
	WHILE 1 = 1 
	BEGIN
		SET @iterationCount = @iterationCount + 1
		
		INSERT INTO dbo.DistributorParts 
		(
			ManufacturerCode,PartNumber, Description,QtyOnHand, Price, ROHS,BatchCode, 
			BreakLevel1,Price1, BreakLevel2,Price2, BreakLevel3,Price3, BreakLevel4,Price4, BreakLevel5,Price5, 
			BreakLevel6,Price6, BreakLevel7,Price7, BreakLevel8,Price8, BreakLevel9,Price9, BreakLevel10,Price10, 
			DistID
		)
		SELECT TOP 10000 
			[ManufacturerCode] ,
			[PartNumber] ,
			[Description],
			[QtyOnHand],
			[Price],
			[ROHS] ,
			[BatchCode] ,
			[BreakLevel1],
			[Price1],
			[BreakLevel2],
			[Price2],
			[BreakLevel3],
			[Price3],
			[BreakLevel4],
			[Price4],
			[BreakLevel5],
			[Price5],
			[BreakLevel6],
			[Price6],
			[BreakLevel7],
			[Price7],
			[BreakLevel8],
			[Price8],
			[BreakLevel9],
			[Price9],
			[BreakLevel10],
			[Price10],
			@CompanyId
		FROM tmpInventoryUpload_INS tmpI

		SET @insertedCountGroup = @@ROWCOUNT
		SET @insertedCount = @insertedCount + @insertedCountGroup
		
		SET @textHolder = 'InsertedCount Group ' + CAST(@iterationCount AS VARCHAR(50))--can't concate string and pass into sp at the same time

		-- Log the number of records inserted.
		EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, @textHolder, @insertedCountGroup, 0


		--PRINT 'Delete the part from table in memory'
		DELETE tmpInventoryUpload_INS
		WHERE InventoryID IN
		(SELECT TOP 10000 InventoryID FROM tmpInventoryUpload_INS)


		SET @tmpRowCount = @@ROWCOUNT				            
		PRINT CAST(@tmpRowCount AS VARCHAR(10)) + ' records updated'

		SET @insertedCountGroup = 0;

		IF @tmpRowCount < 10000
			BREAK
	END

	IF (@insertedCount + @updatedCount) > 0
	AND 
	(
		SELECT DeleteOLDInv
		FROM InventorySettings InvS
		WHERE InvS.CompanyID = @CompanyId
	) = 1
	BEGIN
		DECLARE @currentDate DATETIME = GetDate()

		--PRINT 'Remove old parts'
		DELETE dp
		FROM DistributorParts dp
		WHERE dp.DistID=@CompanyId
			AND DATEADD(dd, DATEDIFF(dd, 0, dp.Uploaded), 0) < DATEADD(dd, DATEDIFF(dd, 0, @currentDate), 0)

		-- Log the number of old records deleted. Does not count towards total of parts records processed.
		EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'OldPartsDeleteCount', @@ROWCOUNT, 0
	END

	-- update distributorpartcount table. do not log. If not exists, create record.
	IF NOT EXISTS 
	(
		SELECT *
		FROM DistributorPartCount dpc WITH(NOLOCK)
		WHERE dpc.DistID = @CompanyId
	)
	BEGIN
		INSERT INTO DistributorPartCount
		SELECT @CompanyId, COUNT(*)
		FROM DistributorParts dp (NOLOCK)
		WHERE dp.DistID = @CompanyId
	END
	ELSE
	BEGIN
		UPDATE dpc
		SET PartCount = 
		(
			SELECT COUNT(*)
			FROM DistributorParts dp (NOLOCK)
			WHERE dp.DistID = @CompanyId
		)
		FROM DistributorPartCount dpc
		WHERE DistID=@CompanyId
	END

	
	-- add manufacturer codes that match exactly by name and are missing.
	INSERT INTO [ManufacturerCode_XRF]
	([DistributorId],[ManufacturerCode],[ManufacturerId],[IsActive],[UpdatedOn])

	SELECT DISTINCT dp.DistID, dp.ManufacturerCode, m.CompanyID as MfrID, 1, GetDate()
	FROM DistributorParts dp WITH(NOLOCK)
	INNER JOIN Company m WITH(NOLOCK)
		ON dp.ManufacturerCode = m.CompanyName
		AND m.CompanyStatusID = 1
		AND m.IsActive = 1
	INNER JOIN CompanyTypeMapping ctm WITH(NOLOCK)
		ON m.CompanyID = ctm.CompanyID
		AND ctm.CompanyTypeID = 1 --CompanyType for Mfr's
	LEFT OUTER JOIN ManufacturerCode_XRF mcxrf WITH(NOLOCK)
		ON dp.DistID = mcxrf.DistributorId
		AND dp.ManufacturerCode = mcxrf.ManufacturerCode
	WHERE dp.DistID = @CompanyId
		AND dp.ManufacturerCode <> '' -- Must have mfr code specified to try and find match
		AND mcxrf.ManufacturerCode IS NULL -- Only look for those that have no existing mfr code mapping
		AND m.CompanyName NOT IN 
		(
			SELECT m.CompanyName
			FROM Company m
			INNER JOIN CompanyTypeMapping ctm
				ON m.CompanyID = ctm.CompanyID
				AND ctm.CompanyTypeID = 1 --CompanyType for Mfr's
			GROUP BY m.CompanyName
			HAVING COUNT(*) > 1
		)

	-- Log the number of mfr codes mapped with exact name. Does not count towards total of parts records processed.
	EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'MfrMappingCount', @@ROWCOUNT, 0
				
	-- Log the number of records deleted from being over the max inventory threshhold.
	EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'UpdatedCount', @updatedCount, 0
	-- Log the number of records deleted from being over the max inventory threshhold.
	EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'InsertedCount', @insertedCount, 0

	SET NOCOUNT OFF
END

GO

/****** Object:  StoredProcedure [dbo].[usp_Rep_DistPartStats]    Script Date: 11/20/2012 14:17:18 ******/
IF EXISTS ( SELECT  * FROM    sys.objects WHERE   object_id = OBJECT_ID(N'[dbo].[usp_Rep_DistPartStats]') AND type IN (N'P', N'PC') ) 
   DROP PROCEDURE [dbo].[usp_Rep_DistPartStats]
GO

CREATE PROC [dbo].[usp_Rep_DistPartStats]
AS 
BEGIN    
	SELECT Name = companyname,
		[Oldest Part] = CONVERT(VARCHAR, YEAR(oldest_part)) + '-' + 
			RIGHT('0' + CONVERT(VARCHAR, MONTH(oldest_part)), 2) + '-' + 
			RIGHT('0' + CONVERT(VARCHAR, DAY(oldest_part)), 2),
		[Newest Part] = CONVERT(VARCHAR, YEAR(newest_part)) + '-' + 
			RIGHT('0' + CONVERT(VARCHAR, MONTH(newest_part)), 2) + '-' + 
			RIGHT('0' + CONVERT(VARCHAR, DAY(newest_part)), 2),
		[Purge Old Parts] = purge_old_inventory,
		[Show Zero Quantity] = show_zero_quantity,
		[Show in Search] = show_in_search,
		[Parts with Manufacturer] = parts_with_manufacturer,
		[Zero Quantity Parts] = zero_quantity_parts,
		[Total Parts] = total_parts,
		[Limit] = limit
	FROM   dbo.vw_distributor_part_stats WITH (NOLOCK)
	ORDER BY companyname

END

GO

/****** Object:  StoredProcedure [dbo].[usp_Rep_InventoryUploadErrorHistory]    Script Date: 12/12/2012 14:05:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Rep_InventoryUploadErrorHistory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Rep_InventoryUploadErrorHistory]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_Rep_InventoryUploadErrorHistory]
(
	@fromDate DATETIME,
	@toDate DATETIME
)
AS

BEGIN
	--DECLARE @fromDate DATETIME = '03/22/2013'
	--DECLARE @toDate DATETIME = '03/22/2013'

	DECLARE @tmpHistory TABLE
	(
		CompanyID INT,
		CompanyName VARCHAR(100),
		Vector CHAR(5),
		FileType CHAR(5),
		SendersEmail VARCHAR(100),
		UploadDate DATETIME,
		[Error Message] VARCHAR(MAX),
		[Process Time] VARCHAR(100),
		[Processed] VARCHAR(10),
		[Lines in File] INT,
		[Records Uploaded] INT,
		[Records Processed] INT,
		[Invalid Data] INT,
		[Over Limit Reject] INT,
		[Duplicate Reject] INT,
		[Records Remaining]	INT,
		InventoryUploadHistoryId INT
	)

	INSERT INTO @tmpHistory
	SELECT C.CompanyID, C.CompanyName, h.Vector, h.FileType, InvS.SendersEmail ,h.UploadDate, 
		ISNULL(h.ErrorMessage, '') AS [Error Message],
		ISNULL(h.ProcessTime, '') AS [Process Time],
		CASE 
			WHEN ISNULL(h.FileInventoryCount,0) = 0 
				THEN 'N'
			WHEN CAST((1 - CAST(ISNULL(h.FileInventoryCount, 0) - (ISNULL(h.UpdatedCount, 0) + ISNULL(h.InsertedCount, 0) + ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount, 0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) + ISNULL(h.OverLimitCount, 0) + ISNULL(h.DuplicateCount,0)) AS FLOAT)/CAST(ISNULL(h.FileInventoryCount, 1) AS FLOAT)) * 100 AS INT) = 0
				THEN 'N'
			WHEN CAST((1 - CAST(ISNULL(h.FileInventoryCount, 0) - (ISNULL(h.UpdatedCount, 0) + ISNULL(h.InsertedCount, 0) + ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount, 0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) + ISNULL(h.OverLimitCount, 0) + ISNULL(h.DuplicateCount,0)) AS FLOAT)/CAST(ISNULL(h.FileInventoryCount, 1) AS FLOAT)) * 100 AS INT) = 100 
				THEN 'Y'
			 ELSE
				CAST(CAST((1 - CAST(ISNULL(h.FileInventoryCount, 0) - (ISNULL(h.UpdatedCount, 0) + ISNULL(h.InsertedCount, 0) + ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount, 0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) + ISNULL(h.OverLimitCount, 0) + ISNULL(h.DuplicateCount,0)) AS FLOAT)/CAST(ISNULL(h.FileInventoryCount, 1) AS FLOAT)) * 100 AS INT) AS VARCHAR(10))
		END AS [Processed],
		ISNULL(h.FileLineCount, 0) as [Lines in File], 
		ISNULL(h.FileInventoryCount, 0) as [Records Uploaded], 
		ISNULL(h.UpdatedCount,0) + ISNULL(h.InsertedCount,0) AS [Records Processed], 
		ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount,0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) AS [Invalid Data],
		ISNULL(h.OverLimitCount,0) AS [Over Limit Reject],
		ISNULL(h.DuplicateCount,0) AS [Duplicate Reject], 
		ISNULL(h.FileInventoryCount, 0) - ((ISNULL(h.UpdatedCount,0) + ISNULL(h.InsertedCount,0)) + (ISNULL(h.InvalidQtyFieldCount,0) + ISNULL(h.OverLimitCount,0) + ISNULL(h.DuplicateCount,0))) AS [Records Remaining],
		h.InventoryUploadHistoryId
	FROM InventoryUploadHistory h
	INNER JOIN Company C
		ON h.CompanyId = C.CompanyID
	LEFT OUTER JOIN InventorySettings InvS
		ON C.CompanyID = InvS.CompanyID
	WHERE DATEADD(dd, DATEDIFF(dd, 0, h.UploadDate), 0) >= DATEADD(dd, DATEDIFF(dd, 0, @fromDate), 0)
		AND DATEADD(dd, DATEDIFF(dd, 0, h.UploadDate), 0) <= DATEADD(dd, DATEDIFF(dd, 0, @toDate), 0)

	SELECT h.*
	FROM @tmpHistory h
	WHERE h.[Error Message] IS NOT NULL AND h.[Error Message] <> ''
	ORDER BY h.InventoryUploadHistoryId DESC
END

GO

/****** Object:  StoredProcedure [dbo].[usp_Rep_InventoryUploadHistory]    Script Date: 12/12/2012 15:58:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Rep_InventoryUploadHistory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Rep_InventoryUploadHistory]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_Rep_InventoryUploadHistory]
(
	@fromDate DATETIME,
	@toDate DATETIME
)
AS

BEGIN
	--DECLARE @fromDate DATETIME = '03/22/2013'
	--DECLARE @toDate DATETIME = '03/22/2013'

	DECLARE @tmpHistory TABLE
	(
		CompanyID INT,
		CompanyName VARCHAR(100),
		Vector CHAR(5),
		FileType CHAR(5),
		SendersEmail VARCHAR(100),
		UploadDate DATETIME,
		[Error Message] VARCHAR(MAX),
		[Process Time] VARCHAR(100),
		[Processed] VARCHAR(10),
		[Limit] INT,
		[Lines in File] INT,
		[Records Uploaded] INT,
		[Records Processed] INT,
		[Invalid Data] INT,
		[Over Limit Reject] INT,
		[Duplicate Reject] INT,
		[Records Remaining]	INT,
		InventoryUploadHistoryId INT
	)

	INSERT INTO @tmpHistory
	SELECT C.CompanyID, C.CompanyName, h.Vector, h.FileType, InvS.SendersEmail ,h.UploadDate, 
		ISNULL(h.ErrorMessage, '') AS [Error Message],
		ISNULL(h.ProcessTime, '') AS [Process Time],
		CASE 
			WHEN ISNULL(h.FileInventoryCount,0) = 0 
				THEN 'N'
			WHEN CAST((1 - CAST(ISNULL(h.FileInventoryCount, 0) - (ISNULL(h.UpdatedCount, 0) + ISNULL(h.InsertedCount, 0) + ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount, 0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) + ISNULL(h.OverLimitCount, 0) + ISNULL(h.DuplicateCount,0)) AS FLOAT)/CAST(ISNULL(h.FileInventoryCount, 1) AS FLOAT)) * 100 AS INT) = 0
				THEN 'N'
			WHEN CAST((1 - CAST(ISNULL(h.FileInventoryCount, 0) - (ISNULL(h.UpdatedCount, 0) + ISNULL(h.InsertedCount, 0) + ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount, 0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) + ISNULL(h.OverLimitCount, 0) + ISNULL(h.DuplicateCount,0)) AS FLOAT)/CAST(ISNULL(h.FileInventoryCount, 1) AS FLOAT)) * 100 AS INT) = 100 
				THEN 'Y'
			 ELSE
				CAST(CAST((1 - CAST(ISNULL(h.FileInventoryCount, 0) - (ISNULL(h.UpdatedCount, 0) + ISNULL(h.InsertedCount, 0) + ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount, 0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) + ISNULL(h.OverLimitCount, 0) + ISNULL(h.DuplicateCount,0)) AS FLOAT)/CAST(ISNULL(h.FileInventoryCount, 1) AS FLOAT)) * 100 AS INT) AS VARCHAR(10))
		END AS [Processed],
		ISNULL(InvS.MaxRecords, 0) AS [Limit],
		ISNULL(h.FileLineCount, 0) as [Lines in File], 
		ISNULL(h.FileInventoryCount, 0) as [Records Uploaded], 
		ISNULL(h.UpdatedCount,0) + ISNULL(h.InsertedCount,0) AS [Records Processed], 
		ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount,0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) AS [Invalid Data],
		ISNULL(h.OverLimitCount,0) AS [Over Limit Reject],
		ISNULL(h.DuplicateCount,0) AS [Duplicate Reject], 
		ISNULL(h.FileInventoryCount, 0) - ((ISNULL(h.UpdatedCount,0) + ISNULL(h.InsertedCount,0)) + (ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount,0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) + ISNULL(h.OverLimitCount,0) + ISNULL(h.DuplicateCount,0))) AS [Records Remaining],
		h.InventoryUploadHistoryId
	FROM InventoryUploadHistory h
	INNER JOIN Company C
		ON h.CompanyId = C.CompanyID
	LEFT OUTER JOIN InventorySettings InvS
		ON C.CompanyID = InvS.CompanyID

	SELECT *
	FROM @tmpHistory h
	WHERE DATEADD(dd, DATEDIFF(dd, 0, h.UploadDate), 0) >= DATEADD(dd, DATEDIFF(dd, 0, @fromDate), 0)
		AND DATEADD(dd, DATEDIFF(dd, 0, h.UploadDate), 0) <= DATEADD(dd, DATEDIFF(dd, 0, @toDate), 0)
	ORDER BY h.CompanyName, h.InventoryUploadHistoryId DESC
END

GO
----------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[Usp_getListofOnlineAdJobFolders]    Script Date: 03/13/2013 12:34:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Usp_getListofOnlineAdJobFolders]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Usp_getListofOnlineAdJobFolders]
GO


/****** Object:  StoredProcedure [dbo].[Usp_getListofOnlineAdJobFolders]    Script Date: 03/13/2013 12:34:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =========================================================================================          
-- Author			: Sudha 
-- Create date		: 09-June-2011 
-- Description		: Get all the online job folders list 
-- Modified by		: Nawnit Kumar       
-- Modified Date	: 06-March-2013
-- Description		: To get the ApprovalRequestDate and ApprovalDate
-- Modified			: By lalbahadur on 4/2/2013 removed edition id to avoid multiple entries for same order#
-- ==========================================================================================
--EXEC [Usp_getListofOnlineAdJobFolders] 'Powell Electronics',0,0,0 
		       
		CREATE PROCEDURE [dbo].[Usp_getListofOnlineAdJobFolders]       
		(      
			@strAdvertisername varchar(75),      
			@statusid int,      
			@month int,      
			@year int      
		)      
		AS   
		   
		set transaction isolation level read uncommitted  
		
		Declare @strSQLSELECT varchar(800)      
		Declare @strSQLFROM varchar(800)      
		Declare @strSQLWHERE varchar(800)   

		set @strAdvertisername = REPLACE(@strAdvertisername, '''', '''''')
		      
		BEGIN
		
		Select  @strSQLSELECT='SELECT DISTINCT 
		adjob.adjobfolderid,
			DATENAME(MM, ad.Activationdate) + '' '' + CAST(DAY(ad.Activationdate)AS  VARCHAR(2)) + '' '' + CAST(YEAR(ad.Activationdate) AS VARCHAR(4)) AS orderdate,
			comp.Companyid,comp.companyname,mstadjob.[description],adord.adordernumber,CONVERT(VARCHAR(10), MAX(Ada.ApprovalRequestDate), 101) AS ApprovalRequestDate,CONVERT(VARCHAR(10), Ada.ApprovalDate, 101) AS ApprovalDate'
			
		Select @strSQLFROM =  ' FROM  AdOrderDetails ad (NOLOCK)
				INNER JOIN ADORDER adord					(NOLOCK)	ON adord.ADORDERID=ad.ADORDERID
				INNER JOIN AdOrderDetailsRegionEdition  aded(NOLOCK)	ON aded.AdOrderDetailsId=ad.AdOrderDetailsId
				INNER JOIN AdJobFolderMaster adjob			(NOLOCK)	ON adjob.ADJOBFOLDERID=aded.ADJOBFOLDERID
				INNER JOIN Company comp						(NOLOCK)	ON comp.COMPANYID=adord.COMPANYID				
				INNER JOIN MstAdJobFolderStatus mstadjob	(NOLOCK)	ON mstadjob.StatusId=adjob.StatusId 
				LEFT JOIN Adapproval Ada					(NOLOCK)	ON Ada.Jobfolderid=aded.ADJOBFOLDERID
				'
				
		Select @strSQLWHERE  = '  WHERE ad.OrderType= ''O'' and adord.StatusId in (3,4,5)'  
		if @strAdvertisername <> ''	
			 Select @strSQLWHERE = @strSQLWHERE + ' and comp.companyname Like  ' + '''' + ltrim(rtrim(@strAdvertisername)) + '%' + ''''       
		          
		If @statusid <> 0  	
				 Select @strSQLWHERE= @strSQLWHERE + ' and adjob.statusid = ' + convert(varchar(30), @statusid)      
		        
		if @month <> 0         
				 Select @strSQLWHERE= @strSQLWHERE + ' and datepart(MM,ad.Activationdate) = ' + convert(varchar(30), @month)      
		        
		if @year <> 0                   
				  Select @strSQLWHERE= @strSQLWHERE + ' and datepart(YYYY,ad.Activationdate) = ' +  convert(varchar(30), @year)    
				   
		exec (@strSQLSELECT + @strSQLFROM + @strSQLWHERE + ' GROUP BY ad.AdOrderId,aded.editionid,adjob.adjobfolderid,ad.Activationdate,comp.Companyid,comp.companyname,mstadjob.[description],adord.adordernumber,Ada.ApprovalDate'+' order by adord.adordernumber desc') 		
		END 


GO
--------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetOnlineJobFolderInfo]    Script Date: 04/02/2013 19:47:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetOnlineJobFolderInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetOnlineJobFolderInfo]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetOnlineJobFolderInfo]    Script Date: 04/02/2013 19:47:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =========================================================================================      
-- Author   : Sudha  
-- Modified By   :  
-- Create date   : 13-June-2011  
-- Modified Date :   
-- Description   : Get Online Job Folder information  
-- Modified by	 : Removed OrderId parameter - There is no need of order id parameter on 4/2/2013
-- ==========================================================================================       
--[usp_GetOnlineJobFolderInfo]       21158
CREATE PROCEDURE [dbo].[usp_GetOnlineJobFolderInfo]                    
(                  
  @adjobfolderid  int
)                          
AS                          
 BEGIN    
  
 SELECT DISTINCT   
  
       com.companyname,  
       aom.companyid,  
       DATENAME(MM, aso.Activationdate) + ' ' + CAST(DAY(aso.Activationdate)AS  VARCHAR(2)) + ' ' + CAST(YEAR(aso.Activationdate) AS VARCHAR(4)) AS orderdate,
       aso.Adorderid,  
       afs.description,  
       a.statusid,  
       a.jobfolderinstruction  
 FROM AdJobFolderMaster a   
        INNER JOIN AdOrderDetailsRegionEdition ad   
           ON a.AdJobFolderId = ad.AdJobFolderId  
  INNER JOIN AdOrderDetails aso  
           ON aso.AdOrderDetailsId = ad.AdOrderDetailsId  
  INNER JOIN AdOrder aom  
           ON aom.AdOrderId = aso.AdOrderId  
  INNER JOIN company com   
           ON com.companyid = aom.companyid          
        INNER JOIN Mstadjobfolderstatus afs  
           ON afs.statusid=a.statusid  
  
  WHERE a.AdJobFolderId =@adjobfolderid 
  
END

GO
---------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetJobFolderInfo]    Script Date: 04/02/2013 19:51:13 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetJobFolderInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetJobFolderInfo]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetJobFolderInfo]    Script Date: 04/02/2013 19:51:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =========================================================================================      
-- Author   : Sudha  
-- Modified By   :  
-- Create date   : 26-May-2011  
-- Modified Date :   
-- Description   : Get Job Folder information  
-- Modified by	 : Removed edition id parameter on 4/2/2013
-- ==========================================================================================       
--[usp_GetJobFolderInfo]    21185   
CREATE PROCEDURE [dbo].[usp_GetJobFolderInfo]               
(                  
  @adjobfolderid  int  
)                          
AS                          
 BEGIN    
  
 SELECT DISTINCT   
       com.companyname,aso.Adorderid, afs.description,ad.editionid,(select zonecode from countryzones where zoneid=E.regionid)+' '+ right(E.[Year],2) as Edition,  a.*  
 FROM AdJobFolderMaster a   
        INNER JOIN AdOrderDetailsRegionEdition ad   
           ON a.AdJobFolderId = ad.AdJobFolderId  
  INNER JOIN AdOrderDetails aso  
           ON aso.AdOrderDetailsId = ad.AdOrderDetailsId  
  INNER JOIN AdOrder aom  
           ON aom.AdOrderId = aso.AdOrderId  
  INNER JOIN company com   
           ON com.companyid = aom.companyid  
        INNER JOIN editions e   
           ON e.editionid=ad.EditionID    
        INNER JOIN Mstadjobfolderstatus afs  
           ON afs.statusid=a.statusid  
  
  WHERE a.AdJobFolderId =@adjobfolderid 
  
END

GO

----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------


/****** Object:  StoredProcedure [dbo].[usp_GetSEOCompanyId]    Script Date: 07/27/2012 08:24:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSEOCompanyId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSEOCompanyId]
GO

  
/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
{This should be a short description about the functionality of this procedure.}

Parameters:
{A short description of parameters and default values if there is any.}

Used by: 
{This could be the name of a single webpage or multiple web pages or a SSIS package or a scheduled job etc. But if this functionality is used in many places within an application then just mention the application name. Otherwise <application name>.<module name or web page name>}
(Having this information will be very helpful to find out what all applications will get affected if we need to make a change.)

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
08.08.2011		Christian		Created. 
04.04.2013		Marcus Ruether	Changed comparison to used c.Search_CompanyName instead of [dbo].[RemoveSpecialCharacter](c.CompanyName)  
								This was made to address performance issue. - 26858 
------------------------------------------------------------------------------------------------------------------------------------------*/     
CREATE PROCEDURE [dbo].[usp_GetSEOCompanyId]
   @companyName varchar(100)      
AS      

--DECLARE @companyName varchar(100) = 'montrosecdt'  

BEGIN      
	SELECT TOP 1 C.CompanyID 
	FROM Company C  with(nolock) 
	INNER JOIN MstStatus S
		ON C.CompanyStatusID = S.StatusID
		AND S.isActive = 1
	WHERE c.Search_CompanyName = [dbo].[RemoveSpecialCharacter](@companyName)  
	ORDER BY S.StatusID -- Display Active companies at top of list
END


GO





----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_AddAdOrderDetails]    Script Date: 04/02/2013 20:39:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_AddAdOrderDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_AddAdOrderDetails]
GO

/****** Object:  StoredProcedure [dbo].[usp_AddAdOrderDetails]    Script Date: 04/02/2013 20:39:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--*****************************************************************************************************                          
--*   Stored Procedure  : [usp_AddAdOrderDetails]                        
--*   Description  : Insert Ad Order Details                         
--*   Author   : SIVA PRAKASH D                    
--*   Creation Date  : 05/27/2011                      
--*****************************************************************************************************         
--*   Modify Auth: Kiran Sangoi 
--*   Description  : Added logic for implementing One Per Edition flag - returns -2 if this validation fails.
--*   Modify  Date  : Dec. 2nd, 2011                      
--usp_AddAdOrderDetails 187, 2, 1, 40, 0, 109276, N'test', 1430.20, 1, N'N', '0', 0, '2001-11-30', 24, '5,6,6,4,7,2,8,9,3,25,1', '213,227,212,218,219,217,220,221,222,225,223', N'P' , 75, 1, '0'
--*****************************************************************************************************         
--*	Modified By : Ajija Fathima.K
--* Modified On : 01/Dec/2011	  
--* Modified	: By Lalbahdaur on 03/29/2013 Modified logic to enter priority dates based on below
--1.	If an order exists for that distributor (company) for given manufacturer in that zone the previous year than keep the priority date on the system. Don�t change anything.
--2.	If no order exists in previous year (either first time advertising or advertising after a break) then set the priority date to order date .    
--*****************************************************************************************************         
		CREATE PROCEDURE [dbo].[usp_AddAdOrderDetails]                                                    
		(                 
		 @AdOrderId    INT,                                                           
		 @SectionID    INT,                                                    
		 @SizeTypeID   INT,                                                   
		 @AdTypeID    INT,        
		 @LogoIndicator   BIT,                                              
		 @PositionTitle   BIGINT,                                                    
		 @Comments    TEXT,                                                     
		 @Price     MONEY,                                                    
		 @ApplyDiscount   BIT,          
		 @CompIndicator   CHAR(1),                                            
		 @CompCode    VARCHAR(10),                                            
		 @Duration    INT,                             
		 @ActivationDate  DATETIME,                                           
		 @LastUpdatedBy   INT,        
		 @RegionSelected  VARCHAR(200),        
		 @EdtionSelected  VARCHAR(200),        
		 @OrderType    CHAR(1),      
		 @RateCardId   INT ,    
		 @Version  INT ,
		 @OrderRegionId VARCHAR(100),
		 @GrossAmountPerGuranteedLine INT                                     
		)                                                    
		AS                                                    
		BEGIN                                                    
			SET NOCOUNT ON            
			DECLARE @DupCount INT, @TmpSQL nvarchar(4000)
			IF @OrderType = 'P'
			BEGIN 
				SET @TmpSQL ='SELECT @DupCount = Count(8) 
				  FROM [AdOrderDetails] AOD
				  JOIN ADDetails Ad on AOD.[AdTypeID] = ad.[AdTypeID]  AND Ad.OnePerEdition = 1 
						AND AOD.AdTypeID = ' +CONVERT(varchar(10), @AdTypeID ) + '
				  JOIN dbo.AdOrderDetailsRegionEdition ADRE on ADRE.AdOrderDetailsID =AOD.AdOrderDetailsID
						AND ADRE.EditionID in (' + @EdtionSelected + ') 
				  WHERE AdOrderID in (Select AdOrderID from AdOrder where StatusID >= 3 )
				  AND AOD.[PositionTitle] =' +CONVERT(varchar(10), @PositionTitle)
				  Print 'Here Success 2'
				EXEC sp_executesql @TmpSQL, N'@DupCount int OUTPUT', @DupCount OUTPUT
				print @TmpSQL
				print @DupCount
				  IF @DupCount > 0 
					--- One Per Edition flag is True & duplicate exists so the transaction should fail.
					return -2
			END	                                                        
		 DECLARE @OrderDetailsId INT        
		        
		 DECLARE @NextStringReg VARCHAR(200)        
		 DECLARE @PosReg INT        
		 DECLARE @NextPosReg INT        
		 DECLARE @StringReg VARCHAR(200)        
		 DECLARE @DelimiterReg VARCHAR(40)        
		        
		 DECLARE @NextStringEdition VARCHAR(200)        
		 DECLARE @PosEdition INT        
		 DECLARE @NextPosEdition INT        
		 DECLARE @StringEdition VARCHAR(200)        
		 DECLARE @DelimiterEdition VARCHAR(40)        
		 DECLARE @RegionId INT        
		 DECLARE @EditionId  INT       
		 DECLARE @PriorityDate datetime        
		  INSERT INTO AdOrderDetails                                              
		  (                                                    
		  AdOrderId,                                                           
		  SectionID,                                                    
		  SizeTypeID,                                                   
		  AdTypeID,        
		  LogoIndicator,                                              
		  PositionTitle,                                                    
		  Comments,                                                     
		  Price,                                                    
		  ApplyDiscount,          
		  CompIndicator,                                            
		  CompCode,                                            
		  Duration,                             
		  ActivationDate,                                           
		  LastUpdatedBy,        
		  OrderType,      
		  RateCardId,
		  OrderRegionId      
		  )                                                  
		  VALUES                            
		  (                                                    
		  @AdOrderId,                                                           
		  @SectionID,                                                    
		  @SizeTypeID,                                                   
		  @AdTypeID,        
		  @LogoIndicator,                                              
		  @PositionTitle,                                                    
		  @Comments,                                                     
		  @Price,                                                    
		  @ApplyDiscount,          
		  @CompIndicator,            
		  @CompCode,                                            
		  @Duration,                             
		  @ActivationDate,      
		  @LastUpdatedBy,        
		  @OrderType,      
		  @RateCardId,
		  @OrderRegionId                                              
		  )                                                   
		  SET @OrderDetailsId = SCOPE_IDENTITY()       
		    
		DECLARE @AdOrderRevisionId INT   
		DECLARE @AdOrderRevisionCount INT
		DECLARE @AdOrderStatus INT  
			-- FOR ORDER REVISION (CHANGE FORM)
			SELECT @AdOrderStatus = StatusId FROM AdOrder WHERE AdOrderId=@AdOrderId 

			IF @AdOrderStatus>=3 AND @AdOrderStatus<=4
			BEGIN
				SELECT @AdOrderRevisionCount = count(*) FROM  AdOrderRevision WHERE Version=@Version AND AdOrderId=@AdOrderId  
				IF @AdOrderRevisionCount>0    
				BEGIN    
						SELECT @AdOrderRevisionId=MAX(AdOrderRevisionId) FROM AdOrderRevision WHERE AdOrderId=@AdOrderId    									
						
				END    
				ELSE    
				BEGIN    
						INSERT INTO AdOrderRevision VALUES(@AdOrderId,@Version,GETDATE(), 
						(select AR.DiscountRate from AdOrder AR where AR.AdOrderId = @AdOrderId))    
						SET @AdOrderRevisionId = SCOPE_IDENTITY()     	
				END

				--Adding This Newly Added Ad To AdOrderDetailsRevision							
				INSERT INTO AdOrderDetailsRevision(AdOrderDetailsId,AdOrderId,SectionID,SizeTypeID,AdTypeID,LogoIndicator,PositionTitle,Comments,Price,ApplyDiscount,CompIndicator,CompCode,Duration,ActivationDate, LastUpdatedBy, OrderType,RateCardId,OrderRegionId,AdOrderRevisionId)
				SELECT @OrderDetailsId,@AdOrderId,@SectionID,@SizeTypeID,@AdTypeID,@LogoIndicator,@PositionTitle,@Comments,@Price,@ApplyDiscount,@CompIndicator,@CompCode,@Duration,@ActivationDate, @LastUpdatedBy, @OrderType,@RateCardId, @OrderRegionId, @AdOrderRevisionId     
				
				--Adding All Existing Ads To AdOrderDetailsRevision			
				INSERT INTO AdOrderDetailsRevision(AdOrderDetailsId,AdOrderId,SectionID,SizeTypeID,AdTypeID,LogoIndicator,PositionTitle,Comments, Price, ApplyDiscount,CompIndicator,CompCode,Duration,ActivationDate, LastUpdatedBy, OrderType,RateCardId,OrderRegionId,AdOrderRevisionId) 
				SELECT AOD.AdOrderDetailsId,AOD.AdOrderId,AOD.SectionID,AOD.SizeTypeID,AOD.AdTypeID,AOD.LogoIndicator, AOD.PositionTitle,AOD.Comments, AOD.Price, AOD.ApplyDiscount,AOD.CompIndicator, AOD.CompCode,AOD.Duration, AOD.ActivationDate, AOD.LastUpdatedBy, AOD.OrderType,AOD.RateCardId,AOD.OrderRegionId,@AdOrderRevisionId  
				FROM AdOrderDetails AOD WHERE AdOrderId = @AdOrderId AND AOD.AdOrderDetailsId NOT IN(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId AND AdOrderRevisionId = @AdOrderRevisionId)
			END 
			------- END ---------   
		        
			 SET @StringReg =@RegionSelected        
			 SET @DelimiterReg = ','        
			 SET @StringReg = @StringReg + @DelimiterReg        
			 SET @PosReg = charindex(@DelimiterReg,@StringReg)        
			        
			 SET @StringEdition =@EdtionSelected        
			 SET @DelimiterEdition = ','        
			 SET @StringEdition = @StringEdition + @DelimiterEdition        
			 SET @PosEdition = charindex(@DelimiterEdition,@StringEdition)        
			        
			 WHILE (@PosReg <> 0)        
			 BEGIN        
			  SET @NextStringEdition = substring(@StringEdition,1,@PosEdition - 1)        
			  --SELECT @NextPosEdition -- Show Results        
			  SET @StringEdition = substring(@StringEdition,@PosEdition+1,len(@StringEdition))        
			  SET @PosEdition = charindex(@DelimiterEdition,@StringEdition)        
			        
			  SET @NextStringReg = substring(@StringReg,1,@PosReg - 1)        
			  --SELECT @NextStringReg -- Show Results        
			  SET @StringReg = substring(@StringReg,@PosReg+1,len(@StringReg))        
			  SET @PosReg = charindex(@DelimiterReg,@StringReg)        
				    
			  IF @OrderType = 'P'  
			  BEGIN   
			  
				 /*------------Added by Lalbahadur on 3/29/2013----------------------------*/
				 set @PriorityDate =  dbo.udf_GetAdOrderPriorityDate(@AdOrderId,@PositionTitle,@NextStringReg,@NextStringEdition)
				 
				 /*-------------------------------------------------------------------------*/
				 INSERT INTO AdOrderDetailsRegionEdition(AdOrderDetailsId,RegionID,EditionID,PriorityDate) 
				 VALUES(@OrderDetailsId,@NextStringReg,@NextStringEdition,@PriorityDate)    -- Priority date added by Fathima 0n 01-12-2011    
				 
				IF @AdOrderStatus>=3 AND @AdOrderStatus<=4
				BEGIN
				
					--Adding This Newly Added Ad To AdOrderDetailsRegionEditionRevision	
					INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId,EditionID,RegionID, PriorityDate, AdOrderRevisionId) 
					VALUES(@OrderDetailsId,@NextStringEdition, @NextStringReg, @PriorityDate, @AdOrderRevisionId)          
				
					--Adding All Existing Ads To AdOrderDetailsRegionEditionRevision	
					INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId, EditionID, RegionID, PriorityDate, AdOrderRevisionId) 			
					SELECT R.AdOrderDetailsId, R.EditionID, R.RegionID, R.PriorityDate, @AdOrderRevisionId 
					FROM AdOrderDetailsRegionEdition R WHERE AdOrderDetailsId IN
					(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId) 
					AND R.AdOrderDetailsId NOT IN(SELECT AdOrderDetailsId FROM AdOrderDetailsRegionEditionRevision WHERE AdOrderDetailsId IN
					(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId) AND AdOrderRevisionId = @AdOrderRevisionId)

				END
			  END  
			  ELSE  
			  BEGIN  
				 INSERT INTO AdOrderDetailsRegionEdition(AdOrderDetailsId,RegionID,EditionID,PriorityDate, OnlineMonth,OnlineYear) 
				 VALUES(@OrderDetailsId,@NextStringReg,@NextStringEdition,@PriorityDate,DATEPART(MONTH,@ActivationDate),DATEPART(YEAR,@ActivationDate))   -- Priority date added by Fathima 0n 01-12-2011         
				 
				IF @AdOrderStatus>=3 AND @AdOrderStatus<=4
				BEGIN	
				
					--Adding This Newly Added Ad To AdOrderDetailsRegionEditionRevision	
					INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId,EditionID, RegionID, PriorityDate, AdOrderRevisionId,OnlineMonth,OnlineYear) 
					VALUES(@OrderDetailsId,@NextStringEdition, @NextStringReg, @PriorityDate, @AdOrderRevisionId,DATEPART(MONTH,@ActivationDate),DATEPART(YEAR,@ActivationDate))             

					--Adding All Existing Ads To AdOrderDetailsRegionEditionRevision	
					INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId, EditionID, RegionID, PriorityDate, AdOrderRevisionId, OnlineMonth, OnlineYear) 			
					SELECT R.AdOrderDetailsId, R.EditionID, R.RegionID, R.PriorityDate, @AdOrderRevisionId, R.OnlineMonth, R.OnlineYear 
					FROM AdOrderDetailsRegionEdition R WHERE AdOrderDetailsId   IN
					(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId)
					AND R.AdOrderDetailsId NOT IN(SELECT AdOrderDetailsId FROM AdOrderDetailsRegionEditionRevision WHERE AdOrderDetailsId IN
					(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId) AND AdOrderRevisionId = @AdOrderRevisionId)


				END
			  END  
			        
			 END         
			  EXEC uspAdJobFolderCreatePrint
			  EXEC uspAdJobFolderCreateOnline
			  EXEC usp_AdOrderGrossNetAmount @AdOrderId, @GrossAmountPerGuranteedLine
			   	         
			 return @OrderDetailsId            
		END



GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_UpdateAdOrderDetails]    Script Date: 04/02/2013 20:42:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_UpdateAdOrderDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_UpdateAdOrderDetails]
GO

/****** Object:  StoredProcedure [dbo].[usp_UpdateAdOrderDetails]    Script Date: 04/02/2013 20:42:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--*****************************************************************************************************                                    
--*   Stored Procedure  : usp_UpdateAdOrderDetails                                  
--*   Description  : Update Ad Order Details                                   
--*   Author   : SIVA PRAKASH D                              
--*   Creation Date  : 05/27/2011                                
--*****************************************************************************************************                                    
--*   Description  : Updated For Change Form
--*   Modified By  : Aatish Agarwal
--*   Modified Date: 25 June 2012
--* Modified	: By Lalbahdaur on 03/29/2013 Modified logic to enter priority dates based on below
--1.	If an order exists for that distributor (company) for given manufacturer in that zone the previous year than keep the priority date on the system. Don�t change anything.
--2.	If no order exists in previous year (either first time advertising or advertising after a break) then set the priority date to order date .    
--*****************************************************************************************************            
				CREATE PROCEDURE [dbo].[usp_UpdateAdOrderDetails]                                                              
				(                           
				 @AdOrderId    INT,                                                                     
				 @SectionID    INT,                                                              
				 @SizeTypeID   INT,                                                             
				 @AdTypeID    INT,                  
				 @LogoIndicator   BIT,                                                        
				 @PositionTitle   BIGINT,                                                              
				 @Comments    TEXT,                                                               
				 @Price     MONEY,                                                              
				 @ApplyDiscount   BIT,                    
				 @CompIndicator   CHAR(1),                                                      
				 @CompCode    VARCHAR(10),                                                      
				 @Duration    INT,                                       
				 @ActivationDate  DATETIME,                                                     
				 @LastUpdatedBy   INT,                  
				 @RegionSelected  VARCHAR(200),                  
				 @EdtionSelected  VARCHAR(200),                  
				 @OrderType    CHAR(1),                
				 @AdOrderDetailsId INT ,              
				 @RateCardId INT,          
				 @Version  INT,      
				 @OrderRegionId VARCHAR(100), 
				 @GrossAmountPerGuranteedLine INT                                                       
				)                                                              
				AS                                                              
				BEGIN                                                              
					SET NOCOUNT ON                      
				                                                        
				 DECLARE @OrderDetailsId INT                  
				                  
				 DECLARE @NextStringReg VARCHAR(200)                  
				 DECLARE @PosReg INT                  
				 DECLARE @NextPosReg INT                  
				 DECLARE @StringReg VARCHAR(200)                  
				 DECLARE @DelimiterReg VARCHAR(200)                  
				                  
				 DECLARE @NextStringEdition VARCHAR(200)                  
				 DECLARE @PosEdition INT                  
				 DECLARE @NextPosEdition INT                  
				 DECLARE @StringEdition VARCHAR(200)                  
				 DECLARE @DelimiterEdition VARCHAR(200)                  
				                  
				 DECLARE @RegionId INT                  
				 DECLARE @EditionId  INT           
				        
				DECLARE @AdOrderRevisionId INT         
				DECLARE @AdOrderRevisionCount INT        
				DECLARE @AdOrderStatus INT  
				DECLARE @PriorityDate datetime              
				      
				  UPDATE AdOrderDetails                 
				  SET                                                         
				  AdOrderId  =@AdOrderId,                                                                     
				  SectionID  =@SectionID,                                                              
				  SizeTypeID =@SizeTypeID,                                                             
				  AdTypeID  =@AdTypeID,                  
				  LogoIndicator =@LogoIndicator,                                                        
				  PositionTitle =@PositionTitle,                                                              
				  Comments  =@Comments,                                                               
				  Price   =@Price,                                                              
				  ApplyDiscount =@ApplyDiscount,                    
				  CompIndicator =@CompIndicator,                                                      
				  CompCode  =@CompCode,                                                      
				  Duration  =@Duration,                                       
				  ActivationDate=@ActivationDate,                                                     
				  LastUpdatedBy =@LastUpdatedBy ,              
				  RateCardId = @RateCardId,            
				  OrderType=@OrderType,      
				  OrderRegionId = @OrderRegionId               
				  WHERE  AdOrderDetailsId =@AdOrderDetailsId                
				                  
				                                                       
				 SET @OrderDetailsId = @AdOrderDetailsId                    
				 
				 --------------FOR ORDER REVISION (CHANGE FORM)---------------------
				 
				 SELECT @AdOrderStatus = StatusId FROM AdOrder WHERE AdOrderId=@AdOrderId       
				      
				 IF @AdOrderStatus>=3 AND @AdOrderStatus<=4                                                         
				 BEGIN      
					SELECT @AdOrderRevisionCount = count(*) FROM  AdOrderRevision WHERE Version=@Version AND AdOrderId=@AdOrderId            
					IF @AdOrderRevisionCount>0          
						BEGIN      
							SELECT @AdOrderRevisionId=MAX(AdOrderRevisionId) FROM AdOrderRevision WHERE AdOrderId=@AdOrderId          
							
							UPDATE AdOrderDetailsRevision                 
							SET                                                         
							AdOrderId  =	@AdOrderId,                                                                     
							SectionID  =	@SectionID,                                                              
							SizeTypeID =	@SizeTypeID,                                                             
							AdTypeID  =		@AdTypeID,                  
							LogoIndicator =	@LogoIndicator,                                                        
							PositionTitle =	@PositionTitle,                                                              
							Comments  =		@Comments,                                                               
							Price   =		@Price,                                                              
							ApplyDiscount =	@ApplyDiscount,                    
							CompIndicator =	@CompIndicator,                                                      
							CompCode  =		@CompCode,                                                      
							Duration  =		@Duration,                                       
							ActivationDate=	@ActivationDate,                                                     
							LastUpdatedBy =	@LastUpdatedBy ,              
							RateCardId =	@RateCardId,            
							OrderType=		@OrderType,      
							OrderRegionId = @OrderRegionId               
							WHERE  AdOrderDetailsId =@AdOrderDetailsId AND  AdOrderRevisionId = @AdOrderRevisionId                     
						END          
					ELSE    
						BEGIN    		
							INSERT INTO AdOrderRevision VALUES(@AdOrderId,@Version,GETDATE(),
							(select AR.DiscountRate from AdOrder AR where AR.AdOrderId = @AdOrderId))    
							SET @AdOrderRevisionId = SCOPE_IDENTITY()     
							
							--Adding This Newly Added Ad To AdOrderDetailsRevision							
							INSERT INTO AdOrderDetailsRevision(AdOrderDetailsId,AdOrderId,SectionID,SizeTypeID,AdTypeID,LogoIndicator,PositionTitle,Price,ApplyDiscount,CompIndicator,CompCode,Duration,ActivationDate, LastUpdatedBy, OrderType,RateCardId,OrderRegionId,AdOrderRevisionId)
							SELECT @OrderDetailsId,@AdOrderId,@SectionID,@SizeTypeID,@AdTypeID,@LogoIndicator,@PositionTitle,@Price,@ApplyDiscount,@CompIndicator,@CompCode,@Duration,@ActivationDate, @LastUpdatedBy, @OrderType,@RateCardId, @OrderRegionId, @AdOrderRevisionId     
								
							--Adding All Existing Ads To AdOrderDetailsRevision			
							INSERT INTO AdOrderDetailsRevision(AdOrderDetailsId,AdOrderId,SectionID,SizeTypeID,AdTypeID,LogoIndicator,PositionTitle,Price,ApplyDiscount,CompIndicator,CompCode,Duration,ActivationDate, LastUpdatedBy, OrderType,RateCardId,OrderRegionId,AdOrderRevisionId) 
							SELECT AOD.AdOrderDetailsId,AOD.AdOrderId,AOD.SectionID,AOD.SizeTypeID,AOD.AdTypeID,AOD.LogoIndicator, AOD.PositionTitle, AOD.Price, AOD.ApplyDiscount,AOD.CompIndicator, AOD.CompCode,AOD.Duration, AOD.ActivationDate, AOD.LastUpdatedBy, AOD.OrderType,AOD.RateCardId,AOD.OrderRegionId,@AdOrderRevisionId 
							FROM AdOrderDetails AOD WHERE AdOrderId = @AdOrderId AND AOD.AdOrderDetailsId NOT IN(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId AND AdOrderRevisionId = @AdOrderRevisionId) 						
						END
				END       
				 ------- END ---------   
				 
				                
				 DELETE FROM AdOrderDetailsRegionEdition WHERE AdOrderDetailsId =@OrderDetailsId 
				 DELETE FROM AdOrderDetailsRegionEditionRevision WHERE AdOrderDetailsId = @OrderDetailsId AND AdOrderRevisionId = @AdOrderRevisionId 
				         
					 SET @StringReg =@RegionSelected        
					 
					 SET @DelimiterReg = ','        
					 SET @StringReg = @StringReg + @DelimiterReg        
					 SET @PosReg = charindex(@DelimiterReg,@StringReg)        
					        
					 SET @StringEdition =@EdtionSelected        
					 SET @DelimiterEdition = ','        
					 SET @StringEdition = @StringEdition + @DelimiterEdition        
					 SET @PosEdition = charindex(@DelimiterEdition,@StringEdition)        
					        
					 WHILE (@PosReg <> 0)        
					 BEGIN        
					  SET @NextStringEdition = substring(@StringEdition,1,@PosEdition - 1)        
					  --SELECT @NextPosEdition -- Show Results        
					  SET @StringEdition = substring(@StringEdition,@PosEdition+1,len(@StringEdition))        
					  SET @PosEdition = charindex(@DelimiterEdition,@StringEdition)        
					        
					  SET @NextStringReg = substring(@StringReg,1,@PosReg - 1)        
					  --SELECT @NextStringReg -- Show Results        
					  SET @StringReg = substring(@StringReg,@PosReg+1,len(@StringReg))        
					  SET @PosReg = charindex(@DelimiterReg,@StringReg)        
				
					  IF @OrderType = 'P'  
					  BEGIN   
						 /*------------Added by Lalbahadur on 3/29/2013----------------------------*/
						 set @PriorityDate =  dbo.udf_GetAdOrderPriorityDate(@AdOrderId,@PositionTitle,@NextStringReg,@NextStringEdition)
						 /*-------------------------------------------------------------------------*/
						 
						 INSERT INTO AdOrderDetailsRegionEdition(AdOrderDetailsId,RegionID,EditionID,PriorityDate) 
						 VALUES(@OrderDetailsId,@NextStringReg,@NextStringEdition,@PriorityDate)    -- Priority date added by Fathima 0n 01-12-2011    
						 
						IF @AdOrderStatus>=3 AND @AdOrderStatus<=4
						BEGIN
						
							--Adding This Newly Added Ad To AdOrderDetailsRegionEditionRevision	
							INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId,EditionID,RegionID, PriorityDate, AdOrderRevisionId) 
							VALUES(@OrderDetailsId,@NextStringEdition, @NextStringReg, @PriorityDate, @AdOrderRevisionId)          
						
							--Adding All Existing Ads To AdOrderDetailsRegionEditionRevision	
							INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId, EditionID, RegionID, PriorityDate, AdOrderRevisionId) 			
							SELECT R.AdOrderDetailsId, R.EditionID, R.RegionID, R.PriorityDate, @AdOrderRevisionId 
							FROM AdOrderDetailsRegionEdition R WHERE AdOrderDetailsId IN
							(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId) 
							AND R.AdOrderDetailsId NOT IN(SELECT AdOrderDetailsId FROM AdOrderDetailsRegionEditionRevision WHERE AdOrderDetailsId IN
							(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId) AND AdOrderRevisionId = @AdOrderRevisionId)

						END
					  END  
					  ELSE  
					  BEGIN  
						 INSERT INTO AdOrderDetailsRegionEdition(AdOrderDetailsId,RegionID,EditionID,PriorityDate, OnlineMonth,OnlineYear) 
						 VALUES(@OrderDetailsId,@NextStringReg,@NextStringEdition,@PriorityDate,DATEPART(MONTH,@ActivationDate),DATEPART(YEAR,@ActivationDate))   -- Priority date added by Fathima 0n 01-12-2011         
						 
						IF @AdOrderStatus>=3 AND @AdOrderStatus<=4
						BEGIN	
						
							--Adding This Newly Added Ad To AdOrderDetailsRegionEditionRevision	
							INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId,EditionID, RegionID, PriorityDate, AdOrderRevisionId,OnlineMonth,OnlineYear) 
							VALUES(@OrderDetailsId,@NextStringEdition, @NextStringReg, @PriorityDate, @AdOrderRevisionId,DATEPART(MONTH,@ActivationDate),DATEPART(YEAR,@ActivationDate))             

							--Adding All Existing Ads To AdOrderDetailsRegionEditionRevision	
							INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId, EditionID, RegionID, PriorityDate, AdOrderRevisionId, OnlineMonth, OnlineYear) 			
							SELECT R.AdOrderDetailsId, R.EditionID, R.RegionID, R.PriorityDate, @AdOrderRevisionId, R.OnlineMonth, R.OnlineYear 
							FROM AdOrderDetailsRegionEdition R WHERE AdOrderDetailsId   IN
							(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId)
							AND R.AdOrderDetailsId NOT IN(SELECT AdOrderDetailsId FROM AdOrderDetailsRegionEditionRevision WHERE AdOrderDetailsId IN
							(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId) AND AdOrderRevisionId = @AdOrderRevisionId)


						END
					  END  
					        
					 END         

				 
				 EXEC uspAdJobFolderCreatePrint      
				 EXEC uspAdJobFolderCreateOnline        
				 EXEC usp_AdOrderGrossNetAmount @AdOrderId, @GrossAmountPerGuranteedLine           
				                   
				 return @OrderDetailsId                                             
				                              
				END


GO
-----------------------------------------------------------------------------------------------------------------------------------------------
GO





/****** Object:  StoredProcedure [dbo].[usp_addCopyADOrder]    Script Date: 04/08/2013 18:45:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_addCopyADOrder]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_addCopyADOrder]
GO

/****** Object:  StoredProcedure [dbo].[usp_addCopyADOrder]    Script Date: 04/08/2013 18:45:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

  
    
    
---------------------------------------------------------------------------------                                                 
--  Created By : Karthik Palanisamy                                          
--  Created On : 29-May-2011                                        
--  Description: This is sp for copy order                 
-----------------------------------------------                       
-- Modified By : Siva Prakash D              
--  Modified On : 16 - jun -11              
--  Add History table         
----------------------------------------------------------             
-- [dbo].[usp_addCopyADOrder] 376566 ,84306, 160        
-- Modified By : Parameswar Mal        
--  Modified On : 28-02-2013        
--Description: not copy inactive order to new order        
--* Modified : By Lalbahdaur on 03/29/2013 Modified logic to enter priority dates based on below      
--1. If an order exists for that distributor (company) for given manufacturer in that zone the previous year than keep the priority date on the system. Don�t change anything.      
--2. If no order exists in previous year (either first time advertising or advertising after a break) then set the priority date to order date .      
--------------------------------------------------    
--* Modified  : By Parameswar on 05/April/2013    
 -- Checking for print orders  for Edition id     
 -- Get the OnlineMonth and OnlineYear from activation date if exists else get the OnlineMonth and OnlineYear from the order     
  ---------------------------------    
  --* Modified  : By Parameswar on 08/April/2013    
 -- added column  AIF_Instruction,AIF_Url in adorderdetails when copy
 -- added column AIF_PrintInstruction in order order when copy
  ---------------------------------------------------------------------------------                               
  CREATE PROCEDURE [dbo].[usp_addCopyADOrder]                   
  (                                
   @AdOrderId INT,                            
   @CreatedBy INT,          
   @GrossAmountPerGuranteedLine INT                        
  )                                             
  AS                                        
  BEGIN                                        
  DECLARE @NeworderID INT                              
  DECLARE @OrderDetailsId INT          
          
  --- CURSOR for check active and inactive order        
          
          
CREATE TABLE #TempActiveOrders    -- create temp table for active order                   
  (                          
        
 AdOrderDetailsId INT,        
 AdOrderId INT,        
 SectionID INT,        
 SizeTypeID INT,        
 AdTypeID INT,        
 LogoIndicator BIT,        
 PositionTitle BIGINT,        
 Comments VARCHAR(1000),        
 Price MONEY,        
 ApplyDiscount BIT,        
 CompIndicator CHAR(1),        
 CompCode VARCHAR(100),        
 Duration INT,        
 ActivationDate DATETIME,        
 LastUpdatedOn DATETIME,        
 LastUpdatedBy INT,        
 OrderType CHAR(1),        
 RateCardId INT,
 AIF_Instruction VARCHAR(MAX),
 AIF_Url VARCHAR(300), 
 OrderRegionId VARCHAR(100)        
)        
CREATE TABLE #TempInActiveOrders  -- create temp table for Inactive order                 
  (                          
        
 AdOrderDetailsId INT,        
 AdOrderId INT,        
 SectionID INT,        
 SizeTypeID INT,        
 AdTypeID INT,        
 LogoIndicator BIT,        
 PositionTitle BIGINT,        
 Comments VARCHAR(1000),        
 Price MONEY,        
 ApplyDiscount BIT,        
 CompIndicator CHAR(1),        
 CompCode VARCHAR(100),        
 Duration INT,        
 ActivationDate DATETIME,        
 LastUpdatedOn DATETIME,        
 LastUpdatedBy INT,        
 OrderType CHAR(1),        
 RateCardId INT,
 AIF_Instruction VARCHAR(MAX),
 AIF_Url VARCHAR(300),              
 OrderRegionId VARCHAR(100)        
)        
        
      DECLARE @AdOrderDetailsId INT         
      DECLARE @SectionID   INT          
      DECLARE @AdTypeID   INT        
      DECLARE @PositionTitle BIGINT        
          
  DECLARE curActiveOrder CURSOR FAST_FORWARD READ_ONLY FOR        
             
     SELECT AdOrderDetailsId,@AdOrderId, SectionID ,AdTypeID,PositionTitle FROM AdOrderDetails WHERE  AdOrderId = @AdOrderId         
                
                
     OPEN curActiveOrder              
     FETCH curActiveOrder               
     INTO @AdOrderDetailsId,@AdOrderId,@SectionID ,@AdTypeID,@PositionTitle             
                
     WHILE @@FETCH_STATUS = 0        
     BEGIN        
            
 IF (SELECT [dbo].[GetActiveSalesOrder](@AdOrderId,@SectionID,@PositionTitle))> 0    --  for active order for(M,X,D,V,P)        
     OR (SELECT [dbo].[GetActiveSalesOrder](@AdOrderId,@SectionID,@PositionTitle))= -1   -- -1 for active order for other section        
                 
      BEGIN   -- for Active order             
      INSERT INTO #TempActiveOrders              
      SELECT        
    AdOrderDetailsId,        
    AdOrderId,                         
    SectionID,                            
    SizeTypeID,             
    AdTypeID,                            
    LogoIndicator,                            
    PositionTitle,                            
    Comments,                            
    Price,                            
    ApplyDiscount,                            
    CompIndicator,                            
    CompCode,                            
    Duration,                            
    ActivationDate,                            
    LastUpdatedOn,                            
    LastUpdatedBy,                            
    OrderType,                
    RateCardId,
    AIF_Instruction,
	AIF_Url,          
    OrderRegionId  FROM AdOrderDetails WHERE  AdOrderDetailsId = @AdOrderDetailsId         
      END        
                
      ELSE    -- for inactive order        
      BEGIN        
       INSERT INTO #TempInActiveOrders              
       SELECT        
       AdOrderDetailsId,        
       AdOrderId,                         
    SectionID,                            
    SizeTypeID,                            
    AdTypeID,                            
    LogoIndicator,                            
    PositionTitle,                            
    Comments,                            
    Price,                            
    ApplyDiscount,                            
    CompIndicator,                            
    CompCode,                            
    Duration,                            
    ActivationDate,                            
    LastUpdatedOn,                            
    LastUpdatedBy,                            
    OrderType,                
    RateCardId,
    AIF_Instruction,
	AIF_Url,             
    OrderRegionId  FROM AdOrderDetails WHERE  AdOrderDetailsId = @AdOrderDetailsId          
     END           
            
                
     FETCH curActiveOrder               
      INTO @AdOrderDetailsId,@AdOrderId,@SectionID ,@AdTypeID,@PositionTitle             
             
     END              
                
     CLOSE curActiveOrder              
     DEALLOCATE curActiveOrder              
            
      ---END  CURSOR for check active and inactive order        
          
     IF EXISTS(SELECT * FROM #TempActiveOrders WHERE AdOrderId=@AdOrderId)         
          
     BEGIN        
                              
   --copy adorder                            
   INSERT INTO adorder                            
   (                            
    SalesPersonId,                            
    CompanyId,                            
    StatusId,                            
    CoopIndicator,                            
    ContactId,                            
    BilltoId,                            
    SoldtoId,                            
    AuthorizedId,                            
    AddressProofId,                            
    CorpId,                            
    MsgCode,                            
    POnumber,                            
    Notes,                            
    Comments,                            
    BillingInstruction,                            
    RateCardYear,                            
    OrderDate,                            
    LastUpdatedOn,                            
    LastUpdatedBy,                            
    VersionNo,                            
    ExistingOrderId,                          
    GrossAmount,                        
    NetAmount,                          
    DiscountRate,              
    OverwriteDiscountFlag,
    AIF_PrintInstruction                         
   )                            
   SELECT                            
    SalesPersonId,                            
            
    CompanyId,                            
    1,                            
    CoopIndicator,                            
    ContactId,                            
    BilltoId,                            
    SoldtoId,                            
    AuthorizedId,                            
    AddressProofId,                            
    CorpId,                            
    MsgCode,                            
    POnumber,                            
    Notes,                            
    Comments,                            
    BillingInstruction,                            
    RateCardYear,                
    Getdate(),                            
    Getdate(),                            
    @CreatedBy,                            
    VersionNo,                            
    ExistingOrderId,                          
    GrossAmount,                          
    NetAmount,                     
    DiscountRate,              
    OverwriteDiscountFlag,
    AIF_PrintInstruction                   
                              
   FROM adorder                            
   WHERE  AdOrderId = @AdOrderId                            
                               
   SET @NeworderID = SCOPE_IDENTITY()              
   --set @NewAdOrderId =  @NeworderID                           
                             
                               
   UPDATE adorder SET AdOrderNumber = @NeworderID + 1000                  
   WHERE AdOrderId = @NeworderID                 
   --//History                         
   INSERT INTO AdOrderRevision VALUES(@NeworderID,1,GETDATE(), (Select DiscountRate FROM adorder              
   WHERE  AdOrderId = @AdOrderId))                
         
             
   --//copy adorderdetails       
         
    -- create temp table for  AdOrdersDetailsIdMap        
   CREATE TABLE #TempAdOrdersDetailsNewOldID                
    (                          
    AdOrderId INT,      
    AdOrderDetailsIdOld INT,        
    AdOrderDetailsIdNew INT,        
       
     )        
    ---START  CURSOR  ADORDER DETAILS ENTRY      
    DECLARE @AdOrderDetailsId_Old INT       
    DECLARE @AdOrderDetailsId_New INT        
    DECLARE curAdOrderDetails CURSOR FAST_FORWARD READ_ONLY FOR        
          
       -- select old adorder Details ID        
     SELECT AdOrderDetailsId FROM #TempActiveOrders WHERE  AdOrderId = @AdOrderId       
            
     OPEN curAdOrderDetails              
     FETCH curAdOrderDetails               
     INTO @AdOrderDetailsId_Old            
                
     WHILE @@FETCH_STATUS = 0        
     BEGIN        
            
     BEGIN   -- for Active AdOrderDetailsId          
    INSERT INTO AdOrderDetails                            
   (                            
    AdOrderId,                            
    SectionID,                            
    SizeTypeID,                            
    AdTypeID,                            
    LogoIndicator,                            
    PositionTitle,                            
    Comments,                            
    Price,                            
    ApplyDiscount,                            
    CompIndicator,                            
    CompCode,                            
    Duration,                            
    ActivationDate,                            
    LastUpdatedOn,                            
    LastUpdatedBy,                            
    OrderType,                
    RateCardId,
    AIF_Instruction,
	AIF_Url, 
    OrderRegionId                          
   )                            
   SELECT                            
    @NeworderID,                            
    SectionID,                            
    SizeTypeID,                            
    AdTypeID,                            
    LogoIndicator,             
    PositionTitle,                            
    Comments,                            
    price,                         
    ApplyDiscount,                            
    CompIndicator,                            
    CompCode,                            
    Duration,   
   (CASE WHEN OrderType = 'O' THEN dbo.[GetSalesOrderActivationDate](AdOrderDetailsId) ELSE NULL END), -- Get activation date  
	 GETDATE(),                            
    @CreatedBy,                            
    OrderType,                
    RateCardId,
    AIF_Instruction,
	AIF_Url,   
    OrderRegionId                
   FROM #TempActiveOrders                            
  WHERE  AdOrderDetailsId = @AdOrderDetailsId_Old       
          
    SET @AdOrderDetailsId_New = SCOPE_IDENTITY() -- set new adorderdetails id      
                
     INSERT INTO #TempAdOrdersDetailsNewOldID -- inserting mapping table                           
             (AdOrderId,AdOrderDetailsIdOld,AdOrderDetailsIdNew) VALUES(@NeworderID,@AdOrderDetailsId_Old,@AdOrderDetailsId_New )        
           
       END       
                    
     FETCH curAdOrderDetails               
      INTO @AdOrderDetailsId_Old             
             
     END              
                
     CLOSE curAdOrderDetails              
     DEALLOCATE curAdOrderDetails              
            
      ---END  CURSOR DETAILS      
   
                   
   DECLARE @AdOrderRevisionId INT               
   DECLARE @AdOrderRevisionCount INT              
                 
   SELECT @AdOrderRevisionId=MAX(AdOrderRevisionId) FROM AdOrderRevision WHERE AdOrderId=@NeworderID               
   INSERT INTO AdOrderDetailsRevision(AdOrderDetailsId,AdOrderId,SectionID,SizeTypeID,AdTypeID,LogoIndicator,PositionTitle,Price,ApplyDiscount,CompIndicator,CompCode,Duration,ActivationDate,OrderType,RateCardId,AdOrderRevisionId)              
   SELECT AdOrderDetailsId,@NeworderID,SectionID,SizeTypeID,AdTypeID,LogoIndicator,PositionTitle,Price,ApplyDiscount,CompIndicator,CompCode,Duration,ActivationDate,OrderType,RateCardId,@AdOrderRevisionId from AdOrderDetails where  AdOrderId= @NeworderID 

   --// copy AdOrderDetailsRegionEdition                          
   CREATE TABLE #AdOrderTEMP                         
   (                          
    AdOrderDetailsId INT,                          
    EditionID INT,                          
    RegionID INT,                          
    ADJobFolderID INT,                       
    PriorityDate DATETIME,              
    OnlineMonth  int,              
    OnlineYear   int,      
    PositionTitle int,      
    AdOrderId int              
   )                          
   INSERT INTO #AdOrderTEMP                          
   SELECT                          
  ADR.AdOrderDetailsId,                          
  (CASE WHEN AD.OrderType = 'P' THEN dbo.GetSalesOrderCurrentEditionID(ADR.RegionID) ELSE 0 END) AS EditionID,    -- get the earliest open edition in given region      
  ADR.RegionID,                          
  NULL,                          
  PriorityDate,   
 (CASE WHEN AD.OrderType = 'O' THEN ISNULL(DATEPART(MONTH,dbo.[GetSalesOrderActivationDate](ADR.AdOrderDetailsId)),OnlineMonth) ELSE OnlineMonth END)AS OnlineMonth,    
 (CASE WHEN AD.OrderType = 'O' THEN ISNULL(DATEPART(YEAR,dbo.[GetSalesOrderActivationDate](ADR.AdOrderDetailsId)),OnlineYear) ELSE OnlineYear END)AS OnlineYear,        
  AD.PositionTitle,      
  AD.AdOrderId                         
  FROM AdOrderDetailsRegionEdition ADR INNER JOIN #TempActiveOrders AD ON ADR.AdOrderDetailsId = AD.AdOrderDetailsId AND                          
  AdOrderId = @AdOrderId                          
      
         
   ---START  CURSOR  DETAILS RegionEdition       
   
    DECLARE @AdOrderDetailsIdOldEdition INT       
    DECLARE @AdOrderDetailsIdNewEdition INT        
    DECLARE curUpdateActiveOrderID CURSOR FAST_FORWARD READ_ONLY FOR       
          
     SELECT AdOrderDetailsIdOld,AdOrderDetailsIdNew FROM #TempAdOrdersDetailsNewOldID WHERE  AdOrderId = @NeworderID          
                 
                
     OPEN curUpdateActiveOrderID              
     FETCH curUpdateActiveOrderID               
     INTO @AdOrderDetailsIdOldEdition,@AdOrderDetailsIdNewEdition            
                
     WHILE @@FETCH_STATUS = 0        
     BEGIN        
            
         BEGIN      
            -- UPDATE OLD AdOrderDetailsId TO NEW  AdOrderDetailsId         
          UPDATE #AdOrderTEMP SET                          
          AdOrderDetailsId = @AdOrderDetailsIdNewEdition Where AdOrderDetailsId = @AdOrderDetailsIdOldEdition         
              
         END       
                    
     FETCH curUpdateActiveOrderID   
     INTO @AdOrderDetailsIdOldEdition,@AdOrderDetailsIdNewEdition                
             
     END              
                
     CLOSE curUpdateActiveOrderID              
     DEALLOCATE curUpdateActiveOrderID              
            
      ---END  CURSOR DETAILS EDITION      
        
                             
   INSERT INTO AdOrderDetailsRegionEdition                          
   SELECT                          
    AdOrderDetailsId,                          
    EditionID,                          
    RegionID,                          
    NULL,                          
    --PriorityDate,              
    dbo.udf_GetAdOrderPriorityDate(AdOrderId,PositionTitle,RegionID,EditionID),      
    OnlineMonth,              
    OnlineYear                           
   FROM #AdOrderTEMP                   
                 
   INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId,RegionID,EditionID,AdOrderRevisionId,OnlineMonth,OnlineYear)              
   SELECT AdOrderDetailsId,RegionID,EditionID,@AdOrderRevisionId,OnlineMonth,OnlineYear FROM #AdOrderTEMP                               
          
   DROP TABLE #AdOrderTEMP                          
   DROP TABLE  #TempAdOrdersDetailsNewOldID                                
                             
    EXEC usp_AdOrderGrossNetAmount @NeworderID , @GrossAmountPerGuranteedLine         
                     
   END         
           
   -- slect new order id        
           
    SELECT @NeworderID as NeworderID        
            
    ---select inactive order        
            
   SELECT AdOrderDetailsId,        
   (CASE WHEN dbo.GetPositionTitle(A.PositionTitle,A.SectionID) = '-' THEN S.Description +' '+SZ.Description +' '          
     ELSE S.Description +' '+SZ.Description +' at '+ dbo.GetPositionTitle(A.PositionTitle,A.SectionID) END)           
     AS SizeSectionPosition,      
       
      (CASE WHEN A.SectionID IN (1,2,12,14,18,26,31,38) THEN (SELECT CompanyName +' - ' +'Inactive' FROM Company WHERE CompanyID=A.PositionTitle)           
              ELSE (CASE WHEN A.SectionID IN (3,4,13,16) THEN (SELECT TypeDescription  +' - ' +'Inactive' FROM  ProductType where ProductTypeId = A.PositionTitle)END) END)      
      AS Remarks       
         
             
      From #TempInActiveOrders  A                 
    INNER JOIN SalesSectionType S ON A.SectionID=S.SectionID                  
    INNER JOIN SalesSizeType SZ ON A.SizeTypeID=SZ.SizeTypeID                 
    WHERE  A.AdOrderId = @AdOrderId             
             
     DROP TABLE  #TempActiveOrders         
     DROP TABLE #TempInActiveOrders              
           
  END          
          
        
      
GO


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_seo_getSiteMapData]    Script Date: 12/19/2012 08:27:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SiteMapLoad_GetSiteMapLinks]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_SiteMapLoad_GetSiteMapLinks]
GO


/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Used to generate sitemap

Used by: 
Global.ascx

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
12.18.2012		Marcus Ruether		Created. 
04.08.2013		Marcus Ruether		Updated to use Search_PartNumber rather than remove special chars from PartNumber with a function
									Added another procedure used in the sitemap gen process - renamed this one to make them consistent
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[usp_SiteMapLoad_GetSiteMapLinks]
AS
BEGIN

	DECLARE @CurrentDate DATETIME = GETDATE();
	CREATE TABLE #tblSiteMapLink_Group 
	(
		[Url] [varchar](500) NOT NULL,
		[ChangeFrequency] [varchar](10) NULL,
		[Priority] [decimal](18, 2) NULL
	)
	
	IF EXISTS(SELECT * FROM tmp_SiteMapLoad_SiteMapLink)
	BEGIN
		
		--Deactivate links that are not in the current list of urls.		
		UPDATE 
			sml SET sml.Active = 0, DateModified = @CurrentDate
		FROM 
			SiteMapLink sml LEFT JOIN
			tmp_SiteMapLoad_SiteMapLink tsml on tsml.Url = sml.Url
		WHERE 
			tsml.Url IS NULL
		
		--Delete those because we no longer need them. (they've been disabled)
		DELETE
			tsml
		FROM 
			SiteMapLink sml LEFT JOIN
			tmp_SiteMapLoad_SiteMapLink tsml on tsml.url = sml.Url
		WHERE 
			tsml.Url IS NULL
		
		--Active inactive links that are in the current list of url.
		UPDATE 
			sml SET sml.Active = 1, DateModified = @CurrentDate
		FROM 
			SiteMapLink sml LEFT JOIN
			tmp_SiteMapLoad_SiteMapLink tsml on tsml.url = sml.Url
		WHERE 
			tsml.Url IS NOT NULL AND
			sml.Active = 0
			
		--Delete records that already exist or have just been enabled
		DELETE tsml
		FROM 
			SiteMapLink sml INNER JOIN
			tmp_SiteMapLoad_SiteMapLink tsml on tsml.url = sml.Url
		

		DECLARE @SiteMapNumber INT;
		DECLARE @SiteMapCount INT;
		SET @SiteMapNumber = (SELECT ISNULL(MAX(SiteMapNumber), 0) FROM SiteMapLink);
		--sitemap can only have 50,000 records, so limit each one to that number
		
		SET @SiteMapCount = 50000;
		if (SELECT COUNT(*) FROM SiteMapLink WHERE SiteMapNumber = @SiteMapNumber) < 50000 
			BEGIN
				SET @SiteMapCount = (SELECT TOP 1 50000 - COUNT(*) FROM SiteMapLink WHERE SiteMapNumber = @SiteMapNumber);	
			END
		
		IF OBJECT_ID('tempdb..#tmpSiteMapLinkGroup') IS NOT NULL
		BEGIN
			DROP TABLE #tmpSiteMapLinkGroup
		END
		
		CREATE TABLE #tmpSiteMapLinkGroup
		(
			[SiteMapNumber] [int] NOT NULL,
			[Url] [varchar](500) NOT NULL,
			[ChangeFrequency] [varchar](10) NULL,
			[Priority] [decimal](18, 2) NULL,
			[Active] [bit] NOT NULL,
			[DateModified] [datetime] NULL,
			[DateCreated] [datetime] NULL,
		)

		WHILE EXISTS(SELECT * FROM tmp_SiteMapLoad_SiteMapLink)
			BEGIN

				/****** Object:  Index [IX_SiteMapLink_Url_SiteMapNumber]    Script Date: 04/08/2013 18:11:08 ******/
				IF  EXISTS (SELECT * FROM tempdb.sys.indexes WHERE object_id = OBJECT_ID(N'tempdb.dbo.#tmpSiteMapLinkGroup') AND name = N'IX_SiteMapLink_Url')
					BEGIN
						DROP INDEX [IX_SiteMapLink_Url] ON [dbo].#tmpSiteMapLinkGroup;
					END

				TRUNCATE TABLE #tmpSiteMapLinkGroup;
				INSERT INTO #tmpSiteMapLinkGroup 
				(
					SiteMapNumber,
					Url,
					ChangeFrequency,
					Priority,
					Active,
					DateModified,
					DateCreated
				)
				SELECT DISTINCT TOP(@SiteMapCount) 
				@SiteMapNumber,
				Url,
				ChangeFrequency,
				[Priority],
				1,
				@CurrentDate,
				@CurrentDate
				FROM 
				tmp_SiteMapLoad_SiteMapLink
				
				CREATE NONCLUSTERED INDEX [IX_SiteMapLink_Url] ON [dbo].#tmpSiteMapLinkGroup 
				(
					[Url] ASC
				)
				
				INSERT INTO SiteMapLink
				(
					SiteMapNumber,
					Url,
					ChangeFrequency,
					Priority,
					Active,
					DateModified,
					DateCreated
				)
				SELECT 
					SiteMapNumber,
					Url,
					ChangeFrequency,
					Priority,
					Active,
					DateModified,
					DateCreated
				 FROM #tmpSiteMapLinkGroup
				
				-- select records that were just added
				DELETE smlt
				FROM 
				tmp_SiteMapLoad_SiteMapLink smlt INNER JOIN
				#tmpSiteMapLinkGroup sml on smlt.Url = sml.Url
				
				--sitemap can only have 50,000 records, so limit each one to that number
				SET @SiteMapCount = (SELECT TOP 1 COUNT(*) FROM tmp_SiteMapLoad_SiteMapLink); -- how many are left for insertion?
				if (@SiteMapCount > 50000)
					BEGIN
						SET @SiteMapCount = 50000
					END
					
				SET @SiteMapNumber = @SiteMapNumber + 1
			END
		
	END
	
	SELECT * FROM SiteMapLink 
	WHERE Active = 1
	ORDER BY SiteMapLinkId, Url
	
END




---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- This is to make sure what this procedure used to be called get dropped.
/****** Object:  StoredProcedure [dbo].[usp_seo_getSiteMapData]    Script Date: 12/19/2012 08:27:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_seo_getSiteMapData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_seo_getSiteMapData]
GO

/****** Object:  StoredProcedure [dbo].[usp_seo_getSiteMapData]    Script Date: 12/19/2012 08:27:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SiteMapLoad_GetSiteMapData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_SiteMapLoad_GetSiteMapData]
GO


/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Used to generate sitemap

Used by: 
Global.ascx

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
12.18.2012		Marcus Ruether		Created. 
04.08.2013		Marcus Ruether		Updated to use Search_PartNumber rather than remove special chars from PartNumber with a function
									Added another procedure used in the sitemap gen process - renamed this one to make them consistent
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[usp_SiteMapLoad_GetSiteMapData]
AS
BEGIN
	--TABLE 0
	--Company Details
	SELECT DISTINCT
		c.Search_CompanyName as CompanyName
	FROM
		Company c WITH (NOLOCK)
	WHERE 
		c.IsActive = 1 AND 
		c.SearchName IS NOT NULL;
		
	--TABLE 1
	--Product Details
	SELECT DISTINCT 
	pt.ProductTypeId,
	dbo.RemoveSpecialCharacter(pt.TypeDescription) as ProductTypeName
	FROM ProductType pt WITH (NOLOCK)
	WHERE 
		pt.IsServices = 0 AND
		pt.IsActive = 1 AND
		pt.TypeDescription IS NOT NULL;
	
	--TABLE 2
	--Service Details
	SELECT 
	pt.ProductTypeId,
	dbo.RemoveSpecialCharacter(pt.TypeDescription) as ServiceName
	FROM ProductType pt WITH (NOLOCK)
	WHERE 
		pt.IsServices = 1 AND
		pt.IsActive = 1 AND
		pt.TypeDescription IS NOT NULL
	ORDER BY pt.typeDescription ;
		
	--TABLE 3
	-- Part Details
	SELECT DISTINCT
	dp.Search_PartNumber AS PartNumber,
	dp.Search_MFR_Name as ManufacturerName
	FROM DistributorPartsSearch1 dp WITH (NOLOCK)
	WHERE dp.PartNumber IS NOT NULL and dp.Search_MFR_Name IS NOT NULL
	order by Search_PartNumber
	
	IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_SiteMapLoad_SiteMapLink]') AND name = N'IX_tmp_SiteMapLoad_SiteMapLink_Url')
	BEGIN
		DROP INDEX [IX_tmp_SiteMapLoad_SiteMapLink_Url] ON [dbo].[tmp_SiteMapLoad_SiteMapLink] WITH ( ONLINE = OFF )
	END
	
	TRUNCATE TABLE tmp_SiteMapLoad_SiteMapLink; -- prepare for bulk insert into this temp table.
	
	
	CREATE NONCLUSTERED INDEX [IX_tmp_SiteMapLoad_SiteMapLink_Url] ON [dbo].[tmp_SiteMapLoad_SiteMapLink] 
	(
		[Url] ASC
	)
END

GO


GO

/****** Object:  StoredProcedure [dbo].[usp_SearchManufacturerWithUser]    Script Date: 12/31/2012 16:37:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SearchManufacturerWithUser]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_SearchManufacturerWithUser]
GO

/****** Object:  StoredProcedure [dbo].[usp_SearchManufacturerWithUser]    Script Date: 12/31/2012 16:37:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

  
  
  /*  
  [usp_SearchManufacturerWithUser] 'Texas','','','','',''  
  */  
  -- EXEC usp_SearchManufacturerWithUser 'diode','','1','4','','','',84306  
  /*------------------------------------------------------------------------------------------------------------------------------------------     
  Description:   
  {This should be a short description about the functionality of this procedure.}  
  
  Parameters:  
  {A short description of parameters and default values if there is any.}  
  
  Used by:   
  {This could be the name of a single webpage or multiple web pages or a SSIS package or a scheduled job etc. But if this functionality is used in many places within an application then just mention the application name. Otherwise <application name>.<modu
le name or web page name>}  
  (Having this information will be very helpful to find out what all applications will get affected if we need to make a change.)  
  
  History:  
  Date    Author    Notes              
  --------------------------------------------------------------------------------------------------------------------------------------------  
  MM.DD.YYYY  <developer name>  Created.   
  12.7.2012  Marcus Ruether  Updated to properly apply region filter when determining enhancement status.  
  ------------------------------------------------------------------------------------------------------------------------------------------*/  
--   
-- exec usp_SearchManufacturerWithUser @SEARCH='altera',@DIST_ID=NULL,@USER_Region='3',@USER_ZONE='0',@DIST_AUTH=NULL,@AttributesIds=NULL,@IsFilterByRegion='1',@UserID=-1    
  CREATE PROCEDURE [dbo].[usp_SearchManufacturerWithUser]  
  (  
   @SEARCH VARCHAR(1000),  
   @DIST_ID VARCHAR(100) = '',  
   @USER_Region VARCHAR(100)= '',  
   @USER_ZONE VARCHAR(100)= '',  
   @DIST_AUTH VARCHAR(100)= '0',  
   @AttributesIds VARCHAR(100)= '',  
   @IsFilterByRegion VARCHAR(10) = '0',  
   @UserID int = 0  
  )  
  AS  
  BEGIN  
  
   set transaction isolation level read uncommitted  
  
   IF(@DIST_ID IS NULL) BEGIN SET @DIST_ID = '' END  
   IF(@USER_Region IS NULL) BEGIN SET @USER_Region = '' END  
   IF(@USER_ZONE IS NULL) BEGIN SET @USER_ZONE = '0' END  
   IF(@USER_ZONE = '') BEGIN SET @USER_ZONE = '0' END  
   IF(@DIST_AUTH IS NULL) BEGIN SET @DIST_AUTH = '' END  
   IF(@IsFilterByRegion IS NULL) BEGIN SET @IsFilterByRegion = '' END  
  
   DECLARE @MAIN_QUERY VARCHAR(MAX)  
   DECLARE @CLEANSEARCH VARCHAR(MAX)  
   DECLARE @JoinAttributes VARCHAR(3000)=''  
  
   Declare @IsEmptyDistIDs VARCHAR(1) = '0'  
   Declare @IsEmptyRegionIDs VARCHAR(1) = '0'  
   Declare @IsEmptyZoneIDs VARCHAR(1) = '0'  
        
   DECLARE @REPLACE_REGIONS_TEMP VARCHAR(MAX)  
  
  
   IF(@DIST_ID = '') BEGIN SET @IsEmptyDistIDs = 1 END  
   IF(@USER_Region = '') BEGIN SET @IsEmptyRegionIDs = 1 END  
   IF(@USER_ZONE = '0' ) BEGIN SET @IsEmptyZoneIDs = 1 END  
   IF(@DIST_AUTH = '') BEGIN SET @DIST_AUTH = '0' END  
   IF(@IsFilterByRegion = '') BEGIN SET @IsFilterByRegion = '0' END  
     
   --23657 - addresses issue with enhancements not appearing properly when clicking the US region filter.  
   -- Replaced logic that was removing region 1 or 2.  
     
   --IF (@IsFilterByRegion <> '0')  
    --BEGIN  
       
          --SET @REPLACE_REGIONS_TEMP = @USER_Region  
           SET @REPLACE_REGIONS_TEMP =  replace(@USER_Region, '1', '')  
           SET @REPLACE_REGIONS_TEMP  = replace(@REPLACE_REGIONS_TEMP, '2', '')  
           SET @REPLACE_REGIONS_TEMP  = replace(@REPLACE_REGIONS_TEMP, '''', '')  
    --   
    --END  
   --ELSE  
   -- BEGIN  
   --  SET @REPLACE_REGIONS_TEMP = '0'  
      
   -- END  
   print @REPLACE_REGIONS_TEMP  
      
   SET @DIST_ID = '' + REPLACE(@DIST_ID,',',''',''') + ''  
   SET @USER_Region = '' + REPLACE(@USER_Region,',',''',''') + ''  
   SET @USER_ZONE = '' + REPLACE(@USER_ZONE,',',''',''') + ''  
  
        
   --Attributes  
   IF((@AttributesIds IS NOT NULL) AND (@AttributesIds <> ''))  
   BEGIN  
   SET @JoinAttributes = 'INNER JOIN dbo.CompanyOwnershipMapping com  
    ON com.CompanyID=reg_auth.DistID  
    INNER JOIN (SELECT * FROM dbo.Split('''+@AttributesIds+''','','')) as Attributes  
    ON com.OwnershipID = Attributes.items'  
   END      
  
   SET @SEARCH = [dbo].VK_RemoveSpecialChars(@SEARCH)  
   SET @CLEANSEARCH = [dbo].RemoveSpecialCharacter(@SEARCH)  
  
   IF OBJECT_ID(N'tempdb..#mantemp1', N'U') IS NOT NULL   
    DROP TABLE #mantemp1  
  
   CREATE TABLE #mantemp1(  
    CompanyID INT NULL,  
    CompanyName VARCHAR(100) NULL,  
    CompanyLogo VARCHAR(100) NULL,  
    CompanyDescription VARCHAR(MAX) NULL,  
    AlsoKnownAS  VARCHAR(MAX) NULL,  
    MaxAuth INT NULL,  
    DistributorId INT NULL,  
    DistributorName VARCHAR(100)NULL,  
    DistributorLogo VARCHAR(100) NULL,  
    DistributorAttributes VARCHAR(MAX) NULL,  
    CompanyStatus INT NULL,  
    WebVersion VARCHAR(500) NULL,  
    WebVersionWOZone VARCHAR(500) NULL,   
    DistID INT NULL,  
    Total decimal NULL,  
    --Total INT NULL,  
    CheckInvURL VARCHAR(200) NULL,  
    IsFav INT NULL,  
    MatchOrder VARCHAR(200) NULL,  
    Trusted_Disty BIT NULL,  
    Priority_Date [datetime] NULL)  
  
  
  
  
  declare @splRegionQuery varchar(max) = 'select min(WebVersion) WebVersion,distmfr.DistID,distmfr.MfrID from lm_distributor_orders (nolock) distmfr  
        JOIN AdOrderDetailsRegionEdition ad_oder_reg_edit  
        ON distmfr.AdOrderDetailsId = ad_oder_reg_edit.AdOrderDetailsId  
        AND (ad_oder_reg_edit.RegionID in ('''+@USER_ZONE+''') and ad_oder_reg_edit.RegionID <> ''0'')  
        group by distmfr.DistID,distmfr.MfrID'
  if (@IsFilterByRegion = '1' and (@USER_Region like '%1%'))
  begin
     set @splRegionQuery = 'select min(WebVersion) WebVersion,distmfr.DistID,distmfr.MfrID
        from lm_distributor_orders (nolock) distmfr  
        JOIN AdOrderDetailsRegionEdition ad_oder_reg_edit  ON distmfr.AdOrderDetailsId = ad_oder_reg_edit.AdOrderDetailsId  
        AND (ad_oder_reg_edit.RegionID in ('''+@USER_ZONE+''') and ad_oder_reg_edit.RegionID <> ''0'')  
        group by WebVersion, distmfr.DistID,distmfr.MfrID
        having COUNT(ad_oder_reg_edit.RegionID) = 9'
  end
  
  SET @MAIN_QUERY = '  
  DECLARE @SEARCH_QUERY VARCHAR(300)  
  SET @SEARCH_QUERY = '''+@SEARCH+'''  
               
   SELECT DISTINCT  -- review if we can remove distinct from here  
       mfr.CompanyID,  
       mfr.CompanyName,  
       mfr.CompanyLogo,  
       mfr.CompanyDescription,  
       also_know.AlsoKnownAs AS AlsoKnownAS,  
       IsNULL(Dist_Qry.MaxAuth, 0) AS MaxAuth,  
       Dist_Qry.DistributorId,  
       Dist_Qry.DistributorName,  
       Dist_Qry.DistributorLogo,  
       Dist_Qry.DistributorAttributes,  
       mfr.CompanyStatus,  
       Dist_Qry.WebVersion,  
       Dist_Qry.WebVersionWOZone,  
       Dist_Qry.DistID,  
       IsNULL(Dist_Qry.Total, 0) AS Total,  
       Dist_Qry.CheckInvURL,  
       CASE WHEN ( uf.TypeID IS NULL ) THEN 0 ELSE 1 END  AS IsFav ,  
       CASE WHEN (mfr.Search_CompanyName LIKE '''+@CLEANSEARCH+''') THEN ''11''  
       WHEN (mfr.Search_AlsoKnownAs LIKE '''+@CLEANSEARCH+''') THEN ''12''  
       WHEN (mfr.Search_BookName1 LIKE '''+@CLEANSEARCH+'''  
       OR mfr.Search_BookName2 LIKE '''+@CLEANSEARCH+'''  
       OR mfr.Search_Keyword1 LIKE '''+@CLEANSEARCH+'''  
       OR mfr.Search_Keyword2 LIKE '''+@CLEANSEARCH+''') THEN ''13''  
  
       WHEN (mfr.Search_CompanyName LIKE '''+ @CLEANSEARCH + '%'') THEN ''21''  
       WHEN (mfr.Search_AlsoKnownAs LIKE '''+@CLEANSEARCH + '%'') THEN ''22''  
       WHEN (mfr.Search_BookName1 LIKE '''+@CLEANSEARCH + '%''  
       OR mfr.Search_BookName2 LIKE '''+@CLEANSEARCH + '%''  
       OR mfr.Search_Keyword1 LIKE '''+@CLEANSEARCH + '%''  
       OR mfr.Search_Keyword2 LIKE '''+@CLEANSEARCH + '%'') THEN ''23''  
              
       WHEN (mfr.Clean_CompanyName LIKE search_term.items + ''_%'')THEN ''31''  
       WHEN (mfr.Clean_AlsoKnownAs LIKE search_term.items + ''_%'')THEN ''32''  
       WHEN (mfr.Clean_BookName1 LIKE search_term.items + ''_%''  
       OR mfr.Clean_BookName2 LIKE search_term.items + ''_%''  
       OR mfr.Clean_Keyword1 LIKE search_term.items + ''_%''  
       OR mfr.Clean_Keyword2 LIKE search_term.items + ''_%'')THEN ''33''  
  
       WHEN (mfr.Clean_CompanyName LIKE ''_%'' + search_term.items + ''%'')THEN ''34''  
       WHEN (mfr.Clean_AlsoKnownAs LIKE ''_%'' + search_term.items + ''%'')THEN ''35''  
       WHEN (mfr.Clean_BookName1 LIKE ''_%'' + search_term.items + ''%''  
       OR mfr.Clean_BookName2 LIKE ''_%'' + search_term.items + ''%''  
       OR mfr.Clean_Keyword1 LIKE ''_%'' + search_term.items + ''%''  
       OR mfr.Clean_Keyword2 LIKE ''_%'' + search_term.items + ''%'')THEN ''36'' ELSE ''40''  
     END AS MatchOrder,   
     IsNULL(Dist_Qry.Trusted_Disty, 0) AS Trusted_Disty,  
     Dist_Qry.Priority_Date  
                 
    FROM (SELECT * FROM dbo.Split(@SEARCH_QUERY,'' '')) AS search_term  
    JOIN [dbo].[lm_seeline_manufacturer] (nolock) AS mfr  
      ON mfr.Clean_CompanyName LIKE ''%'' + search_term.items + ''%''  
      OR mfr.Clean_AlsoKnownAs LIKE ''%'' + search_term.items + ''%''  
      OR mfr.Clean_BookName1 LIKE ''%'' + search_term.items + ''%''  
      OR mfr.Clean_Keyword1 LIKE ''%'' + search_term.items + ''%''  
      OR mfr.Clean_BookName2 LIKE ''%'' + search_term.items + ''%''  
      OR mfr.Clean_Keyword2 LIKE ''%'' + search_term.items + ''%''  
    Left Join [dbo].[MFRAlsoKnownAs] (nolock) also_know on also_know.CompanyID = mfr.CompanyID  
    LEFT JOIN dbo.[UserFavorites]  uf (NOLOCK)  ON mfr.CompanyID = uf.TypeID  
      AND uf.[FavType] in (1,2,4) AND CAST(UserID AS VARCHAR)  = '''+CAST(@UserID AS VARCHAR)+'''  
            
    LEFT JOIN (  
     SELECT DISTINCT  -- review if we can remove distinct from here  
      reg_auth.MfrID AS CompanyID,  
      CASE WHEN (RZS.MaxAuth = 1 OR RZS.MaxAuth = 2 OR RZS.MaxAuth = 3 OR RZS.MaxAuth IS NULL) THEN  1  
       ELSE RZS.MaxAuth END AS MaxAuth ,  
      dist.CompanyId AS DistributorId,  
      dist.CompanyName as DistributorName,  
      dist.CompanyLogo as DistributorLogo,  
      dbo.Get_SearchCompanyOwn (reg_auth.DistID) AS DistributorAttributes,  
      dist_order.WebVersion,  
      dist_order2.WebVersionWOZone,  
      dist.CompanyID as DistID,  
      IsNULL(Spend.Total, 0) AS Total,  
      invs.CheckInvURL,  
      isnull(dist.Trusted_Disty,0) as Trusted_Disty,Spend.Priority_Date  
                 
      FROM [dbo].[RegionAuthorization] (nolock) reg_auth   
  
       LEFT JOIN [dbo].[InventorySettings] invs ON reg_auth.DistID = invs.CompanyID  
  
      left join (  
       Select  
        RZOS.MFRDistID,  
        MAX(case when (AuthStatusID  = 2 and C.Trusted_Disty=1) then 4  
         else AuthStatusID end) as MaxAuth  
       From  
        RegionZoneStatus (nolock) RZOS,  
        Company (nolock) C,  
        RegionAuthorization (nolock) RA  
       WHERE  RA.MfrDistID = RZOS.MfrDistID  
        AND RA.DistID=C.CompanyID  
        AND (RegionId in ('''+@USER_Region+''') OR '+@IsEmptyRegionIDs+' = 1)  
       group By RZOS.MfrDistID  
      ) as RZS  
       ON reg_auth.MfrDistID = RZS.MfrDistID  
                        
                        
        left join Company (nolock) dist on reg_auth.DistID = dist.CompanyID  
       and dist.IsActive =1 and dist.CompanyStatusId = 1  
       and reg_auth.IsActive = 1  and reg_auth.Publish = 1  
                        
  
        left join (  
        Select  
        MfrID,  
        DistID,  
        sum(Print_Amount+Online_Amount) as Total,  
        max(Priority_Date) as Priority_Date  
       From  
        DistMfrSpend (nolock)  
                                                   
       WHERE  (RegionId in ('''+@USER_Region+''') OR '+@IsEmptyRegionIDs+' = 1)  
        AND (ZoneId in ('''+@USER_ZONE+''') OR '+@IsEmptyZoneIDs+' = 1)  
       group By MfrID,DistID  
      ) as Spend  
       ON reg_auth.MfrID = Spend.MfrID AND reg_auth.DistID = Spend.DistID  
           
                          
      left join('+@splRegionQuery+') dist_order  
        on dist_order.DistID = reg_auth.DistID  AND dist_order.MfrID = reg_auth.MfrID  
                         
                 
      left join(select min(WebVersion) WebVersionWOZone,distmfr2.DistID,distmfr2.MfrID from lm_distributor_orders (nolock) distmfr2    
        INNER JOIN (SELECT * FROM dbo.Split('''+@REPLACE_REGIONS_TEMP+''','','')) as regid    
        ON distmfr2.OrderRegionId LIKE ''%'' + regid.items + ''%''   
        group by distmfr2.DistID,distmfr2.MfrID,distmfr2.OrderRegionId) dist_order2    
        on dist_order2.DistID = reg_auth.DistID  AND dist_order2.MfrID = reg_auth.MfrID   
        
      '+@JoinAttributes+'  
      
       WHERE  
      (reg_auth.DistID in('''+@DIST_ID+''') OR '+@IsEmptyDistIDs+' = 1)   
      AND (dist.CompanyStatusId = 1 OR reg_auth.MfrDistID is null)     
      AND ('''+@DIST_AUTH+''' = 0 or RZS.MaxAuth = 4 or reg_auth.MfrDistID is null)  
      AND ('''+@IsFilterByRegion+''' = 0 or MaxAuth = 4 or reg_auth.MfrDistID is null or Total > 0  
       OR (Select 1  
        From CompanyLocations CL, Country C  
        where  
         C.CountryID = CL.CountryID  
         AND reg_auth.DistID = CL.CompanyID  
         AND (C.RegionID IN ('''+@USER_Region+''') OR '+@IsEmptyRegionIDs+' = 1)  
         AND LocationStatusID = 1  --  in @USER_Region  
         AND CL.IsActive = 1  
        group by CompanyID) = 1)  
                
     ) as Dist_Qry on mfr.CompanyID = Dist_Qry.CompanyID'  
                
  
   INSERT INTO #mantemp1  
   Execute(@MAIN_QUERY)  
         print @MAIN_QUERY  
  
   --IF OBJECT_ID(N'tempdb..#man', N'U') IS NOT NULL   
   -- DROP TABLE #man  
   --select a.CompanyID, min(a.MatchOrder) orders,count(a.MatchOrder) counts  
   -- into #man from #mantemp1 a  
   --group by a.companyid  
  
   --IF OBJECT_ID(N'tempdb..#ManDiffTable', N'U') IS NOT NULL   
   -- DROP TABLE #ManDiffTable  
  
   --select a.*, DIFFERENCE(@SEARCH, CompanyName) as diff into #ManDiffTable from #mantemp1 a join #man b on a.companyid=b.companyid and a.matchorder=b.orders  
                      
  
   select CompanyID  
    ,CompanyName  
    ,CompanyLogo  
    ,CompanyDescription  
    ,AlsoKnownAs  
    ,MaxAuth  
    ,DistributorId  
    ,DistributorName  
    ,DistributorLogo  
    ,DistributorAttributes  
    ,CompanyStatus  
    ,WebVersion  
    ,WebVersionWOZone  
    ,DistID  
    ,Total  
    ,CheckInvURL  
    ,IsFav  
    ,MatchOrder  
    ,0--,diff  
    ,Trusted_Disty  
    ,Priority_Date  
   from #mantemp1  
   ORDER BY MatchOrder, --diff desc, 
   CompanyName, Total DESC, Priority_Date ASC, MaxAuth DESC,  DistributorName ASC  
  
  END  
  
  
GO

-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetProductDetailsWithNoManuByPartNumber]    Script Date: 11/26/2012 20:39:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetProductDetailsWithNoManuByPartNumber]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetProductDetailsWithNoManuByPartNumber]
GO


CREATE PROCEDURE [dbo].[usp_GetProductDetailsWithNoManuByPartNumber] 
(
	@PartNumber VARCHAR(100)
)
AS

--DECLARE @PartNumber VARCHAR(100) = '1287'

BEGIN
	SET @PartNumber = dbo.RemoveSpecialCharacter(@PartNumber)

	SELECT TOP 1
		0 as ProductId,
		'' AS CompanyLogo,
		dp.PartNumber,
		0 AS ManufacturerID,
		'Manufacturer Not Identified' AS ManufacturerName,
		'' AS ProductType,
		0 AS ProductTypeId,
		'' AS [Description]
	FROM DistributorPartsStatic dp (NOLOCK) 
	INNER JOIN DistributorParts_Clean dpc
		ON dp.PartNumber = dpc.PartNumber
	LEFT OUTER JOIN ManufacturerCode_XRF code (NOLOCK)  
		ON dp.DistID = code.DistributorId 
		AND dp.ManufacturerCode = code.ManufacturerCode
	WHERE dpc.Search_PartNumber = @PartNumber
		AND code.ManufacturerCodeId IS NULL
END

GO


-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------


/****** Object:  StoredProcedure [dbo].[usp_GetProductDetailsByManu]    Script Date: 09/20/2012 13:29:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetProductDetailsByManu]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetProductDetailsByManu]
GO


/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Gets part details entered by a manufacturer

Used by: 
/SearchDetailsPages/PartDetailListView.aspx.cs

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
09.20.2012		Marcus Ruether		Created. 
09.25.2012		Marcus Ruether		Updated to get info from distrributorParts if there is no product info
04.12.2013		Marcus Ruether		
------------------------------------------------------------------------------------------------------------------------------------------*/

CREATE PROCEDURE [dbo].[usp_GetProductDetailsByManu]
	@ManufacturerId INT,
	@PartNumber VARCHAR(100)
AS

--DECLARE @ManufacturerId INT=103569, @PartNumber VARCHAR(100) = '1287'

BEGIN

	SET @PartNumber = dbo.RemoveSpecialCharacter(@PartNumber)
	
	IF EXISTS
	(
		SELECT * 
		FROM Product P 
		INNER JOIN Company C 
			ON p.ManufacturerId = c.CompanyID 
		WHERE p.Clean_PartNumber = @PartNumber
			AND c.CompanyId = @ManufacturerId
	)
	BEGIN
		-- get the detail from the products table, as that is uploaded by a manufacturer
		SELECT  
			p.ProductId,
			C.CompanyLogo,
			P.PartNumber,
			C.CompanyID AS ManufacturerID,
			C.CompanyName AS ManufacturerName,
			pt.TypeDescription AS ProductType,
			pt.ProductTypeId,
			P.[Description] -- this was using the first distrubutor description
		FROM 
			Product P 
			INNER JOIN Company C 
				ON p.ManufacturerId = c.CompanyID
			LEFT OUTER JOIN productType_XRF AS pt_xrf     
				ON p.ManufacturerID = pt_xrf.ManufacturerID    
				AND p.ProductType = pt_xrf.MfrProdTypeCode    
			LEFT OUTER JOIN ProductType AS pt     
				ON pt_xrf.ProductTypeID = pt.ProductTypeId    
				AND pt.IsActive = 1    
		WHERE p.Clean_PartNumber = @PartNumber
			AND c.CompanyId = @ManufacturerId
	
	END
	ELSE
	BEGIN
		-- if a part has not had details upload by the manufacturer, get basic info from distributor table
		SELECT TOP 1
			0 as ProductId,
			0 AS ProductTypeId,
			C.CompanyLogo,
			DP.PartNumber,
			C.CompanyID AS ManufacturerID,
			C.CompanyName AS ManufacturerName,
			'' AS ProductType,
			'' AS [Description]
		FROM DistributorPartsStatic DP WITH(NOLOCK)
		INNER JOIN DistributorParts_Clean DPC
			ON DP.PartNumber = DPC.PartNumber
		INNER JOIN ManufacturerCode_XRF (NOLOCK) code 
			ON dp.DistID = code.DistributorId 
			AND dp.ManufacturerCode = code.ManufacturerCode 
			AND code.ManufacturerId = @ManufacturerId 
		INNER JOIN Company C WITH(NOLOCK)
			ON c.CompanyId = code.ManufacturerId 
		WHERE DPC.Search_PartNumber = @PartNumber
	END
END

GO


-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
