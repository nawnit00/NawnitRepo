/****** Object:  Table [dbo].[tmp_Load_DistinctPartMfrCodeXRF]    Script Date: 03/28/2013 09:43:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistinctPartMfrCodeXRF]') AND type in (N'U'))
CREATE TABLE [dbo].[tmp_Load_DistinctPartMfrCodeXRF](
	[Search_PartNumber] [varchar](250) NULL,
	[DistributorId] [int] NULL,
	[ManufacturerId] [int] NULL,
	[ManufacturerCode] [varchar](256) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistinctPartMfrCodeXRF]') AND name = N'IDX_DistinctPartMfrCodeXRF_SearchPartNumber')
	CREATE NONCLUSTERED INDEX [IDX_DistinctPartMfrCodeXRF_SearchPartNumber] ON tmp_Load_DistinctPartMfrCodeXRF 
	(
		[Search_PartNumber] ASC,
		DistributorId ASC,
		ManufacturerCode ASC
	)
GO
/****** Object:  Table [dbo].[tmp_Load_DistProduct]    Script Date: 01/03/2013 10:34:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmpDistProduct]') AND type in (N'U'))
	DROP TABLE [dbo].[tmpDistProduct]
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistProduct]') AND type in (N'U'))
CREATE TABLE [dbo].[tmp_Load_DistProduct](
	PartNumber VARCHAR(250) NOT NULL
) ON [PRIMARY]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistProduct]') AND name = N'pk_DistProduct_PartNumber')
ALTER TABLE [dbo].[tmp_Load_DistProduct] ADD  CONSTRAINT [pk_DistProduct_PartNumber] PRIMARY KEY CLUSTERED 
(
	[PartNumber] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO  

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [dbo].[tmp_Load_MfrDist]    Script Date: 04/09/2013 12:08:47 ******/
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_MfrDist]') AND type in (N'U'))
CREATE TABLE [dbo].[tmp_Load_MfrDist](
	[ManufacturerID] [int] NOT NULL,
	[DistributorID] [int] NOT NULL
) ON [PRIMARY]

GO

IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_MfrDist]') AND name = N'IDX_ManufacturerID_DistributorID')
DROP INDEX [IDX_ManufacturerID_DistributorID] ON [dbo].[tmp_Load_MfrDist] WITH ( ONLINE = OFF )
GO

CREATE NONCLUSTERED INDEX [IDX_ManufacturerID_DistributorID] ON [dbo].[tmp_Load_MfrDist] 
(
	[ManufacturerID] ASC,
	[DistributorID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[tmp_Load_MfrProduct]    Script Date: 01/03/2013 10:34:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmpMfrProduct]') AND type in (N'U'))
	DROP TABLE [dbo].[tmpMfrProduct]
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_MfrProduct]') AND type in (N'U'))
CREATE TABLE [dbo].[tmp_Load_MfrProduct](
	PartNumber VARCHAR(250) NOT NULL
) ON [PRIMARY]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_MfrProduct]') AND name = N'pk_MfrProduct_PartNumber')
ALTER TABLE [dbo].[tmp_Load_MfrProduct] ADD  CONSTRAINT [pk_MfrProduct_PartNumber] PRIMARY KEY CLUSTERED 
(
	[PartNumber] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO 
/****** Object:  Table [dbo].[tmp_Load_PartNumber_CommonName]    Script Date: 03/28/2013 09:56:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO


IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_CommonName]') AND type in (N'U'))
CREATE TABLE [dbo].[tmp_Load_PartNumber_CommonName](
	[Common_PartNumber] [varchar](250) NULL,
	[Search_PartNumber] [varchar](256) NULL,
	[ManufacturerId] [int] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_CommonName]') AND name = N'IDX_Search_PartNumber')
BEGIN
	CREATE INDEX IDX_Search_PartNumber ON tmp_Load_PartNumber_CommonName (Search_PartNumber, ManufacturerId);
END
GO

/****** Object:  Table [dbo].[tmp_Load_PartNumber_SearchPartNumber]    Script Date: 03/28/2013 09:50:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO


IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_SearchPartNumber]') AND type in (N'U'))
	CREATE TABLE [dbo].[tmp_Load_PartNumber_SearchPartNumber](
		[PartNumber] [varchar](250) NULL,
		[Search_PartNumber] [varchar](256) NULL,
		[DistAdSpend] [decimal](10, 2) NULL,
		[ManufacturerId] [int] NULL
	) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO
	
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_SearchPartNumber]') AND name = N'IDX_tmp_Load_PartNumber_SearchPartNumber')
BEGIN
	CREATE INDEX IDX_tmp_Load_PartNumber_SearchPartNumber ON tmp_Load_PartNumber_SearchPartNumber (Search_PartNumber, ManufacturerId)
END
GO

/****** Object:  Table [dbo].[tmp_Load_Product]    Script Date: 01/03/2013 10:34:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmpProduct]') AND type in (N'U'))
	DROP TABLE [dbo].[tmpProduct]

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_Product]') AND type in (N'U'))
CREATE TABLE [dbo].[tmp_Load_Product](
		DistributorPartID INT IDENTITY (1000000000,1) NOT NULL,
		DistID INT NULL,
		PartNumber VARCHAR(250) NULL,
		ManufacturerID INT NULL,
		PartUploadDate DATETIME NULL,
		PartQuantity INT NULL,
		Price MONEY NULL,
		Price1 MONEY NULL,
		ROHS VARCHAR(50) NULL
	) ON [PRIMARY]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_Product]') AND name = N'pk_Product_DistributorPartID')
ALTER TABLE [dbo].[tmp_Load_Product] ADD  CONSTRAINT [pk_Product_DistributorPartID] PRIMARY KEY CLUSTERED 
(
	[DistributorPartID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO  

/****** Object:  StoredProcedure [dbo].[usp_Load_DistinctPartMfrCodeXRF]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistinctPartMfrCodeXRF]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistinctPartMfrCodeXRF]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistinctPartMfrCodeXRF]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	----------------------------------------
	-- BUSINESS RULE (Gemini 25312):
	-- We need to get a common PartNumber to display for companies when the "Search_PartNumber" is the same.
	-- It was decided to use the partnumber of the distributor who is paying the most amount of money for the
	-- "Common" name
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_DistinctPartMfrCodeXRF','';
	TRUNCATE TABLE tmp_Load_DistinctPartMfrCodeXRF

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Drop Indexes on tmp_Load_DistinctPartMfrCodeXRF','';

	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistinctPartMfrCodeXRF]') AND name = N'IDX_DistinctPartMfrCodeXRF_Search_PartNumber')
	BEGIN
		DROP INDEX IDX_DistinctPartMfrCodeXRF_Search_PartNumber ON [dbo].tmp_Load_DistinctPartMfrCodeXRF WITH ( ONLINE = OFF )
	END

	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistinctPartMfrCodeXRF]') AND name = N'IX_Distributorid_Manufacturerid')
	BEGIN
		DROP INDEX [IX_Distributorid_Manufacturerid] ON [dbo].[tmp_Load_DistinctPartMfrCodeXRF]  WITH ( ONLINE = OFF )
	END
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_DistinctPartMfrCodeXRF','';

	INSERT INTO tmp_Load_DistinctPartMfrCodeXRF
	SELECT distinct clean.Search_PartNumber, xrf.DistributorId, xrf.ManufacturerId, xrf.ManufacturerCode
	FROM 
		vw_DistinctMfrCodeXRF xrf WITH(NOLOCK) INNER JOIN
		DistributorParts dp WITH(NOLOCK) on xrf.DistributorId = dp.DistID and xrf.ManufacturerCode = dp.ManufacturerCode INNER JOIN
		DistributorParts_Clean clean WITH(NOLOCK) ON dp.PartNumber = clean.PartNumber
		--WHERE dp.PartNumber IN ('BC546B126','BC546B,126','"BC546B,126"','BC546B.126','MAX705CSA','MAX705CSA+')
		
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Build Indexes on tmp_Load_DistinctPartMfrCodeXRF','';
		
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistinctPartMfrCodeXRF]') AND name = N'IDX_DistinctPartMfrCodeXRF_Search_PartNumber')
	BEGIN
		CREATE NONCLUSTERED INDEX [IDX_DistinctPartMfrCodeXRF_Search_PartNumber] ON tmp_Load_DistinctPartMfrCodeXRF 
		(
			[Search_PartNumber] ASC,
			DistributorId ASC,
			ManufacturerCode ASC
		)
	END

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistinctPartMfrCodeXRF]') AND name = N'IX_Distributorid_Manufacturerid')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_Distributorid_Manufacturerid] ON [dbo].[tmp_Load_DistinctPartMfrCodeXRF] 
		(
			  [DistributorId] ASC,
			  [ManufacturerId] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	END

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into tmp_Load_DistinctPartMfrCodeXRF','';
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_DistProduct]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistProduct]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistProduct]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistProduct]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
		--PRINT 'Get all records from Product table that match to DistributorParts table'
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_DistProduct','';
	TRUNCATE TABLE tmp_Load_DistProduct

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_DistProduct','';
	INSERT INTO tmp_Load_DistProduct
	SELECT DISTINCT p.PartNumber
	FROM Product p WITH (NOLOCK)
	INNER JOIN DistributorPartsStatic_Cache dp WITH (NOLOCK)
		ON p.PartNumber = dp.PartNumber 
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorParts_Clean]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorParts_Clean]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorParts_Clean]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorParts_Clean]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ActionText VARCHAR(100) = '';
	
	DECLARE @ProcessId INT = (SELECT TOP 1 ProcessId FROM MstProcess WHERE ProcessName = 'usp_Load_SearchCache');
	
	DECLARE @ProcessLogId INT = 0;
	
	INSERT INTO ProcessLog VALUES (@ProcessId, GETDATE());
	
	SET @ProcessLogId = @@IDENTITY;
	
	DECLARE @StartTime DATETIME = (GETDATE());
	
	SET @ActionText = 'Begin usp_Load_SearchCache at ' + CAST(@StartTime AS VARCHAR);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, @ActionText, '';
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into DistributorParts_Clean','';

	----------------------------------------
	-- Add into the DistibutorParts_Clean table all new partnumbers
	INSERT INTO DistributorParts_Clean
	SELECT
		pn.PartNumber,
		UPPER(dbo.RemoveSpecialChars(pn.PartNumber)) AS Search_PartNumber
	FROM
		(
			SELECT 
				DISTINCT dp.partnumber 
			FROM 
				Distributorparts dp WITH(NOLOCK) LEFT JOIN
				DistributorParts_Clean clean WITH(NOLOCK) ON dp.PartNumber = clean.PartNumber
			WHERE clean.partNumber IS NULL --28 seconds
		) pn
	

	INSERT INTO DistributorParts_Clean
	SELECT 
		pn.PartNumber,
		UPPER(dbo.RemoveSpecialChars(pn.PartNumber)) AS Search_PartNumber
	FROM
		(
			SELECT 
				DISTINCT p.PartNumber 
			FROM
				Product p WITH (NOLOCK) INNER JOIN
				Company c  WITH(NOLOCK) on p.ManufacturerID = c.CompanyId AND c.CompanyStatusID = 1 LEFT JOIN
				DistributorParts_Clean clean  WITH(NOLOCK) ON p.PartNumber = clean.PartNumber
			WHERE clean.partNumber IS NULL
		) pn
	
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorParts_Clean','';
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsLoad]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsLoad]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsLoad]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsLoad]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate DistributorPartsLoad','';										
	TRUNCATE TABLE DistributorPartsLoad

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Begin Insert into DistributorPartsLoad','';										
	--PRINT 'Get all records from DistributorParts table'
	INSERT INTO DistributorPartsLoad
		(DistID
		,PartNumber
		,ManufacturerID
		,PartUploadDate
		,PartQuantity
		,Price
		,Price1
		,DistributorPartID
		,ROHS
		,IsManufacturerProduct
		,Search_PartNumber
	)
	
	SELECT dp.DistID
		,dp.PartNumber
		,ISNULL(MFRC.ManufacturerId, 0) as ManufacturerId
		,MAX(dp.Uploaded) as PartUploadDate
		,SUM(ISNULL(dp.QtyOnHand,0)) as PartQuantity
		,MAX(ISNULL(dp.Price,0)) As Price
		,MAX(ISNULL(dp.Price1,0)) As Price1
		,MAX(dp.InvID) As DistributorPartID
		,dp.ROHS
		,dp.IsManufacturerProduct
		,dp.Search_PartNumber
	FROM DistributorPartsStatic_Cache dp  WITH (NOLOCK)
	LEFT OUTER JOIN ManufacturerCode_XRF MFRC WITH (NOLOCK)
		ON dp.DistID = MFRC.DistributorId
		AND dp.ManufacturerCode = MFRC.ManufacturerCode
		AND (MFRC.IsActive IS NULL OR MFRC.IsActive = 1)
	GROUP BY dp.DistID,ManufacturerId,dp.PartNumber,dp.ROHS,dp.IsManufacturerProduct,dp.Search_PartNumber

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsLoad','';										
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsSearch1]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsSearch1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsSearch1]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsSearch1]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCore'
		ORDER BY pl.LogDate DESC
	);
	---------------------------------------------
	-- DistributorPartsSearch1 -------------------
	-- Queries that need parts data to match that from solr will be executed against DistributorPartsSearch1
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Dropping Indexes on DistributorPartsSearch1','';
	
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch1]') AND name = N'IX_DistributorPartSearch1_PartNumber_ManufacturerId')
		BEGIN
			DROP INDEX [IX_DistributorPartSearch1_PartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch1] WITH ( ONLINE = OFF )	
		END
	
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch1]') AND name = N'IX_DistributorPartSearch1_PartNumber_ManufacturerId')
		BEGIN
			DROP INDEX [IX_DistributorPartSearch1_PartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch1] WITH ( ONLINE = OFF )	
		END
		
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch1]') AND name = N'IX_DistributorPartSearch1_SearchPartNumber_ManufacturerId')
		BEGIN
			DROP INDEX [IX_DistributorPartSearch1_SearchPartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch1] WITH ( ONLINE = OFF )	
		END
	SET IDENTITY_INSERT [DistributorPartsSearch1] ON
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finished Dropping Indexes on DistributorPartsSearch1','';
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate DistributorPartsSearch1','';
	
	TRUNCATE TABLE dbo.DistributorPartsSearch1
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Begin Insert into DistributorPartsSearch1','';
	INSERT INTO dbo.DistributorPartsSearch1 ( [ID],[DistributorId],[DistributorName],[Search_Dist_Name],[DistLogo],[PartNumber],[Search_PartNumber],[ManufacturerCode]
		  ,[ManufacturerId],[ManufacturerName],[Search_MFR_Name],[CompanyLogo],[PartUploadDate],[ProductId],[PartDescription]
		  ,[PartQuantity],[QOHDisp],[Price],[PartDataSheet],[DatasheetLink],[PartSample],[VideoFilePathLink],[ImageFilePathLink]
		  ,[DoNotPub],[ProductTypeId],[ProductTypeDesc],[RFQCPID],[Buy_Button],[DistributorPartID],[ROHS],[HasMfrLogoAd],[IsManufacturerProduct],[ManufacturerSpend] )
	SELECT [ID],[DistributorId],[DistributorName],[Search_Dist_Name],[DistLogo],[PartNumber],[Search_PartNumber],[ManufacturerCode]
		  ,[ManufacturerId],[ManufacturerName],[Search_MFR_Name],[CompanyLogo],[PartUploadDate],[ProductId],[PartDescription]
		  ,[PartQuantity],[QOHDisp],[Price],[PartDataSheet],[DatasheetLink],[PartSample],[VideoFilePathLink],[ImageFilePathLink]
		  ,[DoNotPub],[ProductTypeId],[ProductTypeDesc],[RFQCPID],[Buy_Button],[DistributorPartID],[ROHS],[HasMfrLogoAd],[IsManufacturerProduct],[ManufacturerSpend]
	  FROM [SourceESB].[dbo].[DistributorPartsSearch2]
	  
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsSearch1','';
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Creating Indexes on DistributorPartsSearch1','';
	SET IDENTITY_INSERT [DistributorPartsSearch1] OFF

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch1]') AND name = N'IX_DistributorPartID')
	CREATE NONCLUSTERED INDEX [IX_DistributorPartID] ON [dbo].[DistributorPartsSearch1] 
	(	[DistributorPartID] ASC )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		Set NoCount OFF;

	/****** Object:  Index [IX_DistributorPartSearch1_PartNumber_ManufacturerId]    Script Date: 02/04/2013 13:28:12 ******/
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch1]') AND name = N'IX_DistributorPartSearch1_PartNumber_ManufacturerId')
	CREATE NONCLUSTERED INDEX [IX_DistributorPartSearch1_PartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch1] 
	(
		[PartNumber] ASC,
		[ManufacturerId] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		
	/****** Object:  Index [IX_DistributorPartSearch1_SearchPartNumber_ManufacturerId]    Script Date: 03/05/2013 09:38:24 ******/
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch1]') AND name = N'IX_DistributorPartSearch1_SearchPartNumber_ManufacturerId')
	CREATE NONCLUSTERED INDEX [IX_DistributorPartSearch1_SearchPartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch1] 
	(
		  [Search_PartNumber] ASC,
		  [ManufacturerId] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finished Creating Indexes on DistributorPartsSearch1','';
	
	DECLARE @EndTime DATETIME = (GETDATE());
	
	DECLARE @ActionText VARCHAR(100) = 'END usp_Load_SearchCore at ' + CAST(@EndTime AS VARCHAR);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, @ActionText, '';	
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsSearch2]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsSearch2]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsSearch2]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsSearch2]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate DistributorPartsSearch2','';	
	TRUNCATE TABLE DistributorPartsSearch2;
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into DistributorPartsSearch2','';	
	INSERT INTO DistributorPartsSearch2
	(
		[DistributorId],
		[DistributorName],
		[Search_Dist_Name],
		[DistLogo],
		[PartNumber],
		[Search_PartNumber],
		[ManufacturerId],
		[ManufacturerName],
		[Search_MFR_Name],
		[CompanyLogo],
		[PartUploadDate],
		[ProductId],
		[PartDescription],
		[PartQuantity],
		[QOHDisp],
		[Price],
		[PartDataSheet],
		[DatasheetLink],
		[PartSample],
		[VideoFilePathLink],
		[ImageFilePathLink],
		[DoNotPub],
		[ProductTypeId],
		[ProductTypeDesc],
		[RFQCPID],
		[Buy_Button],
		[DistributorPartID],
		[ROHS],
		[HasMfrLogoAd],
		[IsManufacturerProduct],
		ManufacturerSpend
	)

      SELECT ISNULL(Dist.DistID , 0) AS DistributorId
                  ,C.CompanyName AS DistributorName
                  ,C.Clean_CompanyName AS Search_Dist_Name
                  ,C.CompanyLogo AS DistLogo
                  ,Dist.PartNumber
                  ,Dist.Search_PartNumber
                  ,Dist.ManufacturerId
                  ,ISNULL(C1. CompanyName, 'zzunknown') AS ManufacturerName
                  ,dbo.RemoveSpecialChars(C1.Clean_CompanyName) AS Search_MFR_Name
                  ,C1.CompanyLogo AS CompanyLogo
                  ,Dist.PartUploadDate
                  ,P.ProductID AS ProductId
                  ,ISNULL(P.Description, d.PartDescription) AS PartDescription
                  ,ISNULL(Dist.PartQuantity, 0)
                  ,ISNULL(InS.QOHDisp, 0) as QOHDisp
                  ,CASE WHEN (ISNULL(Dist.Price,0) = 0 AND ISNULL(Dist.Price1,0) <> 0)
                        THEN Dist.Price1
                  ELSE Dist.Price
                  END AS Price
                  ,CASE WHEN ISNULL(P.DataSheet,'') <> '' AND ISNULL(P.DataSheetTitle,'')<> ''  
                          THEN P.DataSheetTitle  
                          ELSE
                              CASE WHEN ISNULL(Ins1.MafSpecURL,'') <> '' AND ISNULL(Ins1.MafSpecTitle,'')<> ''  
                                     THEN Ins1.MafSpecTitle ELSE 'Data Sheet'  
                              END  
                  END AS PartDataSheet  
                  ,CASE WHEN ISNULL(P.DataSheet,'') <> ''  
                          THEN P.DataSheet  
                          ELSE  
                              CASE WHEN ISNULL(Ins1.MafSpecURL,'') <> ''  
                                     THEN Ins1.MafSpecURL  
                              END  
                  END AS DatasheetLink 
                  ,P.SampleUrl AS PartSample
                  ,P.VideoFilePath AS VideoFilePathLink
                  ,P.ImageFilePath AS ImageFilePathLink
                  ,ISNULL(Ins.DoNotPub, 0) as DoNotPub
                  ,ISNULL(PT.ProductTypeId, 0) AS ProductTypeId
                  ,ISNULL(PT.TypeDescription, '') AS ProductTypeDesc
                  ,ISNULL(Ins.RFQCPID, 0) AS RFQCPID
                  ,CASE 
                        WHEN Ins.BuyPentonExpire >= GETDATE() 
                              AND Ins.BuyPentonURL1 IS NOT NULL 
                              AND Ins.BuyPentonURL1 <> '' THEN 1 
                        ELSE 0 
                  END AS Buy_Button
                  ,Dist.DistributorPartID
                  ,CASE Dist.ROHS
                        WHEN 'TRUE' THEN 1 
                        WHEN 'YES' THEN 1
                        WHEN 'Y' THEN 1
                        ELSE 0
                  END AS ROHS
                  ,0 AS HasMFRLogoAd
				  ,Dist.IsManufacturerProduct
				  ,ISNULL(MfrSpend.AmountSpent, 0) AS ManufacturerSpend
      FROM DistributorPartsLoad as Dist
      INNER JOIN Company C
            ON Dist.DistID = C.CompanyID
            AND C.isActive = 1 
            AND C.companystatusid in(1,4)
      INNER JOIN InventorySettings Ins
            ON Dist.DistID = Ins.CompanyID
            AND ISNULL(Ins.DoNotPub, 0) = 0
      LEFT OUTER JOIN Company C1
            ON Dist.ManufacturerId = C1.CompanyID
            AND ISNULL(C1.IsActive, 1) = 1 
      LEFT OUTER JOIN Product P
            ON Dist.PartNumber = P.PartNumber 
            AND Dist.ManufacturerId = P.ManufacturerID
            AND ISNULL(P.IsActive, 1) = 1 
      LEFT OUTER JOIN productType_XRF PT_X
            ON P.ManufacturerID = PT_X.ManufacturerID 
            AND P.ProductType = PT_X.MfrProdTypeCode
      LEFT OUTER JOIN ProductType PT
            ON PT_X.ProductTypeID = PT.ProductTypeId
            AND ISNULL(PT.IsActive,1) = 1
      LEFT OUTER JOIN InventorySettings Ins1
            ON Dist.ManufacturerID = Ins1.CompanyID
      LEFT JOIN ManufacturerPartDescription d
            ON dist.PartNumber = d.PartNumber
            AND Dist.DistID = d.DistributorId
      LEFT JOIN MfrSpend on Dist.ManufacturerID = MfrSpend.MfrID
      
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsSearch2','';	

	DECLARE @EndTime DATETIME = (GETDATE());

	DECLARE @ActionText VARCHAR(100) = 'END usp_Load_SearchCache at ' + CAST(@EndTime AS VARCHAR);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, @ActionText, '';
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsStatic]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsStatic]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsStatic]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsStatic]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ActionText VARCHAR(100) = '';
	
	DECLARE @ProcessId INT = (SELECT TOP 1 ProcessId FROM MstProcess WHERE ProcessName = 'usp_Load_SearchCore');
	
	DECLARE @ProcessLogId INT = 0;
	
	INSERT INTO ProcessLog VALUES (@ProcessId, GETDATE());
	
	SET @ProcessLogId = @@IDENTITY;
	
	DECLARE @StartTime DATETIME = (GETDATE());
	
	SET @ActionText = 'Begin usp_Load_SearchCore at ' + CAST(@StartTime AS VARCHAR);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, @ActionText, '';
	
	---------------------------------------------
	-- DistributorPartsStatic -------------------
	
	-- Queries that would be using the DistributorParts table for display on the web will instead use this table so it matches the 
	-- results from the last solr load.

	
	--EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Dropping Indexes on DistributorPartsStatic','';

	--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Uploaded_1]') AND type = 'D')
	--BEGIN
	--	ALTER TABLE [dbo].[DistributorPartsStatic] DROP CONSTRAINT [DF_DistributorPartsStatic_Uploaded_1]
	--END

	--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Status_1]') AND type = 'D')
	--BEGIN
	--	ALTER TABLE [dbo].[DistributorPartsStatic] DROP CONSTRAINT [DF_DistributorPartsStatic_Status_1]
	--END

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_PartNumber')
	--	DROP INDEX [IDX_PartNumber] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_DistID_ManCode')
	--	DROP INDEX [IDX_DistID_ManCode] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_DistID_PartNumber_ManuCode_BatchCode')
	--	DROP INDEX [IX_DistID_PartNumber_ManuCode_BatchCode] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_DistID_Uploaded_InvID')
	--	DROP INDEX [IX_DistID_Uploaded_InvID] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_InventoryUpload')
	--	DROP INDEX [IX_InventoryUpload] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_PartNumber_ManuCode_BatchCode')
	--	DROP INDEX [IX_PartNumber_ManuCode_BatchCode] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_PartNumber_ManuCode_DistID')
	--	DROP INDEX [IDX_PartNumber_ManuCode_DistID] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )
		
	--EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finished Dropping Indexes on DistributorPartsStatic','';
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate DistributorPartsStatic','';
		
	TRUNCATE TABLE [DistributorPartsStatic];
	
	SET IDENTITY_INSERT [DistributorPartsStatic] ON
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Begin Insert into DistributorPartsStatic','';

	INSERT INTO [DistributorPartsStatic] (
	   [ManufacturerCode]
      ,[PartNumber]
      ,[Description]
      ,[QtyOnHand]
      ,[Price]
      ,[ROHS]
      ,[BatchCode]
      ,[BreakLevel1]
      ,[Price1]
      ,[BreakLevel2]
      ,[Price2]
      ,[BreakLevel3]
      ,[Price3]
      ,[BreakLevel4]
      ,[Price4]
      ,[BreakLevel5]
      ,[Price5]
      ,[BreakLevel6]
      ,[Price6]
      ,[BreakLevel7]
      ,[Price7]
      ,[BreakLevel8]
      ,[Price8]
      ,[BreakLevel9]
      ,[Price9]
      ,[BreakLevel10]
      ,[Price10]
      ,[DistID]
      ,[Uploaded]
      ,[InvID]
      ,[Status]
      ,[IsManufacturerProduct]
      ,[Search_PartNumber]
      )
	SELECT 
	   [ManufacturerCode]
      ,[PartNumber]
      ,[Description]
      ,[QtyOnHand]
      ,[Price]
      ,[ROHS]
      ,[BatchCode]
      ,[BreakLevel1]
      ,[Price1]
      ,[BreakLevel2]
      ,[Price2]
      ,[BreakLevel3]
      ,[Price3]
      ,[BreakLevel4]
      ,[Price4]
      ,[BreakLevel5]
      ,[Price5]
      ,[BreakLevel6]
      ,[Price6]
      ,[BreakLevel7]
      ,[Price7]
      ,[BreakLevel8]
      ,[Price8]
      ,[BreakLevel9]
      ,[Price9]
      ,[BreakLevel10]
      ,[Price10]
      ,[DistID]
      ,[Uploaded]
      ,[InvID]
      ,[Status]
      ,[IsManufacturerProduct]
      ,[Search_PartNumber]
      FROM [DistributorPartsStatic_Cache]
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsStatic','';
	
	SET IDENTITY_INSERT [DistributorPartsStatic] OFF
	
	--EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Creating Indexes on DistributorPartsStatic','';
	
	--IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Uploaded_1]') AND type = 'D')
	--BEGIN
	--	ALTER TABLE [dbo].[DistributorPartsStatic] ADD  CONSTRAINT [DF_DistributorPartsStatic_Uploaded_1]  DEFAULT (GETDATE()) FOR [Uploaded]
	--END

	--IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Status_1]') AND type = 'D')
	--BEGIN
	--	ALTER TABLE [dbo].[DistributorPartsStatic] ADD  CONSTRAINT [DF_DistributorPartsStatic_Status_1]  DEFAULT ('Active') FOR [Status]
	--END

	--IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_PartNumber')
	--	CREATE NONCLUSTERED INDEX [IDX_PartNumber] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		[Status] ASC,
	--		[PartNumber] ASC
	--	)
	--	INCLUDE ( [ManufacturerCode],
	--	[DistID]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--IF  NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_DistID_ManCode')
	--	CREATE NONCLUSTERED INDEX [IDX_DistID_ManCode] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		[DistID] ASC,
	--		[ManufacturerCode] ASC
	--	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--IF  NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_DistID_PartNumber_ManuCode_BatchCode')
	--	CREATE NONCLUSTERED INDEX [IX_DistID_PartNumber_ManuCode_BatchCode] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		[DistID] ASC,
	--		[ManufacturerCode] ASC,
	--		[PartNumber] ASC,
	--		[BatchCode] ASC
	--	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--IF  NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_DistID_Uploaded_InvID')
	--	CREATE NONCLUSTERED INDEX [IX_DistID_Uploaded_InvID] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		[DistID]
	--	)
	--	INCLUDE ([Uploaded],[InvID]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_InventoryUpload')
	--	CREATE NONCLUSTERED INDEX [IX_InventoryUpload] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		[DistID]
	--	)
	--	INCLUDE ([ManufacturerCode],[PartNumber],[QtyOnHand],[BatchCode],[Uploaded],[InvID])
	--	WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_PartNumber_ManuCode_BatchCode')
	--	CREATE NONCLUSTERED INDEX [IX_PartNumber_ManuCode_BatchCode] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		  [ManufacturerCode] ASC,
	--		  [PartNumber] ASC,
	--		  [BatchCode] ASC
	--	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_PartNumber_ManuCode_DistID')
	--	CREATE NONCLUSTERED INDEX [IDX_PartNumber_ManuCode_DistID] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		[PartNumber]
	--	)
	--	INCLUDE ([ManufacturerCode],[DistID])
	--	WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		

	--EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finished Creating Indexes on DistributorPartsStatic','';
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsStatic_Cache]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsStatic_Cache]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsStatic_Cache]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsStatic_Cache]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	---------------------------------------------
	-- DistributorPartsStatic_Cache -------------------
	
	-- Queries that would be using the DistributorParts table for display on the web will instead use this table so it matches the 
	-- results from the last solr load.
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate DistributorPartsStatic_Cache','';
	TRUNCATE TABLE DistributorPartsStatic_Cache

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'DROP INDEX and CONSTRAINTS ON DistributorPartsStatic_Cache','';
	
	SET IDENTITY_INSERT [DistributorPartsStatic_Cache] ON

	IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Cache_Uploaded_1]') AND type = 'D')
	BEGIN
		ALTER TABLE [dbo].[DistributorPartsStatic_Cache] DROP CONSTRAINT [DF_DistributorPartsStatic_Cache_Uploaded_1]
	END

	IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Cache_Status_1]') AND type = 'D')
	BEGIN
		ALTER TABLE [dbo].[DistributorPartsStatic_Cache] DROP CONSTRAINT [DF_DistributorPartsStatic_Cache_Status_1]
	END

	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IDX_PartNumber_ManuCode_DistID')
		DROP INDEX [IDX_PartNumber_ManuCode_DistID] ON [dbo].[DistributorPartsStatic_Cache] WITH ( ONLINE = OFF )

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into DistributorPartsStatic_Cache','';								
	INSERT INTO DistributorPartsStatic_Cache(
		[ManufacturerCode],
		[PartNumber],
		[Description],[QtyOnHand],[Price],[ROHS],[BatchCode],
		[BreakLevel1],[Price1],[BreakLevel2],[Price2],[BreakLevel3],[Price3],[BreakLevel4],[Price4],[BreakLevel5],[Price5],
		[BreakLevel6],[Price6],[BreakLevel7],[Price7],[BreakLevel8],[Price8],[BreakLevel9],[Price9],[BreakLevel10],[Price10],
		dp.[DistID],[Uploaded],[InvID],[Status],[Search_PartNumber])
	SELECT 
		dp.[ManufacturerCode],
		UPPER(dbo.RemoveStringTerminator(ISNULL(pn.Common_PartNumber, ''))),
		[Description],
		[QtyOnHand],
		[Price],
		[ROHS],
		[BatchCode],
		[BreakLevel1],[Price1],[BreakLevel2],[Price2],[BreakLevel3],[Price3],[BreakLevel4],[Price4],[BreakLevel5],[Price5],
		[BreakLevel6],[Price6],[BreakLevel7],[Price7],[BreakLevel8],[Price8],[BreakLevel9],[Price9],[BreakLevel10],[Price10],
		[DistID],
		[Uploaded],
		[InvID],
		[Status],
		clean.Search_PartNumber
	FROM 
		DistributorParts dp WITH (NOLOCK) INNER JOIN
		DistributorParts_Clean clean WITH(NOLOCK) ON dp.partNumber = clean.partnumber LEFT JOIN
		tmp_Load_DistinctPartMfrCodeXRF xrf WITH (NOLOCK) ON dp.ManufacturerCode = xrf.ManufacturerCode
												AND dp.DistID = xrf.DistributorId
												AND clean.Search_PartNumber = xrf.Search_PartNumber LEFT JOIN
		tmp_Load_PartNumber_CommonName pn on clean.Search_PartNumber = pn.Search_PartNumber 
										AND (ISNULL(xrf.ManufacturerId,0) = pn.ManufacturerId)
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsStatic_Cache from DistributorParts','';										
	--WHERE dp.PartNumber IN ('BC546B126','BC546B,126','"BC546B,126"','BC546B.126','MAX705CSA','MAX705CSA+')
	
	SET IDENTITY_INSERT [DistributorPartsStatic_Cache] ON
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsStatic_CacheFromtmp_Load_Product]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsStatic_CacheFromtmp_Load_Product]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsStatic_CacheFromtmp_Load_Product]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsStatic_CacheFromtmp_Load_Product]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	SET IDENTITY_INSERT [DistributorPartsStatic_Cache] ON

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Start Insert into DistributorPartsStatic_Cache from tmp_Load_Product (Mfr Products)','';	
	INSERT INTO DistributorPartsStatic_Cache([ManufacturerCode],[PartNumber],[DistID],[Uploaded],[QtyOnHand],[Price],[Price1], [ROHS], [InvID],[Status], [IsManufacturerProduct], [Search_PartNumber])
		SELECT MAX(xrf.ManufacturerCode), pn.Common_PartNumber,p.[DistID],p.PartUploadDate,0,0,0,0,p.DistributorPartID,'Active', 1, pn.Search_PartNumber
		FROM tmp_Load_Product p 
		INNER JOIN DistributorParts_Clean clean WITH (NOLOCK) 
			ON p.PartNumber = clean.PartNumber 
		INNER JOIN tmp_Load_PartNumber_CommonName pn 
			ON clean.Search_PartNumber = pn.Search_PartNumber AND pn.ManufacturerId = p.ManufacturerID
		LEFT OUTER JOIN tmp_Load_DistinctPartMfrCodeXRF xrf 
			ON p.DistID = xrf.DistributorId
			AND p.ManufacturerID = xrf.ManufacturerId 
		GROUP BY p.DistID, p.ManufacturerID, pn.Common_PartNumber, p.PartUploadDate, p.DistributorPartID,  pn.Search_PartNumber
		          
		--	tmp_Load_DistinctPartMfrCodeXRF xrf WITH (NOLOCK) ON dp.ManufacturerCode = xrf.ManufacturerCode
		--										AND dp.DistID = xrf.DistributorId
		--										AND clean.Search_PartNumber = xrf.Search_PartNumber LEFT JOIN
												
		--Search_PartNumber VARCHAR(250),
		--DistributorId INT,
		--ManufacturerId INT,
		--ManufacturerCode VARCHAR(256)
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'CREATE INDEX and CONSTRAINTS ON DistributorPartsStatic_Cache','';	
	
	SET IDENTITY_INSERT [DistributorPartsStatic_Cache] OFF
	
	IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Cache_Uploaded_1]') AND type = 'D')
	BEGIN
		ALTER TABLE [dbo].[DistributorPartsStatic_Cache] ADD  CONSTRAINT [DF_DistributorPartsStatic_Cache_Uploaded_1]  DEFAULT (GETDATE()) FOR [Uploaded]
	END

	IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Cache_Status_1]') AND type = 'D')
	BEGIN
		ALTER TABLE [dbo].[DistributorPartsStatic_Cache] ADD  CONSTRAINT [DF_DistributorPartsStatic_Cache_Status_1]  DEFAULT ('Active') FOR [Status]
	END

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IDX_PartNumber_ManuCode_DistID')
		CREATE NONCLUSTERED INDEX [IDX_PartNumber_ManuCode_DistID] ON [dbo].[DistributorPartsStatic_Cache] 
		(
			[PartNumber]
		)
		INCLUDE ([ManufacturerCode],[DistID])
		WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsStatic_Cache from tmp_Load_Product (Mfr Products)','';	
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_MfrDist]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_MfrDist]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_MfrDist]
GO


CREATE PROCEDURE [dbo].[usp_Load_MfrDist]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	--PRINT 'Get all authorized distributor records for Manufacturers with Products'
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_MfrDist','';
	TRUNCATE TABLE tmp_Load_MfrDist

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Begin Insert into tmp_Load_MfrDist','';								
	INSERT INTO tmp_Load_MfrDist
	SELECT ra.MfrID, ra.DistID
	FROM RegionAuthorization ra WITH (NOLOCK)
	INNER JOIN RegionZoneStatus rzs WITH (NOLOCK)
		ON ra.MfrDistID = rzs.MfrDistID
		AND rzs.AuthStatusID = 4
	WHERE ra.IsActive = 1
	AND ra.Publish = 1
	AND ra.MfrID IN (
		SELECT DISTINCT p.ManufacturerID
		FROM tmp_Load_MfrProduct m
		INNER JOIN Product p
		ON m.PartNumber = p.PartNumber
	)
	GROUP BY ra.MfrID, ra.DistID

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into tmp_Load_MfrDist','';								
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_MfrProduct]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_MfrProduct]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_MfrProduct]
GO


CREATE PROCEDURE [dbo].[usp_Load_MfrProduct]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);

	--PRINT 'Get all records from Product table that do NOT match to DistributorParts table'
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_MfrProduct','';
	TRUNCATE TABLE tmp_Load_MfrProduct

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_MfrProduct','';
	INSERT INTO tmp_Load_MfrProduct
	SELECT DISTINCT p.PartNumber
	FROM Product p

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Delete tmp_Load_DistProduct from tmp_Load_MfrProduct','';
	DELETE mp
	FROM tmp_Load_MfrProduct mp
	INNER JOIN tmp_Load_DistProduct dp
		ON mp.PartNumber = dp.PartNumber
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_PartNumber_CommonName]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_PartNumber_CommonName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_PartNumber_CommonName]
GO


CREATE PROCEDURE [dbo].[usp_Load_PartNumber_CommonName]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_PartNumber_CommonName','';
	TRUNCATE TABLE tmp_Load_PartNumber_CommonName

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Drop Indexes on tmp_Load_PartNumber_CommonName','';
	
	--Used in in insert into DistributorPartsStatic_Cache to give part numbers a common name
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_CommonName]') AND name = N'IDX_Search_PartNumber')
	BEGIN
		DROP INDEX IDX_Search_PartNumber ON dbo.tmp_Load_PartNumber_CommonName WITH ( ONLINE = OFF )
	END

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_PartNumber_CommonName','';

	--Used in in insert into DistributorPartsStatic_Cache to give part numbers a common name
	INSERT INTO tmp_Load_PartNumber_CommonName 
	SELECT DISTINCT --Original_PartNumbers.PartNumber AS PartNumber, 
	b.PartNumber AS Common_PartNumber, b.Search_PartNumber, b.ManufacturerId
	FROM
	(
		SELECT a.PartNumber, a.Search_PartNumber, a.ManufacturerId, ROW_NUMBER () OVER (PARTITION BY a.Search_PartNumber, a.ManufacturerId ORDER BY a.DistAdSpend DESC) AS GroupPosition
		FROM
		(
			SELECT dp.PartNumber, Search_PartNumber, dp.ManufacturerId, dp.DistAdSpend
			FROM
			tmp_Load_PartNumber_SearchPartNumber dp WITH (NOLOCK)
		) a
	) b 
	LEFT JOIN
	tmp_Load_PartNumber_SearchPartNumber Original_PartNumbers ON b.Search_PartNumber = Original_PartNumbers.Search_PartNumber 
														AND b.ManufacturerId = Original_PartNumbers.ManufacturerId
	WHERE GroupPosition = 1

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Build Indexes on tmp_Load_PartNumber_CommonName','';


	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_CommonName]') AND name = N'IDX_Search_PartNumber')
	BEGIN
		CREATE INDEX IDX_Search_PartNumber ON tmp_Load_PartNumber_CommonName (Search_PartNumber, ManufacturerId);
	END
					
	--select * from tmp_Load_PartNumber_CommonName

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into tmp_Load_PartNumber_CommonName','';
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_PartNumber_SearchPartNumber]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_PartNumber_SearchPartNumber]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_PartNumber_SearchPartNumber]
GO


CREATE PROCEDURE [dbo].[usp_Load_PartNumber_SearchPartNumber]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_PartNumber_SearchPartNumber','';
	TRUNCATE TABLE tmp_Load_PartNumber_SearchPartNumber
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Drop Indexes on tmp_Load_PartNumber_SearchPartNumber','';

	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_SearchPartNumber]') AND name = N'IDX_PartNumber_SearchPartNumber')
	BEGIN
		DROP INDEX IDX_PartNumber_SearchPartNumber ON dbo.tmp_Load_PartNumber_SearchPartNumber WITH ( ONLINE = OFF )
	END
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_PartNumber_SearchPartNumber','';

	INSERT INTO tmp_Load_PartNumber_SearchPartNumber
	SELECT DISTINCT 
		PartNumber,
		Search_PartNumber,
		Spend,
		ManufacturerId
	FROM
	(
		SELECT PartNumber, Search_PartNumber, Spend, ManufacturerId
		FROM
		(
			SELECT -- Distributors
				dp.PartNumber,
				clean.Search_PartNumber,
				AdSpendRollUp.Spend,
				ISNULL(xrf.ManufacturerId, 0) AS ManufacturerId
			FROM
				DistributorParts dp WITH (NOLOCK) LEFT JOIN
				DistributorParts_Clean clean WITH(NOLOCK) on dp.partnumber = clean.partnumber LEFT JOIN
				tmp_Load_DistinctPartMfrCodeXRF xrf WITH (NOLOCK) ON dp.ManufacturerCode = xrf.ManufacturerCode 
														AND dp.DistID = xrf.DistributorId
														AND xrf.Search_PartNumber = clean.Search_PartNumber LEFT JOIN
				Company mfr ON xrf.ManufacturerId = mfr.CompanyID AND mfr.CompanyStatusID = 1 LEFT JOIN --active
				-- We just want some credible Distributor, those who spend money tend to be more credible. We'll use their description of the part for all other disty's
				(SELECT SUM(Online_Amount) as Spend, DistID FROM
				  dbo.DistPartsSpend s WITH (NOLOCK)
				  GROUP BY DistID   
				) AdSpendRollUp ON dp.DistID = AdSpendRollUp.DistId
				--where dp.PartNumber IN ('BC546B126','BC546B,126','�BC546B,126�','BC546B.126','MAX705CSA','MAX705CSA+') 
			UNION
		SELECT -- Manufacturers
			p.PartNumber,
			UPPER(dbo.RemoveSpecialChars(p.PartNumber)) AS Search_PartNumber,
			0,
			p.ManufacturerID
		FROM
			Product p WITH (NOLOCK) INNER JOIN
			Company c on p.ManufacturerID = c.CompanyId AND c.CompanyStatusID = 1 --active
		--WHERE p.PartNumber IN ('BC546B126','BC546B,126','"BC546B,126"','BC546B.126','MAX705CSA','MAX705CSA+')
		) a 
	) b
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Build Indexes on tmp_Load_PartNumber_SearchPartNumber','';
	
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_SearchPartNumber]') AND name = N'IDX_PartNumber_SearchPartNumber')
	BEGIN
		CREATE INDEX IDX_PartNumber_SearchPartNumber ON tmp_Load_PartNumber_SearchPartNumber (Search_PartNumber, ManufacturerId)
	END

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into tmp_Load_PartNumber_SearchPartNumber','';
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_Product]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_Product]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_Product]
GO


CREATE PROCEDURE [dbo].[usp_Load_Product]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	--PRINT 'Roll up all records that do NOT match to DistributorParts table and add authorizated distributors'
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_Product','';
	TRUNCATE TABLE tmp_Load_Product

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Drop indexes on tmp_Load_Product','';
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_Product]') AND name = N'IX_PartNumber')
	BEGIN
		DROP INDEX [IX_PartNumber] ON [dbo].[tmp_Load_Product] 
	END

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Reseed tmp_Load_Product to avoid identity conflict in DistributorPartsStatic_Cache','';
	DECLARE @seed INT = (
		SELECT MAX(InvID) + 1
		FROM dbo.DistributorPartsStatic_Cache AS dpsc
	)

	DBCC CHECKIDENT (tmp_Load_Product, RESEED, @seed)

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_Product','';								
	INSERT INTO tmp_Load_Product
	(DistID, ManufacturerID, PartNumber, PartUploadDate)
	SELECT md.DistributorID, md.ManufacturerID, mp.PartNumber,
		COALESCE(p.CreatedOn, p.LastUpdatedOn, GETDATE()) AS PartUploadDate
	FROM tmp_Load_MfrDist md
	INNER JOIN Product p WITH (NOLOCK)
		ON md.ManufacturerID = p.ManufacturerID
	INNER JOIN tmp_Load_MfrProduct mp WITH (NOLOCK)
		ON p.PartNumber = mp.PartNumber

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Create indexes on tmp_Load_Product','';
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_Product]') AND name = N'IX_PartNumber')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_PartNumber] ON [dbo].[tmp_Load_Product] 
		(
			  [PartNumber] ASC
		)WITH (STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	END
END
GO




USE [msdb]
GO

/****** Object:  Job [ESB SOLR Indexing Test]    Script Date: 04/02/2013 10:55:14 ******/
IF  EXISTS (
SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'ESB SOLR Indexing'
)
BEGIN
	DECLARE @job_id UNIQUEIDENTIFIER
	SELECT @job_id = job_id FROM msdb.dbo.sysjobs_view WHERE name = N'ESB SOLR Indexing'
	
	EXEC msdb.dbo.sp_delete_job @job_id=@job_id, @delete_unused_schedule=1
END

/****** Object:  Job [ESB SOLR Indexing Test]    Script Date: 04/02/2013 10:55:14 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 04/02/2013 10:55:14 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ESB SOLR Indexing', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'imapuser', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_UpdateETLProcessConfiguration FALSE]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_UpdateETLProcessConfiguration FALSE', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_UpdateETLProcessConfiguration ''False''', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_DeleteDistOldDaysParts]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_DeleteDistOldDaysParts', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Exec usp_DeleteDistOldDaysParts 35', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_DistributorParts_Clean]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_DistributorParts_Clean', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_DistributorParts_Clean', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_DistinctPartMfrCodeXRF]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_DistinctPartMfrCodeXRF', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_DistinctPartMfrCodeXRF', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_PartNumber_SearchPartNumber]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_PartNumber_SearchPartNumber', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_PartNumber_SearchPartNumber', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_PartNumber_CommonName]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_PartNumber_CommonName', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_PartNumber_CommonName', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_DistributorPartsStatic_Cache]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_DistributorPartsStatic_Cache', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_DistributorPartsStatic_Cache', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_DistProduct]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_DistProduct', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_DistProduct', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_MfrProduct]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_MfrProduct', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_MfrProduct', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_MfrDist]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_MfrDist', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_MfrDist', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_Product]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_Product', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_Product', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_DistributorPartsStatic_CacheFromtmp_Load_Product]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_DistributorPartsStatic_CacheFromtmp_Load_Product', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_DistributorPartsStatic_CacheFromtmp_Load_Product', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_DistributorPartsLoad]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_DistributorPartsLoad', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_DistributorPartsLoad', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_DistributorPartsSearch_Cache]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_DistributorPartsSearch_Cache', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_DistributorPartsSearch2', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_DistributorPartsStatic]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_DistributorPartsStatic', 
		@step_id=15, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_DistributorPartsStatic', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_DistributorPartsSearch]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_DistributorPartsSearch', 
		@step_id=16, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_DistributorPartsSearch1', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_Load_UpdateETLProcessConfiguration TRUE]    Script Date: 04/02/2013 10:55:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_Load_UpdateETLProcessConfiguration TRUE', 
		@step_id=17, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_Load_UpdateETLProcessConfiguration ''True''', 
		@database_name=N'SourceESB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily - Evening', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20130402, 
		@active_end_date=99991231, 
		@active_start_time=230000, 
		@active_end_time=235959, 
		@schedule_uid=N'a05b0b01-4edf-441f-86d0-c87d66aadd85'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO



