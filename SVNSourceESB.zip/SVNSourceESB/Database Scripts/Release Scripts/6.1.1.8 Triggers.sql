/****** Object:  Trigger [TRG_CompanyProductType_Insert_Update_Delete]    Script Date: 07/25/2012 09:42:54 ******/
IF  EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[TRG_CompanyProductType_Insert_Update_Delete]'))
DROP TRIGGER [dbo].[TRG_CompanyProductType_Insert_Update_Delete]
GO

/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Logs the specific information that was changed so it can be used for logs and alerts.

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
12.21.2012		Marcus Ruether			Created. 
MM.DD.YYYY		<developer name>		<Changes made.> 
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE TRIGGER [dbo].[TRG_CompanyProductType_Insert_Update_Delete]
ON [dbo].[CompanyProductType]
AFTER INSERT, UPDATE, DELETE
AS
	DECLARE @ProcessId INT = (SELECT TOP 1 ProcessId FROM MstProcess WHERE ProcessName = 'TRG_CompanyProductType_Insert_Update_Delete');
	
	DECLARE @ProcessLogId INT = 0;
	
	INSERT INTO ProcessLog VALUES (@ProcessId, GETDATE());
	
	SET @ProcessLogId = @@IDENTITY;
		
	DECLARE @UserId INT;
	SET @UserId = (select convert(int,convert(varbinary(4),CONTEXT_INFO())));
	
	DECLARE @UpdateTime DATETIME;
	SET @UpdateTime = GETDATE();
	
	--Run through affected records
	
	--put these into temp tables so the can by accessed by dynamic sql
	--not the best, but only I could think of to make this generic.
	INSERT INTO dbo.CompanyProductType_ChangeQue
	(		
		[CompProdTypeID]
       ,[CompanyID]
       ,[ProductTypeID]
       ,[IsApproved]
       ,[IsActive]
       ,[CreatedOn]
       ,[CreatedBy]
       ,[UpdatedOn]
       ,[UpdatedBy]
       ,[ProcessLogId]
       ,[UserId]
       ,[IsInsert]
       ,[DateLogged]
    )
	SELECT 
		[CompProdTypeID]
       ,[CompanyID]
       ,[ProductTypeID]
       ,[IsApproved]
       ,[IsActive]
       ,[CreatedOn]
       ,[CreatedBy]
       ,[UpdatedOn]
       ,[UpdatedBy]
      ,@ProcessLogId
      ,@UserId
      ,1 -- IsInsert
      ,@UpdateTime
	FROM inserted


	INSERT INTO dbo.CompanyProductType_ChangeQue
	(		
		[CompProdTypeID]
       ,[CompanyID]
       ,[ProductTypeID]
       ,[IsApproved]
       ,[IsActive]
       ,[CreatedOn]
       ,[CreatedBy]
       ,[UpdatedOn]
       ,[UpdatedBy]
       ,[ProcessLogId]
       ,[UserId]
       ,[IsInsert]
       ,[DateLogged]
    )
	SELECT 
		[CompProdTypeID]
       ,[CompanyID]
       ,[ProductTypeID]
       ,[IsApproved]
       ,[IsActive]
       ,[CreatedOn]
       ,[CreatedBy]
       ,[UpdatedOn]
       ,[UpdatedBy]
      ,@ProcessLogId
      ,@UserId
      ,0 -- IsInsert
      ,@UpdateTime
	FROM deleted

GO



/****** Object:  Trigger [TRG_RegionZoneStatus_Insert_Update_Delete]    Script Date: 07/25/2012 09:42:54 ******/
IF  EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[TRG_RegionZoneStatus_Insert_Update_Delete]'))
DROP TRIGGER [dbo].[TRG_RegionZoneStatus_Insert_Update_Delete]
GO

/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Logs the specific information that was changed so it can be used for logs and alerts.

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
12.21.2012		Marcus Ruether			Created. 
01.16.2013		Marcus Ruether		Updated to pull userid from CONTEXT_INFO and insert a record description
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE TRIGGER [dbo].[TRG_RegionZoneStatus_Insert_Update_Delete]
ON [dbo].[RegionZoneStatus]
AFTER INSERT, UPDATE, DELETE
AS
	DECLARE @ProcessId INT = (SELECT TOP 1 ProcessId FROM MstProcess WHERE ProcessName = 'TRG_RegionZoneStatus_Insert_Update_Delete');
	
	DECLARE @ProcessLogId INT = 0;
	
	INSERT INTO ProcessLog VALUES (@ProcessId, GETDATE());
	
	SET @ProcessLogId = @@IDENTITY;
		
	DECLARE @UserId INT;
	SET @UserId = (select convert(int,convert(varbinary(4),CONTEXT_INFO())));
	
	DECLARE @UpdateTime DATETIME;
	SET @UpdateTime = GETDATE();
	
	--Run through affected records
	
	--put these into temp tables so the can by accessed by dynamic sql
	--not the best, but only I could think of to make this generic.
	INSERT INTO dbo.RegionZoneStatus_ChangeQue
	(		
		ZoneKeyId
	   ,[MfrDistID]
	   ,[RegionID]
	   ,[ZoneID]
	   ,[AuthStatusID]
	   ,[Authorized_Date]
	   ,[Denied_Date]
	   ,[Online_Amount]
	   ,[Print_Amount]
	   ,[ProcessLogId]
	   ,[UserId]
	   ,[IsInsert]
	   ,[DateLogged]
    )
	SELECT 
	   [ZoneKeyID]
      ,[MfrDistID]
      ,[RegionID]
      ,[ZoneID]
      ,[AuthStatusID]
      ,[Authorized_Date]
      ,[Denied_Date]
      ,[Online_Amount]
      ,[Print_Amount]
      ,@ProcessLogId
      ,@UserId
      ,1 -- IsInsert
      ,@UpdateTime
	FROM inserted


	INSERT INTO dbo.RegionZoneStatus_ChangeQue
	(		
		ZoneKeyId
	   ,[MfrDistID]
	   ,[RegionID]
	   ,[ZoneID]
	   ,[AuthStatusID]
	   ,[Authorized_Date]
	   ,[Denied_Date]
	   ,[Online_Amount]
	   ,[Print_Amount]
	   ,[ProcessLogId]
	   ,[UserId]
	   ,[IsInsert]
	   ,[DateLogged]
    )
	SELECT 
	   [ZoneKeyID]
      ,[MfrDistID]
      ,[RegionID]
      ,[ZoneID]
      ,[AuthStatusID]
      ,[Authorized_Date]
      ,[Denied_Date]
      ,[Online_Amount]
      ,[Print_Amount]
      ,@ProcessLogId
      ,@UserId
      ,0 -- IsInsert
      ,@UpdateTime
	FROM deleted
	
GO






