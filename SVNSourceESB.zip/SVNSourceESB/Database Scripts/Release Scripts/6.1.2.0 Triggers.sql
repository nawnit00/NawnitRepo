/****** Object:  Trigger [TRG_RegionZoneStatus_Insert_Update_Delete]    Script Date: 07/25/2012 09:42:54 ******/
IF  EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[TRG_RegionZoneStatus_Insert_Update_Delete]'))
DROP TRIGGER [dbo].[TRG_RegionZoneStatus_Insert_Update_Delete]
GO

--TRG_RegionZoneStatus_Insert_Update_Delete
/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Logs the specific information that was changed so it can be used for logs and alerts.

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
12.21.2012		Marcus Ruether		Created
01.16.2013		Marcus Ruether		Updated to pull userid from CONTEXT_INFO and insert a record description
04.25.2013		Tim Jumps			Insert CompanyID for use in Company Change report. Ticket 27168
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE TRIGGER [dbo].[TRG_RegionZoneStatus_Insert_Update_Delete]
ON [dbo].[RegionZoneStatus]
AFTER INSERT, UPDATE, DELETE
AS
	DECLARE @ProcessId INT = (SELECT TOP 1 ProcessId FROM MstProcess WHERE ProcessName = 'TRG_RegionZoneStatus_Insert_Update_Delete');
	
	DECLARE @ProcessLogId INT = 0;
	
	INSERT INTO ProcessLog VALUES (@ProcessId, GETDATE());
	
	SET @ProcessLogId = @@IDENTITY;
		
	DECLARE @UserId INT;
	SET @UserId = (select convert(int,convert(varbinary(4),CONTEXT_INFO())));
	
	DECLARE @UpdateTime DATETIME;
	SET @UpdateTime = GETDATE();

	--Run through affected records
	
	--put these into temp tables so the can by accessed by dynamic sql
	--not the best, but only I could think of to make this generic.
	INSERT INTO dbo.RegionZoneStatus_ChangeQue
	(		
		ZoneKeyId
	   ,[MfrDistID]
	   ,[CompanyID]
	   ,[RegionID]
	   ,[ZoneID]
	   ,[AuthStatusID]
	   ,[Authorized_Date]
	   ,[Denied_Date]
	   ,[Online_Amount]
	   ,[Print_Amount]
	   ,[ProcessLogId]
	   ,[UserId]
	   ,[IsInsert]
	   ,[DateLogged]
    )
	SELECT 
	   r.[ZoneKeyID]
      ,r.[MfrDistID]
      ,ISNULL(c.CompanyID, 0)
      ,r.[RegionID]
      ,r.[ZoneID]
      ,r.[AuthStatusID]
      ,r.[Authorized_Date]
      ,r.[Denied_Date]
      ,r.[Online_Amount]
      ,r.[Print_Amount]
      ,@ProcessLogId
      ,@UserId
      ,1 -- IsInsert
      ,@UpdateTime
	FROM INSERTED AS r
    INNER JOIN dbo.Region AS rg
            ON r.RegionID = rg.RegionID
    LEFT JOIN dbo.RegionAuthorization AS ra
            ON r.MfrDistID = ra.MfrDistID
	--RegionAuthorization may have been deleted before this record is deleted.  Try to pull from previous log.
    LEFT OUTER JOIN dbo.UpdateLog AS ul
            ON r.MfrDistID = ISNULL(ul.NewValue,ul.OldValue)
               AND ra.MfrDistID IS NULL
               AND ul.LogTableColumnId = 92 -- 92 = RegionAuthorization.MfrDistID
    LEFT OUTER JOIN dbo.UpdateLog AS ul1
            ON ul.PrimaryKey = ul1.PrimaryKey
               AND ul.ChangeDate = ul1.ChangeDate
               AND ul.LogTableColumnId = 93 -- 93 = RegionAuthorization.MfrID
    LEFT OUTER JOIN dbo.Company AS c
            ON COALESCE(ra.MfrID, ul1.NewValue, ul1.OldValue) = c.CompanyID


	INSERT INTO dbo.RegionZoneStatus_ChangeQue
	(		
		ZoneKeyId
	   ,[MfrDistID]
	   ,[CompanyID]
	   ,[RegionID]
	   ,[ZoneID]
	   ,[AuthStatusID]
	   ,[Authorized_Date]
	   ,[Denied_Date]
	   ,[Online_Amount]
	   ,[Print_Amount]
	   ,[ProcessLogId]
	   ,[UserId]
	   ,[IsInsert]
	   ,[DateLogged]
    )
	SELECT 
	   r.[ZoneKeyID]
      ,r.[MfrDistID]
      ,ISNULL(C.CompanyID, 0)
      ,r.[RegionID]
      ,r.[ZoneID]
      ,r.[AuthStatusID]
      ,r.[Authorized_Date]
      ,r.[Denied_Date]
      ,r.[Online_Amount]
      ,r.[Print_Amount]
      ,@ProcessLogId
      ,@UserId
      ,0 -- IsInsert
      ,@UpdateTime
	FROM DELETED AS r
    INNER JOIN dbo.Region AS rg
            ON r.RegionID = rg.RegionID
    LEFT JOIN dbo.RegionAuthorization AS ra
            ON r.MfrDistID = ra.MfrDistID
	--RegionAuthorization may have been deleted before this record is deleted.  Try to pull from previous log.
    LEFT OUTER JOIN dbo.UpdateLog AS ul
            ON r.MfrDistID = ISNULL(ul.NewValue,ul.OldValue)
               AND ra.MfrDistID IS NULL
               AND ul.LogTableColumnId = 92 -- 92 = RegionAuthorization.MfrDistID
    LEFT OUTER JOIN dbo.UpdateLog AS ul1
            ON ul.PrimaryKey = ul1.PrimaryKey
               AND ul.ChangeDate = ul1.ChangeDate
               AND ul.LogTableColumnId = 93 -- 93 = RegionAuthorization.MfrID
    LEFT OUTER JOIN dbo.Company AS c
            ON COALESCE(ra.MfrID, ul1.NewValue, ul1.OldValue) = c.CompanyID

GO
