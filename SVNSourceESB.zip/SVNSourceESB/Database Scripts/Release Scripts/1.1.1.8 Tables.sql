

/****** Object:  Table [dbo].[CompanyProductType_ChangeQue]    Script Date: 03/22/2013 17:07:27 ******/
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CompanyProductType_ChangeQue]') AND type in (N'U'))
BEGIN

	CREATE TABLE [dbo].[CompanyProductType_ChangeQue](
		[CompProdTypeID] [int] NOT NULL,
		[CompanyID] [int] NOT NULL,
		[ProductTypeID] [int] NOT NULL,
		[IsApproved] [bit] NULL,
		[IsActive] [bit] NULL,
		[CreatedOn] [datetime] NULL,
		[CreatedBy] [int] NULL,
		[UpdatedOn] [datetime] NULL,
		[UpdatedBy] [int] NULL,
		ProcessLogId INT,
		UserId INT,
		IsInsert bit,
		DateLogged DATETIME
	 )
END

/****** Object:  Table [dbo].[InventoryUploadHistory]    Script Date: 10/09/2012 14:24:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING OFF
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[InventoryUploadHistory]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[InventoryUploadHistory](
		[InventoryUploadHistoryId] [int] IDENTITY(1,1) NOT NULL,
		[MappingId] [int] NULL,
		[CompanyId] [int] NOT NULL,
		[FileInventoryCount] [int] NULL,
		[InvalidQtyFieldCount] [int] NULL,
		[ZeroQtyFieldCount] [int] NULL,
		[InvalidPriceBreakFieldCount] [int] NULL,
		[OverLimitCount] [int] NULL,
		[UpdatedCount] [int] NULL,
		[InsertedCount] [int] NULL,
		[FileType] [varchar](50) NULL,
		[UploadDate] [datetime] NULL,
		[HasError] [bit] NOT NULL,
		[ErrorMessage] [varchar](8000) NULL,
		[DuplicateCount] [int] NULL,
		[Vector] [varchar](5) NULL,
	 CONSTRAINT [PK_InventoryHistory] PRIMARY KEY CLUSTERED 
	(
		[InventoryUploadHistoryId] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
	GO

	SET ANSI_PADDING OFF
	GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_InventoryUploadHistory_HasError]') AND type = 'D')
BEGIN
	ALTER TABLE [dbo].[InventoryUploadHistory] ADD CONSTRAINT [DF_InventoryUploadHistory_HasError]  DEFAULT ((0)) FOR [HasError]
END
GO

IF NOT EXISTS
(
	SELECT *
	FROM [INFORMATION_SCHEMA].[COLUMNS]
	WHERE TABLE_NAME = 'InventoryUploadHistory'
		AND COLUMN_NAME = 'DuplicateCount'
)
ALTER TABLE dbo.InventoryUploadHistory ADD DuplicateCount INT
GO

IF NOT EXISTS
(
	SELECT *
	FROM [INFORMATION_SCHEMA].[COLUMNS]
	WHERE TABLE_NAME = 'InventoryUploadHistory'
		AND COLUMN_NAME = 'Vector'
)
ALTER TABLE dbo.InventoryUploadHistory ADD [Vector] VARCHAR(5)
GO

IF NOT EXISTS
(
	SELECT *
	FROM [INFORMATION_SCHEMA].[COLUMNS]
	WHERE TABLE_NAME = 'InventoryUploadHistory'
		AND COLUMN_NAME = 'ProcessTime'
)
ALTER TABLE dbo.InventoryUploadHistory ADD [ProcessTime] VARCHAR(100)
GO

IF NOT EXISTS
(
	SELECT *
	FROM [INFORMATION_SCHEMA].[COLUMNS]
	WHERE TABLE_NAME = 'InventoryUploadHistory'
		AND COLUMN_NAME = 'FileLineCount'
)
ALTER TABLE dbo.InventoryUploadHistory ADD [FileLineCount] INT
GO

IF NOT EXISTS
(
	SELECT *
	FROM [INFORMATION_SCHEMA].[COLUMNS]
	WHERE TABLE_NAME = 'InventoryUploadHistory'
		AND COLUMN_NAME = 'InvalidPartNumberFieldCount'
)
ALTER TABLE dbo.InventoryUploadHistory ADD [InvalidPartNumberFieldCount] INT
GO

IF NOT EXISTS
(
	SELECT *
	FROM [INFORMATION_SCHEMA].[COLUMNS]
	WHERE TABLE_NAME = 'InventoryUploadHistory'
		AND COLUMN_NAME = 'ZeroQtyFieldCount'
)
ALTER TABLE dbo.InventoryUploadHistory ADD [ZeroQtyFieldCount] INT
GO

IF NOT EXISTS
(
	SELECT *
	FROM [INFORMATION_SCHEMA].[COLUMNS]
	WHERE TABLE_NAME = 'InventoryUploadHistory'
		AND COLUMN_NAME = 'InvalidPriceBreakFieldCount'
)
ALTER TABLE dbo.InventoryUploadHistory ADD [InvalidPriceBreakFieldCount] INT
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING OFF
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[InventoryUploadHistoryReject]    Script Date: 03/21/2013 11:34:23 ******/
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[InventoryUploadHistoryReject]') AND type in (N'U'))
CREATE TABLE [dbo].[InventoryUploadHistoryReject](
	[InventoryUploadHistoryID] INT NOT NULL,
	[RejectReason] VARCHAR(MAX),
	[ManufacturerCode] [varchar](100) NULL,
	[Prefix] [varchar](250) NULL,
	[PartNumber] [varchar](250) NULL,
	[Description] [varchar](max) NULL,
	[QtyOnHand] [varchar](500) NULL,
	[Price] [varchar](500) NULL,
	[RoHS] [varchar](50) NULL,
	[BatchCode] [varchar](50) NULL,
	[BreakLevel1] [varchar](500) NULL,
	[Price1] [varchar](500) NULL,
	[BreakLevel2] [varchar](500) NULL,
	[Price2] [varchar](500) NULL,
	[BreakLevel3] [varchar](500) NULL,
	[Price3] [varchar](500) NULL,
	[BreakLevel4] [varchar](500) NULL,
	[Price4] [varchar](500) NULL,
	[BreakLevel5] [varchar](500) NULL,
	[Price5] [varchar](500) NULL,
	[BreakLevel6] [varchar](500) NULL,
	[Price6] [varchar](500) NULL,
	[BreakLevel7] [varchar](500) NULL,
	[Price7] [varchar](500) NULL,
	[BreakLevel8] [varchar](500) NULL,
	[Price8] [varchar](500) NULL,
	[BreakLevel9] [varchar](500) NULL,
	[Price9] [varchar](500) NULL,
	[BreakLevel10] [varchar](500) NULL,
	[Price10] [varchar](500) NULL,
	[InventoryID] [int] NOT NULL
) ON [PRIMARY]

GO


/****** Object:  Table [dbo].[RegionZoneStatus_ChangeQue]    Script Date: 03/22/2013 17:09:41 ******/
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RegionZoneStatus_ChangeQue]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[RegionZoneStatus_ChangeQue](
		[ZoneKeyID] [int] NOT NULL,
		[MfrDistID] [int] NOT NULL,
		[RegionID] [int] NOT NULL,
		[ZoneID] [int] NOT NULL,
		[AuthStatusID] [int] NOT NULL,
		[Authorized_Date] [datetime] NULL,
		[Denied_Date] [datetime] NULL,
		[Online_Amount] [money] NULL,
		[Print_Amount] [money] NULL,
		ProcessLogId INT,
		UserId INT,
		IsInsert bit,
		DateLogged DATETIME
	)
END
/****** Object:  Table [dbo].[tmp_Load_DistinctPartMfrCodeXRF]    Script Date: 03/28/2013 09:43:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistinctPartMfrCodeXRF]') AND type in (N'U'))
CREATE TABLE [dbo].[tmp_Load_DistinctPartMfrCodeXRF](
	[Search_PartNumber] [varchar](250) NULL,
	[DistributorId] [int] NULL,
	[ManufacturerId] [int] NULL,
	[ManufacturerCode] [varchar](256) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistinctPartMfrCodeXRF]') AND name = N'IDX_DistinctPartMfrCodeXRF_SearchPartNumber')
	CREATE NONCLUSTERED INDEX [IDX_DistinctPartMfrCodeXRF_SearchPartNumber] ON tmp_Load_DistinctPartMfrCodeXRF 
	(
		[Search_PartNumber] ASC,
		DistributorId ASC,
		ManufacturerCode ASC
	)
GO

/****** Object:  Table [dbo].[tmp_Load_DistProduct]    Script Date: 01/03/2013 10:34:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmpDistProduct]') AND type in (N'U'))
	DROP TABLE [dbo].[tmpDistProduct]
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistProduct]') AND type in (N'U'))
CREATE TABLE [dbo].[tmp_Load_DistProduct](
	PartNumber VARCHAR(250) NOT NULL
) ON [PRIMARY]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_DistProduct]') AND name = N'pk_DistProduct_PartNumber')
ALTER TABLE [dbo].[tmp_Load_DistProduct] ADD  CONSTRAINT [pk_DistProduct_PartNumber] PRIMARY KEY CLUSTERED 
(
	[PartNumber] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO  
/****** Object:  Table [dbo].[tmp_Load_MfrDist]    Script Date: 01/03/2013 10:34:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmpMfrDist]') AND type in (N'U'))
	DROP TABLE tmpMfrDist

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_MfrDist]') AND type in (N'U'))

CREATE TABLE tmp_Load_MfrDist
(
	ManufacturerID INT NOT NULL,
	DistributorID INT NOT NULL
)

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_MfrDist]') AND name = N'IDX_ManufacturerID_DistributorID')
CREATE INDEX IDX_ManufacturerID_DistributorID ON tmp_Load_MfrDist
(
	ManufacturerID ASC,
	DistributorID ASC
)
/****** Object:  Table [dbo].[tmp_Load_MfrProduct]    Script Date: 01/03/2013 10:34:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmpMfrProduct]') AND type in (N'U'))
	DROP TABLE [dbo].[tmpMfrProduct]
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_MfrProduct]') AND type in (N'U'))
CREATE TABLE [dbo].[tmp_Load_MfrProduct](
	PartNumber VARCHAR(250) NOT NULL
) ON [PRIMARY]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_MfrProduct]') AND name = N'pk_MfrProduct_PartNumber')
ALTER TABLE [dbo].[tmp_Load_MfrProduct] ADD  CONSTRAINT [pk_MfrProduct_PartNumber] PRIMARY KEY CLUSTERED 
(
	[PartNumber] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO 
/****** Object:  Table [dbo].[tmp_Load_PartNumber_CommonName]    Script Date: 03/28/2013 09:56:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO


IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_CommonName]') AND type in (N'U'))
CREATE TABLE [dbo].[tmp_Load_PartNumber_CommonName](
	[Common_PartNumber] [varchar](250) NULL,
	[Search_PartNumber] [varchar](256) NULL,
	[ManufacturerId] [int] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_CommonName]') AND name = N'IDX_Search_PartNumber')
BEGIN
	CREATE INDEX IDX_Search_PartNumber ON tmp_Load_PartNumber_CommonName (Search_PartNumber, ManufacturerId);
END
/****** Object:  Table [dbo].[tmp_Load_PartNumber_SearchPartNumber]    Script Date: 03/28/2013 09:50:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO


IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_SearchPartNumber]') AND type in (N'U'))
	CREATE TABLE [dbo].[tmp_Load_PartNumber_SearchPartNumber](
		[PartNumber] [varchar](250) NULL,
		[Search_PartNumber] [varchar](256) NULL,
		[DistAdSpend] [decimal](10, 2) NULL,
		[ManufacturerId] [int] NULL
	) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO
	
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_SearchPartNumber]') AND name = N'IDX_tmp_Load_PartNumber_SearchPartNumber')
BEGIN
	CREATE INDEX IDX_tmp_Load_PartNumber_SearchPartNumber ON tmp_Load_PartNumber_SearchPartNumber (Search_PartNumber, ManufacturerId)
END
GO
/****** Object:  Table [dbo].[tmp_Load_Product]    Script Date: 01/03/2013 10:34:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmpProduct]') AND type in (N'U'))
	DROP TABLE [dbo].[tmpProduct]

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_Product]') AND type in (N'U'))
CREATE TABLE [dbo].[tmp_Load_Product](
		DistributorPartID INT IDENTITY (1000000000,1) NOT NULL,
		DistID INT NULL,
		PartNumber VARCHAR(250) NULL,
		ManufacturerID INT NULL,
		PartUploadDate DATETIME NULL,
		PartQuantity INT NULL,
		Price MONEY NULL,
		Price1 MONEY NULL,
		ROHS VARCHAR(50) NULL
	) ON [PRIMARY]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_Product]') AND name = N'pk_Product_DistributorPartID')
ALTER TABLE [dbo].[tmp_Load_Product] ADD  CONSTRAINT [pk_Product_DistributorPartID] PRIMARY KEY CLUSTERED 
(
	[DistributorPartID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO  

/****** Object:  Table [dbo].[tmp_SiteMapLoad_SiteMapLink]    Script Date: 04/08/2013 18:38:49 ******/
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_SiteMapLoad_SiteMapLink]') AND type in (N'U'))
BEGIN

	CREATE TABLE [dbo].[tmp_SiteMapLoad_SiteMapLink](
		[tmp_SiteMapLoad_SiteMapLinkId] [int] IDENTITY(1,1) NOT NULL,
		[Url] [varchar](500) NOT NULL,
		[ChangeFrequency] [varchar](10) NULL,
		[Priority] [decimal](18, 2) NULL,
	 CONSTRAINT [PK_tmp_SiteMapLoad_SiteMapLink] PRIMARY KEY CLUSTERED 
	(
		[tmp_SiteMapLoad_SiteMapLinkId] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

END
GO

/****** Object:  Table [dbo].[SiteMapLink]    Script Date: 04/08/2013 18:38:00 ******/
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SiteMapLink]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[SiteMapLink](
		[SiteMapLinkId] [int] IDENTITY(1,1) NOT NULL,
		[SiteMapNumber] [int] NOT NULL,
		[Url] [varchar](500) NOT NULL,
		[ChangeFrequency] [varchar](10) NULL,
		[Priority] [decimal](18, 2) NULL,
		[Active] [bit] NOT NULL,
		[DateModified] [datetime] NULL,
		[DateCreated] [datetime] NULL,
	 CONSTRAINT [PK_SiteMapLink] PRIMARY KEY CLUSTERED 
	(
		[SiteMapLinkId] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

END