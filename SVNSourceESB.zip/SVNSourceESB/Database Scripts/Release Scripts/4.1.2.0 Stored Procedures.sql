/****** Object:  StoredProcedure [dbo].[uspAdJobFolderCreatePrint]    Script Date: 04/19/2013 16:15:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAdJobFolderCreatePrint]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspAdJobFolderCreatePrint]
GO

/****** Object:  StoredProcedure [dbo].[uspAdJobFolderCreatePrint]    Script Date: 04/19/2013 16:15:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--*****************************************************************************************************
--*   Modification        : To include Partial Complete & do optimization for updating AdJobfolderID
--*   Author            : Kiran Sangoi
--*   Modify Date        : Feb/27/2012
--*****************************************************************************************************

CREATE PROCEDURE  [dbo].[uspAdJobFolderCreatePrint]
AS
BEGIN

    DECLARE @AdOrderID int
    DECLARE @EditionID int
    DECLARE @AdApprovalID int
    DECLARE @ADJobFolderID int

    -- find ads with missing ad job folders
    DECLARE adordercur CURSOR FOR
        SELECT DISTINCT
            AO.AdOrderID,
            ADR.EditionID
        FROM
            AdOrder AO
            INNER JOIN AdOrderDetails AD
                ON AD.AdOrderID = AO.AdOrderID
            INNER JOIN AdOrderDetailsRegionEdition ADR
                ON ADR.AdOrderDetailsId = AD.AdOrderDetailsId

        WHERE
            AO.StatusId in (3,4)     -- Final OR Partial Complete
            AND ADR.EditionID>0
            AND ADR.ADJobFolderID IS NULL

    -- process orders/edi not having ad job folder
    OPEN adordercur
    FETCH adordercur INTO @AdOrderID, @EditionID

    WHILE @@Fetch_Status = 0
    BEGIN
        -- find out if there is an ad job folder for same order, same edition
        -- if not, create a new ad job folder
        -- if yes, than use the same ad job folder for the new ads
        SELECT @ADJobFolderID = ISNULL(
                            (SELECT
                                MAX(ADR.ADJobFolderID)
                            FROM
                                AdOrder AO
                                INNER JOIN AdOrder AO1
                                    ON AO1.AdOrderNumber = AO.AdOrderNumber
                                INNER JOIN AdOrderDetails AD
                                    ON AO1.AdorderID = AD.AdOrderID
                                INNER JOIN AdOrderDetailsRegionEdition ADR
                                    ON ADR.AdOrderDetailsId = AD.AdOrderDetailsId
                            WHERE
                                AO.AdOrderID = @AdOrderID
                                AND ADR.EditionID = @EditionID
                                AND ADR.ADJobFolderID IS NOT NULL), 0)

        IF @ADJobFolderID = 0
        BEGIN
            INSERT INTO AdJobFolderMaster(AdJobFolderTypeID,StatusId,CreatedDate) VALUES('P',1, GETDATE())
            SET @ADJobFolderID  = SCOPE_IDENTITY()
        END
        UPDATE AdOrderDetailsRegionEdition
                SET AdJobFolderId = @ADJobFolderID
                FROM
                    AdOrderDetailsRegionEdition ADR
                    INNER JOIN AdOrderDetails AD
                        ON ADR.AdOrderDetailsId = AD.AdOrderDetailsId
                WHERE
                    AD.AdOrderID = @AdOrderID
                    AND ADR.EditionID = @EditionID

        FETCH adordercur INTO @AdOrderID, @EditionID
    END

    CLOSE adordercur
    DEALLOCATE adordercur

END
GO
-----------------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[uspAdJobFolderCreateOnline]    Script Date: 04/19/2013 16:15:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAdJobFolderCreateOnline]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspAdJobFolderCreateOnline]
GO

/****** Object:  StoredProcedure [dbo].[uspAdJobFolderCreateOnline]    Script Date: 04/19/2013 16:15:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


		--*****************************************************************************************************
		--*   Stored Procedure  : [uspAdJobFolderCreateOnline]
		--*   Description        : Insert JobFolder
		--*   Author            : SIVA PRAKASH D
		--*   Creation Date        : 07/13/2011
		--*****************************************************************************************************
		--*   Modification        : To implement changes according to flags on AdDetails AdjobFlag  mis spelled as AdJodFlag
		--*   Author            : Kiran Sangoi
		--*   Modify Date        : 11/28/2011
		--*****************************************************************************************************
		--*   Modification        : To implement changes  issue 14136 and 13268
		--*   Author            : Kiran Sangoi
		--*   Modify Date        : Jan/30/2012
		--*****************************************************************************************************
		--*   Modification        : To avoid duplicate job folder creation for each AdOrdrrDetail
		--*   Author            : Kiran Sangoi
		--*   Modify Date        : Feb/24/2012
		--*****************************************************************************************************
		--*   Modification        : To include Partial Complete & do optimization for updating AdJobfolderID
		--*   Author            : Kiran Sangoi
		--*   Modify Date        : Feb/27/2012
		--*****************************************************************************************************


		--*****************************************************************************************************

		CREATE PROCEDURE  [dbo].[uspAdJobFolderCreateOnline]
		AS
		BEGIN

			DECLARE @AdOrderID int
			DECLARE @ActivationDate Datetime
			DECLARE @ADJobFolderID int
			DECLARE @AdOrderDetailsId int

			-- find ads with missing ad job folders
			DECLARE adordercur CURSOR FOR
				SELECT DISTINCT
					AO.AdOrderID,
					AD.ActivationDate,
					ADR.AdOrderDetailsId
				FROM
					AdOrder AO
					INNER JOIN AdOrderDetails AD
						ON AD.AdOrderID = AO.AdOrderID
					INNER JOIN AdOrderDetailsRegionEdition ADR
						ON ADR.AdOrderDetailsId = AD.AdOrderDetailsId
					INNER JOIN AdDetails ADT
						ON ADT.AdTypeID = AD.AdTypeID
				WHERE
					AO.StatusId in (3,4)     -- Final / Partial Complete
					AND ADR.ADJobFolderID IS NULL
					AND ADR.EditionID=0
					AND ADT.AdjodFlag = 1

			-- process orders not having ad job folders
			OPEN adordercur
			FETCH adordercur INTO @AdOrderID,@ActivationDate,@AdOrderDetailsId

			WHILE @@Fetch_Status = 0
			BEGIN
				-- find out if there is an ad job folder for same order
				-- if not, create a new ad job folder
				-- if yes, than use the same ad job folder for the new ads
				SELECT @ADJobFolderID = ISNULL(
							(SELECT
								MAX(ADR.ADJobFolderID)
							FROM
								AdOrderDetails AD
								INNER JOIN AdOrderDetailsRegionEdition ADR
									ON ADR.AdOrderDetailsId = AD.AdOrderDetailsId
							WHERE
								AD.AdOrderID = @AdOrderID AND
								AD.ActivationDate = @ActivationDate AND
								 ADR.ADJobFolderID IS NOT NULL), 0)

				IF @ADJobFolderID = 0
				BEGIN
					INSERT INTO AdJobFolderMaster(AdJobFolderTypeID,StatusId,CreatedDate) VALUES('O',1,GETDATE())
					SET @ADJobFolderID  = SCOPE_IDENTITY()
				END

				UPDATE ADR
					SET AdJobFolderId = @ADJobFolderID
					FROM
						AdOrderDetails AD
						INNER JOIN AdOrderDetailsRegionEdition ADR
							ON ADR.AdOrderDetailsId = AD.AdOrderDetailsId
					WHERE
						AD.AdOrderID = @AdOrderID AND
						AD.ActivationDate = @ActivationDate AND
						AD.AdOrderDetailsId = @AdOrderDetailsId AND
						ADR.ADJobFolderID IS NULL

				FETCH adordercur INTO @AdOrderID,@ActivationDate,@AdOrderDetailsId
			END
			CLOSE adordercur
			DEALLOCATE adordercur
		END


GO
-----------------------------------------------------------------------------------------------------------------
GO
/****** Object:  StoredProcedure [dbo].[GetSOLRData]    Script Date: 02/26/2013 15:39:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetSOLRData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetSOLRData]
GO

CREATE PROCEDURE [dbo].[GetSOLRData] 
AS

BEGIN
	SELECT
	DPS.ID as Id, 
	DPS.PartNumber+'~'+CONVERT(varchar(10), DPS.ManufacturerId) as PartMfrId, 
	--DPS.PartNumber +  ' ' + ISNULL(DPS.ManufacturerName,'') as SearchTerm,
	DPS.ProductID As ProductID,
	DPS.PartNumber,
	DPS.Search_PartNumber,
	DPS.Search_MFR_Name,
	DPS.ManufacturerName,
	DPS.ManufacturerId,
	DPS.DistributorName,
	DPS.DistributorId,
	ISNULL(DPS.PartDescription, '') AS ProductDescription,
	DPS.ManufacturerCode As DistManufacturerCode,
	ISNULL(CONVERT(FLOAT, DPS.Price),0) AS PartPrice,
	ISNULL(CONVERT(FLOAT, DPS.PartQuantity),0) AS PartQuantity,
	ISNULL(DPS.QOHDisp,'') AS QOHDisp,
	DPS.PartUploadDate,
	ISNULL(DPS.PartDataSheet, '') as PartDataSheet,
	ISNULL(DPS.DatasheetLink, '') as PartDataSheetLink,
	DPS.PartSample,
	ISNULL(DPS.VideoFilePathLink, '') as VideoFilePathLink,
	ISNULL(DPS.ImageFilePathLink, '') as ImageFilePathLink,
	DPS.ProductTypeId,
	DPS.ProductTypeDesc as ProductType,
	DPS.ROHS,
	DPS.RFQCPID,
	DPS.Buy_Button,
	DPS.HasMfrLogoAd,
	ISNULL(SUBSTRING( (SELECT '| ' + PR.ProductResourcesTitle from ProductResources PR (NOLOCK) where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1 and PR.ResourcesType = 'APP' for XML Path ('')),3, 2000),'') as PartAppNotes,
	ISNULL(SUBSTRING( (SELECT '| ' + PR.ProductResourcesLink from ProductResources PR (NOLOCK)  where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1 and PR.ResourcesType = 'APP' for XML Path ('')),3, 2000),'') as PartAppNotesLink,
	ISNULL(SUBSTRING( (SELECT '| ' + PR.ProductResourcesTitle from ProductResources PR (NOLOCK) where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1 and PR.ResourcesType = 'Soft' for XML Path ('')),3, 2000),'') as PartSoftTool,
	ISNULL(SUBSTRING( (SELECT '| ' + PR.ProductResourcesLink from ProductResources PR (NOLOCK)  where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1 and PR.ResourcesType = 'Soft' for XML Path ('')),3, 2000),'') as PartSoftToolLink,
	ISNULL(UF.FavType, 0) As SolrMyFav,
	ISNULL(UF.UserID, 0) as UserID,
	DistLogo = Case When DPS.DistLogo IS null Then '' Else DPS.DistLogo End,
	DPS.CompanyLogo As CompanyLogo,
	DPS.DistributorPartID,
	CONVERT(Varchar(20), DPS.ManufacturerId)+'~'+ISNULL(DPS.ManufacturerName, 'MfrNotFound') AS Facet_Manufacturer,
	CONVERT(Varchar(20), DPS.ProductTypeId)+'~'+ISNULL(DPS.ProductTypeDesc,'ProductTypeNotFound') as Facet_ProductType,
	CONVERT(Varchar(20), DPS.DistributorId)+'~'+DPS.DistributorName as Facet_Distributor,
	ISNULL(RZS.MaxAuth, 0) as MaxAuth,

	(
	  Select cast(RegionID as varchar(15))+','
	From [dbo].[RegionAuthorization] reg_auth (nolock)
	inner join [dbo].[RegionZoneStatus] reg_zone_status (nolock) 
	on reg_zone_status.MfrDistID =  reg_auth.MfrDistID
	where reg_auth.MfrID = DPS.ManufacturerId
	and reg_auth.DistID = DPS.DistributorId
	group by reg_zone_status.MfrDistID,reg_zone_status.RegionID
	  For XML Path('') ) as RegionAuth,

	(
	  Select cast(COM_OWN.OwnershipID as varchar(15))+','
	from CompanyOwnerShipMapping COM_OWN (NOLOCK) 
	Where COM_OWN.CompanyID = DPS.DistributorId
	  For XML Path('') ) as CompanyOwnershipID,
	  
	   (
	  Select cast(C.RegionID as varchar(15))+','
	From CompanyLocations CL (nolock)
	inner join Country C (nolock)
	on C.CountryID = CL.CountryID
	where CL.CompanyID = DPS.DistributorId and LocationStatusID = 1 and CL.IsActive = 1
	group by CompanyID,C.RegionID
	  For XML Path('') ) as CountryRegionID,
	(
		Select cast(Spend.RegionID as varchar(15))+','
		From [dbo].[RegionAuthorization] reg_auth (nolock)
		left join (
			Select MfrID,DistID,RegionID,sum(Print_Amount+Online_Amount) as Total
			From [dbo].[DistMfrSpend] (nolock)
			group By MfrID,DistID,RegionID
			) as Spend
		ON reg_auth.MfrID = Spend.MfrID AND reg_auth.DistID = Spend.DistID 
		where 
		reg_auth.MfrID = DPS.ManufacturerId
		and reg_auth.DistID = DPS.DistributorId
		For XML Path('') ) as RegionSpend,

	(
	  Select cast(COM_OWN.OwnershipID as varchar(15))+','
	from CompanyOwnerShipMapping COM_OWN (NOLOCK) 
	Where COM_OWN.CompanyID = DPS.DistributorId
	  For XML Path('') ) as CompanyOwn,
	DPS.IsManufacturerProduct,
	ISNULL(DPS.ManufacturerSpend, 0) AS ManufacturerSpend
	From vw_DistributorPartsSearch AS DPS (NOLOCK) 
	Left Join RegionAuthorization RA (NOLOCK) ON RA.IsActive = 1 and RA.Publish = 1 and DPS.DistributorId = RA.DistID and DPS.ManufacturerId = RA.MfrID
	Left Join (            Select
							RZOS.MFRDistID,
						   MAX(case when (AuthStatusID  = 2 and C.Trusted_Disty=1) then 4 else AuthStatusID end) as MaxAuth,
							sum(Print_Amount+Online_Amount) as Total
						From
							RegionZoneStatus (nolock) RZOS,
							Company (nolock) C,
							RegionAuthorization (nolock) RA
						WHERE  RA.MfrDistID = RZOS.MfrDistID
							AND RA.DistID=C.CompanyID
						group By RZOS.MfrDistID)        as RZS ON RA.MfrDistID = RZS.MfrDistID
	Left Join UserFavorites UF (NOLOCK) ON UF.FavType = 3 and DPS.ProductId = UF.TypeID 
END

GO

/****** Object:  StoredProcedure [dbo].[ReloadDistributorPartsClean]    Script Date: 01/18/2013 22:51:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReloadDistributorPartsClean]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[ReloadDistributorPartsClean]
GO

/****** Object:  StoredProcedure [dbo].[usp_AddUser]    Script Date: 09/24/2011 21:52:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_AddUser]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_AddUser]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_AddUser]          
(          
	@UserID   Int,        
	@LoginName  varchar(100),          
	@Password   varchar(50),          
	@FirstName  varchar(100),          
	@LastName   varchar(100),      
	@SpecifyFlag  bit =NULL,       
	@JobFunctionId    int=NULL,            
	@IndustryTypeID   int=NULL,        
	@Title   Varchar(100)=NULL,          
	@ApprovalLevelID  int=NULL,         
	@PrimarySource varchar(100)=NULL,       
	@Address   varchar(100)=NULL,       
	@City    varchar(50)=NULL,          
	@CountryID  int=NULL,          
	@Phone   varchar(15)=NULL,          
	@Fax    varchar(15)=NULL,          
	@StateID   int=NULL,          
	@Zip    varchar(50)=NULL,          
	@EmailAddress   varchar(100)=NULL,          
	@CompanyName  varchar(100)=NULL,          
	@CompanyWebsite   varchar(100)=NULL,      
	@PhoneExtension varchar(15)=NULL,        
	@JobFunctionIdSpecify    VARCHAR(200)=NULL,              
	@IndustryTypeIdSpecify    VARCHAR(200)=NULL,
	@UserRegID INT OUTPUT,      
	@Createdby INT      
)           
AS          
BEGIN          
      DECLARE @RoleID INT
            , @UserTypeID INT      
      
      SELECT    @RoleID = R.RoleID
      FROM      MstRole R
      WHERE     RoleName = 'Registered User'         
      SELECT    @UserTypeID = UserTypeID
      FROM      MstUserType
      WHERE     UserTypeName = 'External'      
       
      IF (@UserID < 0) 
         BEGIN      
               INSERT   INTO [User] (LoginName,
                                     LoginPassword,
                                     FirstName, LastName,
                                     Isactive,
                                     UserRecommendFlag,
                                     UserJobFunctionID,
                                     UserJobFunctionSpecify,
                                     UserIndustryTypeID,
                                     UserIndustryTypeIDSpecify,
                                     Title,
                                     UserApprovalLevelID,
                                     PrimarySource,
                                     CreatedOn)
               VALUES   (@LoginName, @password, @firstname,
                         @lastname, 0, @SpecifyFlag,
                         CASE WHEN @JobFunctionId = 0
                              THEN NULL
                              ELSE @JobFunctionId
                         END,
                         CASE WHEN LTRIM(RTRIM(@JobFunctionIdSpecify)) = ''
                              THEN NULL
                              ELSE @JobFunctionIdSpecify
                         END,
                         CASE WHEN @IndustryTypeID = 0
                              THEN NULL
                              ELSE @IndustryTypeID
                         END, 
                         CASE WHEN LTRIM(RTRIM(@IndustryTypeIdSpecify)) = ''
                              THEN NULL
                              ELSE @IndustryTypeIdSpecify
                         END,
                         @Title,
                         CASE WHEN @ApprovalLevelID = 0
                              THEN NULL
                              ELSE @ApprovalLevelID
                         END, @PrimarySource, GETDATE())          
               SELECT   @UserId = SCOPE_IDENTITY()          
         END      
      
      IF (@UserId > 0) 
         BEGIN      
               UPDATE   [User]
               SET      UserRegID = 100000000 + @UserId,
                        CreatedBy = CASE WHEN @Createdby > 0
                                         THEN @Createdby
                                         ELSE @UserId
                                    END
               WHERE    UserID = @UserId      
         END       
          
      IF (@UserId > 0) 
         BEGIN          
               INSERT   INTO UserContact (UserID,
                                          EmailAddress,
                                          CompanyName,
                                          CompanyWebsite,
                                          Address, City,
                                          StateID, Zip,
                                          CountryID, Phone,
                                          PhoneExtension,
                                          Fax, CreatedBy,
                                          CreatedOn)
               VALUES   (@UserId, @EmailAddress,
                         @CompanyName, @CompanyWebsite,
                         @Address, @City,
                         CASE WHEN @StateID = 0 THEN NULL
                              ELSE @StateID
                         END, @Zip,
                         CASE WHEN @CountryID = 0 THEN NULL
                              ELSE @CountryID
                         END, @Phone, @PhoneExtension, @Fax,
                         CASE WHEN @Createdby > 0
                              THEN @Createdby
                              ELSE @UserId
                         END, GETDATE())          
         END          
      IF (@UserId > 0) 
         BEGIN          
               INSERT   INTO UserRole (UserID, RoleID,
                                       UserTypeID, CreatedBy,
                                       CreatedOn)
               VALUES   (@UserId, @RoleID, @UserTypeID,
                         CASE WHEN @Createdby > 0
                              THEN @Createdby
                              ELSE @UserId
                         END, GETDATE())          
         END      
      SET @UserRegID = 100000000 + @UserId      
END

GO

/****** Object:  StoredProcedure [dbo].[usp_EditUser]    Script Date: 09/24/2011 21:59:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_EditUser]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_EditUser]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_EditUser]            
(            
	@UserID   Int,          
	@LoginName  varchar(100),            
	@Password   varchar(50),            
	@FirstName  varchar(100),            
	@LastName   varchar(100),        
	@SpecifyFlag  bit =NULL,         
	@JobFunctionId    int=NULL,              
	@IndustryTypeID   int=NULL,          
	@Title   Varchar(100)=NULL,            
	@ApprovalLevelID  int=NULL,           
	@PrimarySource varchar(100)=NULL,         
	@Address   varchar(100)=NULL,         
	@City    varchar(50)=NULL,            
	@CountryID  int=NULL,            
	@Phone   varchar(15)=NULL,            
	@Fax    varchar(15)=NULL,            
	@StateID   int=NULL,            
	@Zip    varchar(50)=NULL,            
	@EmailAddress   varchar(100)=NULL,            
	@CompanyName  varchar(100)=NULL,            
	@CompanyWebsite   varchar(100)=NULL,      
	@PhoneExtension varchar(7)=NULL,        
	@JobFunctionIdSpecify    VARCHAR(200)=NULL,              
	@IndustryTypeIdSpecify    VARCHAR(200)=NULL,
	@UpdatedBy INT      
)             
AS            
BEGIN            
          
      IF (@UserID > 0) 
         BEGIN        
               UPDATE   [User]
               SET      LoginName = @LoginName,
                        LoginPassword = @password,
                        FirstName = @firstname,
                        LastName = @lastname,
                        UserRecommendFlag = @SpecifyFlag,
                        UserJobFunctionID = CASE
                                            WHEN @JobFunctionId = 0
                                            THEN NULL
                                            ELSE @JobFunctionId
                                            END,
                        UserJobFunctionSpecify = CASE
                                            WHEN LTRIM(RTRIM(@JobFunctionIdSpecify)) = ''
                                            THEN NULL
                                            ELSE @JobFunctionIdSpecify
                                            END,
                        UserIndustryTypeID = CASE
                                            WHEN @IndustryTypeID = 0
                                            THEN NULL
                                            ELSE @IndustryTypeID
                                            END,
                        UserIndustryTypeIDSpecify = CASE
                                            WHEN LTRIM(RTRIM(@IndustryTypeIdSpecify)) = ''
                                            THEN NULL
                                            ELSE @IndustryTypeIdSpecify
                                            END,
                        Title = @Title,
                        UserApprovalLevelID = CASE
                                            WHEN @ApprovalLevelID = 0
                                            THEN NULL
                                            ELSE @ApprovalLevelID
                                            END,
                        PrimarySource = @PrimarySource,
                        UpdatedBy = @UpdatedBy,
                        UpdatedOn = GETDATE()
               WHERE    UserID = @UserID        
         END    
      IF EXISTS ( SELECT    1
                  FROM      UserContact
                  WHERE     UserID = @UserID ) 
         BEGIN        
               UPDATE   UserContact
               SET      EmailAddress = @EmailAddress,
                        CompanyName = @CompanyName,
                        CompanyWebsite = @CompanyWebsite,
                        Address = @Address, City = @City,
                        StateID = CASE WHEN @StateID = 0
                                       THEN NULL
                                       ELSE @StateID
                                  END, Zip = @Zip,
                        CountryID = CASE WHEN @CountryID = 0
                                         THEN NULL
                                         ELSE @CountryID
                                    END, Phone = @Phone,
                        PhoneExtension = @PhoneExtension,
                        Fax = @Fax, UpdatedBy = @UpdatedBy,
                        UpdatedOn = GETDATE()
               WHERE    UserID = @UserID          
         END      
      ELSE 
         BEGIN        
               INSERT   INTO UserContact (UserID,
                                          EmailAddress,
                                          CompanyName,
                                          CompanyWebsite,
                                          Address, City,
                                          StateID, Zip,
                                          CountryID, Phone,
                                          PhoneExtension,
                                          Fax, CreatedBy,
                                          CreatedOn)
               VALUES   (@UserId, @EmailAddress,
                         @CompanyName, @CompanyWebsite,
                         @Address, @City,
                         CASE WHEN @StateID = 0 THEN NULL
                              ELSE @StateID
                         END, @Zip,
                         CASE WHEN @CountryID = 0 THEN NULL
                              ELSE @CountryID
                         END, @Phone, @PhoneExtension, @Fax,
                         @UpdatedBy, GETDATE())    
         END    
END

GO

/****** Object:  StoredProcedure [dbo].[usp_EndInventoryUploadHistory]    Script Date: 11/21/2012 14:37:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_EndInventoryUploadHistory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_EndInventoryUploadHistory]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_EndInventoryUploadHistory]
	@InventoryUploadHistoryId int,
	@MappingId int,
	@FileType varchar(50)
AS

--DECLARE	@InventoryUploadHistoryId INT = 18181, @MappingId INT = 18180, @FileType varchar(50) = '.csv'

BEGIN
	DECLARE @Errors VARCHAR(MAX) = '';

	UPDATE [InventoryUploadHistory]
		   SET 
			MappingId = @MappingId,
			FileType = @FileType
	WHERE InventoryUploadHistoryId = @InventoryUploadHistoryId;
    
	DECLARE @file_line_cnt INT = 0
	SELECT @file_line_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'FileLineCount';

	UPDATE h
	SET FileLineCount = @file_line_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
    
	DECLARE @upload_cnt INT = 0
	SELECT @upload_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'BulkInsertCount';

	UPDATE h
	SET FileInventoryCount = @upload_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @invalid_part_num_cnt INT = 0
	SELECT @invalid_part_num_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'InvalidPartNumberFieldCount';

	UPDATE h
	SET InvalidPartNumberFieldCount = @invalid_part_num_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId

	DECLARE @invalid_cnt INT = 0
	SELECT @invalid_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'InvalidQtyFieldCount';

	UPDATE h
	SET InvalidQtyFieldCount = @invalid_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId

	DECLARE @zero_qty_cnt INT = 0
	SELECT @zero_qty_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'ZeroQtyFieldCount';

	UPDATE h
	SET ZeroQtyFieldCount = @zero_qty_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId

	DECLARE @invalid_price_break_cnt INT = 0
	SELECT @invalid_price_break_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'InvalidPriceBreakFieldCount';

	UPDATE h
	SET InvalidPriceBreakFieldCount = @invalid_price_break_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @over_limit_cnt INT = 0
	SELECT @over_limit_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'OverLimitCount';

	UPDATE h
	SET OverLimitCount = @over_limit_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @duplicate_cnt INT = 0
	SELECT @duplicate_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'DuplicateRecordCount';

	UPDATE h
	SET DuplicateCount = @duplicate_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @updated_cnt INT = 0
	SELECT @updated_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'UpdatedCount';

	UPDATE h
	SET UpdatedCount = @updated_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @inserted_cnt INT = 0
	SELECT @inserted_cnt = SUM(CAST(tl.[Message] AS INT))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		tl.[Name] = 'InsertedCount';

	UPDATE h
	SET InsertedCount = @inserted_cnt
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId
		
	DECLARE @start DATETIME
	SELECT @start = MAX(CAST(tl.Message AS DATETIME))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId 
		AND tl.[Name] = 'Inventory Load Started';

	DECLARE @end DATETIME
	SELECT @end = MAX(CAST(tl.Message AS DATETIME))
	FROM
		InventoryUploadHistory h inner join
		InventoryUploadHistoryTraceLog tl on h.InventoryUploadHistoryId = tl.InventoryUploadHistoryId
	WHERE
		h.InventoryUploadHistoryId = @InventoryUploadHistoryId 
		AND tl.[Name] = 'Inventory Load Completed';

	UPDATE h
	SET ProcessTime = CONVERT(varchar,(@end - @start), 108)
	FROM InventoryUploadHistory h
	WHERE h.InventoryUploadHistoryId = @InventoryUploadHistoryId

	SELECT 
		@Errors = COALESCE(@Errors + ', ', '') + [Message] 
	FROM
		InventoryUploadHistoryTraceLog
	WHERE	
		InventoryUploadHistoryId = @InventoryUploadHistoryId AND
		IsError = 1
		
	IF LEN(@Errors) > 0
		BEGIN
			UPDATE [InventoryUploadHistory]
			SET 
				ErrorMessage = SUBSTRING(@Errors, 1, 8000),
				HasError = 1
			WHERE 
				InventoryUploadHistoryId = @InventoryUploadHistoryId;
		END
    
    
END

GO

/****** Object:  StoredProcedure [dbo].[usp_GetAllPartSearchDistOrder]    Script Date: 03/01/2013 12:35:03 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAllPartSearchDistOrder]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAllPartSearchDistOrder]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[usp_GetAllPartSearchDistOrder]
    @REGIONID varchar(100) = '',
    @IsFilterByRegion VARCHAR(10) = '0',
    @Preferences VARCHAR(MAX) = '', -- Comma seperated list of [MstCompanyOwnership] Ids
    @Distributors VARCHAR(MAX) = '', -- Comma Seperated list of Distributor CompanyIds
    @PriceMin DECIMAL = -1,
    @PriceMax DECIMAL = -1,
    @Quantity INT = 0,
    @Authorized BIT = 0, -- If zero, ignore, if 1 then restrict to authorized distributors only    
    @MFRID1 varchar(100) = '',
    @PARTID1 varchar(100) = '',
    @MFRID2 varchar(100) = '',
    @PARTID2 varchar(100) = '',
    @MFRID3 varchar(100) = '',
    @PARTID3 varchar(100) = '',
    @MFRID4 varchar(100) = '',
    @PARTID4 varchar(100) = '',
    @MFRID5 varchar(100) = '',
    @PARTID5 varchar(100) = '',
    @MFRID6 varchar(100) = '',
    @PARTID6 varchar(100) = '',
    @MFRID7 varchar(100) = '',
    @PARTID7 varchar(100) = '',
    @MFRID8 varchar(100) = '',
    @PARTID8 varchar(100) = '',
    @MFRID9 varchar(100) = '',
    @PARTID9 varchar(100) = '',
    @MFRID10 varchar(100) = '',
    @PARTID10 varchar(100) = ''
AS
BEGIN

--DECLARE    @REGIONID varchar(100) = '1',
--    @IsFilterByRegion VARCHAR(10) = '0',
--    @Preferences VARCHAR(MAX) = '', -- Comma seperated list of [MstCompanyOwnership] Ids
--    @Distributors VARCHAR(MAX) = '', -- Comma Seperated list of Distributor CompanyIds
--    @PriceMin DECIMAL = -1,
--    @PriceMax DECIMAL = -1,
--    @Quantity INT = -1,
--    @Authorized BIT = 0, -- If zero, ignore, if 1 then restrict to authorized distributors only    
--    @MFRID1 varchar(100) = '0',
--    @PARTID1 varchar(100) = 'WIRE-J D=1.2MM (R)',
--    @MFRID2 varchar(100) = '',
--    @PARTID2 varchar(100) = '',
--    @MFRID3 varchar(100) = '',
--    @PARTID3 varchar(100) = '',
--    @MFRID4 varchar(100) = '',
--    @PARTID4 varchar(100) = '',
--    @MFRID5 varchar(100) = '',
--    @PARTID5 varchar(100) = '',
--    @MFRID6 varchar(100) = '',
--    @PARTID6 varchar(100) = '',
--    @MFRID7 varchar(100) = '',
--    @PARTID7 varchar(100) = '',
--    @MFRID8 varchar(100) = '',
--    @PARTID8 varchar(100) = '',
--    @MFRID9 varchar(100) = '',
--    @PARTID9 varchar(100) = '',
--    @MFRID10 varchar(100) = '',
--    @PARTID10 varchar(100) = ''

    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;
    set transaction isolation level read uncommitted
    
    DECLARE @tblMfrPart TABLE 
    (MrfId INT, 
    PartNumber VARCHAR(250), --part numbers are the full part number with no cleaning
    SortOrder INT)

    IF (ISNULL(@MFRID1, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID1,dbo.RemoveSpecialCharacter(@PARTID1),1);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID1,@PARTID1,@DISTIDS1,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID2, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID2,dbo.RemoveSpecialCharacter(@PARTID2),2);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID2,@PARTID2,@DISTIDS2,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID3, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID3,dbo.RemoveSpecialCharacter(@PARTID3),3);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID3,@PARTID3,@DISTIDS3,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID4, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID4,dbo.RemoveSpecialCharacter(@PARTID4),4);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID4,@PARTID4,@DISTIDS4,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID5, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID5,dbo.RemoveSpecialCharacter(@PARTID5),5);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID5,@PARTID5,@DISTIDS5,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID6, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID6,dbo.RemoveSpecialCharacter(@PARTID6),6);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID6,@PARTID6,@DISTIDS6,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID7, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID7,dbo.RemoveSpecialCharacter(@PARTID7),7);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID7,@PARTID7,@DISTIDS7,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID8, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID8,dbo.RemoveSpecialCharacter(@PARTID8),8);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID8,@PARTID8,@DISTIDS8,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID9, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID9,dbo.RemoveSpecialCharacter(@PARTID9),9);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID9,@PARTID9,@DISTIDS9,@IsFilterByRegion
    END
    IF (ISNULL(@MFRID10, '') <> '')
    BEGIN
		INSERT INTO @tblMfrPart (MrfId, PartNumber, SortOrder) VALUES (@MFRID10,dbo.RemoveSpecialCharacter(@PARTID10),10);
        --execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID10,@PARTID10,@DISTIDS10,@IsFilterByRegion
    END
    
    DECLARE @RegionQuery VARCHAR(3000)=''
    
    IF(ISNULL(@REGIONID, '') = '') BEGIN SET @REGIONID = '1' END
	
	DECLARE @tblRegionIds TABLE 
	(
		RegionID INT
	)
	INSERT INTO @tblRegionIds
	SELECT array_data 
	FROM dbo.ReturnArray(@REGIONID, ',', NULL)
        
	IF OBJECT_ID(N'tempdb..#temp', N'U') IS NOT NULL   
		DROP TABLE #temp  

    CREATE TABLE #temp 
    (
		MfrId INT, 
		ManufacturerCode VARCHAR(50),
		PartNumber varchar(200),
		SearchPartNumber VARCHAR(200),
		DistributorId INT,
		DistributorName varchar(200), 
		DistLogo varchar(100),
		PartUploadDate DATETIME,
		PartQuantity INT,
		QOHDisp VARCHAR(10),
		Price DECIMAL(18,2),
		DoNotPub BIT,
		RFQCPID INT,
		Buy_Button INT,
		DistributorPartID INT,
        ROHS INT,
        IsManufacturerProduct BIT,
        CountryRegionID VARCHAR(1000),
		MaxAuth int, 
		Total money,
		CompanyAttributes VARCHAR(500),
		SortOrder INT
	)

    --GET EVERYTHING - We will apply the filters in steps below to make it cleaner and in most cases faster
    INSERT INTO #temp
    SELECT
        mp.MrfId as MfrId,
        dp.ManufacturerCode,
        dp.PartNumber as PartNum,
        dp.Search_PartNumber AS SearchPartNumber,
        dp.DistributorId AS DistributorId,
        dp.DistributorName,
        ISNULL(dp.DistLogo, '') AS DistLogo,
        dp.PartUploadDate,
        CAST(CONVERT(DECIMAL(24, 12), CONVERT(FLOAT, ISNULL(PartQuantity, 0))) AS INT) AS PartQuantity, -- This conversion is needed to handle quantities that imported in scientific notation
        dp.QOHDisp,
        ISNULL(Price, 0) AS Price,
        dp.DoNotPub,
        dp.RFQCPID,
        dp.Buy_Button,
        dp.DistributorPartID,
        dp.ROHS,
        dp.IsManufacturerProduct,
        NULL,  -- will update this with a different statment below
        ISNULL(RZS.MaxAuth, 0) AS MaxAuth,
        ISNULL(Spend.Total, 0) AS Total,
        ISNULL(dbo.Get_SearchCompanyOwn(dp.DistributorId), '') as CompanyAttributes,
        mp.SortOrder
    FROM @tblMfrPart AS mp 
	INNER JOIN vw_DistributorPartsSearch AS dp WITH(NOLOCK)
		ON dp.Search_PartNumber = mp.PartNumber 
		AND dp.ManufacturerId = mp.MrfId 
	LEFT OUTER JOIN RegionAuthorization AS RA WITH(NOLOCK) 
		ON dp.DistributorId = RA.DistID 
		AND RA.MfrId = mp.MrfId 
	LEFT OUTER JOIN
	(
		SELECT RZOS.MFRDistID, 
			MAX(
				CASE WHEN (AuthStatusID  = 2 AND C.Trusted_Disty = 1) 
					THEN 4 
				ELSE AuthStatusID 
				END
			) AS MaxAuth
        FROM  RegionZoneStatus AS RZOS WITH(NOLOCK) 
        INNER JOIN RegionAuthorization AS  RA WITH(NOLOCK) 
			ON RZOS.MfrDistID = RA.MfrDistID 
		INNER JOIN Company AS C WITH(NOLOCK) 
			ON RA.DistID = C.CompanyID
		 -- limit it to just the manufacturers specified to increase performance
		INNER JOIN @tblMfrPart AS t
			ON RA.MfrID = t.MrfId
		INNER JOIN @tblRegionIds AS r
			ON RZOS.RegionID = r.RegionID
        GROUP BY RZOS.MfrDistID
    ) AS RZS 
		ON RA.MfrDistID = RZS.MfrDistID 
	LEFT OUTER JOIN
	(
		SELECT MfrID, DistID, SUM(Print_Amount+Online_Amount) as Total
		FROM DistPartsSpend AS dps WITH(NOLOCK) 
		 -- limit it to just the manufacturers specified to increase performance
		INNER JOIN @tblMfrPart AS t
			ON dps.MfrID = t.MrfId
		INNER JOIN @tblRegionIds AS r
			ON dps.RegionID = r.RegionID
		GROUP BY MfrID,DistID
	  ) AS Spend 
          ON RA.MfrID = Spend.MfrID 
          AND RA.DistID = Spend.DistID
    ORDER BY  mp.SortOrder, CASE WHEN MaxAuth = 4 THEN 1 ELSE 0 END DESC, Total DESC, DistributorName
        
    
    -- PREFRENCES FILTER
    IF (LEN(@Preferences) > 0)
		BEGIN
			DECLARE @tblPreferences TABLE 
			(
				OwnershipID INT
			)
			INSERT INTO @tblPreferences
			SELECT array_data 
			FROM dbo.ReturnArray(@Preferences, ',', NULL)

			-- Get all the distributors with the preferences (attribute ids) selected
			DECLARE @tblDistWithPreferences TABLE 
			(
				CompanyID INT
			)
			INSERT INTO @tblDistWithPreferences
			SELECT DISTINCT DistributorId  
			FROM #temp AS t 
			INNER JOIN CompanyOwnerShipMapping AS cosm (NOLOCK) 
				ON cosm.CompanyID = t.DistributorId 
			INNER JOIN @tblPreferences AS p
				ON cosm.OwnershipID = p.OwnershipID
			
			-- Remove all records from the temp table where distributorid does not exist in distributor list got above.
			DELETE t
			FROM #temp AS t 
			LEFT OUTER JOIN @tblDistWithPreferences p
				ON t.DistributorId = p.CompanyID
			WHERE p.CompanyID IS NULL
		END
		
		
    -- DISTRIBUTOR FILTER
    IF (LEN(@Distributors) > 0)
		BEGIN
			DECLARE @tblDistributors TABLE (DistributorId INT)
			INSERT INTO @tblDistributors
			SELECT array_data 
			FROM dbo.ReturnArray(@Distributors, ',', NULL)
			
			DELETE t
			FROM #temp AS t
			LEFT OUTER JOIN @tblDistributors d
				ON t.DistributorId = d.DistributorId
			WHERE d.DistributorId IS NULL
		END
	
	--NOTE: Any changes to the statements that populate the following three temp tables
	--		may also need to be made to the stored procedure GetSOLRData
				
	DECLARE @tblCountryRegionID TABLE 
	(
		RegionId INT,
		MfrId INT,
		DistributorId INT
	)
	
	DECLARE @tblRegionAuth TABLE 
	(
		RegionId INT,
		MfrId INT,
		DistributorId INT
	)
	
	DECLARE @tblRegionSpend TABLE 
	(
		RegionId INT,
		MfrId INT,
		DistributorId INT
	)	
	
	-- CountryRegionID
	INSERT INTO @tblCountryRegionID
	SELECT DISTINCT C.RegionID, t.MfrId, t.DistributorId
	FROM #temp t 
	INNER JOIN CompanyLocations AS CL (NOLOCK) 
		ON t.DistributorId = CL.CompanyID 
		AND CL.IsActive = 1
	INNER JOIN Country AS C (NOLOCK) 
		ON C.CountryID = CL.CountryID
	INNER JOIN @tblRegionIds AS r
		ON C.RegionID = r.RegionID
	WHERE LocationStatusID = 1 
	
	UPDATE t 
		SET t.CountryRegionID = 
		(
			SELECT CAST(cr.RegionId AS VARCHAR(15))+','
			FROM @tblCountryRegionID AS cr
			WHERE t.DistributorId = cr.DistributorId 
				AND t.MfrId = cr.MfrId
			For XML Path('') 
		)
	FROM #temp t
	  
	IF (LEN(@REGIONID) > 0 AND @IsFilterByRegion = '1')
		BEGIN
			--region table defined and filled near top of procedure -- @tblRegionIds (RegionId)	

			--  RegionAuth
			INSERT INTO @tblRegionAuth
			SELECT DISTINCT reg_zone_status.RegionID, t.MfrId, t.DistributorId
			FROM #temp AS t 
			INNER JOIN [dbo].[RegionAuthorization] AS reg_auth (NOLOCK) 
				ON t.MfrId = reg_auth.MfrID 
				AND reg_auth.DistID = t.DistributorId 
			INNER JOIN [dbo].[RegionZoneStatus] AS reg_zone_status (NOLOCK) 
				ON reg_zone_status.MfrDistID =  reg_auth.MfrDistID
			INNER JOIN @tblRegionIds AS r
				ON reg_zone_status.RegionID = r.RegionID


			-- RegionSpend
			INSERT INTO @tblRegionSpend
			SELECT DISTINCT Spend.RegionID, t.MfrId, t.DistributorId
			FROM #temp AS t 
			INNER JOIN [dbo].[RegionAuthorization] AS reg_auth (NOLOCK) 
				ON t.MfrId = reg_auth.MfrID
				AND reg_auth.DistID = t.DistributorId 
			INNER JOIN 
			(
				SELECT MfrID,DistID,RegionID,SUM(Print_Amount+Online_Amount) as Total
				FROM [dbo].[DistMfrSpend] AS dms (nolock)
				-- limit it to just the manufacturers specified to increase performance
				INNER JOIN @tblMfrPart AS t
					ON dms.MfrID = t.MrfId
				GROUP BY dms.MfrID,dms.DistID,dms.RegionID
			) AS Spend 
				ON reg_auth.MfrID = Spend.MfrID 
				AND reg_auth.DistID = Spend.DistID 
			INNER JOIN @tblRegionIds AS r
				ON Spend.RegionID = r.RegionID

			DELETE t 
			FROM #temp AS t 
			LEFT OUTER JOIN
				(
					SELECT RegionId, MfrId, DistributorId FROM @tblCountryRegionID
						UNION
					SELECT RegionId, MfrId, DistributorId FROM @tblRegionAuth
						UNION
					SELECT RegionId, MfrId, DistributorId FROM @tblRegionSpend
				) AS m
					ON t.MfrId = m.MfrId 
					AND t.DistributorId = m.DistributorId
			WHERE m.RegionId IS NULL
		END

	IF (@PriceMin > 0)
		BEGIN
			DELETE FROM #temp WHERE Price <= @PriceMin;
		END
		
	IF (@PriceMax > 0)
		BEGIN
			DELETE FROM #temp WHERE Price >= @PriceMax;
		END
		
	IF (@Quantity > 0)
		BEGIN
			DELETE FROM #temp WHERE PartQuantity < @Quantity;
		END
		
	IF (@Authorized = 1)
		BEGIN
			DELETE FROM #temp WHERE MaxAuth <> 4;
		END
		
			
    SELECT *
	FROM #temp
END

GO

/****** Object:  StoredProcedure [dbo].[usp_GetAllUsers]    Script Date: 06/29/2012 17:09:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAllUsers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAllUsers]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetAllUsers] --0,50,'UR.UserID','1111','1',0,'True'                
(                    
   @startIndex  int,                    
   @pageSize  int,                    
   @searchBy  varchar(30),                    
   @searchText  VarChar(max),                    
   @userID   VarChar(30),                    
   @totalUsers  int OUTPUT,              
   @startsWith  VarChar(20)          
)                    
AS                    
--DECLARE @startIndex INT = 0
--      , @pageSize INT = 100
--      , @searchBy VARCHAR(30) = 'UserRegID'
--      , @searchText VARCHAR(MAX) = '100089226'
--      , @userID VARCHAR(30) = 89226
--      , @totalUsers INT = 0
--      , @startsWith VARCHAR(20) = 'True'
BEGIN
	SET NOCOUNT ON
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	                 
	DECLARE @strBuildSQL VARCHAR(MAX)
		  , @upperBound INT
		  , @strCriteria VARCHAR(MAX)
		  , @StrOrderBy VARCHAR(50)            
	                 
	IF @startIndex < 1 
	   SET @startIndex = 1                    
	ELSE 
	   SET @startIndex = @startIndex + 1                            

	SET @searchText = RTRIM(LTRIM(@searchText))    
	        
	IF (@startswith = 'True') 
	   SET @searchText = @searchText + '%'               
	ELSE 
	   SET @searchText = '%' + @searchText + '%'               
	               
	IF @pageSize < 1 
	   SET @pageSize = 1                 
	SET @upperBound = @startIndex + @pageSize                    
	 
	DECLARE @tempSearchText VARCHAR(MAX)
	                
	IF (@searchBy = 'FirstName') 
	BEGIN                       
		SELECT ur.UserID, ur.LoginName AS UserName, ur.LastName, ur.FirstName, ur.UserRegID                       
		FROM (
			SELECT ROW_NUMBER() OVER(ORDER BY u.LastName, u.FirstName) AS rowNumber, u.*                      
			FROM dbo.[User] AS u
			WHERE u.FirstName LIKE @searchText
				AND u.LoginName <> 'SUPERADMIN'
		) AS ur
		WHERE ur.rowNumber >= @startIndex
			AND ur.rowNumber <  @upperBound
		ORDER BY ur.LastName, ur.FirstName

		SELECT @totalUsers = COUNT(*)
		FROM dbo.[User] AS u
		WHERE u.FirstName LIKE @searchText
			AND u.LoginName <> 'SUPERADMIN'
	END                    
	ELSE 
	BEGIN
		IF (@searchBy = 'LastName') 
		BEGIN                               
			SELECT ur.UserID, ur.LoginName AS UserName, ur.LastName, ur.FirstName, ur.UserRegID                       
			FROM (
				SELECT ROW_NUMBER() OVER(ORDER BY u.LastName, u.FirstName) AS rowNumber, u.*                      
				FROM dbo.[User] AS u
				WHERE u.LastName LIKE @searchText
					AND u.LoginName <> 'SUPERADMIN'
			) AS ur
			WHERE ur.rowNumber >= @startIndex
				AND ur.rowNumber <  @upperBound
			ORDER BY ur.LastName, ur.FirstName

			SELECT @totalUsers = COUNT(*)
			FROM dbo.[User] AS u
			WHERE u.LastName LIKE @searchText
				AND u.LoginName <> 'SUPERADMIN'
		END                    
		ELSE 
		BEGIN
			IF (@searchBy = 'UserRegID') 
			BEGIN     
				SELECT ur.UserID,ur.LoginName AS UserName, ur.LastName, ur.FirstName, ur.UserRegID                       
				FROM (
					SELECT ROW_NUMBER() OVER(ORDER BY u.LastName, u.FirstName) AS rowNumber, u.*                      
					FROM dbo.[User] AS u
					WHERE u.UserRegID LIKE @searchText
						AND u.LoginName <> 'SUPERADMIN'
				) AS ur
				WHERE ur.rowNumber >= @startIndex
					AND ur.rowNumber <  @upperBound
				ORDER BY ur.LastName, ur.FirstName

				SELECT @totalUsers = COUNT(*)
				FROM dbo.[User] AS u
				LEFT JOIN dbo.UserContact AS uc
					ON u.UserID = uc.UserID
					AND u.LoginName <> 'SUPERADMIN'
				WHERE u.UserRegID LIKE @searchText
			END                    
			ELSE 
			BEGIN
				IF (@searchBy = 'CompanyName') 
				BEGIN     
					SELECT ur.UserID,ur.LoginName AS UserName, ur.LastName, ur.FirstName, ur.UserRegID                       
					FROM (
						SELECT ROW_NUMBER() OVER(ORDER BY u.LastName, u.FirstName) AS rowNumber, u.*                      
						FROM dbo.[User] AS u
						LEFT OUTER JOIN dbo.UserContact AS uc
							ON u.UserID = uc.UserID
						WHERE uc.CompanyName LIKE @searchText
							AND u.LoginName <> 'SUPERADMIN'
					) AS ur
					WHERE ur.rowNumber >= @startIndex
						AND ur.rowNumber <  @upperBound
					ORDER BY ur.LastName, ur.FirstName

					SELECT @totalUsers = COUNT(*)
					FROM dbo.[User] AS u
					LEFT OUTER JOIN dbo.UserContact AS uc
						ON u.UserID = uc.UserID
					WHERE uc.CompanyName LIKE @searchText
						AND u.LoginName <> 'SUPERADMIN'
				END                    
				ELSE
				BEGIN
					IF (@searchBy = 'EmailAddress') 
					BEGIN
						SELECT ur.UserID,ur.LoginName AS UserName, ur.LastName, ur.FirstName, ur.UserRegID                       
						FROM (
							SELECT ROW_NUMBER() OVER(ORDER BY u.LastName, u.FirstName) AS rowNumber, u.*                      
							FROM dbo.[User] AS u
							LEFT OUTER JOIN dbo.UserContact AS uc
								ON u.UserID = uc.UserID
							WHERE uc.EmailAddress LIKE @searchText
								AND u.LoginName <> 'SUPERADMIN'
						) AS ur
						WHERE ur.rowNumber >= @startIndex
							AND ur.rowNumber <  @upperBound
						ORDER BY ur.LastName, ur.FirstName

						SELECT @totalUsers = COUNT(*)
						FROM dbo.[User] AS u
						LEFT OUTER JOIN dbo.UserContact AS uc
							ON u.UserID = uc.UserID
						WHERE uc.EmailAddress LIKE @searchText
							AND u.LoginName <> 'SUPERADMIN'
					END
					ELSE
					BEGIN
						IF (LEN(@searchText) = 0) 
						BEGIN                      
							SET   @totalUsers = 0                
						
							SELECT UserID, LastName, FirstName, '' AS Country
							FROM   [User]
							WHERE  UserID = 0                
						END
					END                        
				END
			END
		END
	END     

--SELECT @totalUsers
END

GO

-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------


/****** Object:  StoredProcedure [dbo].[usp_GetCompanyAdOrderInfo]    Script Date: 08/21/2012 14:33:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetCompanyAdOrderInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetCompanyAdOrderInfo]
GO


/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Get all ACTIVE ad order informaion for the given company ID
(The alert should NOT be sent if the order status is Complete - Gemini 26110)


Used by: 
Ad change alert

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
08.21.2013		Fred Cunningham		Created. 
04.05.2013		Marcus Ruether		The alert should NOT be sent if the order status is Complete - Gemini 26110
------------------------------------------------------------------------------------------------------------------------------------------*/
Create PROCEDURE [dbo].[usp_GetCompanyAdOrderInfo]
(
	@CompanyID int
)
AS	

BEGIN
  
  SELECT AO.SalesPersonId, 
         SP.FirstName + ' ' + SP.LastName AS 'SalesPerson', 
         UC.EmailAddress, 
         ADV.CompanyID AS 'AdvertisingCompanyID', 
         ADV.CompanyName AS 'AdvertisingCompanyName', 
         AOD.OrderType, 
         AO.AdOrderNumber, 
         E.HeadingTitle, 
         MFR.CompanyId AS 'ManufatureCompanyID', 
         MFR.CompanyName AS 'ManufatureCompanyName',
         S.Description as OrderStatus
    FROM AdOrder AO
         INNER JOIN [User] SP ON AO.SalesPersonId = SP.UserID
         INNER JOIN UserContact UC ON SP.UserID = UC.UserID
         INNER JOIN AdOrderDetails AOD ON AO.AdOrderId = AOD.AdOrderId
         INNER JOIN AdOrderDetailsRegionEdition AODRE ON AOD.AdOrderDetailsId = AODRE.AdOrderDetailsId
         INNER JOIN Editions E ON AODRE.EditionID = E.EditionID
         INNER JOIN Company MFR ON AOD.PositionTitle = MFR.CompanyID
         INNER JOIN Company ADV ON AO.CompanyId = ADV.CompanyID
         INNER JOIN MstOrderStatus S ON S.StatusID = AO.StatusId
   WHERE AO.CompanyId = @CompanyID
   AND S.Description NOT LIKE 'complete'
ORDER BY AO.SalesPersonId

END
GO




-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetDistrPartSearch]    Script Date: 01/22/2013 09:42:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetDistrPartSearch]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetDistrPartSearch]
GO

CREATE PROCEDURE [dbo].[usp_GetDistrPartSearch]                      
(
	@distID int,          
	@PartNumber varchar(50)                    
)
AS    

--DECLARE @PartNumber varchar(50) = '1287', @distID int = 121230           

BEGIN    
    
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	IF (LEN(@distID) <= 5)  
	BEGIN  
		SELECT @distID = Company_ID FROM dbo.Company_IMAPMDV_XRF WHERE Distributor_ID = @distID   
	END      
	
	SET @PartNumber = dbo.RemoveSpecialChars(@partNumber)
      
	SELECT       
		InvS.RFQCPEmail AS Email,      
		d.CompanyName,      
		dp.DistributorId AS DistID,      
		dp.PartNumber,      
		dp.PartDataSheet AS Description,      
		dp.PartQuantity AS QtyOnHand,
		dp.ManufacturerName AS ManufacturerCode     
		--ISNULL(m.CompanyName, 'Manufacturer Not Identified') AS ManufacturerCode      
	FROM dbo.vw_DistributorPartsSearch AS dp      
	INNER JOIN Company d      
		ON dp.DistributorId = d.CompanyID
	INNER JOIN dbo.InventorySettings AS InvS
		ON d.CompanyID = InvS.CompanyID      
	INNER JOIN dbo.Company AS m
		ON dp.ManufacturerId = m.CompanyID
	WHERE dp.DistributorId = @distID 
		AND dp.Search_PartNumber LIKE + @PartNumber + '%'      
		AND d.CompanyStatusID = 1  
	ORDER BY dp.Search_PartNumber
     
END

GO

/****** Object:  StoredProcedure [dbo].[usp_GetDistSelection]    Script Date: 01/18/2013 16:48:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetDistSelection]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetDistSelection]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*      

exec usp_GetDistSelection '<DocumentElement>\r\n  <Table1>\r\n <ManufacturerId>100403</ManufacturerId>\r\n    <PartNumber>2-34567-1</PartNumber>\r\n    <MyQty>30</MyQty>\r\n    <DistId>103970</DistId>\r\n    <ManufacturerCode>TE Connectivity/AMP</Manufact
urerCode>\r\n  </Table1>\r\n</DocumentElement>',  
'84306','1'  

exec usp_GetDistSelection '<DocumentElement>\r\n  <Table1>\r\n    <ManufacturerId>105603</ManufacturerId>\r\n    <PartNumber>0034561711</PartNumber>\r\n    
<MyQty>50</MyQty>\r\n<DistId>143058</DistId>\r\n <ManufacturerCode>Schurter</ManufacturerCode>\r\n  </Table1>\r\n</DocumentElement>',  '84306','1'  

DECLARE     @mytable XML ='<DocumentElement>
  <Table1>
    <CntrlId>ctl00_ContentPlaceHolder1_gvMultipleRFQ_ctl02_Chip One Stop, Inc.0</CntrlId>
    <AvailableQty>1</AvailableQty>
    <ManufacturerId>0</ManufacturerId>
    <PartNumber>KC0159</PartNumber>
    <MyQty>0</MyQty>
    <DistId>145005</DistId>
    <ManufacturerCode>Manufacturer Not Identified</ManufacturerCode>
  </Table1>
</DocumentElement>',    
    @UserID INT = 89226,    
    @FavType INT = 1  
--*/      


CREATE PROCEDURE [dbo].[usp_GetDistSelection]    
(    
	@mytable XML,    
	@UserID INT,    
	@FavType INT    
)    
AS    
BEGIN    
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED 

	IF OBJECT_ID(N'tempdb..#TEMP', N'U') IS NOT NULL 
	DROP TABLE #TEMP


	SELECT    
		cast(colx.query('data(ManufacturerId) ') as varchar(max)) as ManufacturerId,    
		cast(colx.query('data(PartNumber) ') as varchar(max)) as PartNumber,    
		cast(colx.query('data(MyQty) ') as varchar(max)) as MyQty,    
		cast(colx.query('data(DistId) ') as varchar(max)) as DistId,    
		cast(colx.query('data(ManufacturerCode) ') as varchar(max)) as ManufacturerCode    
	INTO #TEMP 
	FROM @mytable.nodes('DocumentElement/Table1') AS Tabx(Colx)    

	-- TABLE [0] 
	SELECT DISTINCT    
		DistId,CompanyName AS Distributor,    
		[dbo].[RFQFavoriteMail](DistId,@FavType,@UserID) as EMail,    
		ISNULL(I.companyid,0) as Buybutton,    
		buypentonurl1 as PrefixURL,    
		buypentonurl2 as MidURL1,    
		buypentonurl3 as MidURL2,    
		buypentonurl4 as MidURL3,    
		buypentonurl5 as SuffixURL,    
		I.RFQCPEmail, buypentonexpire    
	FROM #TEMP T    
	INNER JOIN Company CO 
		ON T.DistId = CO.companyID    
	LEFT OUTER JOIN InventorySettings I 
		ON T.DistId = I.companyid  
	ORDER BY CompanyName   


	IF OBJECT_ID(N'tempdb..#TEMP_MFR', N'U') IS NOT NULL 
	DROP TABLE #TEMP_MFR

	CREATE TABLE #TEMP_MFR (
		ManufacturerId int,
		Partnumber VARCHAR(100),
		Manufacturer VARCHAR(100),
		DistId VARCHAR(100),
		Distributor VARCHAR(100),
		AvailableQTY VARCHAR(100),
		DateCode VARCHAR(50),
		Price FLOAT,
		Price1 FLOAT,
		Break1 INT,
		Price2 FLOAT,
		Break2 INT,
		Price3 FLOAT,
		Break3 INT,
		Price4 FLOAT,
		Break4 INT,
		Price5 FLOAT,
		Break5 INT,
		Price6 FLOAT,
		Break6 INT,
		Price7 FLOAT,
		Break7 INT,
		Price8 FLOAT,
		Break8 INT,
		Price9 FLOAT,
		Break9 INT,
		Price10 FLOAT,
		Break10 INT,
		MyQty VARCHAR(100),
		ManufacturerCode VARCHAR(50)
	)

	INSERT INTO #TEMP_MFR(ManufacturerId,Partnumber,Manufacturer,DistId,Distributor,AvailableQTY,DateCode,
		Price,Price1,Break1,Price2,Break2,Price3,Break3,Price4,Break4,Price5,Break5,Price6,Break6,Price7,Break7,Price8,Break8,Price9,Break9,Price10,Break10,
		MyQty,ManufacturerCode)   

		SELECT    
			T.ManufacturerId,    
			T.Partnumber,    
			ISNULL(T.ManufacturerCode,'') AS Manufacturer,    
			T.DistId,    
			CO.CompanyName as Distributor,    
			CASE WHEN dp.IsManufacturerProduct = 1 THEN 'Inquire' WHEN UPPER(I.QOHDisp) = 'ACTUAL' THEN CONVERT(VARCHAR(25), CONVERT( INT, dp.QtyOnHand)) ELSE I.QOHDisp END as AvailableQty,    
			DP.BatchCode as DateCode,    
			DP.Price,
			DP.Price1,
			DP.BreakLevel1,
			DP.Price2,
			DP.BreakLevel2,
			DP.Price3,
			DP.BreakLevel3,
			DP.Price4,
			DP.BreakLevel4,
			DP.Price5,
			DP.BreakLevel5,
			DP.Price6,
			DP.BreakLevel6,
			DP.Price7,
			DP.BreakLevel7,
			DP.Price8,
			DP.BreakLevel8,
			DP.Price9,
			DP.BreakLevel9,
			DP.Price10,
			DP.BreakLevel10,
			T.MyQty,
			DP.ManufacturerCode  
		FROM #TEMP T    
		INNER JOIN Company AS CO 
			ON T.DistId = CO.companyID    
		INNER JOIN vw_DistributorPartsStatic AS DP 
			ON DP.PartNumber = T.PartNumber 
			AND DP.DistID = T.DistID 
			AND dp.MfrID = T.ManufacturerID
		LEFT OUTER JOIN InventorySettings AS I 
			ON I.CompanyID = T.DistId    
		WHERE T.ManufacturerId = 0    

	UNION    

		SELECT    
			T.ManufacturerId,    
			T.Partnumber,    
			C.CompanyName AS Manufacturer,    
			T.DistId,CO.CompanyName as Distributor,    
			CASE WHEN dp.IsManufacturerProduct = 1 THEN 'Inquire' WHEN UPPER(I.QOHDisp) = 'ACTUAL' THEN CONVERT(VARCHAR(25), CONVERT( INT, dp.QtyOnHand)) ELSE I.QOHDisp END as AvailableQty,    
			DP.BatchCode as DateCode,    
			DP.Price,
			DP.Price1,
			DP.BreakLevel1,
			DP.Price2,
			DP.BreakLevel2,
			DP.Price3,
			DP.BreakLevel3,
			DP.Price4,
			DP.BreakLevel4,
			DP.Price5,
			DP.BreakLevel5,
			DP.Price6,
			DP.BreakLevel6,
			DP.Price7,
			DP.BreakLevel7,
			DP.Price8,
			DP.BreakLevel8,
			DP.Price9,
			DP.BreakLevel9,
			DP.Price10,
			DP.BreakLevel10,
			T.MyQty,
			DP.ManufacturerCode   
		FROM #TEMP T    
		INNER JOIN Company AS C 
			ON T.ManufacturerId = C.companyID    
		INNER JOIN Company AS CO 
			ON T.DistId = CO.companyID    
		INNER JOIN vw_DistributorPartsStatic AS DP 
			ON DP.PartNumber = T.PartNumber 
			AND DP.DistID = T.DistID  
			AND dp.MfrID = T.ManufacturerId
		LEFT OUTER JOIN InventorySettings AS I 
			ON I.CompanyID = T.DistId    
		WHERE T.ManufacturerId > 0    

	UNION    

		SELECT    
			T.ManufacturerId,    
			T.Partnumber,    
			'ZZZUnKnown' AS Manufacturer,    
			T.DistId,    
			CO.CompanyName as Distributor,    
			CASE WHEN dp.IsManufacturerProduct = 1 THEN 'Inquire' WHEN UPPER(I.QOHDisp) = 'ACTUAL' THEN CONVERT(VARCHAR(25), CONVERT( INT, dp.QtyOnHand)) ELSE I.QOHDisp END as AvailableQty,    
			DP.BatchCode as DateCode,    
			DP.Price,
			DP.Price1,
			DP.BreakLevel1,
			DP.Price2,
			DP.BreakLevel2,
			DP.Price3,
			DP.BreakLevel3,
			DP.Price4,
			DP.BreakLevel4,
			DP.Price5,
			DP.BreakLevel5,
			DP.Price6,
			DP.BreakLevel6,
			DP.Price7,
			DP.BreakLevel7,
			DP.Price8,
			DP.BreakLevel8,
			DP.Price9,
			DP.BreakLevel9,
			DP.Price10,
			DP.BreakLevel10,
			T.MyQty,
			DP.ManufacturerCode  
		FROM #TEMP T    
		INNER JOIN Company CO 
			ON T.DistId = CO.companyID    
		INNER JOIN vw_DistributorPartsStatic DP 
			ON DP.PartNumber = T.PartNumber 
			AND DP.DistID = T.DistID  
			AND DP.ManufacturerCode <> T.ManufacturerCode    
		LEFT OUTER JOIN InventorySettings I 
			ON I.CompanyID = T.DistId    
		WHERE T.ManufacturerId = 0 
		ORDER BY Partnumber, Manufacturer 


	-- TABLE [1] 
	SELECT ManufacturerId,Partnumber,REPLACE(Manufacturer, 'ZZZUnKnown', 'Manufacturer Not Identified')AS Manufacturer,DistId,Distributor,AvailableQTY,DateCode,
		Price, Price1, Break1, Price2, Break2, Price3, Break3, Price4, Break4, Price5, Break5, Price6, Break6, Price7, Break7, Price8, Break8, Price9, Break9, Price10, Break10,
		MyQty,ManufacturerCode
	FROM #TEMP_MFR

	-- TABLE [2]     
	DECLARE @SQL VARCHAR(2000)  

	SET @SQL ='SELECT dp.DistID,dp.PartNumber, RFC.Contact,rfc.Phone,rfc.Fax, rfc.Email,CompanyName AS Distributor   
		FROM #TEMP dp INNER JOIN Company C ON dp.DistID = CompanyID     
		OUTER APPLY dbo.[RFQFavoriteContact]( dp.DistID , ' + Convert(varchar,@FavType) + ' , ' + Convert(varchar,@UserID) + ' ) AS RFC
		ORDER BY CompanyName'  

	-- print @SQL     
	EXEC(@SQL) 
END    

GO

/****** Object:  StoredProcedure [dbo].[usp_GetDistUnderMfr]    Script Date: 04/15/2013 13:22:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetDistUnderMfr]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetDistUnderMfr]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetDistUnderMfr] 
(                  
   @companyID int,                
   @partNumber varchar(100),                
   @type int            
)
AS                  

--DECLARE   @companyID INT = 35764,  @partNumber varchar(100) = '019', @type INT = 1            

BEGIN           
	SET @partNumber = dbo.RemoveSpecialChars(@partNumber)

	IF (LEN(@companyID) <= 5)  
	BEGIN  
		SELECT @companyID = Company_ID FROM dbo.Company_IMAPMDV_XRF WHERE Manufacturer_ID = @companyID   
	END  

	SELECT      
		c.CompanyID as ManufacturerId,          
		c.CompanyName as ManufacturerName,          
		c.CompanyLogo,          
		dp.DistID AS DistributorID,          
		c1.CompanyName as DistributorName,          
		dp.ManufacturerCode,          
		dp.PartNumber,          
		dp.QtyOnHand as Qty,          
		dp.Uploaded as LastupdatedOn,    
		dp.ROHS,      
		'RFQCPID' = 
			CASE             
				WHEN i.RFQCPID <> 0 THEN 'Send RFQ'             
			ELSE ''            
			END,            
		'RFQCPEmail' = 
			CASE             
				WHEN i.RFQCPID = 0 THEN ''             
			ELSE uc.EmailAddress            
			END,          
		'BuyPentonExpire' = 
			CASE          
				WHEN (i.BuyPentonExpire >= GETDATE() AND i.BuyPentonURL1 <> '') THEN 'Buy'            
			ELSE ''            
			END,            
		i.BuyPentonURL1,            
		'BuyPentonURL2' = 
			CASE             
				WHEN (i.BuyPentonURL2 = 1) THEN dp.PartNumber            
				WHEN (i.BuyPentonURL2 = 2) THEN dp.PartNumber            
				WHEN (i.BuyPentonURL2 = 3) THEN dp.ManufacturerCode            
				WHEN (i.BuyPentonURL2 = 4) THEN ISNULL(c.CompanyName, dp.ManufacturerCode)            
			ELSE ''            
			END,            
		i.BuyPentonURL3,            
		'BuyPentonURL4' = 
			CASE             
				WHEN (i.BuyPentonURL4 = 1) THEN dp.PartNumber            
				WHEN (i.BuyPentonURL4 = 2) THEN dp.PartNumber            
				WHEN (i.BuyPentonURL4 = 3) THEN dp.ManufacturerCode            
				WHEN (i.BuyPentonURL4 = 4) THEN ISNULL(c.CompanyName, dp.ManufacturerCode)            
			ELSE ''            
			END,             
		i.BuyPentonURL5,
		dp.MfrID,
		ISNULL(P.ProductId, 0) AS ProductId         
	FROM dbo.vw_DistributorPartsStatic dp    
	INNER JOIN dbo.Company c          
		ON dp.MfrID = c.CompanyID
	INNER JOIN dbo.RegionAuthorization ra          
		ON dp.MfrID = ra.MfrID 
		AND dp.DistID = ra.DistID          
	INNER JOIN (
		SELECT MfrDistID, MAX(AuthStatusID) AS AuthStatus
		FROM dbo.RegionZoneStatus 
		WHERE AuthStatusID in (4,2) 
		GROUP BY MFRDistId
	) rz     
		ON ra.MfrDistID = rz.MfrDistID       
	INNER JOIN dbo.InventorySettings i          
		ON dp.DistID = i.CompanyID 
	INNER JOIN dbo.Company c1          
		ON dp.DistID = c1.CompanyID        
	LEFT OUTER JOIN dbo.UserContact uc    
		ON i.RFQCPID = uc.UserID    
	LEFT OUTER JOIN Product P
		ON dp.PartNumber = P.PartNumber 
		AND dp.MfrID = P.ManufacturerID
		AND ISNULL(P.IsActive, 1) = 1     
	WHERE dp.Search_PartNumber LIKE @partNumber + '%' 
		AND dp.Status = 'Active'          
		AND c.CompanyID = @companyID 
		AND c.CompanyStatusID = 1          
		AND c1.CompanyStatusID = 1          
		AND ((uc.EmailAddress IS NOT NULL) OR (i.BuyPentonExpire >= GETDATE() AND i.BuyPentonURL1 <> ''))
		AND (rz.authstatus = 4 OR (rz.authstatus = 2 AND c1.Trusted_Disty = 1))
	ORDER BY dp.PartNumber, c1.CompanyName
END
  
GO

/****** Object:  StoredProcedure [dbo].[usp_GetDistUnderMfrCount]    Script Date: 04/15/2013 13:22:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetDistUnderMfrCount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetDistUnderMfrCount]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetDistUnderMfrCount]
(
	@companyID INT, 
	@partNumber VARCHAR(100), 
	@type INT
)
AS 
BEGIN      

--DECLARE   @companyID INT = 35764,  @partNumber varchar(100) = '019', @type INT = 1            

	SET @partNumber = dbo.RemoveSpecialChars(@partNumber)

	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
 
	IF (LEN(@companyID) <= 5) 
	BEGIN
	  SELECT    @companyID = Company_ID
	  FROM      dbo.Company_IMAPMDV_XRF
	  WHERE     Manufacturer_ID = @companyID	
	END

  
	SELECT COUNT(DISTINCT a.PartNumber) MatchCount
	FROM   
	(
		SELECT dp.PartNumber
		FROM   dbo.Company c
		INNER JOIN vw_DistributorPartsStatic dp
			ON c.CompanyID = dp.MfrID
		INNER JOIN dbo.RegionAuthorization ra
			ON dp.MfrID = ra.MfrID
			AND dp.DistID = ra.DistID
		INNER JOIN 
		(
			SELECT MfrDistID, MAX(AuthStatusID) AuthStatus
			FROM   dbo.RegionZoneStatus
			WHERE  AuthStatusID IN (4,2)
			GROUP BY MFRDistId
		) rz
			ON ra.MfrDistID = rz.MfrDistID
		INNER JOIN dbo.InventorySettings i
			ON dp.DistID = i.CompanyID
		INNER JOIN dbo.Company c1
			ON dp.DistID = c1.CompanyID
		LEFT OUTER JOIN dbo.UserContact uc
			ON i.RFQCPID = uc.UserID
		WHERE  c.CompanyID = @companyID
			AND c.CompanyStatusID = 1
			AND dp.Search_PartNumber LIKE @partNumber + '%'
			AND dp.Status = 'Active'
			AND c1.CompanyStatusID = 1
			AND ((uc.EmailAddress IS NOT NULL) OR (i.BuyPentonExpire >= GETDATE() AND i.BuyPentonURL1 <> ''))
			AND (rz.authstatus = 4 OR (rz.authstatus = 2 AND c1.Trusted_Disty = 1))
	) a

END

GO

/****** Object:  StoredProcedure [dbo].[usp_GetMultipleRFQ]    Script Date: 11/09/2012 18:49:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetMultipleRFQ]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetMultipleRFQ]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetMultipleRFQ]    Script Date: 11/09/2012 18:49:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [dbo].[usp_GetMultipleRFQ]
(
    @mytable XML
)
AS

/*
declare @p1 xml
set @p1=convert(xml,N'<DocumentElement><Table1><ManufacturerId>0</ManufacturerId><PartNumber>A100</PartNumber><MyQty>0</MyQty><PartId>0</PartId><DistributorId>0</DistributorId><DistributorPartID>272707254</DistributorPartID></Table1><Table1><ManufacturerId>0</ManufacturerId><PartNumber>A-1-003</PartNumber><MyQty>0</MyQty><PartId>0</PartId><DistributorId>0</DistributorId><DistributorPartID>272793955</DistributorPartID></Table1><Table1><ManufacturerId>0</ManufacturerId><PartNumber>A-1.007-B</PartNumber><MyQty>0</MyQty><PartId>0</PartId><DistributorId>0</DistributorId><DistributorPartID>265033142</DistributorPartID></Table1></DocumentElement>')
exec usp_GetMultipleRFQ @mytable=@p1

declare @p1 xml
set @p1=convert(xml,N'<DocumentElement><Table1><ManufacturerId>0</ManufacturerId><PartNumber>A100</PartNumber><MyQty>260</MyQty><PartId>0</PartId><DistributorId>0</DistributorId><DistributorPartID>272707254</DistributorPartID></Table1></DocumentElement>')
exec usp_GetMultipleRFQ @mytable=@p1

declare @p1 xml
set @p1=convert(xml,N'<DocumentElement><Table1><ManufacturerId>100322</ManufacturerId><PartNumber>1234</PartNumber><MyQty>0</MyQty><PartId>0</PartId><DistributorId>0</DistributorId><DistributorPartID>273819704</DistributorPartID></Table1></DocumentElement>')
exec usp_GetMultipleRFQ @mytable=@p1

Gets 2 records for Alpha Wire

declare @p1 xml
set @p1=convert(xml,N'<DocumentElement><Table1><ManufacturerId>0</ManufacturerId><PartNumber>1234</PartNumber><MyQty>10</MyQty><PartId>0</PartId><DistributorId>0</DistributorId><DistributorPartID>284722184</DistributorPartID></Table1></DocumentElement>')
exec usp_GetMultipleRFQ @mytable=@p1

Gets 2 records Manufacturer Not Identified

DECLARE @mytable XML = CONVERT(XML,N'<DocumentElement><Table1><ManufacturerId>0</ManufacturerId><PartNumber>BC546B126</PartNumber><MyQty>0</MyQty><PartId>0</PartId><DistributorId>120020</DistributorId><DistributorPartID>120020,143832,143058</DistributorPartID></Table1></DocumentElement>')
*/

BEGIN
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	DECLARE @count INT
	DECLARE @rowID INT
	DECLARE @SQL VARCHAR(1000)
	DECLARE @ManuID int = 0
	DECLARE @PartNum VARCHAR(1000)


	SET @count = 0
	SET @rowID = 1

	IF OBJECT_ID(N'tempdb..#TEMP', N'U') IS NOT NULL 
	DROP TABLE #TEMP

	SELECT
		CAST(colx.query('data(ManufacturerId) ') as varchar(max)) as ManufacturerId,
		CAST(colx.query('data(PartNumber) ') as varchar(max)) as PartNumber,
		CAST(colx.query('data(MyQty) ') as varchar(max)) as MyQty,
		CAST(colx.query('data(DistributorPartID) ') as varchar(max)) as PartId,
		IDENTITY( INT ) AS ID
	INTO #TEMP 
	FROM @mytable.nodes('DocumentElement/Table1') AS Tabx(Colx)

	--Select * FROM #TEMP

	IF OBJECT_ID(N'tempdb..#MultipleRFQ', N'U') IS NOT NULL 
	DROP TABLE #MultipleRFQ

	CREATE TABLE #MultipleRFQ
	(
		[PartNumber]  VARCHAR(200),
		[ManufacturerId] INT,
		[Manufacturer]  VARCHAR(200),
		[DistributorId]  INT,
		[Distributor]  VARCHAR(200),
		[MyQty]    INT,
		[AvailableQty]  INT
	)

	-- Manufacturer Parts --
	INSERT INTO #MultipleRFQ
	SELECT
		T.PartNumber,
		ISNULL(T.ManufacturerId,0),
		C.CompanyName as Manufacturer,
		0 as DistributorId,
		---'No Distributor' as Distributor,
		'' as Distributor,
		T.MyQty,
		0 as AvailableQty
	FROM #Temp T 
	LEFT OUTER JOIN Product P 
		ON T.PartId = P.ProductID
	LEFT OUTER JOIN Company AS C 
		ON C.CompanyID = T.ManufacturerId
	WHERE ISNULL(T.ManufacturerId, 0) >= 0

	--Select * from #MultipleRFQ

	SELECT @count = count(*) FROM #Temp

	-- While Loop Begins --
	WHILE(@count >= @rowID)
	BEGIN
		-- Distributor's PartID
		SELECT @PartNum = dbo.RemoveSpecialCharacter(PartNumber), @SQL = PartId, @ManuID = ManufacturerId 
		FROM #TEMP 
		WHERE ID = @rowID

		--Print 'PartID ' + Convert(varchar(30), @SQL) + 'PartID End'


		IF OBJECT_ID(N'tempdb..#TempDistpartID', N'U') IS NOT NULL 
		DROP TABLE #TempDistpartID

		CREATE TABLE #TempDistpartID
		(
			PartNum  varchar(1000)
		)
		

		INSERT INTO #TempDistpartID
		SELECT array_data 
		FROM dbo.ReturnArray(@PartNum, ',', NULL)
		
		IF @ManuID = 0
		BEGIN	 
			INSERT INTO  #MultipleRFQ
			SELECT
				DP.PartNumber,
				ISNULL(DP.MfrID, 0) AS MfrID,
				'Manufacturer Not Identified',
				DP.DistID,
				D.CompanyName,
				(
					SELECT MyQty 
					FROM #TEMP 
					WHERE ManufacturerId = @ManuID 
					AND ID = @rowID 
				) AS MyQty,
				CASE 
					WHEN dp.IsManufacturerProduct = 1 
						THEN 2147483646
					WHEN UPPER(Ins.QOHDisp) = 'ACTUAL' 
						THEN dp.QtyOnHand
					ELSE 2147483646 
				END   
			FROM vw_DistributorPartsStatic DP
			INNER JOIN DistributorParts_Clean DPC
				ON DP.PartNumber = DPC.PartNumber
			INNER JOIN #TempDistpartID AS tmp
				ON dpc.Search_PartNumber = tmp.PartNum
			INNER JOIN InventorySettings Ins
				ON DP.DistID = Ins.CompanyID
				AND Ins.DoNotPub = 0
				AND ISNULL(Ins.RFQCPEmail,'') <> ''
			LEFT OUTER JOIN Company D 
				ON DP.DistID = D.CompanyID
			WHERE DP.MfrID IS NULL
			GROUP BY DP.DistID, DP.MfrID, DP.PartNumber, Ins.QOHDisp, QtyOnHand, dp.IsManufacturerProduct, D.CompanyName
		END
		ELSE
		BEGIN
			INSERT INTO  #MultipleRFQ
			SELECT
				DP.PartNumber,
				DP.MfrID,
				MF.CompanyName,
				DP.DistID,
				D.CompanyName,
				(
					SELECT MyQty 
					FROM #TEMP 
					WHERE ManufacturerId = @ManuID 
					AND ID = @rowID 
				) AS MyQty,
				CASE 
					WHEN dp.IsManufacturerProduct = 1 
						THEN 2147483646
					WHEN UPPER(Ins.QOHDisp) = 'ACTUAL' 
						THEN dp.QtyOnHand
					ELSE 2147483646 
				END   
			FROM vw_DistributorPartsStatic DP
			INNER JOIN DistributorParts_Clean DPC
				ON DP.PartNumber = DPC.PartNumber
			INNER JOIN #TempDistpartID AS tmp
				ON dpc.Search_PartNumber = tmp.PartNum
			INNER JOIN InventorySettings Ins
				ON DP.DistID = Ins.CompanyID
				AND Ins.DoNotPub = 0
				AND ISNULL(Ins.RFQCPEmail,'') <> ''
				INNER JOIN Company MF 
					ON DP.MfrID = MF.CompanyID
				LEFT OUTER JOIN Company D 
					ON DP.DistID = D.CompanyID
			GROUP BY DP.DistID,DP.MfrID,DP.PartNumber, Ins.QOHDisp, QtyOnHand, dp.IsManufacturerProduct, D.CompanyName, MF.CompanyName
		END

		SET @rowID = @rowID + 1
		SET @SQL = ''
		SET @ManuID = 0

		--Select * FROM #TempDistpartID
	END

	DELETE #MultipleRFQ 
	WHERE DistributorId = 0 --and  AvailableQty = 0

	SELECT DISTINCT DistributorId,REPLACE(REPLACE(REPLACE(REPLACE(Distributor,'''',' '),'%',' '),'*',' '),':',' ') AS Distributor 
	FROM #MultipleRFQ
	WHERE Distributor <> ''
	ORDER BY Distributor

	SELECT DISTINCT Manufacturer,ManufacturerId,PartNumber,MyQty 
	FROM #MultipleRFQ

	SELECT PartNumber,ManufacturerId,Manufacturer,DistributorId,
		REPLACE(REPLACE(REPLACE(REPLACE(Distributor,'''',' '),'%',' '),'*',' '),':',' ') AS Distributor,
		MyQty,AvailableQty 
	FROM #MultipleRFQ
	ORDER BY PartNumber,Manufacturer

	--SELECT * FROM #MultipleRFQ
	--SELECT * FROM #TEMP
END

GO

/****** Object:  StoredProcedure [dbo].[Usp_GetPartNumberDetail]    Script Date: 09/24/2011 22:12:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetPartNumberDetail]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetPartNumberDetail]
GO
/****** Object:  StoredProcedure [dbo].[usp_GetPartNumberDetail]    Script Date: 09/24/2011 22:12:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC usp_GetPartNumberDetail
(  
	@DistributorID int,
	@PartNumber Varchar(100)  
)  
AS  

--DECLARE @DistributorID INT, @PartNumber VARCHAR(100)

BEGIN  
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	DECLARE @Number VARCHAR(100)
	SET @PartNumber = dbo.RemoveSpecialChars(@PartNumber)
	SET @Number = '%' + @PartNumber + '%'
	
	SELECT dp.InvID AS DistributorPartID, dp.DistID as DistributorID, dp.PartNumber, CONVERT(INT,dp.QtyOnHand) AS AvailableQty
	FROM dbo.vw_DistributorPartsStatic AS dp
	WHERE dp.DistID = @DistributorID 
		AND dp.Status = 'Active' 
		AND dp.QtyOnHand > 0  
		AND dp.Search_PartNumber LIKE @Number
	ORDER BY PartNumber  
END

GO

/****** Object:  StoredProcedure [dbo].[usp_GetProductDetailsByManu]    Script Date: 09/20/2012 13:29:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetProductDetailsByManu]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetProductDetailsByManu]
GO


/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Gets part details entered by a manufacturer

Used by: 
/SearchDetailsPages/PartDetailListView.aspx.cs

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
09.20.2012		Marcus Ruether		Created. 
09.25.2012		Marcus Ruether		Updated to get info from distrributorParts if there is no product info
04.12.2013		Marcus Ruether		Added ProductTypeId, fixed where ProductType was being pulled from
04.26.2013		Marcus Ruether		Got changed to not query by MfrId if a product wasn't matched. 
									Updated it to limit to mfrId and also removed join on redundent table DistributorParts_Cleaned
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[usp_GetProductDetailsByManu]
	@ManufacturerId INT,
	@PartNumber VARCHAR(100)
AS

--DECLARE @ManufacturerId INT=103569, @PartNumber VARCHAR(100) = '1287'

BEGIN

	SET @PartNumber = dbo.RemoveSpecialCharacter(@PartNumber)
	
	IF EXISTS
	(
		SELECT * 
		FROM Product P 
		INNER JOIN Company C 
			ON p.ManufacturerId = c.CompanyID 
		WHERE p.Clean_PartNumber = @PartNumber
			AND c.CompanyId = @ManufacturerId
	)
	BEGIN
		-- get the detail from the products table, as that is uploaded by a manufacturer
		SELECT  
			p.ProductId,
			C.CompanyLogo,
			P.PartNumber,
			C.CompanyID AS ManufacturerID,
			C.CompanyName AS ManufacturerName,
			pt.TypeDescription AS ProductType,
			pt.ProductTypeId,
			P.[Description] -- this was using the first distrubutor description
		FROM 
			Product P 
			INNER JOIN Company C 
				ON p.ManufacturerId = c.CompanyID
			LEFT OUTER JOIN productType_XRF AS pt_xrf     
				ON p.ManufacturerID = pt_xrf.ManufacturerID    
				AND p.ProductType = pt_xrf.MfrProdTypeCode    
			LEFT OUTER JOIN ProductType AS pt     
				ON pt_xrf.ProductTypeID = pt.ProductTypeId    
				AND pt.IsActive = 1    
		WHERE p.Clean_PartNumber = @PartNumber
			AND c.CompanyId = @ManufacturerId
	
	END
	ELSE
	BEGIN
		-- if a part has not had details upload by the manufacturer, get basic info from distributor table
		SELECT TOP 1
			0 as ProductId,
			0 AS ProductTypeId,
			C.CompanyLogo,
			DP.PartNumber,
			C.CompanyID AS ManufacturerID,
			C.CompanyName AS ManufacturerName,
			'' AS ProductType,
			'' AS [Description]
		FROM vw_DistributorPartsStatic DP WITH(NOLOCK)
		INNER JOIN Company C 
			ON c.CompanyId = DP.MfrID
		WHERE 
			DP.Search_PartNumber = @PartNumber AND
			DP.MfrID = @ManufacturerId
		
		
	END
END

GO

/****** Object:  StoredProcedure [dbo].[usp_GetProductDetailsWithNoManuByPartNumber]    Script Date: 11/26/2012 20:39:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetProductDetailsWithNoManuByPartNumber]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetProductDetailsWithNoManuByPartNumber]
GO

CREATE PROCEDURE [dbo].[usp_GetProductDetailsWithNoManuByPartNumber] 
(
	@PartNumber VARCHAR(100)
)
AS

--DECLARE @PartNumber VARCHAR(100) = 'wire18awg5black'

BEGIN
	SET @PartNumber = dbo.RemoveSpecialCharacter(@PartNumber)

	SELECT TOP 1
		0 as ProductId,
		'' AS CompanyLogo,
		dp.PartNumber,
		0 AS ManufacturerID,
		'Manufacturer Not Identified' AS ManufacturerName,
		'' AS ProductType,
		0 AS ProductTypeId,
		'' AS [Description]
	FROM vw_DistributorPartsStatic dp (NOLOCK) 
	WHERE dp.Search_PartNumber = @PartNumber
		AND dp.MfrID IS NULL
END

GO

/****** Object:  StoredProcedure [dbo].[usp_GetRFQParts]    Script Date: 01/18/2013 22:49:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetRFQParts]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetRFQParts]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [dbo].[usp_GetRFQParts]     
(    
    @ManufacturerId varchar(max),     
    @DistributorId varchar(max),     
    @DistpartIds varchar(max),    
    @FavType INT,     
    @UserID varchar(max),    
    @PartNumber varchar(max)    
)     
AS     

--DECLARE @ManufacturerId VARCHAR(MAX) = '', @DistributorId VARCHAR(MAX)='106474', @DistpartIds VARCHAR(MAX)='106474,101842,104333,104462', @FavType INT='1', @UserID VARCHAR(MAX)='89226', @PartNumber VARCHAR(MAX)='LM4040B10IDBZTG4'    
--DECLARE @ManufacturerId VARCHAR(MAX) = '', @DistributorId VARCHAR(MAX)='', @DistpartIds VARCHAR(MAX)='106042', @FavType INT='1', @UserID VARCHAR(MAX)='89226', @PartNumber VARCHAR(MAX)='00011187A'    
--DECLARE @ManufacturerId VARCHAR(MAX) = '', @DistributorId VARCHAR(MAX)='120020', @DistpartIds VARCHAR(MAX)='120020,143832,143058', @FavType INT='1', @UserID VARCHAR(MAX)='89226', @PartNumber VARCHAR(MAX)='BC546B,126'
--DECLARE @ManufacturerId VARCHAR(MAX) = '103569', @DistributorId VARCHAR(MAX)='101842', @DistpartIds VARCHAR(MAX)='101842,102877,100845,121230,100298,120361,108060,101118,101397,101664,101748,102617,121564,104333,104462,110192,122985,101092,120020,120059,142361,142361,142361,140991,102416,135757,130203,102979,102979,123082,143636,142175,142175', @FavType INT='1', @UserID VARCHAR(MAX)='89226', @PartNumber VARCHAR(MAX)='1287'    
--DECLARE @ManufacturerId VARCHAR(MAX) = '0', @DistributorId VARCHAR(MAX)='102979', @DistpartIds VARCHAR(MAX)='141498,100535,120059,100277,100298,144642,123637,120361,138113,100845,108060,144217,101118,142361,144518,101748,139004,101842,140991,143957,109920,102205,144727,102416,143751,140420,102617,121230,102877,121564,121577,135757,145136,144547,122257,104333,104462,110192,102979,122792,122985,123082,106042,143636,142175', @FavType INT='1', @UserID VARCHAR(MAX)='89226', @PartNumber VARCHAR(MAX)='1287'    

BEGIN    
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED     

	SET @PartNumber = dbo.RemoveSpecialCharacter(@PartNumber)

	DECLARE @PartDesc VARCHAR(MAX)    

	DECLARE @mfr TABLE
	(
		MfrID INT
	)

	INSERT INTO @mfr
	SELECT array_data 
	FROM dbo.ReturnArray(@ManufacturerId, ',', NULL)

	DECLARE @dist TABLE
	(
		DistID INT
	)

	INSERT INTO @dist
	SELECT array_data 
	FROM dbo.ReturnArray(@DistpartIds, ',', NULL)
	
	-- Remove duplicate IDs
	DECLARE @distUnique TABLE
	(
		DistID INT
	)

	INSERT INTO @distUnique
	SELECT DistID
	FROM @dist d
	GROUP BY DistID

	IF OBJECT_ID(N'tempdb..#temp', N'U') IS NOT NULL   
		DROP TABLE #temp  
  
	CREATE TABLE #temp     
	(     
	   DistributorId int,     
	   PartNumber VARCHAR(500),     
	   BatchCode VARCHAR(50),  
	   Distributor VARCHAR(500),     
	   AvailableQty varchar(25),     
	   Contact varchar(500),     
	   Phone varchar(100),     
	   Fax varchar(100),     
	   EMail VARCHAR(500)     
	) 

	IF EXISTS (SELECT * FROM @mfr WHERE MfrID > 0)     
	BEGIN     
		INSERT INTO #temp(DistributorId,PartNumber,BatchCode,Distributor,AvailableQty,Contact,Phone,Fax,EMail)     
		SELECT dp.DistID,     
			dp.PartNumber,     
			dp.BatchCode,   
			c.CompanyName AS Distributor,  
			CASE WHEN dp.IsManufacturerProduct = 1 THEN 'Inquire' WHEN UPPER(inv.QOHDisp) = 'ACTUAL' THEN CONVERT(VARCHAR(25), CONVERT(INT, dp.QtyOnHand)) ELSE inv.QOHDisp END as AvailableQty,    
			rfc.Contact,     
			rfc.Phone,     
			rfc.Fax,     
			rfc.Email    
		FROM vw_DistributorPartsStatic dp
		INNER JOIN DistributorParts_Clean dpc
			ON dp.PartNumber = dpc.PartNumber
		INNER JOIN Company c 
			ON dp.DistID = c.CompanyID   
		INNER JOIN @distUnique d
			ON dp.DistID = d.DistID
		INNER JOIN @mfr m
			ON dp.MfrID = m.MfrID 
		LEFT OUTER JOIN InventorySettings inv 
			ON inv.CompanyID = dp.DistID   
		OUTER APPLY dbo.[RFQFavoriteContact]( dp.DistID , 1 , @UserID ) AS rfc   
		WHERE dpc.Search_PartNumber = @PartNumber
			AND rfc.Email IS NOT NULL
	END    
	ELSE
	BEGIN
		INSERT INTO #temp(DistributorId,PartNumber,BatchCode,Distributor,AvailableQty,Contact,Phone,Fax,EMail)     
		SELECT dp.DistID,     
			dp.PartNumber,     
			dp.BatchCode,   
			c.CompanyName AS Distributor,  
			CASE WHEN dp.IsManufacturerProduct = 1 THEN 'Inquire' WHEN UPPER(inv.QOHDisp) = 'ACTUAL' THEN CONVERT(VARCHAR(25), CONVERT(INT, dp.QtyOnHand)) ELSE inv.QOHDisp END as AvailableQty,    
			rfc.Contact,     
			rfc.Phone,     
			rfc.Fax,     
			rfc.Email    
		FROM vw_DistributorPartsStatic dp WITH(NOLOCK)
		INNER JOIN DistributorParts_Clean dpc WITH(NOLOCK)
			ON dp.PartNumber = dpc.PartNumber
		INNER JOIN Company c  WITH(NOLOCK)
			ON dp.DistID = c.CompanyID   
		INNER JOIN @distUnique d
			ON dp.DistID = d.DistID
		LEFT OUTER JOIN InventorySettings inv WITH(NOLOCK) 
			ON inv.CompanyID = dp.DistID   
		OUTER APPLY dbo.[RFQFavoriteContact]( dp.DistID , 1 , @UserID ) AS rfc   
		WHERE dpc.Search_PartNumber = @PartNumber
			AND rfc.Email IS NOT NULL
			AND ISNULL(dp.MfrID, 0) = 0
	END

	SELECT *    
	FROM #temp    
	ORDER BY Distributor, BatchCode  
	    
	SELECT @PartNumber = PartNumber    
	FROM #temp    
	ORDER BY Distributor, BatchCode  

	SELECT @PartDesc = [description] 
	FROM dbo.Product p
	INNER JOIN @mfr m
		ON p.ManufacturerID = m.MfrID
	WHERE PartNumber = @PartNumber 
		AND [Description] <> 'Null'    

	SELECT c.CompanyName AS Manufacturer,    
		   c.CompanyDescription AS Description,    
		   Isnull(@PartDesc,'') AS PartDesc    
	FROM Company c
	INNER JOIN @mfr m
		ON c.CompanyID = m.MfrID
	   
	DROP TABLE #temp     
END    
    
GO

/****** Object:  StoredProcedure [dbo].[usp_GetRFQPartSuggestion]    Script Date: 09/24/2011 22:15:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetRFQPartSuggestion]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetRFQPartSuggestion]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetRFQPartSuggestion]   --3,''d'',20
(  
	@CompanyId  int,  
	@PrefixText  varchar(300),  
	@PartCount  int  
)  
AS  

--DECLARE @CompanyId INT = 0, @PrefixText  VARCHAR(300) = 'MF', @PartCount INT = 10
BEGIN  
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	SET @PrefixText = dbo.RemoveSpecialChars(@PrefixText)

	DECLARE @strSQL VARCHAR(MAX) = ''

	BEGIN  
		SET @strSQL ='SELECT DISTINCT TOP ' + CONVERT(VARCHAR(9), @PartCount) + ' DP.PartNumber  
			FROM  vw_DistributorPartsStatic AS DP  
			WHERE LOWER(DP.Search_PartNumber) LIKE ''' + @PrefixText + '%'' 
				AND DP.QtyOnHand > 0 
				AND DP.DistID = ' + CONVERT(VARCHAR(9), @CompanyId)
	END  
	
	--SELECT @strSQL
	EXEC (@strSQL)
END

GO

/****** Object:  StoredProcedure [dbo].[Usp_GetRFQStatusDetail]    Script Date: 09/24/2011 22:15:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Usp_GetRFQStatusDetail]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Usp_GetRFQStatusDetail]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE usp_GetRFQStatusDetail
(      
	@RFQMPID INT    
)      
AS      
--DECLARE @RFQMPID INT    

BEGIN     
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	SELECT	R.RFQMPDID,
			R.DistributorPartID AS DistributorPartID,
			D.PartNumber,
			CONVERT(INT,D.QtyOnHand) AS  AvailableQty, 
			R.QuantityRequested AS RequestedQuatity,
			R.TargetPrice,
			CASE 
				WHEN ISNULL(DateRequired,'') = '' 
					THEN NULL 
				ELSE CONVERT(VARCHAR,R.DateRequired,101) 
			END AS RequestedDate
	FROM RFQMultiplePartDetail AS R
	INNER JOIN vw_DistributorPartsStatic AS D
		ON R.DistributorPartID = D.InvID
	WHERE RFQMPID = @RFQMPID 
END

GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchPartDetails]    Script Date: 01/18/2013 22:51:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchPartDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchPartDetails]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchPartDetails]    Script Date: 01/18/2013 22:51:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

      
/*--------------------------------------------------------------------------          
-- Name   : [usp_GetSearchPartProductType] ManuDist Detailspage          
-- Description : This Procedure Will Get the ManuDist Details.          
-- Arguments : CompanyID, PartNumber          
-- Returns  : List of Parts          
-- Updated    : 11/28/2012 by lalbahadur to add ISO certified & registered year in company attributes 
-- Updated    : 12/26/2012 by parameswar to update for  QtyOnHand field             

-- and removed inactive distributor    
Modifications
Author			Date		Desc
Marcus Ruether	01.07.2013	Order by auth status
Marcus Ruether	01.14.2013  Added check for InventorySettings.DoNotPub
Cory Lafferty		02.07.2013  Using temp table DistributorParts_Clean
Marcus Ruether  04.20.2013  Removed join to DistributorParts_Clean, no longer needed
--------------------------------------------------------------------------          
--   [dbo].[usp_GetSearchPartDetails] 103569,'1287'     
*/       
CREATE PROCEDURE [dbo].[usp_GetSearchPartDetails]  
(          
	@CompanyID INT,          
	@PartNumber VARCHAR(50)          
)          
AS          
--DECLARE @CompanyID INT = 103569, @PartNumber VARCHAR(50) = '1287'          
    
BEGIN          
    
	SET @partnumber = dbo.RemoveSpecialCharacter(@partnumber)        
	       
	SELECT dp.DistID AS DistributorID,           
		p.ProductID,           
		dp.InvID,           
		pt.TypeDescription AS ProductType,          
		c1.CompanyID AS ManufacturerID,           
		c.CompanyName AS DistributorName,           
		c1.CompanyName AS ManufacturerName,           
		dp.ManufacturerCode AS DistManufacturerCode,           
		c1.CompanyLogo,          
		dp.PartNumber,           
		dp.Uploaded,     
		CASE 
			WHEN dp.IsManufacturerProduct = 1 
				THEN 'Inquire'
			WHEN UPPER(ins.QOHDisp) = 'ACTUAL' 
				THEN CONVERT(VARCHAR(25), CONVERT( INT, dp.QtyOnHand)) 
			ELSE ins.QOHDisp 
		END as QtyOnHand,    
		dp.BatchCode,
		dp.Price,          
		dp.Price1,        
		dp.BreakLevel1,        
		dp.Price2,        
		dp.BreakLevel2,        
		dp.Price3,        
		dp.BreakLevel3,        
		dp.Price4,        
		dp.BreakLevel4,        
		dp.Price5,        
		dp.BreakLevel5,        
		dp.Price6,        
		dp.BreakLevel6,        
		dp.Price7,        
		dp.BreakLevel7,        
		dp.Price8,        
		dp.BreakLevel8,        
		dp.Price9,        
		dp.BreakLevel9,        
		dp.Price10,        
		dp.BreakLevel10,
		ins.RFQCPID,        
		ins.BuyPentonExpire,           
		ins.BuyPentonURL1,           
		ins.BuyPentonURL2,           
		ins.BuyPentonURL3,           
		ins.BuyPentonURL4,           
		ins.BuyPentonURL5,          
		cast(dp.Description as varchar(max)) AS ColumnDescription,
		IsNULL(RZS.MaxAuth, 0) AS MaxAuth,        
		dbo.Get_SearchCompanyOwn (dp.DistID) AS DistributorAttributes
	FROM vw_DistributorPartsStatic AS dp WITH(NOLOCK)
	--INNER JOIN DistributorParts_Clean dpc WITH(NOLOCK)
	--	ON dp.PartNumber = dpc.PartNumber          
	INNER JOIN InventorySettings (NOLOCK) AS ins           
		ON ins.DoNotPub = 0          
		AND dp.DistID = ins.CompanyID      
	LEFT OUTER JOIN RegionAuthorization (NOLOCK) AS ra           
		ON ra.DistID = dp.DistID          
		AND ra.MfrID = @CompanyID          
	LEFT OUTER JOIN Company (NOLOCK) AS c           
		ON c.isActive = 1                 
		AND c.CompanyID = dp.DistID          
	LEFT OUTER JOIN Company (NOLOCK) AS c1           
		ON dp.MfrID = c1.CompanyID
		AND c1.CompanyStatusID = 1          
		AND c1.IsActive = 1          
	LEFT OUTER JOIN 
	(          
		SELECT RZOS.MFRDistID,           
		MAX(          
			CASE           
				WHEN (AuthStatusID  = 2 and C.Trusted_Disty=1)           
					THEN 4           
				ELSE AuthStatusID           
			END          
		) AS MaxAuth          
		FROM RegionZoneStatus (NOLOCK) AS RZOS
		INNER JOIN RegionAuthorization (NOLOCK) AS RA          
			ON RZOS.MfrDistID = RA.MfrDistID
		INNER JOIN Company (NOLOCK) AS C
		ON RA.MfrID=C.CompanyID 
		GROUP BY RZOS.MfrDistID          
	) AS RZS         
		ON ra.MfrDistID = RZS.MfrDistID          
	LEFT OUTER JOIN
	(
		SELECT MfrID, DistID, SUM(Print_Amount+Online_Amount) as Total
		FROM DistPartsSpend WITH(NOLOCK) 
		GROUP BY MfrID,DistID
	) AS Spend 
		ON RA.MfrID = Spend.MfrID AND RA.DistID = Spend.DistID
	LEFT OUTER JOIN Product (NOLOCK) AS p           
		ON p.StatusID = 1          
		AND dp.PartNumber = p.PartNumber          
		AND dp.MfrID = p.ManufacturerID
	LEFT OUTER JOIN productType_XRF (NOLOCK) AS pt_xrf           
		ON p.ManufacturerID = pt_xrf.ManufacturerID          
		AND p.ProductType = pt_xrf.MfrProdTypeCode          
	LEFT OUTER JOIN ProductType (NOLOCK) AS pt           
		ON pt.IsActive = 1          
		AND pt_xrf.ProductTypeID = pt.ProductTypeId          
	WHERE dp.Search_PartNumber = @partnumber
		AND dp.MfrID = @CompanyID
		AND c.CompanyStatusID = 1              
	ORDER BY 
		CASE 
			WHEN RZS.MaxAuth = 4 
				THEN 1 
			ELSE 0 
		END DESC, 
		Spend.Total DESC,
		c.CompanyName          

END

GO


/****** Object:  StoredProcedure [dbo].[usp_GetSearchPartDetailsNoManufacturer]    Script Date: 01/18/2013 22:52:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchPartDetailsNoManufacturer]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchPartDetailsNoManufacturer]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
    
/*  --------------------------------------------------------------------------    
  -- Name   : [usp_GetSearchPartDetailsNoManufacturer] ManuDist Detailspage    
  -- Description : This Procedure Will Get the ManuDist Details.    
  -- Arguments : DistributorID, PartNumber    
  -- Returns  : List of Parts   
    -- Updated    : 12/26/2012 by parameswar to update for  QtyOnHand field    
  Modifications
  Author			Date		Desc
  Marcus Ruether	01.07.2013	Order by auth status
  Marcus Ruether	01.14.2013  Added check for InventorySettings.DoNotPub
  --------------------------------------------------------------------------    
 --  [dbo].[usp_GetSearchPartDetailsNoManufacturer] '1250'  
 */
CREATE PROCEDURE [dbo].[usp_GetSearchPartDetailsNoManufacturer]  
(    
	@PartNumber VARCHAR(50)    
)    
AS    

--DECLARE @PartNumber VARCHAR(50) = 'wire18awg5black'    

BEGIN    
	SET @PartNumber = dbo.RemoveSpecialCharacter(@PartNumber)    

	SELECT dp.DistID AS DistributorID,     
		p.ProductID,     
		dp.InvID,     
		pt.TypeDescription AS ProductType,    
		'0' AS ManufacturerID,     
		c.CompanyName AS DistributorName,     
		'Manufacturer Unknown' AS ManufacturerName,     
		dp.ManufacturerCode AS DistManufacturerCode,     
		'' AS CompanyLogo,    
		dp.PartNumber,     
		dp.Uploaded,     
		CASE 
			WHEN dp.IsManufacturerProduct = 1 
				THEN 'Inquire'
			WHEN UPPER(ins.QOHDisp) = 'ACTUAL' 
				THEN CONVERT(VARCHAR(25), CONVERT( INT, dp.QtyOnHand)) 
			ELSE ins.QOHDisp 
		END as QtyOnHand,    
		dp.BatchCode,    
		dp.Price,    
		dp.Price1,    
		dp.BreakLevel1,    
		dp.Price2,    
		dp.BreakLevel2,    
		dp.Price3,    
		dp.BreakLevel3,    
		dp.Price4,    
		dp.BreakLevel4,    
		dp.Price5,    
		dp.BreakLevel5,    
		dp.Price6,    
		dp.BreakLevel6,    
		dp.Price7,    
		dp.BreakLevel7,    
		dp.Price8,    
		dp.BreakLevel8,    
		dp.Price9,    
		dp.BreakLevel9,    
		dp.Price10,    
		dp.BreakLevel10,    
		ins.RFQCPID,     
		ins.BuyPentonExpire,     
		ins.BuyPentonURL1,     
		ins.BuyPentonURL2,     
		ins.BuyPentonURL3,     
		ins.BuyPentonURL4,     
		ins.BuyPentonURL5,    
		cast(dp.Description as varchar(max)) AS ColumnDescription,
		IsNULL(RZS.MaxAuth, 0) AS MaxAuth,    
		dbo.Get_SearchCompanyOwn (dp.DistID) AS DistributorAttributes    
	FROM vw_DistributorPartsStatic dp
	INNER JOIN InventorySettings AS ins (NOLOCK)    
		ON ins.CompanyID = dp.DistID
		AND ins.DoNotPub = 0        
	LEFT OUTER JOIN  RegionAuthorization ra (NOLOCK)    
		ON dp.DistID = ra.DistID    
		AND ra.MfrID IS NULL    
	LEFT OUTER JOIN  Company AS c (NOLOCK)    
		ON c.CompanyID = dp.DistID    
		AND c.CompanyStatusID = 1    
		AND c.isActive = 1    
	LEFT OUTER JOIN  (    
		SELECT RZOS.MFRDistID,     
		MAX(    
			CASE     
				WHEN (AuthStatusID  = 2 AND C.Trusted_Disty=1)     
					THEN 4     
				ELSE AuthStatusID     
			END    
		) AS MaxAuth    
		FROM RegionZoneStatus (nolock) AS RZOS    
		INNER JOIN RegionAuthorization (nolock) AS RA    
			ON RZOS.MfrDistID = RA.MfrDistID    
		INNER JOIN Company (nolock) AS C    
			ON C.CompanyID=RA.MfrID    
		GROUP BY RZOS.MfrDistID    
	) AS RZS    
		ON ra.MfrDistID = RZS.MfrDistID    
	LEFT OUTER JOIN
	(
		SELECT MfrID, DistID, SUM(Print_Amount+Online_Amount) as Total
		FROM DistPartsSpend WITH(NOLOCK) 
		GROUP BY MfrID,DistID
	) AS Spend 
		ON RA.MfrID = Spend.MfrID AND RA.DistID = Spend.DistID
	LEFT OUTER JOIN  Product AS p with(nolock)     
		ON dp.PartNumber = p.PartNumber    
		AND p.StatusID = 1    
		AND p.ManufacturerID NOT IN     
		(    
			SELECT DISTINCT xrf.ManufacturerId    
			FROM ManufacturerCode_XRF (NOLOCK) xrf     
			WHERE dp.DistID = xrf.DistributorId     
				AND dp.ManufacturerCode = xrf.ManufacturerCode     
		)    
	LEFT OUTER JOIN productType_XRF AS pt_xrf     
		ON p.ManufacturerID = pt_xrf.ManufacturerID    
		AND p.ProductType = pt_xrf.MfrProdTypeCode    
	LEFT OUTER JOIN ProductType AS pt     
		ON pt_xrf.ProductTypeID = pt.ProductTypeId    
		AND pt.IsActive = 1    
	WHERE dp.Search_PartNumber = @PartNumber
		AND dp.MfrID IS NULL
	ORDER BY 
		CASE 
			WHEN RZS.MaxAuth = 4 
				THEN 1 
			ELSE 0 
		END DESC, 
		Spend.Total DESC,
		c.CompanyName    
END    

GO


/****** Object:  StoredProcedure [dbo].[usp_GetSearchPartDetailsSingleDistributor]    Script Date: 01/18/2013 22:52:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchPartDetailsSingleDistributor]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchPartDetailsSingleDistributor]
GO


/****** Object:  StoredProcedure [dbo].[usp_GetSearchPartDetailsSingleDistributor]    Script Date: 01/18/2013 22:52:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


      
/*  --------------------------------------------------------------------------      
  -- Name   : [usp_GetSearchPartDetailsSingleDistributor] ManuDist Detailspage      
  -- Description : This Procedure Will Get the ManuDist Details.      
  -- Arguments : DistributorID, PartNumber      
  -- Returns  : List of Parts  
  -- Updated    : 12/26/2012 by parameswar to update for  QtyOnHand field   
  Modifications
  Author			Date		Desc
  Marcus Ruether	01.07.2013	Order by auth status  
  Marcus Ruether	01.14.2013  Added check for InventorySettings.DoNotPub
  --------------------------------------------------------------------------      
    ---   [dbo].[usp_GetSearchPartDetailsSingleDistributor] 142175,'1287'  
   */   
  CREATE PROCEDURE [dbo].[usp_GetSearchPartDetailsSingleDistributor]      
   (      
    @companyid INT,      
    @partnumber VARCHAR(50)      
   )      
  AS      
  --DECLARE @CompanyID INT = 106042, @PartNumber VARCHAR(50) = '1287'      
      
  BEGIN      
   SELECT dp.DistID AS DistributorID,       
    p.ProductID,       
    dp.InvID,       
    pt.TypeDescription AS ProductType,      
    c1.CompanyID AS ManufacturerID,       
    c.CompanyName AS DistributorName,       
    c1.CompanyName AS ManufacturerName,       
    dp.ManufacturerCode AS DistManufacturerCode,       
    c1.CompanyLogo,      
    dp.PartNumber,       
    dp.Uploaded,  
   CASE WHEN UPPER(ins.QOHDisp) = 'ACTUAL' THEN  COnvert(varchar(25), dp.QtyOnHand) ELSE ins.QOHDisp END as QtyOnHand,  
    dp.BatchCode,
    dp.Price,      
    dp.Price1,      
    dp.BreakLevel1,      
    dp.Price2,      
    dp.BreakLevel2,      
    dp.Price3,      
    dp.BreakLevel3,      
    dp.Price4,      
    dp.BreakLevel4,      
    dp.Price5,      
    dp.BreakLevel5,      
    dp.Price6,      
    dp.BreakLevel6,      
    dp.Price7,      
    dp.BreakLevel7,      
    dp.Price8,      
    dp.BreakLevel8,      
    dp.Price9,      
    dp.BreakLevel9,      
    dp.Price10,      
    dp.BreakLevel10,      
    ins.RFQCPID,   
    ins.BuyPentonExpire,       
    ins.BuyPentonURL1,       
    ins.BuyPentonURL2,       
    ins.BuyPentonURL3,       
    ins.BuyPentonURL4,       
    ins.BuyPentonURL5,      
    cast(dp.Description as varchar(max)) AS ColumnDescription,       
    IsNULL(RZS.MaxAuth, 0) AS MaxAuth      
   FROM dbo.vw_DistributorPartsStatic AS dp      
   LEFT JOIN RegionAuthorization AS ra       
    ON ra.DistID = dp.DistID      
    AND ra.MfrID = @CompanyID      
   LEFT JOIN Company AS c       
    ON c.isActive = 1      
    AND c.companystatusid = 1      
    AND c.CompanyID = dp.DistID      
   LEFT JOIN Company AS c1       
    ON c1.IsActive = 1      
    AND c1.companystatusid = 1      
    AND c1.CompanyID = dp.MfrID    
   INNER JOIN InventorySettings AS ins       
    ON ins.DoNotPub = 0      
    AND dp.DistID = ins.CompanyID      
   LEFT JOIN (      
      SELECT RZOS.MFRDistID, MAX(CASE WHEN (AuthStatusID  = 2 and C.Trusted_Disty=1) THEN 4 ELSE AuthStatusID END) AS MaxAuth      
      FROM RegionZoneStatus (nolock) AS RZOS,      
        Company (nolock) AS C,      
        RegionAuthorization (nolock) AS RA      
      WHERE  RA.MfrDistID = RZOS.MfrDistID      
        AND RA.MfrID=C.CompanyID      
      GROUP BY RZOS.MfrDistID      
       ) AS RZS      
      ON ra.MfrDistID = RZS.MfrDistID      
   LEFT JOIN Product AS p       
    ON p.StatusID = 1      
    AND dp.PartNumber = p.PartNumber      
    AND dp.MfrID = p.ManufacturerID      
   LEFT JOIN productType_XRF AS pt_xrf       
    ON p.ManufacturerID = pt_xrf.ManufacturerID      
    AND p.ProductType = pt_xrf.MfrProdTypeCode      
   LEFT JOIN ProductType AS pt       
    ON pt.IsActive = 1      
    AND pt_xrf.ProductTypeID = pt.ProductTypeId      
   WHERE [dbo].[RemoveSpecialCharacter](dp.PartNumber) = [dbo].[RemoveSpecialCharacter](@PartNumber)     
   ORDER BY CASE WHEN RZS.MaxAuth = 4 THEN 1 ELSE 0 END desc, c.CompanyName      
          
  END 


GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchPartNumber]    Script Date: 01/10/2013 11:46:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchPartNumber]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchPartNumber]
GO

   
--------------------------------------------------------------------------    
-- Name   : usp_GetSearchPartNumber PartListing  
-- Description : This Procedure Will Get the PartNumber .   
-- Arguments :   
-- Returns  : None  
-----------------------------------------------------------------------  
CREATE PROCEDURE [dbo].[usp_GetSearchPartNumber]
(  
	@PartNumber varchar(100),  
	@startIndex int,  
	@pageSize int  
)  
AS  
--DECLARE @PartNumber VARCHAR(100) = 'a', @startIndex INT = 1, @pageSize INT = 25  
BEGIN  
      SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
      IF (@PartNumber = '0-9') 
         BEGIN
               SELECT DISTINCT
                        PartNumber, ManufacturerName,
                        ManufacturerID
               FROM     (
                         SELECT DISTINCT
                                PartNumber, ManufacturerID,
                                ManufacturerName,
                                ROW_NUMBER() OVER (ORDER BY PartNumber)
                                AS rowNumber
                         FROM   (
                                 SELECT DISTINCT
                                        p.PartNumber AS 'PartNumber',
                                        c.CompanyID AS 'ManufacturerID',
                                        c.CompanyName AS 'ManufacturerName'
                                 FROM   dbo.Product p (NOLOCK)
                                 INNER JOIN dbo.Company c (NOLOCK)
                                        ON p.ManufacturerID = c.CompanyID
                                           AND c.IsActive = 1
                                           AND c.CompanyStatusID = 1
                                 INNER JOIN dbo.ProductType pt (NOLOCK)
                                        ON p.ProductTypeId = pt.ProductTypeId
                                           AND pt.IsActive = 1
                                           AND pt.StatusID = 1
                                 WHERE  p.IsActive = 1
                                        AND p.StatusID = 1
                                        AND (p.PartNumber LIKE '1%'
                                            OR p.PartNumber LIKE '2%'
                                            OR p.PartNumber LIKE '3%'
                                            OR p.PartNumber LIKE '4%'
                                            OR p.PartNumber LIKE '5%'
                                            OR p.PartNumber LIKE '6%'
                                            OR p.PartNumber LIKE '7%'
                                            OR p.PartNumber LIKE '8%'
                                            OR p.PartNumber LIKE '9%'
                                            )
                                 UNION ALL
                                 SELECT DISTINCT
                                        d.PartNumber AS 'PartNumber',
                                        d.MfrID AS 'ManufacturerID',
                                        imc.CompanyName AS 'ManufacturerName'
                                 FROM   vw_DistributorPartsStatic d (NOLOCK)
                                 INNER JOIN dbo.Company c (NOLOCK)
                                        ON d.DistID = c.CompanyID
                                           AND c.IsActive = 1
                                           AND c.CompanyStatusID = 1
                                 LEFT JOIN company imc (NOLOCK)
                                        ON imc.CompanyID = d.MfrID
                                           AND imc.IsActive = 1
                                 WHERE  d.Status = 'Active'
                                        AND (d.PartNumber LIKE '1%'
                                            OR d.PartNumber LIKE '2%'
                                            OR d.PartNumber LIKE '3%'
                                            OR d.PartNumber LIKE '4%'
                                            OR d.PartNumber LIKE '5%'
                                            OR d.PartNumber LIKE '6%'
                                            OR d.PartNumber LIKE '7%'
                                            OR d.PartNumber LIKE '8%'
                                            OR d.PartNumber LIKE '9%'
                                            )
                                ) AS y
                        ) AS x
               WHERE    x.rowNumber BETWEEN @startIndex
                                    AND     @pageSize  
         END
      ELSE 
         BEGIN  
               SELECT DISTINCT
                        PartNumber, ManufacturerID,
                        ManufacturerName
               FROM     (
                         SELECT DISTINCT
                                PartNumber, ManufacturerID,
                                ManufacturerName,
                                ROW_NUMBER() OVER (ORDER BY PartNumber)
                                AS rowNumber
                         FROM   (
                                 SELECT DISTINCT
                                        p.PartNumber AS 'PartNumber',
                                        c.CompanyID AS 'ManufacturerID',
                                        c.CompanyName AS 'ManufacturerName'
                                 FROM   dbo.Product p (NOLOCK)
                                 INNER JOIN dbo.Company c (NOLOCK)
                                        ON p.ManufacturerID = c.CompanyID
                                           AND c.IsActive = 1
                                           AND c.CompanyStatusID = 1
                                 INNER JOIN dbo.ProductType pt (NOLOCK)
                                        ON p.ProductTypeId = pt.ProductTypeId
                                           AND pt.IsActive = 1
                                           AND pt.StatusID = 1
                                 WHERE  p.PartNumber LIKE @PartNumber
                                        + '%'
                                        AND p.StatusID = 1
                                        AND p.IsActive = 1
                                 UNION ALL
                                 SELECT DISTINCT
                                        d.PartNumber AS 'PartNumber',
                                        d.MfrID AS 'ManufacturerID',
                                        imc.CompanyName AS 'ManufacturerName'
                                 FROM   dbo.vw_DistributorPartsStatic
                                        AS d (NOLOCK)
                                 INNER JOIN dbo.Company AS c (NOLOCK)
                                        ON d.DistID = c.CompanyID
                                           AND c.IsActive = 1
                                           AND c.CompanyStatusID = 1
                                 LEFT OUTER JOIN dbo.Company
                                        AS imc
                                        ON d.MfrID = imc.CompanyID
                                           AND imc.IsActive = 1
                                 WHERE  d.Status = 'Active'
                                        AND d.Search_PartNumber LIKE @PartNumber
                                        + '%'
                                ) AS y
                        ) AS x
               WHERE    x.rowNumber BETWEEN @startIndex
                                    AND     @pageSize  
         END  
END  

GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchPartNumberCount]    Script Date: 04/24/2013 10:50:01 ******/
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[usp_GetSearchPartNumberCount]')
                    AND type IN (N'P', N'PC') ) 
   DROP PROCEDURE [dbo].[usp_GetSearchPartNumberCount]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetSearchPartNumberCount]
       (
        @PartNumber VARCHAR(100)
       )
AS 
--DECLARE @PartNumber VARCHAR(100) = 'a'
BEGIN  
	IF (@PartNumber = '0-9') 
		BEGIN  
              WITH  #CTE1
                      AS (
                          SELECT DISTINCT
                                    PartNumber,
                                    ManufacturerName,
                                    ManufacturerID
                          FROM      (
                                    SELECT DISTINCT
                                    PartNumber,
                                    ManufacturerID,
                                    ManufacturerName,
                                    ROW_NUMBER() OVER (ORDER BY PartNumber)
                                    AS rowNumber
                                    FROM
                                    (
                                    SELECT DISTINCT
                                    p.PartNumber AS 'PartNumber',
                                    c.CompanyID AS 'ManufacturerID',
                                    c.CompanyName AS 'ManufacturerName'
                                    FROM
                                    dbo.Product p (NOLOCK)
                                    INNER JOIN dbo.Company c (NOLOCK)
                                    ON p.ManufacturerID = c.CompanyID
                                    AND c.IsActive = 1
                                    AND c.CompanyStatusID = 1
                                    INNER JOIN dbo.ProductType pt (NOLOCK)
                                    ON p.ProductTypeId = pt.ProductTypeId
                                    AND pt.IsActive = 1
                                    AND pt.StatusID = 1
                                    WHERE
                                    p.IsActive = 1
                                    AND p.StatusID = 1
                                    AND (p.PartNumber LIKE '1%'
                                    OR p.PartNumber LIKE '2%'
                                    OR p.PartNumber LIKE '3%'
                                    OR p.PartNumber LIKE '4%'
                                    OR p.PartNumber LIKE '5%'
                                    OR p.PartNumber LIKE '6%'
                                    OR p.PartNumber LIKE '7%'
                                    OR p.PartNumber LIKE '8%'
                                    OR p.PartNumber LIKE '9%'
                                    )
                                    UNION ALL
                                    SELECT DISTINCT
                                    d.PartNumber AS 'PartNumber',
                                    d.MfrID AS 'ManufacturerID',
                                    imc.CompanyName
                                    AS 'ManufacturerName'
                                    FROM
                                    vw_DistributorPartsStatic d (NOLOCK)
                                    INNER JOIN dbo.Company c (NOLOCK)
                                    ON d.DistID = c.CompanyID
                                    AND c.IsActive = 1
                                    AND c.CompanyStatusID = 1
                                    LEFT JOIN company imc (NOLOCK)
                                    ON imc.CompanyID = d.MfrID
                                    AND imc.IsActive = 1
                                    WHERE
                                    d.Status = 'Active'
                                    AND (d.PartNumber LIKE '1%'
                                    OR d.PartNumber LIKE '2%'
                                    OR d.PartNumber LIKE '3%'
                                    OR d.PartNumber LIKE '4%'
                                    OR d.PartNumber LIKE '5%'
                                    OR d.PartNumber LIKE '6%'
                                    OR d.PartNumber LIKE '7%'
                                    OR d.PartNumber LIKE '8%'
                                    OR d.PartNumber LIKE '9%'
                                    )
                                    ) AS y
                                    ) AS x
                         )
                   SELECT   COUNT(*)
                   FROM     #CTE1     

        END   
	ELSE 
        BEGIN  
              WITH  #CTE2
                      AS (
                          SELECT DISTINCT
                                    PartNumber,
                                    ManufacturerID,
                                    ManufacturerName
                          FROM      (
                                    SELECT DISTINCT
                                    PartNumber,
                                    ManufacturerID,
                                    ManufacturerName,
                                    ROW_NUMBER() OVER (ORDER BY PartNumber)
                                    AS rowNumber
                                    FROM
                                    (
                                    SELECT DISTINCT
                                    p.PartNumber AS 'PartNumber',
                                    c.CompanyID AS 'ManufacturerID',
                                    c.CompanyName AS 'ManufacturerName'
                                    FROM
                                    dbo.Product p (NOLOCK)
                                    INNER JOIN dbo.Company c (NOLOCK)
                                    ON p.ManufacturerID = c.CompanyID
                                    AND c.IsActive = 1
                                    AND c.CompanyStatusID = 1
                                    INNER JOIN dbo.ProductType pt (NOLOCK)
                                    ON p.ProductTypeId = pt.ProductTypeId
                                    AND pt.IsActive = 1
                                    AND pt.StatusID = 1
                                    WHERE
                                    p.PartNumber LIKE @PartNumber
                                    + '%'
                                    AND p.StatusID = 1
                                    AND p.IsActive = 1
                                    UNION ALL
                                    SELECT DISTINCT
                                    d.PartNumber AS 'PartNumber',
                                    d.MfrID AS 'ManufacturerID',
                                    imc.CompanyName
                                    AS 'ManufacturerName'
                                    FROM
                                    dbo.vw_DistributorPartsStatic
                                    AS d (NOLOCK)
                                    INNER JOIN dbo.Company
                                    AS c (NOLOCK)
                                    ON d.DistID = c.CompanyID
                                    AND c.IsActive = 1
                                    AND c.CompanyStatusID = 1
                                    LEFT OUTER JOIN dbo.Company
                                    AS imc
                                    ON d.MfrID = imc.CompanyID
                                    AND imc.IsActive = 1
                                    WHERE
                                    d.Status = 'Active'
                                    AND d.Search_PartNumber LIKE @PartNumber
                                    + '%'
                                    ) AS y
                                    ) AS x
                         )
                   SELECT   COUNT(*)
                   FROM     #CTE2  
        END  
END

GO

/****** Object:  StoredProcedure [dbo].[usp_GetUserProfile]    Script Date: 09/24/2011 22:23:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetUserProfile]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetUserProfile]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE  PROCEDURE [dbo].[usp_GetUserProfile]
(
    @LoginName   VARCHAR(50)     
) 
AS
--DECLARE @LoginName VARCHAR(50) = 'tjumps'
BEGIN
      SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
      SELECT    U.UserID, U.LoginName, U.LoginPassword,
                U.FirstName, U.LastName, U.isActive,
                U.UserRecommendFlag, U.UserJobFunctionID,
                U.UserIndustryTypeID, Title,
                U.UserApprovalLevelID, U.PrimarySource,
                UC.EmailAddress, UC.CompanyName,
                UC.CompanyWebsite, UC.Address, UC.City,
                UC.StateID, UC.Zip, UC.CountryID, UC.Phone,
                UC.PhoneExtension, UC.Fax, U.UserRegID,
                C.CountryName, C.CountryCode, CS.StateName,
                U.UserJobFunctionSpecify,
                U.UserIndustryTypeIDSpecify
      FROM      [User] U
      LEFT JOIN dbo.UserContact UC
                ON U.UserID = UC.UserID
      LEFT JOIN Country C
                ON UC.CountryID = C.CountryID
      LEFT JOIN CountryStates CS
                ON UC.CountryID = CS.CountryID
                   AND UC.StateID = CS.StateID
      WHERE     U.LoginName = LTRIM(RTRIM(@LoginName))
END

GO

/****** Object:  StoredProcedure [dbo].[usp_GetUserProfileByID]    Script Date: 12/16/2012 18:07:23 ******/
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   object_id = OBJECT_ID(N'[dbo].[usp_GetUserProfileByID]')
                    AND type IN (N'P', N'PC') ) 
   DROP PROCEDURE [dbo].[usp_GetUserProfileByID]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetUserProfileByID] --24 
(
	@UserID INT
)
AS 
--DECLARE @UserID INT = 89226
       BEGIN        
             SELECT U.UserID, U.LoginName, U.LoginPassword,
                    U.FirstName, U.LastName, U.isActive,
                    U.UserRecommendFlag, U.UserJobFunctionID,
                    U.UserIndustryTypeID, Title,
                    U.UserApprovalLevelID, U.PrimarySource,
                    UC.EmailAddress, UC.CompanyName,
                    UC.CompanyWebsite, UC.Address, UC.City,
                    UC.StateID, UC.Zip, UC.CountryID,
                    UC.Phone, UC.PhoneExtension, UC.Fax,
                    U.UserRegID, C.CountryName,
                    C.CountryCode, CS.StateName,
                    U.UserJobFunctionSpecify,
                    U.UserIndustryTypeIDSpecify
             FROM   [User] U
             LEFT JOIN dbo.UserContact UC
                    ON U.UserID = UC.UserID
             LEFT JOIN Country C
                    ON UC.CountryID = C.CountryID
             LEFT JOIN CountryStates CS
                    ON UC.CountryID = CS.CountryID
                       AND UC.StateID = CS.StateID
             WHERE  U.UserID = @UserID    
       END
GO

/****** Object:  StoredProcedure [dbo].[usp_GetUserProfileByName]    Script Date: 09/24/2011 22:23:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetUserProfileByName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetUserProfileByName]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE  PROCEDURE [dbo].[usp_GetUserProfileByName] ---''admin''    
(
    @LoginName   varchar(100)         
)
AS    
--DECLARE @LoginName VARCHAR(100) = 'tjumps'
BEGIN
      SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
      SELECT    U.UserID, U.LoginName, U.LoginPassword,
                U.FirstName, U.LastName, U.isActive,
                U.UserRecommendFlag, U.UserJobFunctionID,
                U.UserIndustryTypeID, Title,
                U.UserApprovalLevelID, U.PrimarySource,
                UC.EmailAddress, UC.CompanyName,
                UC.CompanyWebsite, UC.Address, UC.City,
                UC.StateID, UC.Zip, UC.CountryID, UC.Phone,
                UC.PhoneExtension, UC.Fax, U.UserRegID,
                C.CountryName, C.CountryCode, CS.StateName,
                U.UserJobFunctionSpecify,
                U.UserIndustryTypeIDSpecify
      FROM      [User] U
      INNER JOIN dbo.UserContact UC
                ON U.UserID = UC.UserID
      LEFT JOIN Country C
                ON UC.CountryID = C.CountryID
      LEFT JOIN CountryStates CS
                ON UC.CountryID = CS.CountryID
                   AND UC.StateID = CS.StateID
      WHERE     U.LoginName = LTRIM(RTRIM(@LoginName))
END
GO

/****** Object:  StoredProcedure [dbo].[usp_GetUserProfileByRegID]    Script Date: 09/24/2011 22:23:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetUserProfileByRegID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetUserProfileByRegID]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetUserProfileByRegID] --15      
(        
	@UserRegID int        
)        
AS        
--DECLARE @UserRegID INT = 100089226
BEGIN        
      SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED     
      SELECT    U.UserID, U.LoginName, U.LoginPassword,
                U.FirstName, U.LastName, U.isActive,
                U.UserRecommendFlag, U.UserJobFunctionID,
                U.UserIndustryTypeID, Title,
                U.UserApprovalLevelID, U.PrimarySource,
                UC.EmailAddress, UC.CompanyName,
                UC.CompanyWebsite, UC.Address, UC.City,
                UC.StateID, UC.Zip, UC.CountryID, UC.Phone,
                UC.PhoneExtension, UC.Fax, U.UserRegID,
                C.CountryName, C.CountryCode, CS.StateName,
                U.UserJobFunctionSpecify,
                U.UserIndustryTypeIDSpecify
      FROM      [User] U
      LEFT JOIN dbo.UserContact UC
                ON U.UserID = UC.UserID
      LEFT JOIN Country C
                ON UC.CountryID = C.CountryID
      LEFT JOIN CountryStates CS
                ON UC.CountryID = CS.CountryID
                   AND UC.StateID = CS.StateID
      WHERE     U.UserRegID = @UserRegID        
END
GO
------------------------------------------------------------------------------------------------------
GO
/****** Object:  StoredProcedure [dbo].[usp_InsertAdApprovalDetails]    Script Date: 04/19/2013 15:54:13 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_InsertAdApprovalDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_InsertAdApprovalDetails]
GO

/****** Object:  StoredProcedure [dbo].[usp_InsertAdApprovalDetails]    Script Date: 04/19/2013 15:54:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




		-- =========================================================================================      
		-- Author		: Sudha 		
		-- Create date	: 6-June-2011
		-- Description	: Insert Ad apporval details  
		-- Modified By	: Nawnit Kumar 		
		-- Modified Date: 8-March-2013 
		-- Description	: Added condition to check if record exists then it'll update the ApprovalRequestDate 
		--				  otherwise it'll insert a new record. 	
		-- Modified By	: Nawnit Kumar 		
		-- Modified Date: 19-April-2013 
		-- Description	: When user send the ad for advertiser approval.
		--				  If the current status is not 4 (Pending AdApproval) then update the status =4 in the AdJobFolderMaster table,  
		--				  Insert a new record in history table with the status = 4, 
		--				  Update the approval request date = current date and set the approval date = null in AdApproval table
	 
		-- ==========================================================================================
		CREATE  PROCEDURE [dbo].[usp_InsertAdApprovalDetails] 
			 
			@orderid int,     
			@jobfolderid int,  
			@Companyname varchar(50),  
			@ToAddress varchar(50),  
			@username varchar(50),  
			@ApprovalRequestBy int,  
			@reguserid varchar(50),  
			@editionid int,  
			@phone varchar(50), 
			@fax varchar(50), 
			@editionname varchar(50),
			@usercontactname varchar(50),
			@pubdate datetime,
			@UserID int,
			@AdApprovalId int output  
		  
		AS  
		      
		BEGIN  
			SET NOCOUNT ON;
			
			--If the current status is not 4 (Pending AdApproval) then update the status =4 in the AdJobFolderMaster table, insert a new record in history table with the status = 4 
			IF EXISTS (SELECT 1   FROM   AdjobFolderMaster  WHERE ADJobFolderID = @jobfolderid AND StatusId <> 4) 
				BEGIN
				
					INSERT INTO AdJobFolderHistory(AdJobFolderId, Statusid, LastUpdatedTimeStamp, UserId)
						   VALUES(@jobfolderid,  4, GETDATE(), @UserID)
					
					UPDATE AdjobFolderMaster SET                         
						   StatusId	= 4 
						   WHERE Adjobfolderid=@jobfolderid			
				END			
			
			-- Check AdJobfolder available in Adapproval table or not
			IF EXISTS (SELECT 1   FROM   Adapproval    WHERE  jobfolderid = @jobfolderid)
				BEGIN	-- If AdJobfolder available in Adapproval table, Update the ApprovalRequestDate as CurrentDate
					
					UPDATE Adapproval SET ApprovalRequestDate = GETDATE(), ApprovalDate = NULL WHERE  jobfolderid = @jobfolderid		
					SELECT @AdApprovalId = AdApprovalId FROM Adapproval WHERE  jobfolderid = @jobfolderid
							
				END
			ELSE 
				BEGIN	-- If AdJobfolder not available in Adapproval table, Insert a new record for AdJobfolder
				  
				  INSERT INTO Adapproval  
				  
						  (  
						   orderid,  
						   ApprovalRequestDate,  
						   jobfolderid,  
						   MailSentCount,  
						   Companyname,  
						   ToAddress,  
						   username,  
						   ApprovalRequestBy,  
						   Reguserid,  
						   Editionid,  
						   phone,
						   fax,
						   editionname,
						   usercontactname,
						   PubDate
						  )             
				  
						 VALUES  
						 (  
						   @orderid,  
						   GETDATE(),  
						   @jobfolderid,  
						   1,  
						   @Companyname,  
						   @ToAddress,  
						   @username,  
						   @ApprovalRequestBy,  
						   @reguserid,  
						   @editionid,  
						   @phone,
						   @fax,
						   @editionname,
						   @usercontactname,
						   @Pubdate  
						   )
						   Set @AdApprovalId=SCOPE_IDENTITY()  
				END 		  
					
					Return @AdApprovalId  
		END
GO
------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsLoad]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsLoad]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsLoad]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsLoad]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate DistributorPartsLoad','';										
	TRUNCATE TABLE DistributorPartsLoad

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Begin Insert into DistributorPartsLoad','';										
	--PRINT 'Get all records from DistributorParts table'
	INSERT INTO DistributorPartsLoad
		(DistID
		,PartNumber
		,ManufacturerID
		,PartUploadDate
		,PartQuantity
		,Price
		,Price1
		,DistributorPartID
		,ROHS
		,IsManufacturerProduct
		,Search_PartNumber
	)
	
	SELECT dp.DistID
		,dp.PartNumber
		,ISNULL(dp.MfrID, 0) as ManufacturerId
		,MAX(dp.Uploaded) as PartUploadDate
		,SUM(ISNULL(dp.QtyOnHand,0)) as PartQuantity
		,MAX(ISNULL(dp.Price,0)) As Price
		,MAX(ISNULL(dp.Price1,0)) As Price1
		,MAX(dp.InvID) As DistributorPartID
		,dp.ROHS
		,dp.IsManufacturerProduct
		,dp.Search_PartNumber
	FROM DistributorPartsStatic_Cache dp  WITH (NOLOCK)
	GROUP BY dp.DistID,dp.MfrID,dp.PartNumber,dp.ROHS,dp.IsManufacturerProduct,dp.Search_PartNumber

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsLoad','';										
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsSearch]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsSearch1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsSearch1]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsSearch]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsSearch]
GO

CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsSearch]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCore'
		ORDER BY pl.LogDate DESC
	);
	---------------------------------------------
	-- DistributorPartsSearch -------------------
	-- Queries that need parts data to match that from solr will be executed against DistributorPartsSearch
	--EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Dropping Indexes on DistributorPartsSearch','';
	
	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch]') AND name = N'IX_DistributorPartSearch_PartNumber_ManufacturerId')
	--	BEGIN
	--		DROP INDEX [IX_DistributorPartSearch_PartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch] WITH ( ONLINE = OFF )	
	--	END
		
	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch]') AND name = N'IX_DistributorPartsSearch_SearchPartNumber_ManufacturerId')
	--	BEGIN
	--		DROP INDEX [IX_DistributorPartsSearch_SearchPartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch] WITH ( ONLINE = OFF )	
	--	END

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch]') AND name = N'IX_DistributorPartID')
	--	BEGIN
	--		DROP INDEX IX_DistributorPartID ON [dbo].[DistributorPartsSearch] WITH ( ONLINE = OFF )	
	--	END

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch]') AND name = N'IX_DistributorPartSearch_DistributorId_SearchPartNumber')
	--	BEGIN
	--		DROP INDEX IX_DistributorPartSearch_DistributorId_SearchPartNumber ON [dbo].[DistributorPartsSearch] WITH ( ONLINE = OFF )	
	--	END

	--EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finished Dropping Indexes on DistributorPartsSearch','';

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate DistributorPartsSearch','';
	
	TRUNCATE TABLE dbo.DistributorPartsSearch

	SET IDENTITY_INSERT [DistributorPartsSearch] ON
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Begin Insert into DistributorPartsSearch','';
	INSERT INTO dbo.DistributorPartsSearch ( [ID],[DistributorId],[DistributorName],[Search_Dist_Name],[DistLogo],[PartNumber],[Search_PartNumber],[ManufacturerCode]
		  ,[ManufacturerId],[ManufacturerName],[Search_MFR_Name],[CompanyLogo],[PartUploadDate],[ProductId],[PartDescription]
		  ,[PartQuantity],[QOHDisp],[Price],[PartDataSheet],[DatasheetLink],[PartSample],[VideoFilePathLink],[ImageFilePathLink]
		  ,[DoNotPub],[ProductTypeId],[ProductTypeDesc],[RFQCPID],[Buy_Button],[DistributorPartID],[ROHS],[HasMfrLogoAd],[IsManufacturerProduct],[ManufacturerSpend] )
	SELECT [ID],[DistributorId],[DistributorName],[Search_Dist_Name],[DistLogo],[PartNumber],[Search_PartNumber],[ManufacturerCode]
		  ,[ManufacturerId],[ManufacturerName],[Search_MFR_Name],[CompanyLogo],[PartUploadDate],[ProductId],[PartDescription]
		  ,[PartQuantity],[QOHDisp],[Price],[PartDataSheet],[DatasheetLink],[PartSample],[VideoFilePathLink],[ImageFilePathLink]
		  ,[DoNotPub],[ProductTypeId],[ProductTypeDesc],[RFQCPID],[Buy_Button],[DistributorPartID],[ROHS],[HasMfrLogoAd],[IsManufacturerProduct],[ManufacturerSpend]
	  FROM [SourceESB].[dbo].[DistributorPartsSearch_Cache]
	  
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsSearch','';

	SET IDENTITY_INSERT [DistributorPartsSearch] OFF

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Creating Indexes on DistributorPartsSearch','';

	/****** Object:  Index [IX_DistributorPartID]    Script Date: 04/10/2013 12:44:04 ******/
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch]') AND name = N'IX_DistributorPartID')
	CREATE NONCLUSTERED INDEX [IX_DistributorPartID] ON [dbo].[DistributorPartsSearch] 
	(	[DistributorPartID] ASC )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		Set NoCount OFF;

	/****** Object:  Index [IX_DistributorPartsSearch_PartNumber_ManufacturerId]    Script Date: 02/04/2013 13:28:12 ******/
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch]') AND name = N'IX_DistributorPartsSearch_PartNumber_ManufacturerId')
	CREATE NONCLUSTERED INDEX [IX_DistributorPartsSearch_PartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch] 
	(
		[PartNumber] ASC,
		[ManufacturerId] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		
	/****** Object:  Index [IX_DistributorPartsSearch_SearchPartNumber_ManufacturerId]    Script Date: 03/05/2013 09:38:24 ******/
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch]') AND name = N'IX_DistributorPartsSearch_SearchPartNumber_ManufacturerId')
	CREATE NONCLUSTERED INDEX [IX_DistributorPartsSearch_SearchPartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch] 
	(
		  [Search_PartNumber] ASC,
		  [ManufacturerId] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]


	/****** Object:  Index [IX_DistributorPartSearch_DistributorId_SearchPartNumber]    Script Date: 03/05/2013 09:38:24 ******/
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch]') AND name = N'IX_DistributorPartSearch_DistributorId_SearchPartNumber')
	CREATE NONCLUSTERED INDEX [IX_DistributorPartSearch_DistributorId_SearchPartNumber] ON [dbo].[DistributorPartsSearch] 
	(
		[DistributorId] ASC,
		[Search_PartNumber] ASC
	)
	INCLUDE 
	(
		[PartNumber],
		[ManufacturerId],
		[ManufacturerName],
		[PartQuantity],
		[PartDataSheet]
	)
	WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finished Creating Indexes on DistributorPartsSearch','';
	
	DECLARE @EndTime DATETIME = (GETDATE());
	
	DECLARE @ActionText VARCHAR(100) = 'END usp_Load_SearchCore at ' + CAST(@EndTime AS VARCHAR);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, @ActionText, '';	
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsSearch_Cache]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsSearch2]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsSearch2]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsSearch_Cache]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsSearch_Cache]
GO

/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
{This should be a short description about the functionality of this procedure.}

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
MM.DD.YYYY		<developer name>		Created. 
04.28.2013		Marcus Ruether		Modified where manufacturer spend was being pulled from
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsSearch_Cache]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate DistributorPartsSearch_Cache','';	
	TRUNCATE TABLE DistributorPartsSearch_Cache;
	
	--EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Start Dropping Indexes on DistributorPartsSearch_Cache','';
	
	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch_Cache]') AND name = N'IX_DistributorPartSearch_PartNumber_ManufacturerId')
	--	BEGIN
	--		DROP INDEX [IX_DistributorPartSearch_PartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch_Cache] WITH ( ONLINE = OFF )	
	--	END
		
	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch_Cache]') AND name = N'IX_DistributorPartsSearch_Cache_SearchPartNumber_ManufacturerId')
	--	BEGIN
	--		DROP INDEX [IX_DistributorPartsSearch_Cache_SearchPartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch_Cache] WITH ( ONLINE = OFF )	
	--	END

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch_Cache]') AND name = N'IX_DistributorPartID')
	--	BEGIN
	--		DROP INDEX IX_DistributorPartID ON [dbo].[DistributorPartsSearch_Cache] WITH ( ONLINE = OFF )	
	--	END

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch_Cache]') AND name = N'IX_DistributorPartSearch_DistributorId_SearchPartNumber')
	--	BEGIN
	--		DROP INDEX IX_DistributorPartSearch_DistributorId_SearchPartNumber ON [dbo].[DistributorPartsSearch_Cache] WITH ( ONLINE = OFF )	
	--	END

	--EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finished Dropping Indexes on DistributorPartsSearch_Cache','';

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into DistributorPartsSearch_Cache','';	
	INSERT INTO DistributorPartsSearch_Cache
	(
		[DistributorId],
		[DistributorName],
		[Search_Dist_Name],
		[DistLogo],
		[PartNumber],
		[Search_PartNumber],
		[ManufacturerId],
		[ManufacturerName],
		[Search_MFR_Name],
		[CompanyLogo],
		[PartUploadDate],
		[ProductId],
		[PartDescription],
		[PartQuantity],
		[QOHDisp],
		[Price],
		[PartDataSheet],
		[DatasheetLink],
		[PartSample],
		[VideoFilePathLink],
		[ImageFilePathLink],
		[DoNotPub],
		[ProductTypeId],
		[ProductTypeDesc],
		[RFQCPID],
		[Buy_Button],
		[DistributorPartID],
		[ROHS],
		[HasMfrLogoAd],
		[IsManufacturerProduct],
		ManufacturerSpend
	)

      SELECT ISNULL(Dist.DistID , 0) AS DistributorId
                  ,C.CompanyName AS DistributorName
                  ,C.Clean_CompanyName AS Search_Dist_Name
                  ,C.CompanyLogo AS DistLogo
                  ,Dist.PartNumber
                  ,Dist.Search_PartNumber
                  ,Dist.ManufacturerId
                  ,ISNULL(C1. CompanyName, 'zzunknown') AS ManufacturerName
                  ,dbo.RemoveSpecialChars(C1.Clean_CompanyName) AS Search_MFR_Name
                  ,C1.CompanyLogo AS CompanyLogo
                  ,Dist.PartUploadDate
                  ,P.ProductID AS ProductId
                  ,ISNULL(P.Description, d.PartDescription) AS PartDescription
                  ,ISNULL(Dist.PartQuantity, 0)
                  ,ISNULL(InS.QOHDisp, 0) as QOHDisp
                  ,CASE WHEN (ISNULL(Dist.Price,0) = 0 AND ISNULL(Dist.Price1,0) <> 0)
                        THEN Dist.Price1
                  ELSE Dist.Price
                  END AS Price
                  ,CASE WHEN ISNULL(P.DataSheet,'') <> '' AND ISNULL(P.DataSheetTitle,'')<> ''  
                          THEN P.DataSheetTitle  
                          ELSE
                              CASE WHEN ISNULL(Ins1.MafSpecURL,'') <> '' AND ISNULL(Ins1.MafSpecTitle,'')<> ''  
                                     THEN Ins1.MafSpecTitle ELSE 'Data Sheet'  
                              END  
                  END AS PartDataSheet  
                  ,CASE WHEN ISNULL(P.DataSheet,'') <> ''  
                          THEN P.DataSheet  
                          ELSE  
                              CASE WHEN ISNULL(Ins1.MafSpecURL,'') <> ''  
                                     THEN Ins1.MafSpecURL  
                              END  
                  END AS DatasheetLink 
                  ,P.SampleUrl AS PartSample
                  ,P.VideoFilePath AS VideoFilePathLink
                  ,P.ImageFilePath AS ImageFilePathLink
                  ,ISNULL(Ins.DoNotPub, 0) as DoNotPub
                  ,ISNULL(PT.ProductTypeId, 0) AS ProductTypeId
                  ,ISNULL(PT.TypeDescription, '') AS ProductTypeDesc
                  ,ISNULL(Ins.RFQCPID, 0) AS RFQCPID
                  ,CASE 
                        WHEN Ins.BuyPentonExpire >= GETDATE() 
                              AND Ins.BuyPentonURL1 IS NOT NULL 
                              AND Ins.BuyPentonURL1 <> '' THEN 1 
                        ELSE 0 
                  END AS Buy_Button
                  ,Dist.DistributorPartID
                  ,CASE Dist.ROHS
                        WHEN 'TRUE' THEN 1 
                        WHEN 'YES' THEN 1
                        WHEN 'Y' THEN 1
                        ELSE 0
                  END AS ROHS
                  ,0 AS HasMFRLogoAd
				  ,Dist.IsManufacturerProduct
				  ,ISNULL(Spend.AmountSpent, 0) AS ManufacturerSpend
      FROM DistributorPartsLoad as Dist
      INNER JOIN Company C
            ON Dist.DistID = C.CompanyID
            AND C.isActive = 1 
            AND C.companystatusid in(1,4)
      INNER JOIN InventorySettings Ins
            ON Dist.DistID = Ins.CompanyID
            AND ISNULL(Ins.DoNotPub, 0) = 0
      LEFT OUTER JOIN Company C1
            ON Dist.ManufacturerId = C1.CompanyID
            AND ISNULL(C1.IsActive, 1) = 1 
      LEFT OUTER JOIN Product P
            ON Dist.PartNumber = P.PartNumber 
            AND Dist.ManufacturerId = P.ManufacturerID
            AND ISNULL(P.IsActive, 1) = 1 
      LEFT OUTER JOIN productType_XRF PT_X
            ON P.ManufacturerID = PT_X.ManufacturerID 
            AND P.ProductType = PT_X.MfrProdTypeCode
      LEFT OUTER JOIN ProductType PT
            ON PT_X.ProductTypeID = PT.ProductTypeId
            AND ISNULL(PT.IsActive,1) = 1
      LEFT OUTER JOIN InventorySettings Ins1
            ON Dist.ManufacturerID = Ins1.CompanyID
      LEFT JOIN ManufacturerPartDescription d
            ON dist.PartNumber = d.PartNumber
            AND Dist.DistID = d.DistributorId
      LEFT JOIN 
			(
				SELECT MfrId,  SUM(AmountSpent) AS AmountSpent
				FROM
				(
					--SELECT [MfrID],[AmountSpent] FROM  [MfrSpend] s
					--UNION --commented out until we can revisit how mfr spend is being determined (Tina says we have values for Mfrs who've not spent money)
					select MfrID, SUM(Online_Amount) + SUM( Print_Amount) As AmountSpent from [DistMfrSpend] s 
					group by MfrID
				) 
				SpendRollup 
				Group By MfrId
			) Spend on Dist.ManufacturerID = Spend.MfrID
      
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsSearch_Cache','';	


	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Start Creating Indexes on DistributorPartsSearch_Cache','';

	/****** Object:  Index [IX_DistributorPartID]    Script Date: 04/10/2013 12:44:04 ******/
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch_Cache]') AND name = N'IX_DistributorPartID')
	CREATE NONCLUSTERED INDEX [IX_DistributorPartID] ON [dbo].[DistributorPartsSearch_Cache] 
	(	[DistributorPartID] ASC )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		Set NoCount OFF;

	/****** Object:  Index [IX_DistributorPartsSearch_Cache_PartNumber_ManufacturerId]    Script Date: 02/04/2013 13:28:12 ******/
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch_Cache]') AND name = N'IX_DistributorPartsSearch_Cache_PartNumber_ManufacturerId')
	CREATE NONCLUSTERED INDEX [IX_DistributorPartsSearch_Cache_PartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch_Cache] 
	(
		[PartNumber] ASC,
		[ManufacturerId] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		
	/****** Object:  Index [IX_DistributorPartsSearch_Cache_SearchPartNumber_ManufacturerId]    Script Date: 03/05/2013 09:38:24 ******/
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch_Cache]') AND name = N'IX_DistributorPartsSearch_Cache_SearchPartNumber_ManufacturerId')
	CREATE NONCLUSTERED INDEX [IX_DistributorPartsSearch_Cache_SearchPartNumber_ManufacturerId] ON [dbo].[DistributorPartsSearch_Cache] 
	(
		  [Search_PartNumber] ASC,
		  [ManufacturerId] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]


	/****** Object:  Index [IX_DistributorPartSearch_DistributorId_SearchPartNumber]    Script Date: 03/05/2013 09:38:24 ******/
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch_Cache]') AND name = N'IX_DistributorPartSearch_DistributorId_SearchPartNumber')
	CREATE NONCLUSTERED INDEX [IX_DistributorPartSearch_DistributorId_SearchPartNumber] ON [dbo].[DistributorPartsSearch_Cache] 
	(
		[DistributorId] ASC,
		[Search_PartNumber] ASC
	)
	INCLUDE 
	(
		[PartNumber],
		[ManufacturerId],
		[ManufacturerName],
		[PartQuantity],
		[PartDataSheet]
	)
	WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finished Creating Indexes on DistributorPartsSearch_Cache','';
	
	DECLARE @EndTime DATETIME = (GETDATE());

	DECLARE @ActionText VARCHAR(100) = 'END usp_Load_SearchCache at ' + CAST(@EndTime AS VARCHAR);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, @ActionText, '';
END
GO


/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsSearch1]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsSearch1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsSearch1]
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsSearch2]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsSearch2]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsSearch2]
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsStatic]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsStatic]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsStatic]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsStatic]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ActionText VARCHAR(100) = '';
	
	DECLARE @ProcessId INT = (SELECT TOP 1 ProcessId FROM MstProcess WHERE ProcessName = 'usp_Load_SearchCore');
	
	DECLARE @ProcessLogId INT = 0;
	
	INSERT INTO ProcessLog VALUES (@ProcessId, GETDATE());
	
	SET @ProcessLogId = @@IDENTITY;
	
	DECLARE @StartTime DATETIME = (GETDATE());
	
	SET @ActionText = 'Begin usp_Load_SearchCore at ' + CAST(@StartTime AS VARCHAR);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, @ActionText, '';
	
	---------------------------------------------
	-- DistributorPartsStatic -------------------
	
	-- Queries that would be using the DistributorParts table for display on the web will instead use this table so it matches the 
	-- results from the last solr load.

	
	--EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Dropping Indexes on DistributorPartsStatic','';

	--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Uploaded_1]') AND type = 'D')
	--BEGIN
	--	ALTER TABLE [dbo].[DistributorPartsStatic] DROP CONSTRAINT [DF_DistributorPartsStatic_Uploaded_1]
	--END

	--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Status_1]') AND type = 'D')
	--BEGIN
	--	ALTER TABLE [dbo].[DistributorPartsStatic] DROP CONSTRAINT [DF_DistributorPartsStatic_Status_1]
	--END

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_PartNumber')
	--	DROP INDEX [IDX_PartNumber] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_DistID_ManCode')
	--	DROP INDEX [IDX_DistID_ManCode] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_DistID_PartNumber_ManuCode_BatchCode')
	--	DROP INDEX [IX_DistID_PartNumber_ManuCode_BatchCode] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_DistID_Uploaded_InvID')
	--	DROP INDEX [IX_DistID_Uploaded_InvID] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_InventoryUpload')
	--	DROP INDEX [IX_InventoryUpload] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_PartNumber_ManuCode_BatchCode')
	--	DROP INDEX [IX_PartNumber_ManuCode_BatchCode] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_PartNumber_ManuCode_DistID')
	--	DROP INDEX [IDX_PartNumber_ManuCode_DistID] ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_Status_PartNumber')
	--	DROP INDEX IDX_Status_PartNumber ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_Status_Search_PartNumber')
	--	DROP INDEX IDX_Status_Search_PartNumber ON [dbo].[DistributorPartsStatic] WITH ( ONLINE = OFF )
		
	--EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finished Dropping Indexes on DistributorPartsStatic','';
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate DistributorPartsStatic','';
		
	TRUNCATE TABLE [DistributorPartsStatic];
	
	SET IDENTITY_INSERT [DistributorPartsStatic] ON
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Begin Insert into DistributorPartsStatic','';

	INSERT INTO [DistributorPartsStatic] (
	   [ManufacturerCode]
      ,[PartNumber]
      ,[Description]
      ,[QtyOnHand]
      ,[Price]
      ,[ROHS]
      ,[BatchCode]
      ,[BreakLevel1]
      ,[Price1]
      ,[BreakLevel2]
      ,[Price2]
      ,[BreakLevel3]
      ,[Price3]
      ,[BreakLevel4]
      ,[Price4]
      ,[BreakLevel5]
      ,[Price5]
      ,[BreakLevel6]
      ,[Price6]
      ,[BreakLevel7]
      ,[Price7]
      ,[BreakLevel8]
      ,[Price8]
      ,[BreakLevel9]
      ,[Price9]
      ,[BreakLevel10]
      ,[Price10]
      ,[DistID]
      ,[Uploaded]
      ,[InvID]
      ,[Status]
      ,[IsManufacturerProduct]
      ,[Search_PartNumber]
      ,[MfrID]
      )
	SELECT 
	   [ManufacturerCode]
      ,[PartNumber]
      ,[Description]
      ,[QtyOnHand]
      ,[Price]
      ,[ROHS]
      ,[BatchCode]
      ,[BreakLevel1]
      ,[Price1]
      ,[BreakLevel2]
      ,[Price2]
      ,[BreakLevel3]
      ,[Price3]
      ,[BreakLevel4]
      ,[Price4]
      ,[BreakLevel5]
      ,[Price5]
      ,[BreakLevel6]
      ,[Price6]
      ,[BreakLevel7]
      ,[Price7]
      ,[BreakLevel8]
      ,[Price8]
      ,[BreakLevel9]
      ,[Price9]
      ,[BreakLevel10]
      ,[Price10]
      ,[DistID]
      ,[Uploaded]
      ,[InvID]
      ,[Status]
      ,[IsManufacturerProduct]
      ,[Search_PartNumber]
      ,[MfrID]
      FROM [DistributorPartsStatic_Cache]
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsStatic','';
	
	SET IDENTITY_INSERT [DistributorPartsStatic] OFF
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Creating Indexes on DistributorPartsStatic','';
	
	--IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Uploaded_1]') AND type = 'D')
	--BEGIN
	--	ALTER TABLE [dbo].[DistributorPartsStatic] ADD  CONSTRAINT [DF_DistributorPartsStatic_Uploaded_1]  DEFAULT (GETDATE()) FOR [Uploaded]
	--END

	--IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Status_1]') AND type = 'D')
	--BEGIN
	--	ALTER TABLE [dbo].[DistributorPartsStatic] ADD  CONSTRAINT [DF_DistributorPartsStatic_Status_1]  DEFAULT ('Active') FOR [Status]
	--END

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_PartNumber')
		CREATE NONCLUSTERED INDEX [IDX_PartNumber] ON [dbo].[DistributorPartsStatic] 
		(
			[Status] ASC,
			[PartNumber] ASC
		)
		INCLUDE ( [ManufacturerCode],
		[DistID]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	IF  NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_DistID_ManCode')
		CREATE NONCLUSTERED INDEX [IDX_DistID_ManCode] ON [dbo].[DistributorPartsStatic] 
		(
			[DistID] ASC,
			[ManufacturerCode] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	IF  NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_DistID_PartNumber_ManuCode_BatchCode')
		CREATE NONCLUSTERED INDEX [IX_DistID_PartNumber_ManuCode_BatchCode] ON [dbo].[DistributorPartsStatic] 
		(
			[DistID] ASC,
			[ManufacturerCode] ASC,
			[PartNumber] ASC,
			[BatchCode] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--IF  NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_DistID_Uploaded_InvID')
	--	CREATE NONCLUSTERED INDEX [IX_DistID_Uploaded_InvID] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		[DistID]
	--	)
	--	INCLUDE ([Uploaded],[InvID]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_InventoryUpload')
	--	CREATE NONCLUSTERED INDEX [IX_InventoryUpload] ON [dbo].[DistributorPartsStatic] 
	--	(
	--		[DistID]
	--	)
	--	INCLUDE ([ManufacturerCode],[PartNumber],[QtyOnHand],[BatchCode],[Uploaded],[InvID])
	--	WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IX_PartNumber_ManuCode_BatchCode')
		CREATE NONCLUSTERED INDEX [IX_PartNumber_ManuCode_BatchCode] ON [dbo].[DistributorPartsStatic] 
		(
			  [ManufacturerCode] ASC,
			  [PartNumber] ASC,
			  [BatchCode] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic]') AND name = N'IDX_PartNumber_ManuCode_DistID')
		CREATE NONCLUSTERED INDEX [IDX_PartNumber_ManuCode_DistID] ON [dbo].[DistributorPartsStatic] 
		(
			[PartNumber]
		)
		INCLUDE ([ManufacturerCode],[DistID])
		WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finished Creating Indexes on DistributorPartsStatic','';
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsStatic_Cache]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsStatic_Cache]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsStatic_Cache]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsStatic_Cache]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	---------------------------------------------
	-- DistributorPartsStatic_Cache -------------------
	
	-- Queries that would be using the DistributorParts table for display on the web will instead use this table so it matches the 
	-- results from the last solr load.
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate DistributorPartsStatic_Cache','';
	TRUNCATE TABLE DistributorPartsStatic_Cache

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'DROP INDEX and CONSTRAINTS ON DistributorPartsStatic_Cache','';
	
	SET IDENTITY_INSERT [DistributorPartsStatic_Cache] ON

	IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Cache_Uploaded_1]') AND type = 'D')
	BEGIN
		ALTER TABLE [dbo].[DistributorPartsStatic_Cache] DROP CONSTRAINT [DF_DistributorPartsStatic_Cache_Uploaded_1]
	END

	IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Cache_Status_1]') AND type = 'D')
	BEGIN
		ALTER TABLE [dbo].[DistributorPartsStatic_Cache] DROP CONSTRAINT [DF_DistributorPartsStatic_Cache_Status_1]
	END

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IDX_PartNumber_ManuCode_DistID')
	--	DROP INDEX [IDX_PartNumber_ManuCode_DistID] ON [dbo].[DistributorPartsStatic_Cache] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IDX_PartNumber')
	--	DROP INDEX IDX_PartNumber ON [dbo].[DistributorPartsStatic_Cache] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IDX_DistID_ManCode')
	--	DROP INDEX IDX_DistID_ManCode ON [dbo].[DistributorPartsStatic_Cache] WITH ( ONLINE = OFF )

	--IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IX_DistID_PartNumber_ManuCode_BatchCode')
	--	DROP INDEX IX_DistID_PartNumber_ManuCode_BatchCode ON [dbo].[DistributorPartsStatic_Cache] WITH ( ONLINE = OFF )

	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IX_DistID_Uploaded_InvID')
		DROP INDEX IX_DistID_Uploaded_InvID ON [dbo].[DistributorPartsStatic_Cache] WITH ( ONLINE = OFF )

	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IX_InventoryUpload')
		DROP INDEX IX_InventoryUpload ON [dbo].[DistributorPartsStatic_Cache] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IX_PartNumber_ManuCode_BatchCode')
	--	DROP INDEX IX_PartNumber_ManuCode_BatchCode ON [dbo].[DistributorPartsStatic_Cache] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IDX_Status_PartNumber')
	--	DROP INDEX IDX_Status_PartNumber ON [dbo].[DistributorPartsStatic_Cache] WITH ( ONLINE = OFF )

	--IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IDX_Status_Search_PartNumber')
	--	DROP INDEX IDX_Status_Search_PartNumber ON [dbo].[DistributorPartsStatic_Cache] WITH ( ONLINE = OFF )


	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into DistributorPartsStatic_Cache','';								
	INSERT INTO DistributorPartsStatic_Cache(
		[ManufacturerCode],
		[PartNumber],
		[Description],[QtyOnHand],[Price],[ROHS],[BatchCode],
		[BreakLevel1],[Price1],[BreakLevel2],[Price2],[BreakLevel3],[Price3],[BreakLevel4],[Price4],[BreakLevel5],[Price5],
		[BreakLevel6],[Price6],[BreakLevel7],[Price7],[BreakLevel8],[Price8],[BreakLevel9],[Price9],[BreakLevel10],[Price10],
		[DistID],[Uploaded],[InvID],[Status],[Search_PartNumber], [MfrID])
	SELECT 
		dp.[ManufacturerCode],
		UPPER(dbo.RemoveStringTerminator(ISNULL(pn.Common_PartNumber, ''))),
		[Description],
		[QtyOnHand],
		[Price],
		[ROHS],
		[BatchCode],
		[BreakLevel1],[Price1],[BreakLevel2],[Price2],[BreakLevel3],[Price3],[BreakLevel4],[Price4],[BreakLevel5],[Price5],
		[BreakLevel6],[Price6],[BreakLevel7],[Price7],[BreakLevel8],[Price8],[BreakLevel9],[Price9],[BreakLevel10],[Price10],
		[DistID],
		[Uploaded],
		[InvID],
		[Status],
		clean.Search_PartNumber,
		xrf.ManufacturerId
	FROM 
		DistributorParts dp WITH (NOLOCK) INNER JOIN
		DistributorParts_Clean clean WITH(NOLOCK) ON dp.partNumber = clean.partnumber LEFT JOIN
		tmp_Load_DistinctPartMfrCodeXRF xrf WITH (NOLOCK) ON dp.ManufacturerCode = xrf.ManufacturerCode
												AND dp.DistID = xrf.DistributorId
												AND clean.Search_PartNumber = xrf.Search_PartNumber LEFT JOIN
		tmp_Load_PartNumber_CommonName pn on clean.Search_PartNumber = pn.Search_PartNumber 
										AND (ISNULL(xrf.ManufacturerId,0) = pn.ManufacturerId)
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsStatic_Cache from DistributorParts','';										
	--WHERE dp.PartNumber IN ('BC546B126','BC546B,126','"BC546B,126"','BC546B.126','MAX705CSA','MAX705CSA+')
	
	SET IDENTITY_INSERT [DistributorPartsStatic_Cache] ON
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_DistributorPartsStatic_CacheFromtmp_Load_Product]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_DistributorPartsStatic_CacheFromtmp_Load_Product]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_DistributorPartsStatic_CacheFromtmp_Load_Product]
GO


CREATE PROCEDURE [dbo].[usp_Load_DistributorPartsStatic_CacheFromtmp_Load_Product]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	SET IDENTITY_INSERT [DistributorPartsStatic_Cache] ON

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Start Insert into DistributorPartsStatic_Cache from tmp_Load_Product (Mfr Products)','';	
	INSERT INTO DistributorPartsStatic_Cache([ManufacturerCode],[PartNumber],[DistID],[Uploaded],[QtyOnHand],[Price],[Price1], [ROHS], [InvID],[Status], [IsManufacturerProduct], [Search_PartNumber])
		SELECT MAX(xrf.ManufacturerCode), pn.Common_PartNumber,p.[DistID],p.PartUploadDate,0,0,0,0,p.DistributorPartID,'Active', 1, pn.Search_PartNumber
		FROM tmp_Load_Product p 
		INNER JOIN DistributorParts_Clean clean WITH (NOLOCK) 
			ON p.PartNumber = clean.PartNumber 
		INNER JOIN tmp_Load_PartNumber_CommonName pn 
			ON clean.Search_PartNumber = pn.Search_PartNumber AND pn.ManufacturerId = p.ManufacturerID
		LEFT OUTER JOIN tmp_Load_DistinctPartMfrCodeXRF xrf 
			ON p.DistID = xrf.DistributorId
			AND p.ManufacturerID = xrf.ManufacturerId 
		GROUP BY p.DistID, p.ManufacturerID, pn.Common_PartNumber, p.PartUploadDate, p.DistributorPartID,  pn.Search_PartNumber
		          
		--	tmp_Load_DistinctPartMfrCodeXRF xrf WITH (NOLOCK) ON dp.ManufacturerCode = xrf.ManufacturerCode
		--										AND dp.DistID = xrf.DistributorId
		--										AND clean.Search_PartNumber = xrf.Search_PartNumber LEFT JOIN
												
		--Search_PartNumber VARCHAR(250),
		--DistributorId INT,
		--ManufacturerId INT,
		--ManufacturerCode VARCHAR(256)
		
	SET IDENTITY_INSERT [DistributorPartsStatic_Cache] OFF
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'CREATE INDEX ON DistributorPartsStatic_Cache','';	

	--IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Cache_Uploaded_1]') AND type = 'D')
	--BEGIN
	--	ALTER TABLE [dbo].[DistributorPartsStatic_Cache] ADD  CONSTRAINT [DF_DistributorPartsStatic_Cache_Uploaded_1]  DEFAULT (GETDATE()) FOR [Uploaded]
	--END

	--IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_DistributorPartsStatic_Cache_Status_1]') AND type = 'D')
	--BEGIN
	--	ALTER TABLE [dbo].[DistributorPartsStatic_Cache] ADD  CONSTRAINT [DF_DistributorPartsStatic_Cache_Status_1]  DEFAULT ('Active') FOR [Status]
	--END


	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IDX_PartNumber')
		CREATE NONCLUSTERED INDEX [IDX_PartNumber] ON [dbo].[DistributorPartsStatic_Cache] 
		(
			[Status] ASC,
			[PartNumber] ASC
		)
		INCLUDE ( [ManufacturerCode],
		[DistID]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	IF  NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IDX_DistID_ManCode')
		CREATE NONCLUSTERED INDEX [IDX_DistID_ManCode] ON [dbo].[DistributorPartsStatic_Cache] 
		(
			[DistID] ASC,
			[ManufacturerCode] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	IF  NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IX_DistID_PartNumber_ManuCode_BatchCode')
		CREATE NONCLUSTERED INDEX [IX_DistID_PartNumber_ManuCode_BatchCode] ON [dbo].[DistributorPartsStatic_Cache] 
		(
			[DistID] ASC,
			[ManufacturerCode] ASC,
			[PartNumber] ASC,
			[BatchCode] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IX_PartNumber_ManuCode_BatchCode')
		CREATE NONCLUSTERED INDEX [IX_PartNumber_ManuCode_BatchCode] ON [dbo].[DistributorPartsStatic_Cache] 
		(
			  [ManufacturerCode] ASC,
			  [PartNumber] ASC,
			  [BatchCode] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IDX_PartNumber_ManuCode_DistID')
		CREATE NONCLUSTERED INDEX [IDX_PartNumber_ManuCode_DistID] ON [dbo].[DistributorPartsStatic_Cache] 
		(
			[PartNumber]
		)
		INCLUDE ([ManufacturerCode],[DistID])
		WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IDX_Status_PartNumber')
		CREATE NONCLUSTERED INDEX [IDX_Status_PartNumber] ON [dbo].[DistributorPartsStatic_Cache] 
		(
			[Status],
			[PartNumber]
		)
		INCLUDE ([DistID],[MfrID])
		WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]


	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsStatic_Cache]') AND name = N'IDX_Status_Search_PartNumber')
		CREATE NONCLUSTERED INDEX [IDX_Status_Search_PartNumber] ON [dbo].[DistributorPartsStatic_Cache] 
		(
			[Status],
			[Search_PartNumber]
		)
		INCLUDE ([PartNumber],[DistID],[MfrID])
		WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into DistributorPartsStatic_Cache from tmp_Load_Product (Mfr Products)','';	
END
GO

/****** Object:  StoredProcedure [dbo].[USP_Load_intoDistributorPartSearch]    Script Date: 01/08/2013 10:53:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_Load_intoDistributorPartSearch]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[USP_Load_intoDistributorPartSearch]
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_MfrDist]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_MfrDist]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_MfrDist]
GO


CREATE PROCEDURE [dbo].[usp_Load_MfrDist]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	--PRINT 'Get all authorized distributor records for Manufacturers with Products'
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_MfrDist','';
	TRUNCATE TABLE tmp_Load_MfrDist

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Begin Insert into tmp_Load_MfrDist','';								
	INSERT INTO tmp_Load_MfrDist
	SELECT ra.MfrID, ra.DistID
	FROM RegionAuthorization ra WITH (NOLOCK)
	INNER JOIN RegionZoneStatus rzs WITH (NOLOCK)
		ON ra.MfrDistID = rzs.MfrDistID
		AND rzs.AuthStatusID = 4
	WHERE ra.IsActive = 1
	AND ra.Publish = 1
	AND ra.MfrID IN (
		SELECT DISTINCT p.ManufacturerID
		FROM tmp_Load_MfrProduct m
		INNER JOIN Product p
		ON m.PartNumber = p.PartNumber
	)
	GROUP BY ra.MfrID, ra.DistID

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into tmp_Load_MfrDist','';								
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_MfrProduct]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_MfrProduct]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_MfrProduct]
GO


CREATE PROCEDURE [dbo].[usp_Load_MfrProduct]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);

	--PRINT 'Get all records from Product table that do NOT match to DistributorParts table'
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_MfrProduct','';
	TRUNCATE TABLE tmp_Load_MfrProduct

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_MfrProduct','';
	INSERT INTO tmp_Load_MfrProduct
	SELECT DISTINCT p.PartNumber
	FROM Product p

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Delete tmp_Load_DistProduct from tmp_Load_MfrProduct','';
	DELETE mp
	FROM tmp_Load_MfrProduct mp
	INNER JOIN tmp_Load_DistProduct dp
		ON mp.PartNumber = dp.PartNumber
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_PartNumber_CommonName]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_PartNumber_CommonName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_PartNumber_CommonName]
GO


CREATE PROCEDURE [dbo].[usp_Load_PartNumber_CommonName]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_PartNumber_CommonName','';
	TRUNCATE TABLE tmp_Load_PartNumber_CommonName

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Drop Indexes on tmp_Load_PartNumber_CommonName','';
	
	--Used in in insert into DistributorPartsStatic_Cache to give part numbers a common name
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_CommonName]') AND name = N'IDX_Search_PartNumber')
	BEGIN
		DROP INDEX IDX_Search_PartNumber ON dbo.tmp_Load_PartNumber_CommonName WITH ( ONLINE = OFF )
	END

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_PartNumber_CommonName','';

	--Used in in insert into DistributorPartsStatic_Cache to give part numbers a common name
	INSERT INTO tmp_Load_PartNumber_CommonName 
	SELECT DISTINCT --Original_PartNumbers.PartNumber AS PartNumber, 
	b.PartNumber AS Common_PartNumber, b.Search_PartNumber, b.ManufacturerId
	FROM
	(
		SELECT a.PartNumber, a.Search_PartNumber, a.ManufacturerId, ROW_NUMBER () OVER (PARTITION BY a.Search_PartNumber, a.ManufacturerId ORDER BY a.DistAdSpend DESC) AS GroupPosition
		FROM
		(
			SELECT dp.PartNumber, Search_PartNumber, dp.ManufacturerId, dp.DistAdSpend
			FROM
			tmp_Load_PartNumber_SearchPartNumber dp WITH (NOLOCK)
		) a
	) b 
	LEFT JOIN
	tmp_Load_PartNumber_SearchPartNumber Original_PartNumbers ON b.Search_PartNumber = Original_PartNumbers.Search_PartNumber 
														AND b.ManufacturerId = Original_PartNumbers.ManufacturerId
	WHERE GroupPosition = 1

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Build Indexes on tmp_Load_PartNumber_CommonName','';


	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_CommonName]') AND name = N'IDX_Search_PartNumber')
	BEGIN
		CREATE INDEX IDX_Search_PartNumber ON tmp_Load_PartNumber_CommonName (Search_PartNumber, ManufacturerId);
	END
					
	--select * from tmp_Load_PartNumber_CommonName

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into tmp_Load_PartNumber_CommonName','';
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_PartNumber_SearchPartNumber]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_PartNumber_SearchPartNumber]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_PartNumber_SearchPartNumber]
GO


CREATE PROCEDURE [dbo].[usp_Load_PartNumber_SearchPartNumber]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_PartNumber_SearchPartNumber','';
	TRUNCATE TABLE tmp_Load_PartNumber_SearchPartNumber
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Drop Indexes on tmp_Load_PartNumber_SearchPartNumber','';

	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_SearchPartNumber]') AND name = N'IDX_PartNumber_SearchPartNumber')
	BEGIN
		DROP INDEX IDX_PartNumber_SearchPartNumber ON dbo.tmp_Load_PartNumber_SearchPartNumber WITH ( ONLINE = OFF )
	END
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_PartNumber_SearchPartNumber','';

	INSERT INTO tmp_Load_PartNumber_SearchPartNumber
	SELECT DISTINCT 
		PartNumber,
		Search_PartNumber,
		Spend,
		ManufacturerId
	FROM
	(
		SELECT PartNumber, Search_PartNumber, Spend, ManufacturerId
		FROM
		(
			SELECT -- Distributors
				dp.PartNumber,
				clean.Search_PartNumber,
				AdSpendRollUp.Spend,
				ISNULL(xrf.ManufacturerId, 0) AS ManufacturerId
			FROM
				DistributorParts dp WITH (NOLOCK) LEFT JOIN
				DistributorParts_Clean clean WITH(NOLOCK) on dp.partnumber = clean.partnumber LEFT JOIN
				tmp_Load_DistinctPartMfrCodeXRF xrf WITH (NOLOCK) ON dp.ManufacturerCode = xrf.ManufacturerCode 
														AND dp.DistID = xrf.DistributorId
														AND xrf.Search_PartNumber = clean.Search_PartNumber LEFT JOIN
				Company mfr ON xrf.ManufacturerId = mfr.CompanyID AND mfr.CompanyStatusID = 1 LEFT JOIN --active
				-- We just want some credible Distributor, those who spend money tend to be more credible. We'll use their description of the part for all other disty's
				(SELECT SUM(Online_Amount) as Spend, DistID FROM
				  dbo.DistPartsSpend s WITH (NOLOCK)
				  GROUP BY DistID   
				) AdSpendRollUp ON dp.DistID = AdSpendRollUp.DistId
				--where dp.PartNumber IN ('BC546B126','BC546B,126','�BC546B,126�','BC546B.126','MAX705CSA','MAX705CSA+') 
			UNION
		SELECT -- Manufacturers
			p.PartNumber,
			UPPER(dbo.RemoveSpecialChars(p.PartNumber)) AS Search_PartNumber,
			0,
			p.ManufacturerID
		FROM
			Product p WITH (NOLOCK) INNER JOIN
			Company c on p.ManufacturerID = c.CompanyId AND c.CompanyStatusID = 1 --active
		--WHERE p.PartNumber IN ('BC546B126','BC546B,126','"BC546B,126"','BC546B.126','MAX705CSA','MAX705CSA+')
		) a 
	) b
	
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Build Indexes on tmp_Load_PartNumber_SearchPartNumber','';
	
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_PartNumber_SearchPartNumber]') AND name = N'IDX_PartNumber_SearchPartNumber')
	BEGIN
		CREATE INDEX IDX_PartNumber_SearchPartNumber ON tmp_Load_PartNumber_SearchPartNumber (Search_PartNumber, ManufacturerId)
	END

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Finish Insert into tmp_Load_PartNumber_SearchPartNumber','';
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_Product]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_Product]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_Product]
GO


CREATE PROCEDURE [dbo].[usp_Load_Product]
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @ProcessLogId INT = 
	(
		SELECT TOP 1 ProcessLogId 
		FROM dbo.MstProcess AS mp
		INNER JOIN dbo.ProcessLog AS pl
			ON mp.ProcessId = pl.ProcessId
		WHERE mp.ProcessName = 'usp_Load_SearchCache'
		ORDER BY pl.LogDate DESC
	);
	--PRINT 'Roll up all records that do NOT match to DistributorParts table and add authorizated distributors'
	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Truncate tmp_Load_Product','';
	TRUNCATE TABLE tmp_Load_Product

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Drop indexes on tmp_Load_Product','';
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_Product]') AND name = N'IX_PartNumber')
	BEGIN
		DROP INDEX [IX_PartNumber] ON [dbo].[tmp_Load_Product] 
	END

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Reseed tmp_Load_Product to avoid identity conflict in DistributorPartsStatic_Cache','';
	DECLARE @seed INT = (
		SELECT MAX(InvID) + 1
		FROM dbo.DistributorPartsStatic_Cache AS dpsc
	)

	DBCC CHECKIDENT (tmp_Load_Product, RESEED, @seed)

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Insert into tmp_Load_Product','';								
	INSERT INTO tmp_Load_Product
	(DistID, ManufacturerID, PartNumber, PartUploadDate)
	SELECT md.DistributorID, md.ManufacturerID, mp.PartNumber,
		COALESCE(p.CreatedOn, p.LastUpdatedOn, GETDATE()) AS PartUploadDate
	FROM tmp_Load_MfrDist md
	INNER JOIN Product p WITH (NOLOCK)
		ON md.ManufacturerID = p.ManufacturerID
	INNER JOIN tmp_Load_MfrProduct mp WITH (NOLOCK)
		ON p.PartNumber = mp.PartNumber

	EXEC dbo.usp_LogProcessAction @ProcessLogId, 'Create indexes on tmp_Load_Product','';
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_Load_Product]') AND name = N'IX_PartNumber')
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_PartNumber] ON [dbo].[tmp_Load_Product] 
		(
			  [PartNumber] ASC
		)WITH (STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	END
END
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_ReloadDistributorParts_Clean]    Script Date: 01/18/2013 22:51:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_ReloadDistributorParts_Clean]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[usp_Load_ReloadDistributorParts_Clean]
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_ReloadDistributorParts_Clean]    Script Date: 01/18/2013 22:51:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

  CREATE PROCEDURE [dbo].[usp_Load_ReloadDistributorParts_Clean]  
  AS          
        
  BEGIN          
		TRUNCATE TABLE dbo.DistributorParts_Clean

		INSERT INTO dbo.DistributorParts_Clean
		SELECT dps.PartNumber, dbo.RemoveSpecialCharacter(dps.PartNumber) 
		FROM dbo.DistributorPartsSearch2 AS dps
		WHERE dps.PartNumber IS NOT NULL 
			AND LEN(dps.PartNumber) > 2
		GROUP BY dps.PartNumber
  END 
  
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_SearchCache]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_SearchCache]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_SearchCache]
GO

/****** Object:  StoredProcedure [dbo].[usp_Load_SearchCore]    Script Date: 03/12/2013 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_SearchCore]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_SearchCore]
GO

/****** Object:  StoredProcedure [dbo].[usp_Process_CompanyProductType_ChangeQue]    Script Date: 03/25/2013 13:55:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Process_CompanyProductType_ChangeQue]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Process_CompanyProductType_ChangeQue]
GO


/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Intended to be a scheduled process.  Triggers were added to many company related tables to log changes.  The processing inside of them
caused some functions in the admin to run very slow.  The trigger is still in place, but now just does an insert, and the processing
functionlity to find the diffs is now in this procedure.  Purpose is to log only fields that have had a value change.

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
03.22.2013		Marcus Ruether		Created. 
MM.DD.YYYY		<developer name>		<Changes made.> 
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[usp_Process_CompanyProductType_ChangeQue]
AS
BEGIN

	DECLARE @CurrentPrimaryKeyId INT;

	DECLARE @LogTableColumnId INT;
	DECLARE @ColumnName VARCHAR(MAX);
	
	DECLARE @NewSql NVARCHAR(1000);
	DECLARE @OldSQL NVARCHAR(1000);
	DECLARE @NewValue VARCHAR(100);
	DECLARE @OldValue VARCHAR(100);
	DECLARE @RecordDescription VARCHAR(256);
	DECLARE @UserId INT;
	DECLARE @ProcessLogId INT;
	DECLARE @UpdateTime DATETIME;
	
	
	-- Change Events
	DECLARE CUR_PROCESSLOGIDS CURSOR FOR
	SELECT DISTINCT ProcessLogId FROM CompanyProductType_ChangeQue WITH(NOLOCK)
	
	OPEN CUR_PROCESSLOGIDS;
	
	FETCH NEXT FROM CUR_PROCESSLOGIDS INTO @ProcessLogId;
	
	WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @UserId = (SELECT TOP 1 UserId FROM CompanyProductType_ChangeQue q WHERE q.ProcessLogId = @ProcessLogId);
			SET @UpdateTime = (SELECT TOP 1 DateLogged FROM CompanyProductType_ChangeQue q WHERE q.ProcessLogId = @ProcessLogId);
		
			SELECT * 
			INTO #DELETED_CACHE
			FROM CompanyProductType_ChangeQue q WITH(NOLOCK)
			
			WHERE
				q.ProcessLogId = @ProcessLogId AND
				q.IsInsert = 0;
				
			SELECT * 
			INTO #INSERTED_CACHE
			FROM CompanyProductType_ChangeQue q WITH(NOLOCK)
			WHERE
				q.ProcessLogId = @ProcessLogId AND
				q.IsInsert = 1;	
	
			DECLARE @action as VARCHAR(6);
			SET @action = 'INSERT'; -- Set Action to Insert by default.
			IF (EXISTS(SELECT * FROM #DELETED_CACHE) AND EXISTS(SELECT * FROM #INSERTED_CACHE))
				BEGIN
					SET @action = 'UPDATE';
				END
			ELSE IF (EXISTS(SELECT * FROM #DELETED_CACHE) AND NOT EXISTS(SELECT * FROM #INSERTED_CACHE))
				BEGIN
					SET @action = 'DELETE';
				END

			DECLARE @CompanyId INT = 0;
			
			
			--Run through affected records
			
			--put these into temp tables so the can by accessed by dynamic sql
			--not the best, but only I could think of to make this generic.
			SELECT *
			INTO #inserted
			FROM #INSERTED_CACHE
			
			SELECT * 
			INTO #deleted
			FROM #DELETED_CACHE
			
			DECLARE CUR_MSTLOGTABLECOLUMNS CURSOR FOR
			SELECT LogTableColumnId, ColumnName
			FROM 
				MstLogTableColumns c INNER JOIN
				MstLogTable t ON c.LogTableId = t.LogTableId
			WHERE
				t.LogTableName = 'CompanyProductType'
			
			
			DECLARE CUR_AFFECTED_RECORDS CURSOR FOR
			SELECT CompProdTypeID FROM #INSERTED_CACHE
				UNION
			SELECT CompProdTypeID From #DELETED_CACHE
			
			OPEN CUR_AFFECTED_RECORDS;
			
			FETCH NEXT FROM CUR_AFFECTED_RECORDS INTO @CurrentPrimaryKeyId;
			
			WHILE @@FETCH_STATUS = 0
				BEGIN
				
						IF @action = 'DELETE'
							BEGIN
						SET @CompanyId = (SELECT TOP 1 CompanyId FROM #DELETED_CACHE where CompProdTypeID = @CurrentPrimaryKeyId);
						SET @RecordDescription = (SELECT TOP 1 TypeDescription FROM
												#DELETED_CACHE m INNER JOIN 
												ProductType p on m.ProductTypeID = p.ProductTypeId
												WHERE m.CompProdTypeID = @CurrentPrimaryKeyId);
					END
				ELSE
					BEGIN
						SET @CompanyId = (SELECT TOP 1 CompanyId FROM #INSERTED_CACHE where CompProdTypeID = @CurrentPrimaryKeyId);
						SET @RecordDescription = (SELECT TOP 1 TypeDescription FROM
												#INSERTED_CACHE m INNER JOIN 
												ProductType p on m.ProductTypeID = p.ProductTypeId
												WHERE m.CompProdTypeID = @CurrentPrimaryKeyId);
						END
			
					OPEN CUR_MSTLOGTABLECOLUMNS;
					
					FETCH NEXT FROM CUR_MSTLOGTABLECOLUMNS INTO @LogTableColumnId, @ColumnName;
					
					WHILE @@FETCH_STATUS = 0
						BEGIN
					SET @NewSql = N'(SELECT TOP 1 @NewValue = LEFT(CAST(' + @ColumnName + N' AS VARCHAR(100)), 100) FROM #inserted WHERE CompProdTypeID = ' + CAST(@CurrentPrimaryKeyId AS VARCHAR(100)) + N')';
					SET @OldSql = N'(SELECT TOP 1 @OldValue = LEFT(CAST(' + @ColumnName + N' AS VARCHAR(100)), 100) FROM #deleted WHERE CompProdTypeID = ' + CAST(@CurrentPrimaryKeyId AS VARCHAR(100)) + N')';
						
							EXEC sp_executesql 
								@statement = @NewSql,
								@parameters = N'@NewValue VARCHAR(100) OUTPUT',
								@NewValue = @NewValue OUTPUT 
							EXEC sp_executesql 
								@statement = @OldSql,
								@parameters = N'@OldValue VARCHAR(100) OUTPUT',
								@OldValue = @OldValue OUTPUT 	
							print @ColumnName + ' || New = ' + ISNULL(CAST(@NewValue AS VARCHAR(100)), '') + ' Old = ' + ISNULL(CAST(@OldValue AS VARCHAR(100)), '');
							IF ISNULL(CAST(@NewValue AS VARCHAR(100)), '') <> ISNULL(CAST(@OldValue AS VARCHAR(100)), '')
							BEGIN
								INSERT INTO UpdateLog (
									PrimaryKey, 
									LogTableColumnId, 
									NewValue, 
									OldValue,
									ChangeDate, 
									CompanyId, 
									[Action],
									RecordDescription,
									UserId
								)
								VALUES (
									@CurrentPrimaryKeyId, 
									@LogTableColumnId,
									@NewValue,
									@OldValue,
									@UpdateTime,
									@CompanyId,
									@action,
									@RecordDescription,
									@UserId
								)
							END
							
							FETCH NEXT FROM CUR_MSTLOGTABLECOLUMNS INTO @LogTableColumnId, @ColumnName;
						END
						
					CLOSE CUR_MSTLOGTABLECOLUMNS; --reset the cursor
					
					FETCH NEXT FROM CUR_AFFECTED_RECORDS INTO @CurrentPrimaryKeyId;
					
				END -- END CUR_AFFECTED_RECORDS
				
			DEALLOCATE CUR_MSTLOGTABLECOLUMNS;
			
			CLOSE CUR_AFFECTED_RECORDS;
			DEALLOCATE CUR_AFFECTED_RECORDS;
			
			IF OBJECT_ID('tempdb..#inserted') IS NOT NULL
			BEGIN
				DROP TABLE #inserted;	
			END
			
			IF OBJECT_ID('tempdb..#INSERTED_CACHE') IS NOT NULL
			BEGIN
				DROP TABLE #INSERTED_CACHE;	
			END
			
			IF OBJECT_ID('tempdb..#deleted') IS NOT NULL
			BEGIN
				DROP TABLE #deleted;	
			END
			
			IF OBJECT_ID('tempdb..#DELETED_CACHE') IS NOT NULL
			BEGIN
				DROP TABLE #DELETED_CACHE;	
			END
			
			DELETE FROM CompanyProductType_ChangeQue
			WHERE ProcessLogId = @ProcessLogId
				
			FETCH NEXT FROM CUR_PROCESSLOGIDS INTO @ProcessLogId;
		END -- END CUR_PROCESSLOGIDS
	
	CLOSE CUR_PROCESSLOGIDS;
	DEALLOCATE CUR_PROCESSLOGIDS;	

END

GO





-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_Process_RegionZoneStatus_ChangeQue]    Script Date: 03/25/2013 13:55:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Process_RegionZoneStatus_ChangeQue]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Process_RegionZoneStatus_ChangeQue]
GO

-- usp_Process_RegionZoneStatus_ChangeQue
/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Intended to be a scheduled process.  Triggers were added to many company related tables to log changes.  The processing inside of them
caused some functions in the admin to run very slow.  The trigger is still in place, but now just does an insert, and the processing
functionlity to find the diffs is now in this procedure.  Purpose is to log only fields that have had a value change.

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
03.22.2013		Marcus Ruether		Created. 
04.26.2013		Tim Jumps			Ticket 27168. Add CompanyID to ChangeQue table
MM.DD.YYYY		<developer name>		<Changes made.> 
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[usp_Process_RegionZoneStatus_ChangeQue]
AS
BEGIN

	DECLARE @CurrentPrimaryKeyId INT;

	DECLARE @LogTableColumnId INT;
	DECLARE @ColumnName VARCHAR(MAX);
	
	DECLARE @NewSql NVARCHAR(1000);
	DECLARE @OldSQL NVARCHAR(1000);
	DECLARE @NewValue VARCHAR(100);
	DECLARE @OldValue VARCHAR(100);
	DECLARE @RecordDescription VARCHAR(256);
	DECLARE @UserId INT;
	DECLARE @ProcessLogId INT;
	DECLARE @UpdateTime DATETIME;
	
	
	-- Change Events
	DECLARE CUR_PROCESSLOGIDS CURSOR FOR
	SELECT DISTINCT ProcessLogId FROM RegionZoneStatus_ChangeQue WITH(NOLOCK)
	
	OPEN CUR_PROCESSLOGIDS;
	
	FETCH NEXT FROM CUR_PROCESSLOGIDS INTO @ProcessLogId;
	
	WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @UserId = (SELECT TOP 1 UserId FROM RegionZoneStatus_ChangeQue q WHERE q.ProcessLogId = @ProcessLogId);
			SET @UpdateTime = (SELECT TOP 1 DateLogged FROM RegionZoneStatus_ChangeQue q WHERE q.ProcessLogId = @ProcessLogId);
		
			SELECT * 
			INTO #DELETED_CACHE
			FROM RegionZoneStatus_ChangeQue q WITH(NOLOCK)
			
			WHERE
				q.ProcessLogId = @ProcessLogId AND
				q.IsInsert = 0;
				
			SELECT * 
			INTO #INSERTED_CACHE
			FROM RegionZoneStatus_ChangeQue q WITH(NOLOCK)
			WHERE
				q.ProcessLogId = @ProcessLogId AND
				q.IsInsert = 1;	
	
			DECLARE @action as VARCHAR(6);
			SET @action = 'INSERT'; -- Set Action to Insert by default.
			IF (EXISTS(SELECT * FROM #DELETED_CACHE) AND EXISTS(SELECT * FROM #INSERTED_CACHE))
				BEGIN
					SET @action = 'UPDATE';
				END
			ELSE IF (EXISTS(SELECT * FROM #DELETED_CACHE) AND NOT EXISTS(SELECT * FROM #INSERTED_CACHE))
				BEGIN
					SET @action = 'DELETE';
				END

			DECLARE @CompanyId INT = 0;
			
			
			--Run through affected records
			
			--put these into temp tables so the can by accessed by dynamic sql
			--not the best, but only I could think of to make this generic.
			SELECT *
			INTO #inserted
			FROM #INSERTED_CACHE
			
			SELECT * 
			INTO #deleted
			FROM #DELETED_CACHE
			
			DECLARE CUR_MSTLOGTABLECOLUMNS CURSOR FOR
			SELECT LogTableColumnId, ColumnName
			FROM 
				MstLogTableColumns c INNER JOIN
				MstLogTable t ON c.LogTableId = t.LogTableId
			WHERE
				t.LogTableName = 'RegionZoneStatus'
			
			
			DECLARE CUR_AFFECTED_RECORDS CURSOR FOR
			SELECT ZoneKeyID FROM #INSERTED_CACHE
				UNION
			SELECT ZoneKeyID From #DELETED_CACHE
			
			OPEN CUR_AFFECTED_RECORDS;
			
			FETCH NEXT FROM CUR_AFFECTED_RECORDS INTO @CurrentPrimaryKeyId;
			
			WHILE @@FETCH_STATUS = 0
				BEGIN
			
					IF @action = 'DELETE'
						BEGIN
							SELECT @CompanyId = d.CompanyID FROM #DELETED_CACHE AS d WHERE d.ZoneKeyId = @CurrentPrimaryKeyId;
							SET @RecordDescription = (SELECT TOP 1 ISNULL(cmp.CompanyName + ' - ', '') + ISNULL(rg.RegionName, '') + ' - ' + ISNULL(ISNULL(z.ZoneName, c.CountryName), '')
														FROM #DELETED_CACHE r INNER JOIN
														Region rg on r.RegionID = rg.RegionID LEFT JOIN
														RegionAuthorization ra on r.MfrDistID = ra.MfrDistID LEFT JOIN
														--RegionAuthorization may have been deleted before this record is deleted.  Try to pull from previous log.
														UpdateLog ul ON ra.MfrDistID IS NULL AND r.MfrDistID = ISNULL(ul.NewValue, ul.OldValue) AND ul.LogTableColumnId = 92 LEFT JOIN-- 92 = RegionAuthorization.MfrDistID
														UpdateLog ul1 on ul.PrimaryKey = ul1.PrimaryKey and ul.ChangeDate = ul1.ChangeDate and ul.LogTableColumnId = 93 LEFT JOIN -- 92 = RegionAuthorization.MfrDistID
														Company cmp ON ISNULL(ra.MfrID, ISNULL(ul1.NewValue, ul1.OldValue)) = cmp.CompanyID LEFT JOIN
														CountryZones z on r.ZoneID = z.ZoneID AND rg.RegionID IN ('1','2') LEFT JOIN
														Country c ON r.ZoneID = c.CountryID AND rg.RegionID NOT IN ('1','2')
														WHERE r.ZoneKeyId = @CurrentPrimaryKeyId)
						END
					ELSE
						BEGIN
							SELECT @CompanyId = i.CompanyID FROM #INSERTED_CACHE AS i WHERE i.ZoneKeyId = @CurrentPrimaryKeyId;
							SET @RecordDescription = (SELECT TOP 1 ISNULL(cmp.CompanyName + ' - ', '') + ISNULL(rg.RegionName, '') + ' - ' + ISNULL(ISNULL(z.ZoneName, c.CountryName), '')
														FROM #INSERTED_CACHE r INNER JOIN
														Region rg on r.RegionID = rg.RegionID LEFT JOIN
														RegionAuthorization ra on r.MfrDistID = ra.MfrDistID LEFT JOIN
														Company cmp ON ra.MfrID = cmp.CompanyID LEFT JOIN 
														CountryZones z on r.ZoneID = z.ZoneID AND rg.RegionID IN ('1','2') LEFT JOIN
														Country c ON r.ZoneID = c.CountryID AND rg.RegionID NOT IN ('1','2')
														WHERE r.ZoneKeyId = @CurrentPrimaryKeyId)
						END
			
					OPEN CUR_MSTLOGTABLECOLUMNS;
					
					FETCH NEXT FROM CUR_MSTLOGTABLECOLUMNS INTO @LogTableColumnId, @ColumnName;
					
					WHILE @@FETCH_STATUS = 0
						BEGIN
							SET @NewSql = N'(SELECT TOP 1 @NewValue = LEFT(CAST(' + @ColumnName + N' AS VARCHAR(100)), 100) FROM #inserted WHERE ZoneKeyID = ' + CAST(@CurrentPrimaryKeyId AS VARCHAR(100)) + N')';
							SET @OldSql = N'(SELECT TOP 1 @OldValue = LEFT(CAST(' + @ColumnName + N' AS VARCHAR(100)), 100) FROM #deleted WHERE ZoneKeyID = ' + CAST(@CurrentPrimaryKeyId AS VARCHAR(100)) + N')';
						
							EXEC sp_executesql 
								@statement = @NewSql,
								@parameters = N'@NewValue VARCHAR(100) OUTPUT',
								@NewValue = @NewValue OUTPUT 
							EXEC sp_executesql 
								@statement = @OldSql,
								@parameters = N'@OldValue VARCHAR(100) OUTPUT',
								@OldValue = @OldValue OUTPUT 	
							print @ColumnName + ' || New = ' + ISNULL(CAST(@NewValue AS VARCHAR(100)), '') + ' Old = ' + ISNULL(CAST(@OldValue AS VARCHAR(100)), '');
							IF ISNULL(CAST(@NewValue AS VARCHAR(100)), '') <> ISNULL(CAST(@OldValue AS VARCHAR(100)), '')
							BEGIN
								INSERT INTO UpdateLog (
									PrimaryKey, 
									LogTableColumnId, 
									NewValue, 
									OldValue,
									ChangeDate, 
									CompanyId, 
									[Action],
									RecordDescription,
									UserId
								)
								VALUES (
									@CurrentPrimaryKeyId, 
									@LogTableColumnId,
									@NewValue,
									@OldValue,
									@UpdateTime,
									@CompanyId,
									@action,
									@RecordDescription,
									@UserId
								)
							END
							
							FETCH NEXT FROM CUR_MSTLOGTABLECOLUMNS INTO @LogTableColumnId, @ColumnName;
						END
						
					CLOSE CUR_MSTLOGTABLECOLUMNS; --reset the cursor
					
					FETCH NEXT FROM CUR_AFFECTED_RECORDS INTO @CurrentPrimaryKeyId;
					
				END -- END CUR_AFFECTED_RECORDS
				
			DEALLOCATE CUR_MSTLOGTABLECOLUMNS;
			
			CLOSE CUR_AFFECTED_RECORDS;
			DEALLOCATE CUR_AFFECTED_RECORDS;
			
			IF OBJECT_ID('tempdb..#inserted') IS NOT NULL
			BEGIN
				DROP TABLE #inserted;	
			END
			
			IF OBJECT_ID('tempdb..#INSERTED_CACHE') IS NOT NULL
			BEGIN
				DROP TABLE #INSERTED_CACHE;	
			END
			
			IF OBJECT_ID('tempdb..#deleted') IS NOT NULL
			BEGIN
				DROP TABLE #deleted;	
			END
			
			IF OBJECT_ID('tempdb..#DELETED_CACHE') IS NOT NULL
			BEGIN
				DROP TABLE #DELETED_CACHE;	
			END
			
			DELETE FROM RegionZoneStatus_ChangeQue
			WHERE ProcessLogId = @ProcessLogId
			
			FETCH NEXT FROM CUR_PROCESSLOGIDS INTO @ProcessLogId;
		END -- END CUR_PROCESSLOGIDS
	
	CLOSE CUR_PROCESSLOGIDS;
	DEALLOCATE CUR_PROCESSLOGIDS;	

END

GO


-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------




/****** Object:  StoredProcedure [dbo].[usp_ProcessInventoryUpload]    Script Date: 01/23/2013 14:29:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_ProcessInventoryUpload]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_ProcessInventoryUpload]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_ProcessInventoryUpload]
(
	@CompanyId INT,
	@InventoryUploadHistoryId INT,
	@FileType CHAR(5)
)
AS

--DECLARE @CompanyId INT = 144697, @InventoryUploadHistoryId INT = 18177, @FileType CHAR(5)='.csv'

BEGIN
	SET NOCOUNT OFF

	DECLARE @updatedCount INT = 0;
	DECLARE @insertedCount INT = 0;
	DECLARE @updatedCountGroup INT = 0;
	DECLARE @insertedCountGroup INT = 0;
	DECLARE @iterationCount INT = 0;
	DECLARE @textHolder AS VARCHAR(MAX) = '';
	DECLARE @maxRecords INT 
	DECLARE @uploadDateTimeStamp DATETIME = GETDATE()

	DECLARE @SQL VARCHAR(MAX)
	
	--PRINT 'Set all NULL values on keys to empty string for performance increase'
	UPDATE dp
	SET PartNumber = ''
	FROM DistributorParts dp
	WHERE dp.PartNumber IS NULL
	
	UPDATE dp
	SET ManufacturerCode = ''
	FROM DistributorParts dp
	WHERE dp.ManufacturerCode IS NULL

	UPDATE dp
	SET BatchCode = ''
	FROM DistributorParts dp
	WHERE dp.BatchCode IS NULL

	UPDATE dp
	SET BatchCode = ''
	FROM DistributorParts dp
	WHERE dp.BatchCode = '0'
		
	UPDATE tmpI
	SET PartNumber = ''
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.PartNumber IS NULL
		
	UPDATE tmpI
	SET Prefix = ''
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.Prefix IS NULL
	
	UPDATE tmpI
	SET ManufacturerCode = ''
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.ManufacturerCode IS NULL
	
	UPDATE tmpI
	SET ManufacturerCode = LEFT(tmpI.ManufacturerCode, 50)
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.ManufacturerCode IS NULL

	UPDATE tmpI
	SET BatchCode = ''
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.BatchCode IS NULL

	UPDATE tmpI
	SET BatchCode = ''
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.BatchCode = '0'
	
	--PRINT 'Remove white space from composite key fields to match more accurately'
	UPDATE tmpI
	SET ManufacturerCode = LEFT(LTRIM(RTRIM([ManufacturerCode])), 50), 
		PartNumber = LEFT(LTRIM(RTRIM([PartNumber])), 250), 
		BatchCode = LEFT(LTRIM(RTRIM(tmpI.[BatchCode])), 50),
		Prefix = LEFT(LTRIM(RTRIM(tmpI.Prefix)), 250)
	FROM tmpInventoryUpload tmpI

	--PRINT 'Remove non-numeric , character from QOH field because it makes casting to numeric fail'
	UPDATE tmpI
	SET QtyOnHand = REPLACE(RTRIM(LTRIM(tmpI.QtyOnHand)), ',', '')
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.QtyOnHand LIKE ('%,%')
	
	--PRINT 'Remove non-numeric characters from QOH field'
	UPDATE tmpI
	SET QtyOnHand = ''
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.QtyOnHand IN ('-','+','.', ',') 
	
	--PRINT 'Update Prefix to concatenate with PartNumber'
	UPDATE tmpI
	SET PartNumber = tmpI.Prefix + tmpI.PartNumber
	FROM tmpInventoryUpload tmpI
	WHERE tmpI.Prefix <> ''

	-- Log the number of records with concatenated part numbers
	EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'PrefixAddedToPartNumberFieldCount', @@ROWCOUNT, 0
				
	--PRINT 'Remove Part Numbers 2 characters or less from tmp'
	INSERT INTO dbo.InventoryUploadHistoryReject 
		(InventoryUploadHistoryID,RejectReason,ManufacturerCode,Prefix,PartNumber,Description,QtyOnHand, Price,RoHS, BatchCode,
		   BreakLevel1,Price1,BreakLevel2,Price2,BreakLevel3,Price3,BreakLevel4,Price4,BreakLevel5,Price5,
		   BreakLevel6,Price6,BreakLevel7,Price7,BreakLevel8,Price8,BreakLevel9,Price9,BreakLevel10,Price10, InventoryID)
	SELECT @InventoryUploadHistoryId, 'Invalid Part Number',  tmpI.ManufacturerCode, tmpI.Prefix, tmpI.PartNumber,tmpI.Description, tmpI.QtyOnHand, 
			tmpI.Price, tmpI.RoHS, tmpI.BatchCode, tmpI.BreakLevel1,tmpI.Price1, tmpI.BreakLevel2, tmpI.Price2,tmpI.BreakLevel3, tmpI.Price3, 
			tmpI.BreakLevel4,tmpI.Price4, tmpI.BreakLevel5, tmpI.Price5,tmpI.BreakLevel6, tmpI.Price6, tmpI.BreakLevel7,tmpI.Price7, 
			tmpI.BreakLevel8, tmpI.Price8,tmpI.BreakLevel9, tmpI.Price9, tmpI.BreakLevel10,tmpI.Price10, tmpI.InventoryID
	FROM tmpInventoryUpload tmpI
	WHERE LEN(tmpI.PartNumber) <= 2
	
	DELETE tmpI
	FROM tmpInventoryUpload tmpI
	WHERE LEN(tmpI.PartNumber) <= 2

	-- Log the number of records deleted from invalid part number
	EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'InvalidPartNumberFieldCount', @@ROWCOUNT, 0

	--PRINT 'Remove non-numeric QOH records from tmp'
	INSERT INTO dbo.InventoryUploadHistoryReject 
		(InventoryUploadHistoryID,RejectReason,ManufacturerCode,Prefix,PartNumber,Description,QtyOnHand, Price,RoHS, BatchCode,
		   BreakLevel1,Price1,BreakLevel2,Price2,BreakLevel3,Price3,BreakLevel4,Price4,BreakLevel5,Price5,
		   BreakLevel6,Price6,BreakLevel7,Price7,BreakLevel8,Price8,BreakLevel9,Price9,BreakLevel10,Price10, InventoryID)
	SELECT @InventoryUploadHistoryId, 'Invalid Quantity',  tmpI.ManufacturerCode, tmpI.Prefix, tmpI.PartNumber,tmpI.Description, tmpI.QtyOnHand, 
			tmpI.Price, tmpI.RoHS, tmpI.BatchCode, tmpI.BreakLevel1,tmpI.Price1, tmpI.BreakLevel2, tmpI.Price2,tmpI.BreakLevel3, tmpI.Price3, 
			tmpI.BreakLevel4,tmpI.Price4, tmpI.BreakLevel5, tmpI.Price5,tmpI.BreakLevel6, tmpI.Price6, tmpI.BreakLevel7,tmpI.Price7, 
			tmpI.BreakLevel8, tmpI.Price8,tmpI.BreakLevel9, tmpI.Price9, tmpI.BreakLevel10,tmpI.Price10, tmpI.InventoryID
	FROM tmpInventoryUpload tmpI
	WHERE (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.QtyOnHand)) = '' THEN 1
				WHEN tmpI.QtyOnHand IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.QtyOnHand) = 0 THEN 0
				WHEN tmpI.QtyOnHand LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.QtyOnHand AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.QtyOnHand) <= 0) AND (LEN(tmpI.QtyOnHand) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.QtyOnHand) > 0) AND (LEN(LEFT(tmpI.QtyOnHand, CHARINDEX('.', tmpI.QtyOnHand) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0

	DELETE tmpI
	FROM tmpInventoryUpload tmpI
	WHERE (
			CASE 
				WHEN RTRIM(LTRIM(tmpI.QtyOnHand)) = '' THEN 1
				WHEN tmpI.QtyOnHand IS NULL THEN 1
				WHEN ISNUMERIC(tmpI.QtyOnHand) = 0 THEN 0
				WHEN tmpI.QtyOnHand LIKE '%[^-+. 0-9]%' THEN 0
				WHEN CAST(tmpI.QtyOnHand AS NUMERIC(38, 0)) NOT BETWEEN -2147483648. AND 2147483647. THEN 0
				WHEN (CHARINDEX('.', tmpI.QtyOnHand) <= 0) AND (LEN(tmpI.QtyOnHand) > 12) THEN 0
				WHEN (CHARINDEX('.', tmpI.QtyOnHand) > 0) AND (LEN(LEFT(tmpI.QtyOnHand, CHARINDEX('.', tmpI.QtyOnHand) - 1)) > 12) THEN 0
				ELSE 1
			END
	) = 0

	-- Log the number of records deleted from invalid quantity
	EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'InvalidQtyFieldCount', @@ROWCOUNT, 0
	

	-- Check Zero QOH field. If set, remove 0 QOH records. Otherwise, delete existing records that have zero QOH
	IF (
		SELECT InvS.AllowZeroQOH
		FROM InventorySettings InvS
		WHERE InvS.CompanyID = @CompanyId
	) = 0
	BEGIN
		--PRINT 'Remove zero quantity records'
		DELETE dp
		FROM DistributorParts dp
		INNER JOIN tmpInventoryUpload tmpI
			ON dp.PartNumber = tmpI.PartNumber
			AND dp.ManufacturerCode = tmpI.ManufacturerCode
			AND dp.BatchCode = tmpI.BatchCode
		WHERE dp.DistID = @CompanyId
			AND CAST(CAST(LTRIM(RTRIM(tmpI.QtyOnHand)) AS FLOAT) AS INT) <= 0

		INSERT INTO dbo.InventoryUploadHistoryReject 
			(InventoryUploadHistoryID,RejectReason,ManufacturerCode,Prefix,PartNumber,Description,QtyOnHand, Price,RoHS, BatchCode,
			   BreakLevel1,Price1,BreakLevel2,Price2,BreakLevel3,Price3,BreakLevel4,Price4,BreakLevel5,Price5,
			   BreakLevel6,Price6,BreakLevel7,Price7,BreakLevel8,Price8,BreakLevel9,Price9,BreakLevel10,Price10, InventoryID)
		SELECT @InventoryUploadHistoryId, 'Zero Quantity',  tmpI.ManufacturerCode, tmpI.Prefix, tmpI.PartNumber,tmpI.Description, tmpI.QtyOnHand, 
				tmpI.Price, tmpI.RoHS, tmpI.BatchCode, tmpI.BreakLevel1,tmpI.Price1, tmpI.BreakLevel2, tmpI.Price2,tmpI.BreakLevel3, tmpI.Price3, 
				tmpI.BreakLevel4,tmpI.Price4, tmpI.BreakLevel5, tmpI.Price5,tmpI.BreakLevel6, tmpI.Price6, tmpI.BreakLevel7,tmpI.Price7, 
				tmpI.BreakLevel8, tmpI.Price8,tmpI.BreakLevel9, tmpI.Price9, tmpI.BreakLevel10,tmpI.Price10, tmpI.InventoryID
		FROM tmpInventoryUpload tmpI
		WHERE ISNULL(CAST(CAST(LTRIM(RTRIM(tmpI.QtyOnHand)) AS FLOAT) AS INT),0) <= 0

		DELETE tmpI
		FROM tmpInventoryUpload tmpI
		WHERE ISNULL(CAST(CAST(LTRIM(RTRIM(tmpI.QtyOnHand)) AS FLOAT) AS INT), 0) <= 0

		-- Log the number of 0 QOH records deleted.
		EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'ZeroQtyFieldCount', @@ROWCOUNT, 0
	END

	--PRINT 'Remove non-numeric Price/Break records from tmp'
	EXEC dbo.usp_ProcessInventoryUpload_RejectPriceBreak @InventoryUploadHistoryID

	--PRINT 'Remove duplicate records'
	TRUNCATE TABLE dbo.tmpInventoryUpload_DUP

	INSERT INTO dbo.tmpInventoryUpload_DUP(PartNumber,ManufacturerCode,BatchCode,QtyOnHand,InventoryID)
		SELECT tmpI.PartNumber,tmpI.ManufacturerCode,tmpI.BatchCode, SUM(CAST(CAST(LTRIM(RTRIM([QtyOnHand])) AS FLOAT) AS BIGINT)), MAX(InventoryID) AS InventoryID
		FROM tmpInventoryUpload tmpI WITH(NOLOCK)
		GROUP BY tmpI.PartNumber,tmpI.ManufacturerCode,tmpI.BatchCode
		HAVING COUNT(*) > 1

	UPDATE t
	SET QtyOnHand = td.QtyOnHand
	FROM dbo.tmpInventoryUpload AS t
	INNER JOIN dbo.tmpInventoryUpload_DUP AS td
		ON t.InventoryID = td.InventoryID
		
	DELETE tmpI
	FROM tmpInventoryUpload tmpI
	INNER JOIN dbo.tmpInventoryUpload_DUP AS tmpD
		ON tmpI.PartNumber = tmpD.PartNumber
		AND tmpI.ManufacturerCode = tmpD.ManufacturerCode
		AND tmpI.BatchCode = tmpD.BatchCode	
		AND tmpI.InventoryID <> tmpD.InventoryID
			
	--Log the number of records that are duplicates.
	EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'DuplicateRecordCount', @@ROWCOUNT, 0

	DECLARE @insertRecordCount INT
	SELECT @insertRecordCount = COUNT(*)
	FROM DistributorParts dp (NOLOCK)
	WHERE dp.DistID = @CompanyId
		AND DATEADD(dd, DATEDIFF(dd, 0, dp.Uploaded), 0) = DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0)

	SELECT @insertRecordCount =  @insertRecordCount + COUNT(*)
	FROM
	(
		SELECT tmpI.PartNumber, tmpI.ManufacturerCode, tmpI.BatchCode
		FROM tmpInventoryUpload tmpI WITH(NOLOCK)
		WHERE tmpI.PartNumber + '|' + tmpI.ManufacturerCode NOT IN
		(
			SELECT DISTINCT tmpI.PartNumber + '|' + tmpI.ManufacturerCode
			FROM tmpInventoryUpload tmpI
			GROUP BY tmpI.PartNumber, tmpI.ManufacturerCode
			HAVING COUNT (*) > 1
		)				
		GROUP BY tmpI.PartNumber, tmpI.ManufacturerCode, tmpI.BatchCode
		HAVING COUNT (*) = 1
	) as tmp

	SELECT @insertRecordCount = @insertRecordCount + COUNT(*)
	FROM
	(
		SELECT tmpI.PartNumber, tmpI.ManufacturerCode
		FROM tmpInventoryUpload tmpI WITH(NOLOCK)
		GROUP BY tmpI.PartNumber, tmpI.ManufacturerCode
		HAVING COUNT (*) > 1
	) as tmp

	TRUNCATE TABLE tmpInventoryUpload_INS
	WHILE 1 = 1 
	BEGIN
		SET @iterationCount = @iterationCount + 1
		TRUNCATE TABLE tmpInventoryUpload_LA
		INSERT INTO tmpInventoryUpload_LA
		SELECT TOP 10000 
			[ManufacturerCode],[PartNumber],[Description],[QtyOnHand],[Price],[RoHS],[BatchCode],
			[BreakLevel1],[Price1],[BreakLevel2],[Price2],[BreakLevel3],[Price3],[BreakLevel4],[Price4],[BreakLevel5],[Price5],
			[BreakLevel6],[Price6],[BreakLevel7],[Price7],[BreakLevel8],[Price8],[BreakLevel9],[Price9],[BreakLevel10],[Price10],
			[InventoryID]
		FROM tmpInventoryUpload tmpI

		--PRINT 'Store existing records that match'
		TRUNCATE TABLE tmpInventoryUpload_UPD

		INSERT INTO tmpInventoryUpload_UPD
		SELECT dp.PartNumber, dp.ManufacturerCode, dp.BatchCode 
		FROM DistributorParts dp WITH(NOLOCK, INDEX(IX_DistID_PartNumber_ManuCode_BatchCode))
		INNER JOIN tmpInventoryUpload_LA tmpI WITH(NOLOCK)
			ON dp.PartNumber = tmpI.PartNumber
			AND dp.ManufacturerCode = tmpI.ManufacturerCode
			AND dp.BatchCode = tmpI.BatchCode
		WHERE dp.DistID = @CompanyId
		GROUP BY dp.ManufacturerCode, dp.PartNumber, dp.BatchCode 

		--PRINT 'Delete existing matches'
		DELETE dp
		FROM DistributorParts dp
		INNER JOIN tmpInventoryUpload_LA tmpI WITH(NOLOCK)
			ON dp.PartNumber = tmpI.PartNumber
			AND dp.ManufacturerCode = tmpI.ManufacturerCode
			AND dp.BatchCode = tmpI.BatchCode
		WHERE dp.DistID = @CompanyId

		--PRINT 'Insert Existing matches'
		INSERT INTO DistributorParts
		(
			[ManufacturerCode] ,
			[PartNumber] ,
			[Description],
			[QtyOnHand],
			[Price],
			[ROHS] ,
			[BatchCode] ,
			[BreakLevel1],
			[Price1],
			[BreakLevel2],
			[Price2],
			[BreakLevel3],
			[Price3],
			[BreakLevel4],
			[Price4],
			[BreakLevel5],
			[Price5],
			[BreakLevel6],
			[Price6],
			[BreakLevel7],
			[Price7],
			[BreakLevel8],
			[Price8],
			[BreakLevel9],
			[Price9],
			[BreakLevel10],
			[Price10],
			[DistID]
		)
		SELECT 
			LEFT(LTRIM(RTRIM(tmpI.[ManufacturerCode])), 50) ,
			UPPER(LEFT(LTRIM(RTRIM(tmpI.[PartNumber])), 250)) ,

			CASE 
				WHEN [Description] IS NOT NULL AND [Description] <> '0' 
					THEN LTRIM(RTRIM([Description]))
			END,
			
			CAST(CAST(LTRIM(RTRIM([QtyOnHand])) AS FLOAT) AS BIGINT),
			CAST(LTRIM(RTRIM([Price])) AS FLOAT),

			CASE LEFT(LTRIM(RTRIM([ROHS])), 50)
				WHEN 'Yes' THEN 'True'
				WHEN 'Y' THEN 'True'
				ELSE 'False'
			END,

			CASE 
				WHEN tmpI.[BatchCode] IS NOT NULL AND tmpI.[BatchCode] <> '0' 
					THEN LEFT(LTRIM(RTRIM(tmpI.[BatchCode])), 50)
			END,
			CASE 
				WHEN [BreakLevel1] IS NOT NULL AND [BreakLevel1] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel1])) AS INT)
			END,
			CASE 
				WHEN [Price1] IS NOT NULL AND [Price1] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price1])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel2] IS NOT NULL AND [BreakLevel2] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel2])) AS INT)
			END,
			CASE 
				WHEN [Price2] IS NOT NULL AND [Price2] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price2])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel3] IS NOT NULL AND [BreakLevel3] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel3])) AS INT)
			END,
			CASE 
				WHEN [Price3] IS NOT NULL AND [Price3] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price3])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel4] IS NOT NULL AND [BreakLevel4] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel4])) AS INT)
			END,
			CASE 
				WHEN [Price4] IS NOT NULL AND [Price4] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price4])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel5] IS NOT NULL AND [BreakLevel5] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel5])) AS INT)
			END,
			CASE 
				WHEN [Price5] IS NOT NULL AND [Price5] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price5])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel6] IS NOT NULL AND [BreakLevel6] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel6])) AS INT)
			END,
			CASE 
				WHEN [Price6] IS NOT NULL AND [Price6] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price6])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel7] IS NOT NULL AND [BreakLevel7] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel7])) AS INT)
			END,
			CASE 
				WHEN [Price7] IS NOT NULL AND [Price7] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price7])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel8] IS NOT NULL AND [BreakLevel8] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel8])) AS INT)
			END,
			CASE 
				WHEN [Price8] IS NOT NULL AND [Price8] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price8])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel9] IS NOT NULL AND [BreakLevel9] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel9])) AS INT)
			END,
			CASE 
				WHEN [Price9] IS NOT NULL AND [Price9] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price9])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel10] IS NOT NULL AND [BreakLevel10] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel10])) AS INT)
			END,
			CASE 
				WHEN [Price10] IS NOT NULL AND [Price10] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price10])) AS FLOAT)
			END,
			@CompanyId
		FROM tmpInventoryUpload_UPD dp WITH(NOLOCK)
		INNER JOIN tmpInventoryUpload_LA tmpI WITH(NOLOCK)
			ON dp.PartNumber = tmpI.PartNumber
			AND dp.ManufacturerCode = tmpI.ManufacturerCode
			AND dp.BatchCode = tmpI.BatchCode
		
		SET @updatedCountGroup = @@ROWCOUNT
		SET @updatedCount = @updatedCount + @updatedCountGroup
		SET @textHolder = 'UpdatedCount Group ' + CAST(@iterationCount AS VARCHAR(50)) --can't concate string and pass into sp at the same time

		-- Log the number of records updated (meaning an existing match was found, that match was deleted and the new data was inserted).
		EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, @textHolder, @updatedCountGroup, 0

		--PRINT 'Delete existing matches from temp table'
		DELETE tmpInventoryUpload_LA
		FROM tmpInventoryUpload_UPD dp WITH(NOLOCK)
		INNER JOIN tmpInventoryUpload_LA tmpLA
			ON dp.PartNumber = tmpLA.PartNumber
			AND dp.ManufacturerCode = tmpLA.ManufacturerCode
			AND dp.BatchCode = tmpLA.BatchCode
	
		--PRINT 'Insert clean data'
		INSERT INTO dbo.tmpInventoryUpload_INS 
		(
			ManufacturerCode,PartNumber,Description,QtyOnHand, Price,RoHS, BatchCode,
			BreakLevel1, Price1,BreakLevel2, Price2,BreakLevel3, Price3,BreakLevel4, Price4,BreakLevel5, Price5,
			BreakLevel6, Price6,BreakLevel7, Price7,BreakLevel8, Price8,BreakLevel9, Price9,BreakLevel10,Price10,
			InventoryID
		)
		SELECT 
			LEFT(LTRIM(RTRIM([ManufacturerCode])), 50) ,
			UPPER(LEFT(LTRIM(RTRIM([PartNumber])), 250)) ,

			CASE 
				WHEN [Description] IS NOT NULL AND [Description] <> '0' 
					THEN LTRIM(RTRIM([Description]))
			END,
			
			CAST(CAST(LTRIM(RTRIM([QtyOnHand])) AS FLOAT) AS BIGINT),
			CAST(LTRIM(RTRIM([Price])) AS FLOAT),

			CASE LEFT(LTRIM(RTRIM([ROHS])), 50)
				WHEN 'Yes' THEN 'True'
				WHEN 'Y' THEN 'True'
				ELSE 'False'
			END,

			CASE 
				WHEN [BatchCode] IS NOT NULL AND [BatchCode] <> '0' 
					THEN LEFT(LTRIM(RTRIM([BatchCode])), 50)
			END,
			CASE 
				WHEN [BreakLevel1] IS NOT NULL AND [BreakLevel1] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel1])) AS INT)
			END,
			CASE 
				WHEN [Price1] IS NOT NULL AND [Price1] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price1])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel2] IS NOT NULL AND [BreakLevel2] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel2])) AS INT)
			END,
			CASE 
				WHEN [Price2] IS NOT NULL AND [Price2] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price2])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel3] IS NOT NULL AND [BreakLevel3] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel3])) AS INT)
			END,
			CASE 
				WHEN [Price3] IS NOT NULL AND [Price3] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price3])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel4] IS NOT NULL AND [BreakLevel4] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel4])) AS INT)
			END,
			CASE 
				WHEN [Price4] IS NOT NULL AND [Price4] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price4])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel5] IS NOT NULL AND [BreakLevel5] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel5])) AS INT)
			END,
			CASE 
				WHEN [Price5] IS NOT NULL AND [Price5] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price5])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel6] IS NOT NULL AND [BreakLevel6] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel6])) AS INT)
			END,
			CASE 
				WHEN [Price6] IS NOT NULL AND [Price6] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price6])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel7] IS NOT NULL AND [BreakLevel7] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel7])) AS INT)
			END,
			CASE 
				WHEN [Price7] IS NOT NULL AND [Price7] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price7])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel8] IS NOT NULL AND [BreakLevel8] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel8])) AS INT)
			END,
			CASE 
				WHEN [Price8] IS NOT NULL AND [Price8] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price8])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel9] IS NOT NULL AND [BreakLevel9] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel9])) AS INT)
			END,
			CASE 
				WHEN [Price9] IS NOT NULL AND [Price9] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price9])) AS FLOAT)
			END,
			CASE 
				WHEN [BreakLevel10] IS NOT NULL AND [BreakLevel10] <> '0' 
					THEN CAST(LTRIM(RTRIM([BreakLevel10])) AS INT)
			END,
			CASE 
				WHEN [Price10] IS NOT NULL AND [Price10] <> '0' 
					THEN CAST(LTRIM(RTRIM([Price10])) AS FLOAT)
			END,
			InventoryID
		FROM tmpInventoryUpload_LA WITH(NOLOCK)
		
		--PRINT 'Delete the part from table in memory'
		DELETE FROM tmpInventoryUpload_LA

		--PRINT 'Delete the part from table in memory'
		DELETE tmpInventoryUpload
		WHERE InventoryID IN
		(SELECT TOP 10000 InventoryID FROM tmpInventoryUpload)

		DECLARE @tmpRowCount INT = @@ROWCOUNT				            
		PRINT CAST(@tmpRowCount AS VARCHAR(10)) + ' records updated'

		SET @updatedCountGroup = 0;

		IF @tmpRowCount < 10000
			BREAK
	END

	SELECT @maxRecords = InvS.MaxRecords
	FROM InventorySettings InvS
	WHERE InvS.CompanyID = @CompanyId
	
	IF (@insertRecordCount > @maxRecords)
	BEGIN
		--PRINT 'Remove more than max rows from tmp'
		DELETE 
		FROM tmpInventoryUpload_INS
		WHERE InventoryID IN (
			SELECT TOP (@insertRecordCount - @maxRecords) InventoryID 
			FROM tmpInventoryUpload_INS WITH(NOLOCK)
			ORDER BY InventoryID DESC
		)
			
		-- Log the number of records deleted from being over the max inventory threshhold.
		EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'OverLimitCount', @@ROWCOUNT, 0
	END

	SET @iterationCount = 0
	WHILE 1 = 1 
	BEGIN
		SET @iterationCount = @iterationCount + 1
		
		INSERT INTO dbo.DistributorParts 
		(
			ManufacturerCode,PartNumber, Description,QtyOnHand, Price, ROHS,BatchCode, 
			BreakLevel1,Price1, BreakLevel2,Price2, BreakLevel3,Price3, BreakLevel4,Price4, BreakLevel5,Price5, 
			BreakLevel6,Price6, BreakLevel7,Price7, BreakLevel8,Price8, BreakLevel9,Price9, BreakLevel10,Price10, 
			DistID
		)
		SELECT TOP 10000 
			[ManufacturerCode] ,
			[PartNumber] ,
			[Description],
			[QtyOnHand],
			[Price],
			[ROHS] ,
			[BatchCode] ,
			[BreakLevel1],
			[Price1],
			[BreakLevel2],
			[Price2],
			[BreakLevel3],
			[Price3],
			[BreakLevel4],
			[Price4],
			[BreakLevel5],
			[Price5],
			[BreakLevel6],
			[Price6],
			[BreakLevel7],
			[Price7],
			[BreakLevel8],
			[Price8],
			[BreakLevel9],
			[Price9],
			[BreakLevel10],
			[Price10],
			@CompanyId
		FROM tmpInventoryUpload_INS tmpI

		SET @insertedCountGroup = @@ROWCOUNT
		SET @insertedCount = @insertedCount + @insertedCountGroup
		
		SET @textHolder = 'InsertedCount Group ' + CAST(@iterationCount AS VARCHAR(50))--can't concate string and pass into sp at the same time

		-- Log the number of records inserted.
		EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, @textHolder, @insertedCountGroup, 0


		--PRINT 'Delete the part from table in memory'
		DELETE tmpInventoryUpload_INS
		WHERE InventoryID IN
		(SELECT TOP 10000 InventoryID FROM tmpInventoryUpload_INS)


		SET @tmpRowCount = @@ROWCOUNT				            
		PRINT CAST(@tmpRowCount AS VARCHAR(10)) + ' records updated'

		SET @insertedCountGroup = 0;

		IF @tmpRowCount < 10000
			BREAK
	END

	IF (@insertedCount + @updatedCount) > 0
	AND 
	(
		SELECT DeleteOLDInv
		FROM InventorySettings InvS
		WHERE InvS.CompanyID = @CompanyId
	) = 1
	BEGIN
		DECLARE @currentDate DATETIME = GetDate()

		--PRINT 'Remove old parts'
		DELETE dp
		FROM DistributorParts dp
		WHERE dp.DistID=@CompanyId
			AND DATEADD(dd, DATEDIFF(dd, 0, dp.Uploaded), 0) < DATEADD(dd, DATEDIFF(dd, 0, @currentDate), 0)

		-- Log the number of old records deleted. Does not count towards total of parts records processed.
		EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'OldPartsDeleteCount', @@ROWCOUNT, 0
	END

	-- update distributorpartcount table. do not log. If not exists, create record.
	IF NOT EXISTS 
	(
		SELECT *
		FROM DistributorPartCount dpc WITH(NOLOCK)
		WHERE dpc.DistID = @CompanyId
	)
	BEGIN
		INSERT INTO DistributorPartCount
		SELECT @CompanyId, COUNT(*)
		FROM DistributorParts dp (NOLOCK)
		WHERE dp.DistID = @CompanyId
	END
	ELSE
	BEGIN
		UPDATE dpc
		SET PartCount = 
		(
			SELECT COUNT(*)
			FROM DistributorParts dp (NOLOCK)
			WHERE dp.DistID = @CompanyId
		)
		FROM DistributorPartCount dpc
		WHERE DistID=@CompanyId
	END

	
	-- add manufacturer codes that match exactly by name and are missing.
	INSERT INTO [ManufacturerCode_XRF]
	([DistributorId],[ManufacturerCode],[ManufacturerId],[IsActive],[UpdatedOn])

	SELECT DISTINCT dp.DistID, dp.ManufacturerCode, m.CompanyID as MfrID, 1, GetDate()
	FROM DistributorParts dp WITH(NOLOCK)
	INNER JOIN Company m WITH(NOLOCK)
		ON dp.ManufacturerCode = m.CompanyName
		AND m.CompanyStatusID = 1
		AND m.IsActive = 1
	INNER JOIN CompanyTypeMapping ctm WITH(NOLOCK)
		ON m.CompanyID = ctm.CompanyID
		AND ctm.CompanyTypeID = 1 --CompanyType for Mfr's
	LEFT OUTER JOIN ManufacturerCode_XRF mcxrf WITH(NOLOCK)
		ON dp.DistID = mcxrf.DistributorId
		AND dp.ManufacturerCode = mcxrf.ManufacturerCode
	WHERE dp.DistID = @CompanyId
		AND dp.ManufacturerCode <> '' -- Must have mfr code specified to try and find match
		AND mcxrf.ManufacturerCode IS NULL -- Only look for those that have no existing mfr code mapping
		AND m.CompanyName NOT IN 
		(
			SELECT m.CompanyName
			FROM Company m
			INNER JOIN CompanyTypeMapping ctm
				ON m.CompanyID = ctm.CompanyID
				AND ctm.CompanyTypeID = 1 --CompanyType for Mfr's
			GROUP BY m.CompanyName
			HAVING COUNT(*) > 1
		)

	-- Log the number of mfr codes mapped with exact name. Does not count towards total of parts records processed.
	EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'MfrMappingCount', @@ROWCOUNT, 0
				
	-- Log the number of records deleted from being over the max inventory threshhold.
	EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'UpdatedCount', @updatedCount, 0
	-- Log the number of records deleted from being over the max inventory threshhold.
	EXEC usp_AddInventoryUploadHistoryTraceLog @InventoryUploadHistoryId, 'InsertedCount', @insertedCount, 0

	SET NOCOUNT OFF
END

GO

/****** Object:  StoredProcedure [dbo].[usp_Rep_CirculationModule]    Script Date: 04/15/2013 14:58:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Rep_CirculationModule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Rep_CirculationModule]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_Rep_CirculationModule] --'2','0','0','0','0','0' 
(    
 @UserRequesting as VARCHAR(2),    
 @Zone as VARCHAR(500),     
 @SpcfyBuy as VARCHAR(50),    
 @JobFunc as VARCHAR(500),    
 @Industry as VARCHAR(500),    
 @AnnualPurchase as VARCHAR(100)    
    
)     
AS       
BEGIN    
      --DECLARE @UserRequesting AS VARCHAR(2) = '0';
      --DECLARE @Zone AS VARCHAR(500) = '10';
      --DECLARE @SpcfyBuy AS VARCHAR(50) = '0';
      --DECLARE @JobFunc AS VARCHAR(500) = '0';
      --DECLARE @Industry AS VARCHAR(500)= '0';
      --DECLARE @AnnualPurchase AS VARCHAR(100) = '0';


      DECLARE @tblEditions TABLE (EditionId INT);
      DECLARE @tblJobFunctions TABLE (JobFunctionId INT);
      DECLARE @tblIndustries TABLE (IndustryId INT);
      DECLARE @tblAnnualPurchases TABLE (PurchaseId INT);

      INSERT    INTO @tblEditions
                SELECT  items
                FROM    dbo.split(@Zone, ',')
                WHERE   items NOT LIKE '0'

      INSERT    INTO @tblJobFunctions
                SELECT  items
                FROM    dbo.split(@JobFunc, ',')
                WHERE   items NOT LIKE '0'

      INSERT    INTO @tblIndustries
                SELECT  items
                FROM    dbo.split(@Industry, ',')
                WHERE   items NOT LIKE '0'

      INSERT    INTO @tblAnnualPurchases
                SELECT  items
                FROM    dbo.split(@AnnualPurchase, ',')
                WHERE   items NOT LIKE '0'

      SELECT 
      DISTINCT
                U.userID, U.Firstname, U.LastName, U.Title, U.LastLogin, U.CreatedOn , 
                COALESCE(UC.CompanyName, C.CompanyName) AS Company, 
                UC.Address,
                UC.City, St.StateCode AS State,
                Ct.CountryName AS Country, UC.Zip,
                CZ.ZoneCode AS Zone, UC.Phone, UC.Fax,
                UC.EmailAddress,
                (CASE WHEN ISNULL(U.UserRecommendFlag, 0) = 1
                      THEN 'Y'
                      ELSE 'N'
                 END) AS SpecifyQuestion,
                JF.Description AS JobFunction,
                U.UserJobFunctionSpecify,
                IT.Description AS Industry,
                U.UserIndustryTypeIDSpecify,
                AL.Description AS AnnualPurchases,
                (CASE WHEN P.ReceiveEnewsLetter = 0
                           AND P.OrderBook = 0 THEN ' '
                      WHEN P.OrderBook = 1 THEN 'Y'
                      ELSE 'N'
                 END) AS Book,
                 CASE 
					WHEN P.ReceiveEnewsLetter = 1 THEN 'Y'
					ELSE 'N'
				 END AS ReceiveEnewsLetter,
				 CASE 
					WHEN P.ReceiveDistributionResource = 1 THEN 'Y'
					ELSE 'N'
				END AS ReceiveDistributionResource

                 
      FROM      [User] U
      INNER JOIN dbo.UserContact AS UC
                ON U.UserID = UC.UserID
                   AND U.IsActive = 1
      INNER JOIN MySourceUserPreferences P
                ON UC.UserID = P.UserID
                   AND P.PreferenceId = 7
      INNER JOIN ZipCode ZC
                ON UC.Zip >= ZC.ZipFrom
                   AND UC.Zip <= ZC.ZipTo
      INNER JOIN Editions E
                ON ZC.ZoneId = E.RegionID
                   AND E.StatusID <> 2
      INNER JOIN CountryZones CZ
                ON ZC.ZoneId = CZ.ZoneID
      LEFT JOIN MstJobFunction JF
                ON U.UserJobFunctionID = JF.JobFunctionID
      LEFT JOIN MstIndustryType IT
                ON U.UserIndustryTypeID = IT.IndustryTypeID
      LEFT JOIN MstApprovalLevel AL
                ON U.UserApprovalLevelID = AL.UserApprovalLevelID
      LEFT JOIN UserRole UR
                ON U.UserID = UR.UserID
      LEFT JOIN Company C
                ON UR.CompanyID = c.CompanyID
      LEFT JOIN Country Ct
                ON UC.CountryId = Ct.CountryId
      LEFT JOIN CountryStates St
                ON UC.StateID = St.StateID
                   AND UC.CountryID = St.CountryID
      WHERE     ISNULL(UC.Address, '') <> ''
                AND ((@UserRequesting = 1
                      AND P.ReceiveEnewsLetter = 1
                     )
                     OR @UserRequesting <> 1
                    )
                AND ((@UserRequesting = 2
                      AND P.OrderBook = 1
                      AND UC.CountryID IN (197, 35) -- Unites States and Canada ONLY
                      AND Ct.CountryID IS NOT NULL
                     )
                     OR @UserRequesting <> 2
                    )
		--@SpcfyBuy
		-- 0 means to not apply this filter
		-- 1 means only show those not User Recommend
		-- 2 means only show those which are User Recommend
                AND ((@SpcfyBuy = 1
                      AND U.UserRecommendFlag = 0
                     )
                     OR @SpcfyBuy <> 1
                    )
                AND ((@SpcfyBuy = 2
                      AND U.UserRecommendFlag = 1
                     )
                     OR @SpcfyBuy <> 2
                    )
                AND (JF.JobFunctionID IN (SELECT
                                            JobFunctionId
                                          FROM
                                            @tblJobFunctions)
                     OR (
                         SELECT COUNT(JobFunctionId)
                         FROM   @tblJobFunctions
                        ) = 0
                    )
                AND (IT.IndustryTypeID IN (SELECT
                                            IndustryId
                                           FROM
                                            @tblIndustries)
                     OR (
                         SELECT COUNT(IndustryId)
                         FROM   @tblIndustries
                        ) = 0
                    )
                AND (AL.UserApprovalLevelID IN (
                     SELECT PurchaseId
                     FROM   @tblAnnualPurchases)
                     OR (
                         SELECT COUNT(PurchaseID)
                         FROM   @tblAnnualPurchases
                        ) = 0
                    )
                AND (E.Regionid IN (SELECT  EditionID
                                    FROM    @tblEditions)
                     OR (
                         SELECT COUNT(EditionId)
                         FROM   @tblEditions
                        ) = 0
                    )
	ORDER BY u.LastName, u.FirstName, U.UserID
END

GO

/****** Object:  StoredProcedure [dbo].[usp_Rep_InventoryUploadErrorHistory]    Script Date: 12/12/2012 14:05:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Rep_InventoryUploadErrorHistory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Rep_InventoryUploadErrorHistory]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_Rep_InventoryUploadErrorHistory]
(
	@fromDate DATETIME,
	@toDate DATETIME
)
AS

BEGIN
	--DECLARE @fromDate DATETIME = '03/22/2013'
	--DECLARE @toDate DATETIME = '03/22/2013'

	DECLARE @tmpHistory TABLE
	(
		CompanyID INT,
		CompanyName VARCHAR(100),
		Vector CHAR(5),
		FileType CHAR(5),
		SendersEmail VARCHAR(100),
		UploadDate DATETIME,
		[Error Message] VARCHAR(MAX),
		[Process Time] VARCHAR(100),
		[Processed] VARCHAR(10),
		[Lines in File] INT,
		[Records Uploaded] INT,
		[Records Processed] INT,
		[Invalid Data] INT,
		[Over Limit Reject] INT,
		[Duplicate Reject] INT,
		[Records Remaining]	INT,
		InventoryUploadHistoryId INT
	)

	INSERT INTO @tmpHistory
	SELECT C.CompanyID, C.CompanyName, h.Vector, h.FileType, InvS.SendersEmail ,h.UploadDate, 
		ISNULL(h.ErrorMessage, '') AS [Error Message],
		ISNULL(h.ProcessTime, '') AS [Process Time],
		CASE 
			WHEN ISNULL(h.FileInventoryCount,0) = 0 
				THEN 'N'
			WHEN CAST((1 - CAST(ISNULL(h.FileInventoryCount, 0) - (ISNULL(h.UpdatedCount, 0) + ISNULL(h.InsertedCount, 0) + ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount, 0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) + ISNULL(h.OverLimitCount, 0) + ISNULL(h.DuplicateCount,0)) AS FLOAT)/CAST(ISNULL(h.FileInventoryCount, 1) AS FLOAT)) * 100 AS INT) = 0
				THEN 'N'
			WHEN CAST((1 - CAST(ISNULL(h.FileInventoryCount, 0) - (ISNULL(h.UpdatedCount, 0) + ISNULL(h.InsertedCount, 0) + ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount, 0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) + ISNULL(h.OverLimitCount, 0) + ISNULL(h.DuplicateCount,0)) AS FLOAT)/CAST(ISNULL(h.FileInventoryCount, 1) AS FLOAT)) * 100 AS INT) = 100 
				THEN 'Y'
			 ELSE
				CAST(CAST((1 - CAST(ISNULL(h.FileInventoryCount, 0) - (ISNULL(h.UpdatedCount, 0) + ISNULL(h.InsertedCount, 0) + ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount, 0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) + ISNULL(h.OverLimitCount, 0) + ISNULL(h.DuplicateCount,0)) AS FLOAT)/CAST(ISNULL(h.FileInventoryCount, 1) AS FLOAT)) * 100 AS INT) AS VARCHAR(10))
		END AS [Processed],
		ISNULL(h.FileLineCount, 0) as [Lines in File], 
		ISNULL(h.FileInventoryCount, 0) as [Records Uploaded], 
		ISNULL(h.UpdatedCount,0) + ISNULL(h.InsertedCount,0) AS [Records Processed], 
		ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount,0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) AS [Invalid Data],
		ISNULL(h.OverLimitCount,0) AS [Over Limit Reject],
		ISNULL(h.DuplicateCount,0) AS [Duplicate Reject], 
		ISNULL(h.FileInventoryCount, 0) - ((ISNULL(h.UpdatedCount,0) + ISNULL(h.InsertedCount,0)) + (ISNULL(h.InvalidQtyFieldCount,0) + ISNULL(h.OverLimitCount,0) + ISNULL(h.DuplicateCount,0))) AS [Records Remaining],
		h.InventoryUploadHistoryId
	FROM InventoryUploadHistory h
	INNER JOIN Company C
		ON h.CompanyId = C.CompanyID
	LEFT OUTER JOIN InventorySettings InvS
		ON C.CompanyID = InvS.CompanyID
	WHERE DATEADD(dd, DATEDIFF(dd, 0, h.UploadDate), 0) >= DATEADD(dd, DATEDIFF(dd, 0, @fromDate), 0)
		AND DATEADD(dd, DATEDIFF(dd, 0, h.UploadDate), 0) <= DATEADD(dd, DATEDIFF(dd, 0, @toDate), 0)

	SELECT h.*
	FROM @tmpHistory h
	WHERE h.[Error Message] IS NOT NULL AND h.[Error Message] <> ''
	ORDER BY h.InventoryUploadHistoryId DESC
END

GO

/****** Object:  StoredProcedure [dbo].[usp_Rep_InventoryUploadHistory]    Script Date: 12/12/2012 15:58:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Rep_InventoryUploadHistory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Rep_InventoryUploadHistory]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_Rep_InventoryUploadHistory]
(
	@fromDate DATETIME,
	@toDate DATETIME
)
AS

BEGIN
	--DECLARE @fromDate DATETIME = '03/22/2013'
	--DECLARE @toDate DATETIME = '03/22/2013'

	DECLARE @tmpHistory TABLE
	(
		CompanyID INT,
		CompanyName VARCHAR(100),
		Vector CHAR(5),
		FileType CHAR(5),
		SendersEmail VARCHAR(100),
		UploadDate DATETIME,
		[Error Message] VARCHAR(MAX),
		[Process Time] VARCHAR(100),
		[Processed] VARCHAR(10),
		[Limit] INT,
		[Lines in File] INT,
		[Records Uploaded] INT,
		[Records Processed] INT,
		[Invalid Data] INT,
		[Over Limit Reject] INT,
		[Duplicate Reject] INT,
		[Records Remaining]	INT,
		InventoryUploadHistoryId INT
	)

	INSERT INTO @tmpHistory
	SELECT C.CompanyID, C.CompanyName, h.Vector, h.FileType, InvS.SendersEmail ,h.UploadDate, 
		ISNULL(h.ErrorMessage, '') AS [Error Message],
		ISNULL(h.ProcessTime, '') AS [Process Time],
		CASE 
			WHEN ISNULL(h.FileInventoryCount,0) = 0 
				THEN 'N'
			WHEN CAST((1 - CAST(ISNULL(h.FileInventoryCount, 0) - (ISNULL(h.UpdatedCount, 0) + ISNULL(h.InsertedCount, 0) + ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount, 0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) + ISNULL(h.OverLimitCount, 0) + ISNULL(h.DuplicateCount,0)) AS FLOAT)/CAST(ISNULL(h.FileInventoryCount, 1) AS FLOAT)) * 100 AS INT) = 0
				THEN 'N'
			WHEN CAST((1 - CAST(ISNULL(h.FileInventoryCount, 0) - (ISNULL(h.UpdatedCount, 0) + ISNULL(h.InsertedCount, 0) + ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount, 0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) + ISNULL(h.OverLimitCount, 0) + ISNULL(h.DuplicateCount,0)) AS FLOAT)/CAST(ISNULL(h.FileInventoryCount, 1) AS FLOAT)) * 100 AS INT) = 100 
				THEN 'Y'
			 ELSE
				CAST(CAST((1 - CAST(ISNULL(h.FileInventoryCount, 0) - (ISNULL(h.UpdatedCount, 0) + ISNULL(h.InsertedCount, 0) + ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount, 0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) + ISNULL(h.OverLimitCount, 0) + ISNULL(h.DuplicateCount,0)) AS FLOAT)/CAST(ISNULL(h.FileInventoryCount, 1) AS FLOAT)) * 100 AS INT) AS VARCHAR(10))
		END AS [Processed],
		ISNULL(InvS.MaxRecords, 0) AS [Limit],
		ISNULL(h.FileLineCount, 0) as [Lines in File], 
		ISNULL(h.FileInventoryCount, 0) as [Records Uploaded], 
		ISNULL(h.UpdatedCount,0) + ISNULL(h.InsertedCount,0) AS [Records Processed], 
		ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount,0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) AS [Invalid Data],
		ISNULL(h.OverLimitCount,0) AS [Over Limit Reject],
		ISNULL(h.DuplicateCount,0) AS [Duplicate Reject], 
		ISNULL(h.FileInventoryCount, 0) - ((ISNULL(h.UpdatedCount,0) + ISNULL(h.InsertedCount,0)) + (ISNULL(h.InvalidPartNumberFieldCount , 0) + ISNULL(h.InvalidQtyFieldCount,0) + ISNULL(h.ZeroQtyFieldCount, 0) + ISNULL(h.InvalidPriceBreakFieldCount, 0) + ISNULL(h.OverLimitCount,0) + ISNULL(h.DuplicateCount,0))) AS [Records Remaining],
		h.InventoryUploadHistoryId
	FROM InventoryUploadHistory h
	INNER JOIN Company C
		ON h.CompanyId = C.CompanyID
	LEFT OUTER JOIN InventorySettings InvS
		ON C.CompanyID = InvS.CompanyID

	SELECT *
	FROM @tmpHistory h
	WHERE DATEADD(dd, DATEDIFF(dd, 0, h.UploadDate), 0) >= DATEADD(dd, DATEDIFF(dd, 0, @fromDate), 0)
		AND DATEADD(dd, DATEDIFF(dd, 0, h.UploadDate), 0) <= DATEADD(dd, DATEDIFF(dd, 0, @toDate), 0)
	ORDER BY h.CompanyName, h.InventoryUploadHistoryId DESC
END

GO
----------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[Usp_getListofOnlineAdJobFolders]    Script Date: 03/13/2013 12:34:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Usp_getListofOnlineAdJobFolders]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Usp_getListofOnlineAdJobFolders]
GO


/****** Object:  StoredProcedure [dbo].[Usp_getListofOnlineAdJobFolders]    Script Date: 03/13/2013 12:34:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =========================================================================================          
-- Author			: Sudha 
-- Create date		: 09-June-2011 
-- Description		: Get all the online job folders list 
-- Modified by		: Nawnit Kumar       
-- Modified Date	: 06-March-2013
-- Description		: To get the ApprovalRequestDate and ApprovalDate
-- Modified			: By lalbahadur on 4/2/2013 removed edition id to avoid multiple entries for same order#
-- ==========================================================================================
--EXEC [Usp_getListofOnlineAdJobFolders] 'Powell Electronics',0,0,0 
		       
		CREATE PROCEDURE [dbo].[Usp_getListofOnlineAdJobFolders]       
		(      
			@strAdvertisername varchar(75),      
			@statusid int,      
			@month int,      
			@year int      
		)      
		AS   
		   
		set transaction isolation level read uncommitted  
		
		Declare @strSQLSELECT varchar(800)      
		Declare @strSQLFROM varchar(800)      
		Declare @strSQLWHERE varchar(800)   

		set @strAdvertisername = REPLACE(@strAdvertisername, '''', '''''')
		      
		BEGIN
		
		Select  @strSQLSELECT='SELECT DISTINCT 
		adjob.adjobfolderid,
			DATENAME(MM, ad.Activationdate) + '' '' + CAST(DAY(ad.Activationdate)AS  VARCHAR(2)) + '' '' + CAST(YEAR(ad.Activationdate) AS VARCHAR(4)) AS orderdate,
			comp.Companyid,comp.companyname,mstadjob.[description],adord.adordernumber,CONVERT(VARCHAR(10), MAX(Ada.ApprovalRequestDate), 101) AS ApprovalRequestDate,CONVERT(VARCHAR(10), Ada.ApprovalDate, 101) AS ApprovalDate'
			
		Select @strSQLFROM =  ' FROM  AdOrderDetails ad (NOLOCK)
				INNER JOIN ADORDER adord					(NOLOCK)	ON adord.ADORDERID=ad.ADORDERID
				INNER JOIN AdOrderDetailsRegionEdition  aded(NOLOCK)	ON aded.AdOrderDetailsId=ad.AdOrderDetailsId
				INNER JOIN AdJobFolderMaster adjob			(NOLOCK)	ON adjob.ADJOBFOLDERID=aded.ADJOBFOLDERID
				INNER JOIN Company comp						(NOLOCK)	ON comp.COMPANYID=adord.COMPANYID				
				INNER JOIN MstAdJobFolderStatus mstadjob	(NOLOCK)	ON mstadjob.StatusId=adjob.StatusId 
				LEFT JOIN Adapproval Ada					(NOLOCK)	ON Ada.Jobfolderid=aded.ADJOBFOLDERID
				'
				
		Select @strSQLWHERE  = '  WHERE ad.OrderType= ''O'' and adord.StatusId in (3,4,5)'  
		if @strAdvertisername <> ''	
			 Select @strSQLWHERE = @strSQLWHERE + ' and comp.companyname Like  ' + '''' + ltrim(rtrim(@strAdvertisername)) + '%' + ''''       
		          
		If @statusid <> 0  	
				 Select @strSQLWHERE= @strSQLWHERE + ' and adjob.statusid = ' + convert(varchar(30), @statusid)      
		        
		if @month <> 0         
				 Select @strSQLWHERE= @strSQLWHERE + ' and datepart(MM,ad.Activationdate) = ' + convert(varchar(30), @month)      
		        
		if @year <> 0                   
				  Select @strSQLWHERE= @strSQLWHERE + ' and datepart(YYYY,ad.Activationdate) = ' +  convert(varchar(30), @year)    
				   
		exec (@strSQLSELECT + @strSQLFROM + @strSQLWHERE + ' GROUP BY ad.AdOrderId,aded.editionid,adjob.adjobfolderid,ad.Activationdate,comp.Companyid,comp.companyname,mstadjob.[description],adord.adordernumber,Ada.ApprovalDate'+' order by adord.adordernumber desc') 		
		END 


GO
--------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetOnlineJobFolderInfo]    Script Date: 04/02/2013 19:47:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetOnlineJobFolderInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetOnlineJobFolderInfo]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetOnlineJobFolderInfo]    Script Date: 04/02/2013 19:47:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =========================================================================================      
-- Author   : Sudha  
-- Modified By   :  
-- Create date   : 13-June-2011  
-- Modified Date :   
-- Description   : Get Online Job Folder information  
-- Modified by	 : Removed OrderId parameter - There is no need of order id parameter on 4/2/2013
-- ==========================================================================================       
--[usp_GetOnlineJobFolderInfo]       21158
CREATE PROCEDURE [dbo].[usp_GetOnlineJobFolderInfo]                    
(                  
  @adjobfolderid  int
)                          
AS                          
 BEGIN    
  
 SELECT DISTINCT   
  
       com.companyname,  
       aom.companyid,  
       DATENAME(MM, aso.Activationdate) + ' ' + CAST(DAY(aso.Activationdate)AS  VARCHAR(2)) + ' ' + CAST(YEAR(aso.Activationdate) AS VARCHAR(4)) AS orderdate,
       aso.Adorderid,  
       afs.description,  
       a.statusid,  
       a.jobfolderinstruction  
 FROM AdJobFolderMaster a   
        INNER JOIN AdOrderDetailsRegionEdition ad   
           ON a.AdJobFolderId = ad.AdJobFolderId  
  INNER JOIN AdOrderDetails aso  
           ON aso.AdOrderDetailsId = ad.AdOrderDetailsId  
  INNER JOIN AdOrder aom  
           ON aom.AdOrderId = aso.AdOrderId  
  INNER JOIN company com   
           ON com.companyid = aom.companyid          
        INNER JOIN Mstadjobfolderstatus afs  
           ON afs.statusid=a.statusid  
  
  WHERE a.AdJobFolderId =@adjobfolderid 
  
END

GO
---------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetJobFolderInfo]    Script Date: 04/02/2013 19:51:13 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetJobFolderInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetJobFolderInfo]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetJobFolderInfo]    Script Date: 04/02/2013 19:51:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =========================================================================================      
-- Author   : Sudha  
-- Modified By   :  
-- Create date   : 26-May-2011  
-- Modified Date :   
-- Description   : Get Job Folder information  
-- Modified by	 : Removed edition id parameter on 4/2/2013
-- ==========================================================================================       
--[usp_GetJobFolderInfo]    21185   
CREATE PROCEDURE [dbo].[usp_GetJobFolderInfo]               
(                  
  @adjobfolderid  int  
)                          
AS                          
 BEGIN    
  
 SELECT DISTINCT   
       com.companyname,aso.Adorderid, afs.description,ad.editionid,(select zonecode from countryzones where zoneid=E.regionid)+' '+ right(E.[Year],2) as Edition,  a.*  
 FROM AdJobFolderMaster a   
        INNER JOIN AdOrderDetailsRegionEdition ad   
           ON a.AdJobFolderId = ad.AdJobFolderId  
  INNER JOIN AdOrderDetails aso  
           ON aso.AdOrderDetailsId = ad.AdOrderDetailsId  
  INNER JOIN AdOrder aom  
           ON aom.AdOrderId = aso.AdOrderId  
  INNER JOIN company com   
           ON com.companyid = aom.companyid  
        INNER JOIN editions e   
           ON e.editionid=ad.EditionID    
        INNER JOIN Mstadjobfolderstatus afs  
           ON afs.statusid=a.statusid  
  
  WHERE a.AdJobFolderId =@adjobfolderid 
  
END

GO

----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------


/****** Object:  StoredProcedure [dbo].[usp_GetSEOCompanyId]    Script Date: 07/27/2012 08:24:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSEOCompanyId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSEOCompanyId]
GO

  
/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
{This should be a short description about the functionality of this procedure.}

Parameters:
{A short description of parameters and default values if there is any.}

Used by: 
{This could be the name of a single webpage or multiple web pages or a SSIS package or a scheduled job etc. But if this functionality is used in many places within an application then just mention the application name. Otherwise <application name>.<module name or web page name>}
(Having this information will be very helpful to find out what all applications will get affected if we need to make a change.)

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
08.08.2011		Christian		Created. 
04.04.2013		Marcus Ruether	Changed comparison to used c.Search_CompanyName instead of [dbo].[RemoveSpecialCharacter](c.CompanyName)  
								This was made to address performance issue. - 26858 
------------------------------------------------------------------------------------------------------------------------------------------*/     
CREATE PROCEDURE [dbo].[usp_GetSEOCompanyId]
   @companyName varchar(100)      
AS      

--DECLARE @companyName varchar(100) = 'montrosecdt'  

BEGIN      
	SELECT TOP 1 C.CompanyID 
	FROM Company C  with(nolock) 
	INNER JOIN MstStatus S
		ON C.CompanyStatusID = S.StatusID
		AND S.isActive = 1
	WHERE c.Search_CompanyName = [dbo].[RemoveSpecialCharacter](@companyName)  
	ORDER BY S.StatusID -- Display Active companies at top of list
END


GO





----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_AddAdOrderDetails]    Script Date: 04/02/2013 20:39:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_AddAdOrderDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_AddAdOrderDetails]
GO

/****** Object:  StoredProcedure [dbo].[usp_AddAdOrderDetails]    Script Date: 04/02/2013 20:39:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--*****************************************************************************************************                          
--*   Stored Procedure  : [usp_AddAdOrderDetails]                        
--*   Description  : Insert Ad Order Details                         
--*   Author   : SIVA PRAKASH D                    
--*   Creation Date  : 05/27/2011                      
--*****************************************************************************************************         
--*   Modify Auth: Kiran Sangoi 
--*   Description  : Added logic for implementing One Per Edition flag - returns -2 if this validation fails.
--*   Modify  Date  : Dec. 2nd, 2011                      
--usp_AddAdOrderDetails 187, 2, 1, 40, 0, 109276, N'test', 1430.20, 1, N'N', '0', 0, '2001-11-30', 24, '5,6,6,4,7,2,8,9,3,25,1', '213,227,212,218,219,217,220,221,222,225,223', N'P' , 75, 1, '0'
--*****************************************************************************************************         
--*	Modified By : Ajija Fathima.K
--* Modified On : 01/Dec/2011	  
--* Modified	: By Lalbahdaur on 03/29/2013 Modified logic to enter priority dates based on below
--1.	If an order exists for that distributor (company) for given manufacturer in that zone the previous year than keep the priority date on the system. Don�t change anything.
--2.	If no order exists in previous year (either first time advertising or advertising after a break) then set the priority date to order date .    
--*****************************************************************************************************         
		CREATE PROCEDURE [dbo].[usp_AddAdOrderDetails]                                                    
		(                 
		 @AdOrderId    INT,                                                           
		 @SectionID    INT,                                                    
		 @SizeTypeID   INT,                                                   
		 @AdTypeID    INT,        
		 @LogoIndicator   BIT,                                              
		 @PositionTitle   BIGINT,                                                    
		 @Comments    TEXT,                                                     
		 @Price     MONEY,                                                    
		 @ApplyDiscount   BIT,          
		 @CompIndicator   CHAR(1),                                            
		 @CompCode    VARCHAR(10),                                            
		 @Duration    INT,                             
		 @ActivationDate  DATETIME,                                           
		 @LastUpdatedBy   INT,        
		 @RegionSelected  VARCHAR(200),        
		 @EdtionSelected  VARCHAR(200),        
		 @OrderType    CHAR(1),      
		 @RateCardId   INT ,    
		 @Version  INT ,
		 @OrderRegionId VARCHAR(100),
		 @GrossAmountPerGuranteedLine INT                                     
		)                                                    
		AS                                                    
		BEGIN                                                    
			SET NOCOUNT ON            
			DECLARE @DupCount INT, @TmpSQL nvarchar(4000)
			IF @OrderType = 'P'
			BEGIN 
				SET @TmpSQL ='SELECT @DupCount = Count(8) 
				  FROM [AdOrderDetails] AOD
				  JOIN ADDetails Ad on AOD.[AdTypeID] = ad.[AdTypeID]  AND Ad.OnePerEdition = 1 
						AND AOD.AdTypeID = ' +CONVERT(varchar(10), @AdTypeID ) + '
				  JOIN dbo.AdOrderDetailsRegionEdition ADRE on ADRE.AdOrderDetailsID =AOD.AdOrderDetailsID
						AND ADRE.EditionID in (' + @EdtionSelected + ') 
				  WHERE AdOrderID in (Select AdOrderID from AdOrder where StatusID >= 3 )
				  AND AOD.[PositionTitle] =' +CONVERT(varchar(10), @PositionTitle)
				  Print 'Here Success 2'
				EXEC sp_executesql @TmpSQL, N'@DupCount int OUTPUT', @DupCount OUTPUT
				print @TmpSQL
				print @DupCount
				  IF @DupCount > 0 
					--- One Per Edition flag is True & duplicate exists so the transaction should fail.
					return -2
			END	                                                        
		 DECLARE @OrderDetailsId INT        
		        
		 DECLARE @NextStringReg VARCHAR(200)        
		 DECLARE @PosReg INT        
		 DECLARE @NextPosReg INT        
		 DECLARE @StringReg VARCHAR(200)        
		 DECLARE @DelimiterReg VARCHAR(40)        
		        
		 DECLARE @NextStringEdition VARCHAR(200)        
		 DECLARE @PosEdition INT        
		 DECLARE @NextPosEdition INT        
		 DECLARE @StringEdition VARCHAR(200)        
		 DECLARE @DelimiterEdition VARCHAR(40)        
		 DECLARE @RegionId INT        
		 DECLARE @EditionId  INT       
		 DECLARE @PriorityDate datetime        
		  INSERT INTO AdOrderDetails                                              
		  (                                                    
		  AdOrderId,                                                           
		  SectionID,                                                    
		  SizeTypeID,                                                   
		  AdTypeID,        
		  LogoIndicator,                                              
		  PositionTitle,                                                    
		  Comments,                                                     
		  Price,                                                    
		  ApplyDiscount,          
		  CompIndicator,                                            
		  CompCode,                                            
		  Duration,                             
		  ActivationDate,                                           
		  LastUpdatedBy,        
		  OrderType,      
		  RateCardId,
		  OrderRegionId      
		  )                                                  
		  VALUES                            
		  (                                                    
		  @AdOrderId,                                                           
		  @SectionID,                                                    
		  @SizeTypeID,                                                   
		  @AdTypeID,        
		  @LogoIndicator,                                              
		  @PositionTitle,                                                    
		  @Comments,                                                     
		  @Price,                                                    
		  @ApplyDiscount,          
		  @CompIndicator,            
		  @CompCode,                                            
		  @Duration,                             
		  @ActivationDate,      
		  @LastUpdatedBy,        
		  @OrderType,      
		  @RateCardId,
		  @OrderRegionId                                              
		  )                                                   
		  SET @OrderDetailsId = SCOPE_IDENTITY()       
		    
		DECLARE @AdOrderRevisionId INT   
		DECLARE @AdOrderRevisionCount INT
		DECLARE @AdOrderStatus INT  
			-- FOR ORDER REVISION (CHANGE FORM)
			SELECT @AdOrderStatus = StatusId FROM AdOrder WHERE AdOrderId=@AdOrderId 

			IF @AdOrderStatus>=3 AND @AdOrderStatus<=4
			BEGIN
				SELECT @AdOrderRevisionCount = count(*) FROM  AdOrderRevision WHERE Version=@Version AND AdOrderId=@AdOrderId  
				IF @AdOrderRevisionCount>0    
				BEGIN    
						SELECT @AdOrderRevisionId=MAX(AdOrderRevisionId) FROM AdOrderRevision WHERE AdOrderId=@AdOrderId    									
						
				END    
				ELSE    
				BEGIN    
						INSERT INTO AdOrderRevision VALUES(@AdOrderId,@Version,GETDATE(), 
						(select AR.DiscountRate from AdOrder AR where AR.AdOrderId = @AdOrderId))    
						SET @AdOrderRevisionId = SCOPE_IDENTITY()     	
				END

				--Adding This Newly Added Ad To AdOrderDetailsRevision							
				INSERT INTO AdOrderDetailsRevision(AdOrderDetailsId,AdOrderId,SectionID,SizeTypeID,AdTypeID,LogoIndicator,PositionTitle,Comments,Price,ApplyDiscount,CompIndicator,CompCode,Duration,ActivationDate, LastUpdatedBy, OrderType,RateCardId,OrderRegionId,AdOrderRevisionId)
				SELECT @OrderDetailsId,@AdOrderId,@SectionID,@SizeTypeID,@AdTypeID,@LogoIndicator,@PositionTitle,@Comments,@Price,@ApplyDiscount,@CompIndicator,@CompCode,@Duration,@ActivationDate, @LastUpdatedBy, @OrderType,@RateCardId, @OrderRegionId, @AdOrderRevisionId     
				
				--Adding All Existing Ads To AdOrderDetailsRevision			
				INSERT INTO AdOrderDetailsRevision(AdOrderDetailsId,AdOrderId,SectionID,SizeTypeID,AdTypeID,LogoIndicator,PositionTitle,Comments, Price, ApplyDiscount,CompIndicator,CompCode,Duration,ActivationDate, LastUpdatedBy, OrderType,RateCardId,OrderRegionId,AdOrderRevisionId) 
				SELECT AOD.AdOrderDetailsId,AOD.AdOrderId,AOD.SectionID,AOD.SizeTypeID,AOD.AdTypeID,AOD.LogoIndicator, AOD.PositionTitle,AOD.Comments, AOD.Price, AOD.ApplyDiscount,AOD.CompIndicator, AOD.CompCode,AOD.Duration, AOD.ActivationDate, AOD.LastUpdatedBy, AOD.OrderType,AOD.RateCardId,AOD.OrderRegionId,@AdOrderRevisionId  
				FROM AdOrderDetails AOD WHERE AdOrderId = @AdOrderId AND AOD.AdOrderDetailsId NOT IN(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId AND AdOrderRevisionId = @AdOrderRevisionId)
			END 
			------- END ---------   
		        
			 SET @StringReg =@RegionSelected        
			 SET @DelimiterReg = ','        
			 SET @StringReg = @StringReg + @DelimiterReg        
			 SET @PosReg = charindex(@DelimiterReg,@StringReg)        
			        
			 SET @StringEdition =@EdtionSelected        
			 SET @DelimiterEdition = ','        
			 SET @StringEdition = @StringEdition + @DelimiterEdition        
			 SET @PosEdition = charindex(@DelimiterEdition,@StringEdition)        
			        
			 WHILE (@PosReg <> 0)        
			 BEGIN        
			  SET @NextStringEdition = substring(@StringEdition,1,@PosEdition - 1)        
			  --SELECT @NextPosEdition -- Show Results        
			  SET @StringEdition = substring(@StringEdition,@PosEdition+1,len(@StringEdition))        
			  SET @PosEdition = charindex(@DelimiterEdition,@StringEdition)        
			        
			  SET @NextStringReg = substring(@StringReg,1,@PosReg - 1)        
			  --SELECT @NextStringReg -- Show Results        
			  SET @StringReg = substring(@StringReg,@PosReg+1,len(@StringReg))        
			  SET @PosReg = charindex(@DelimiterReg,@StringReg)        
				    
			  IF @OrderType = 'P'  
			  BEGIN   
			  
				 /*------------Added by Lalbahadur on 3/29/2013----------------------------*/
				 set @PriorityDate =  dbo.udf_GetAdOrderPriorityDate(@AdOrderId,@PositionTitle,@NextStringReg,@NextStringEdition)
				 
				 /*-------------------------------------------------------------------------*/
				 INSERT INTO AdOrderDetailsRegionEdition(AdOrderDetailsId,RegionID,EditionID,PriorityDate) 
				 VALUES(@OrderDetailsId,@NextStringReg,@NextStringEdition,@PriorityDate)    -- Priority date added by Fathima 0n 01-12-2011    
				 
				IF @AdOrderStatus>=3 AND @AdOrderStatus<=4
				BEGIN
				
					--Adding This Newly Added Ad To AdOrderDetailsRegionEditionRevision	
					INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId,EditionID,RegionID, PriorityDate, AdOrderRevisionId) 
					VALUES(@OrderDetailsId,@NextStringEdition, @NextStringReg, @PriorityDate, @AdOrderRevisionId)          
				
					--Adding All Existing Ads To AdOrderDetailsRegionEditionRevision	
					INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId, EditionID, RegionID, PriorityDate, AdOrderRevisionId) 			
					SELECT R.AdOrderDetailsId, R.EditionID, R.RegionID, R.PriorityDate, @AdOrderRevisionId 
					FROM AdOrderDetailsRegionEdition R WHERE AdOrderDetailsId IN
					(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId) 
					AND R.AdOrderDetailsId NOT IN(SELECT AdOrderDetailsId FROM AdOrderDetailsRegionEditionRevision WHERE AdOrderDetailsId IN
					(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId) AND AdOrderRevisionId = @AdOrderRevisionId)

				END
			  END  
			  ELSE  
			  BEGIN  
				 INSERT INTO AdOrderDetailsRegionEdition(AdOrderDetailsId,RegionID,EditionID,PriorityDate, OnlineMonth,OnlineYear) 
				 VALUES(@OrderDetailsId,@NextStringReg,@NextStringEdition,@PriorityDate,DATEPART(MONTH,@ActivationDate),DATEPART(YEAR,@ActivationDate))   -- Priority date added by Fathima 0n 01-12-2011         
				 
				IF @AdOrderStatus>=3 AND @AdOrderStatus<=4
				BEGIN	
				
					--Adding This Newly Added Ad To AdOrderDetailsRegionEditionRevision	
					INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId,EditionID, RegionID, PriorityDate, AdOrderRevisionId,OnlineMonth,OnlineYear) 
					VALUES(@OrderDetailsId,@NextStringEdition, @NextStringReg, @PriorityDate, @AdOrderRevisionId,DATEPART(MONTH,@ActivationDate),DATEPART(YEAR,@ActivationDate))             

					--Adding All Existing Ads To AdOrderDetailsRegionEditionRevision	
					INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId, EditionID, RegionID, PriorityDate, AdOrderRevisionId, OnlineMonth, OnlineYear) 			
					SELECT R.AdOrderDetailsId, R.EditionID, R.RegionID, R.PriorityDate, @AdOrderRevisionId, R.OnlineMonth, R.OnlineYear 
					FROM AdOrderDetailsRegionEdition R WHERE AdOrderDetailsId   IN
					(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId)
					AND R.AdOrderDetailsId NOT IN(SELECT AdOrderDetailsId FROM AdOrderDetailsRegionEditionRevision WHERE AdOrderDetailsId IN
					(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId) AND AdOrderRevisionId = @AdOrderRevisionId)


				END
			  END  
			        
			 END         
			  EXEC uspAdJobFolderCreatePrint
			  EXEC uspAdJobFolderCreateOnline
			  EXEC usp_AdOrderGrossNetAmount @AdOrderId, @GrossAmountPerGuranteedLine
			   	         
			 return @OrderDetailsId            
		END



GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_UpdateJob]    Script Date: 04/19/2013 15:55:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_UpdateJob]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_UpdateJob]
GO

/****** Object:  StoredProcedure [dbo].[usp_UpdateJob]    Script Date: 04/19/2013 15:55:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =========================================================================================      
-- Author			: Sudha  
-- Create date		: 26-May-2011 
-- Description		: Update Job Details  
-- Modified By		: Nawmit Kumar
-- Modified Date	: 8-March-2013
-- Description		: Update Adapproval table for ApprovalDate    

-- ==========================================================================================
  
  
CREATE Procedure [dbo].[usp_UpdateJob]  
          
            
           
			@Statusid                   varchar(50) ,              
			@JobFolderInstruction       varchar(8000),  
			@Adjobfolderid              bigint,  
			@userid                     int,
			@orderid					int,
			@Companyname				varchar(50),  
			@ToAddress					varchar(50),  
			@username					varchar(50),			 
			@editionid					int,  
			@phone						varchar(50), 
			@fax						varchar(50), 
			@editionname				varchar(50),
			@usercontactname			varchar(50),
			@pubdate					datetime
  
AS  
    
BEGIN
SET NOCOUNT ON 

		-- Add in AdjobFolderMaster table
		INSERT INTO AdJobFolderHistory(AdJobFolderId, Statusid, LastUpdatedTimeStamp, UserId)
		VALUES(@Adjobfolderid,  @Statusid, GETDATE(), @userid)  
		
		-- Update in AdjobFolderMaster table
		UPDATE AdjobFolderMaster SET                         
		StatusId	=	@Statusid,    
		JobFolderInstruction	=	@JobFolderInstruction							
		WHERE Adjobfolderid=@Adjobfolderid	
		
		-- Check AdJobfolder available in Adapproval table or not		
		IF EXISTS (SELECT 1   FROM   Adapproval    WHERE  jobfolderid = @Adjobfolderid)
			BEGIN
				IF @Statusid <> 5 -- 5 - Approved 
					BEGIN --If status is not approved then it'll update ApprovalDate as Null 
						UPDATE Adapproval SET ApprovalDate = NULL WHERE  JobFolderid = @Adjobfolderid
					END
				ELSE
					BEGIN --If status is approved then it'll update ApprovalDate as CurrentDate
						UPDATE Adapproval SET ApprovalDate =GETDATE() WHERE  JobFolderid = @Adjobfolderid	
					END												
			END
		ELSE
			BEGIN  
				INSERT INTO Adapproval		  
						(  
						orderid,
						jobfolderid,
						Companyname,  
						ToAddress,  
						username,
						Editionid,  
						phone,
						fax,
						editionname,
						usercontactname,
						PubDate,
						ApprovalDate
						)             
						VALUES  
						(  
						@orderid,
						@Adjobfolderid,
						@Companyname,  
						@ToAddress,  
						@username,
						@editionid,  
						@phone,
						@fax,
						@editionname,
						@usercontactname,
						@Pubdate,
						GETDATE()  
						)			
					END
END				

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_UpdateAdOrderDetails]    Script Date: 04/02/2013 20:42:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_UpdateAdOrderDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_UpdateAdOrderDetails]
GO

/****** Object:  StoredProcedure [dbo].[usp_UpdateAdOrderDetails]    Script Date: 04/02/2013 20:42:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--*****************************************************************************************************                                    
--*   Stored Procedure  : usp_UpdateAdOrderDetails                                  
--*   Description  : Update Ad Order Details                                   
--*   Author   : SIVA PRAKASH D                              
--*   Creation Date  : 05/27/2011                                
--*****************************************************************************************************                                    
--*   Description  : Updated For Change Form
--*   Modified By  : Aatish Agarwal
--*   Modified Date: 25 June 2012
--* Modified	: By Lalbahdaur on 03/29/2013 Modified logic to enter priority dates based on below
--1.	If an order exists for that distributor (company) for given manufacturer in that zone the previous year than keep the priority date on the system. Don�t change anything.
--2.	If no order exists in previous year (either first time advertising or advertising after a break) then set the priority date to order date .    
--*****************************************************************************************************            
				CREATE PROCEDURE [dbo].[usp_UpdateAdOrderDetails]                                                              
				(                           
				 @AdOrderId    INT,                                                                     
				 @SectionID    INT,                                                              
				 @SizeTypeID   INT,                                                             
				 @AdTypeID    INT,                  
				 @LogoIndicator   BIT,                                                        
				 @PositionTitle   BIGINT,                                                              
				 @Comments    TEXT,                                                               
				 @Price     MONEY,                                                              
				 @ApplyDiscount   BIT,                    
				 @CompIndicator   CHAR(1),                                                      
				 @CompCode    VARCHAR(10),                                                      
				 @Duration    INT,                                       
				 @ActivationDate  DATETIME,                                                     
				 @LastUpdatedBy   INT,                  
				 @RegionSelected  VARCHAR(200),                  
				 @EdtionSelected  VARCHAR(200),                  
				 @OrderType    CHAR(1),                
				 @AdOrderDetailsId INT ,              
				 @RateCardId INT,          
				 @Version  INT,      
				 @OrderRegionId VARCHAR(100), 
				 @GrossAmountPerGuranteedLine INT                                                       
				)                                                              
				AS                                                              
				BEGIN                                                              
					SET NOCOUNT ON                      
				                                                        
				 DECLARE @OrderDetailsId INT                  
				                  
				 DECLARE @NextStringReg VARCHAR(200)                  
				 DECLARE @PosReg INT                  
				 DECLARE @NextPosReg INT                  
				 DECLARE @StringReg VARCHAR(200)                  
				 DECLARE @DelimiterReg VARCHAR(200)                  
				                  
				 DECLARE @NextStringEdition VARCHAR(200)                  
				 DECLARE @PosEdition INT                  
				 DECLARE @NextPosEdition INT                  
				 DECLARE @StringEdition VARCHAR(200)                  
				 DECLARE @DelimiterEdition VARCHAR(200)                  
				                  
				 DECLARE @RegionId INT                  
				 DECLARE @EditionId  INT           
				        
				DECLARE @AdOrderRevisionId INT         
				DECLARE @AdOrderRevisionCount INT        
				DECLARE @AdOrderStatus INT  
				DECLARE @PriorityDate datetime              
				      
				  UPDATE AdOrderDetails                 
				  SET                                                         
				  AdOrderId  =@AdOrderId,                                                                     
				  SectionID  =@SectionID,                                                              
				  SizeTypeID =@SizeTypeID,                                                             
				  AdTypeID  =@AdTypeID,                  
				  LogoIndicator =@LogoIndicator,                                                        
				  PositionTitle =@PositionTitle,                                                              
				  Comments  =@Comments,                                                               
				  Price   =@Price,                                                              
				  ApplyDiscount =@ApplyDiscount,                    
				  CompIndicator =@CompIndicator,                                                      
				  CompCode  =@CompCode,                                                      
				  Duration  =@Duration,                                       
				  ActivationDate=@ActivationDate,                                                     
				  LastUpdatedBy =@LastUpdatedBy ,              
				  RateCardId = @RateCardId,            
				  OrderType=@OrderType,      
				  OrderRegionId = @OrderRegionId               
				  WHERE  AdOrderDetailsId =@AdOrderDetailsId                
				                  
				                                                       
				 SET @OrderDetailsId = @AdOrderDetailsId                    
				 
				 --------------FOR ORDER REVISION (CHANGE FORM)---------------------
				 
				 SELECT @AdOrderStatus = StatusId FROM AdOrder WHERE AdOrderId=@AdOrderId       
				      
				 IF @AdOrderStatus>=3 AND @AdOrderStatus<=4                                                         
				 BEGIN      
					SELECT @AdOrderRevisionCount = count(*) FROM  AdOrderRevision WHERE Version=@Version AND AdOrderId=@AdOrderId            
					IF @AdOrderRevisionCount>0          
						BEGIN      
							SELECT @AdOrderRevisionId=MAX(AdOrderRevisionId) FROM AdOrderRevision WHERE AdOrderId=@AdOrderId          
							
							UPDATE AdOrderDetailsRevision                 
							SET                                                         
							AdOrderId  =	@AdOrderId,                                                                     
							SectionID  =	@SectionID,                                                              
							SizeTypeID =	@SizeTypeID,                                                             
							AdTypeID  =		@AdTypeID,                  
							LogoIndicator =	@LogoIndicator,                                                        
							PositionTitle =	@PositionTitle,                                                              
							Comments  =		@Comments,                                                               
							Price   =		@Price,                                                              
							ApplyDiscount =	@ApplyDiscount,                    
							CompIndicator =	@CompIndicator,                                                      
							CompCode  =		@CompCode,                                                      
							Duration  =		@Duration,                                       
							ActivationDate=	@ActivationDate,                                                     
							LastUpdatedBy =	@LastUpdatedBy ,              
							RateCardId =	@RateCardId,            
							OrderType=		@OrderType,      
							OrderRegionId = @OrderRegionId               
							WHERE  AdOrderDetailsId =@AdOrderDetailsId AND  AdOrderRevisionId = @AdOrderRevisionId                     
						END          
					ELSE    
						BEGIN    		
							INSERT INTO AdOrderRevision VALUES(@AdOrderId,@Version,GETDATE(),
							(select AR.DiscountRate from AdOrder AR where AR.AdOrderId = @AdOrderId))    
							SET @AdOrderRevisionId = SCOPE_IDENTITY()     
							
							--Adding This Newly Added Ad To AdOrderDetailsRevision							
							INSERT INTO AdOrderDetailsRevision(AdOrderDetailsId,AdOrderId,SectionID,SizeTypeID,AdTypeID,LogoIndicator,PositionTitle,Price,ApplyDiscount,CompIndicator,CompCode,Duration,ActivationDate, LastUpdatedBy, OrderType,RateCardId,OrderRegionId,AdOrderRevisionId)
							SELECT @OrderDetailsId,@AdOrderId,@SectionID,@SizeTypeID,@AdTypeID,@LogoIndicator,@PositionTitle,@Price,@ApplyDiscount,@CompIndicator,@CompCode,@Duration,@ActivationDate, @LastUpdatedBy, @OrderType,@RateCardId, @OrderRegionId, @AdOrderRevisionId     
								
							--Adding All Existing Ads To AdOrderDetailsRevision			
							INSERT INTO AdOrderDetailsRevision(AdOrderDetailsId,AdOrderId,SectionID,SizeTypeID,AdTypeID,LogoIndicator,PositionTitle,Price,ApplyDiscount,CompIndicator,CompCode,Duration,ActivationDate, LastUpdatedBy, OrderType,RateCardId,OrderRegionId,AdOrderRevisionId) 
							SELECT AOD.AdOrderDetailsId,AOD.AdOrderId,AOD.SectionID,AOD.SizeTypeID,AOD.AdTypeID,AOD.LogoIndicator, AOD.PositionTitle, AOD.Price, AOD.ApplyDiscount,AOD.CompIndicator, AOD.CompCode,AOD.Duration, AOD.ActivationDate, AOD.LastUpdatedBy, AOD.OrderType,AOD.RateCardId,AOD.OrderRegionId,@AdOrderRevisionId 
							FROM AdOrderDetails AOD WHERE AdOrderId = @AdOrderId AND AOD.AdOrderDetailsId NOT IN(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId AND AdOrderRevisionId = @AdOrderRevisionId) 						
						END
				END       
				 ------- END ---------   
				 
				                
				 DELETE FROM AdOrderDetailsRegionEdition WHERE AdOrderDetailsId =@OrderDetailsId 
				 DELETE FROM AdOrderDetailsRegionEditionRevision WHERE AdOrderDetailsId = @OrderDetailsId AND AdOrderRevisionId = @AdOrderRevisionId 
				         
					 SET @StringReg =@RegionSelected        
					 
					 SET @DelimiterReg = ','        
					 SET @StringReg = @StringReg + @DelimiterReg        
					 SET @PosReg = charindex(@DelimiterReg,@StringReg)        
					        
					 SET @StringEdition =@EdtionSelected        
					 SET @DelimiterEdition = ','        
					 SET @StringEdition = @StringEdition + @DelimiterEdition        
					 SET @PosEdition = charindex(@DelimiterEdition,@StringEdition)        
					        
					 WHILE (@PosReg <> 0)        
					 BEGIN        
					  SET @NextStringEdition = substring(@StringEdition,1,@PosEdition - 1)        
					  --SELECT @NextPosEdition -- Show Results        
					  SET @StringEdition = substring(@StringEdition,@PosEdition+1,len(@StringEdition))        
					  SET @PosEdition = charindex(@DelimiterEdition,@StringEdition)        
					        
					  SET @NextStringReg = substring(@StringReg,1,@PosReg - 1)        
					  --SELECT @NextStringReg -- Show Results        
					  SET @StringReg = substring(@StringReg,@PosReg+1,len(@StringReg))        
					  SET @PosReg = charindex(@DelimiterReg,@StringReg)        
				
					  IF @OrderType = 'P'  
					  BEGIN   
						 /*------------Added by Lalbahadur on 3/29/2013----------------------------*/
						 set @PriorityDate =  dbo.udf_GetAdOrderPriorityDate(@AdOrderId,@PositionTitle,@NextStringReg,@NextStringEdition)
						 /*-------------------------------------------------------------------------*/
						 
						 INSERT INTO AdOrderDetailsRegionEdition(AdOrderDetailsId,RegionID,EditionID,PriorityDate) 
						 VALUES(@OrderDetailsId,@NextStringReg,@NextStringEdition,@PriorityDate)    -- Priority date added by Fathima 0n 01-12-2011    
						 
						IF @AdOrderStatus>=3 AND @AdOrderStatus<=4
						BEGIN
						
							--Adding This Newly Added Ad To AdOrderDetailsRegionEditionRevision	
							INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId,EditionID,RegionID, PriorityDate, AdOrderRevisionId) 
							VALUES(@OrderDetailsId,@NextStringEdition, @NextStringReg, @PriorityDate, @AdOrderRevisionId)          
						
							--Adding All Existing Ads To AdOrderDetailsRegionEditionRevision	
							INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId, EditionID, RegionID, PriorityDate, AdOrderRevisionId) 			
							SELECT R.AdOrderDetailsId, R.EditionID, R.RegionID, R.PriorityDate, @AdOrderRevisionId 
							FROM AdOrderDetailsRegionEdition R WHERE AdOrderDetailsId IN
							(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId) 
							AND R.AdOrderDetailsId NOT IN(SELECT AdOrderDetailsId FROM AdOrderDetailsRegionEditionRevision WHERE AdOrderDetailsId IN
							(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId) AND AdOrderRevisionId = @AdOrderRevisionId)

						END
					  END  
					  ELSE  
					  BEGIN  
						 INSERT INTO AdOrderDetailsRegionEdition(AdOrderDetailsId,RegionID,EditionID,PriorityDate, OnlineMonth,OnlineYear) 
						 VALUES(@OrderDetailsId,@NextStringReg,@NextStringEdition,@PriorityDate,DATEPART(MONTH,@ActivationDate),DATEPART(YEAR,@ActivationDate))   -- Priority date added by Fathima 0n 01-12-2011         
						 
						IF @AdOrderStatus>=3 AND @AdOrderStatus<=4
						BEGIN	
						
							--Adding This Newly Added Ad To AdOrderDetailsRegionEditionRevision	
							INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId,EditionID, RegionID, PriorityDate, AdOrderRevisionId,OnlineMonth,OnlineYear) 
							VALUES(@OrderDetailsId,@NextStringEdition, @NextStringReg, @PriorityDate, @AdOrderRevisionId,DATEPART(MONTH,@ActivationDate),DATEPART(YEAR,@ActivationDate))             

							--Adding All Existing Ads To AdOrderDetailsRegionEditionRevision	
							INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId, EditionID, RegionID, PriorityDate, AdOrderRevisionId, OnlineMonth, OnlineYear) 			
							SELECT R.AdOrderDetailsId, R.EditionID, R.RegionID, R.PriorityDate, @AdOrderRevisionId, R.OnlineMonth, R.OnlineYear 
							FROM AdOrderDetailsRegionEdition R WHERE AdOrderDetailsId   IN
							(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId)
							AND R.AdOrderDetailsId NOT IN(SELECT AdOrderDetailsId FROM AdOrderDetailsRegionEditionRevision WHERE AdOrderDetailsId IN
							(SELECT AdOrderDetailsId FROM AdOrderDetailsRevision WHERE AdOrderId = @AdOrderId) AND AdOrderRevisionId = @AdOrderRevisionId)


						END
					  END  
					        
					 END         

				 
				 EXEC uspAdJobFolderCreatePrint      
				 EXEC uspAdJobFolderCreateOnline        
				 EXEC usp_AdOrderGrossNetAmount @AdOrderId, @GrossAmountPerGuranteedLine           
				                   
				 return @OrderDetailsId                                             
				                              
				END


GO
-----------------------------------------------------------------------------------------------------------------------------------------------
GO





/****** Object:  StoredProcedure [dbo].[usp_addCopyADOrder]    Script Date: 04/08/2013 18:45:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_addCopyADOrder]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_addCopyADOrder]
GO

/****** Object:  StoredProcedure [dbo].[usp_addCopyADOrder]    Script Date: 04/08/2013 18:45:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

  
    
    
---------------------------------------------------------------------------------                                                 
--  Created By : Karthik Palanisamy                                          
--  Created On : 29-May-2011                                        
--  Description: This is sp for copy order                 
-----------------------------------------------                       
-- Modified By : Siva Prakash D              
--  Modified On : 16 - jun -11              
--  Add History table         
----------------------------------------------------------             
-- [dbo].[usp_addCopyADOrder] 376566 ,84306, 160        
-- Modified By : Parameswar Mal        
--  Modified On : 28-02-2013        
--Description: not copy inactive order to new order        
--* Modified : By Lalbahdaur on 03/29/2013 Modified logic to enter priority dates based on below      
--1. If an order exists for that distributor (company) for given manufacturer in that zone the previous year than keep the priority date on the system. Don�t change anything.      
--2. If no order exists in previous year (either first time advertising or advertising after a break) then set the priority date to order date .      
--------------------------------------------------    
--* Modified  : By Parameswar on 05/April/2013    
 -- Checking for print orders  for Edition id     
 -- Get the OnlineMonth and OnlineYear from activation date if exists else get the OnlineMonth and OnlineYear from the order     
  ---------------------------------    
  --* Modified  : By Parameswar on 08/April/2013    
 -- added column  AIF_Instruction,AIF_Url in adorderdetails when copy
 -- added column AIF_PrintInstruction in order order when copy
  ---------------------------------------------------------------------------------                               
  CREATE PROCEDURE [dbo].[usp_addCopyADOrder]                   
  (                                
   @AdOrderId INT,                            
   @CreatedBy INT,          
   @GrossAmountPerGuranteedLine INT                        
  )                                             
  AS                                        
  BEGIN                                        
  DECLARE @NeworderID INT                              
  DECLARE @OrderDetailsId INT          
          
  --- CURSOR for check active and inactive order        
          
          
CREATE TABLE #TempActiveOrders    -- create temp table for active order                   
  (                          
        
 AdOrderDetailsId INT,        
 AdOrderId INT,        
 SectionID INT,        
 SizeTypeID INT,        
 AdTypeID INT,        
 LogoIndicator BIT,        
 PositionTitle BIGINT,        
 Comments VARCHAR(1000),        
 Price MONEY,        
 ApplyDiscount BIT,        
 CompIndicator CHAR(1),        
 CompCode VARCHAR(100),        
 Duration INT,        
 ActivationDate DATETIME,        
 LastUpdatedOn DATETIME,        
 LastUpdatedBy INT,        
 OrderType CHAR(1),        
 RateCardId INT,
 AIF_Instruction VARCHAR(MAX),
 AIF_Url VARCHAR(300), 
 OrderRegionId VARCHAR(100)        
)        
CREATE TABLE #TempInActiveOrders  -- create temp table for Inactive order                 
  (                          
        
 AdOrderDetailsId INT,        
 AdOrderId INT,        
 SectionID INT,        
 SizeTypeID INT,        
 AdTypeID INT,        
 LogoIndicator BIT,        
 PositionTitle BIGINT,        
 Comments VARCHAR(1000),        
 Price MONEY,        
 ApplyDiscount BIT,        
 CompIndicator CHAR(1),        
 CompCode VARCHAR(100),        
 Duration INT,        
 ActivationDate DATETIME,        
 LastUpdatedOn DATETIME,        
 LastUpdatedBy INT,        
 OrderType CHAR(1),        
 RateCardId INT,
 AIF_Instruction VARCHAR(MAX),
 AIF_Url VARCHAR(300),              
 OrderRegionId VARCHAR(100)        
)        
        
      DECLARE @AdOrderDetailsId INT         
      DECLARE @SectionID   INT          
      DECLARE @AdTypeID   INT        
      DECLARE @PositionTitle BIGINT        
          
  DECLARE curActiveOrder CURSOR FAST_FORWARD READ_ONLY FOR        
             
     SELECT AdOrderDetailsId,@AdOrderId, SectionID ,AdTypeID,PositionTitle FROM AdOrderDetails WHERE  AdOrderId = @AdOrderId         
                
                
     OPEN curActiveOrder              
     FETCH curActiveOrder               
     INTO @AdOrderDetailsId,@AdOrderId,@SectionID ,@AdTypeID,@PositionTitle             
                
     WHILE @@FETCH_STATUS = 0        
     BEGIN        
            
 IF (SELECT [dbo].[GetActiveSalesOrder](@AdOrderId,@SectionID,@PositionTitle))> 0    --  for active order for(M,X,D,V,P)        
     OR (SELECT [dbo].[GetActiveSalesOrder](@AdOrderId,@SectionID,@PositionTitle))= -1   -- -1 for active order for other section        
                 
      BEGIN   -- for Active order             
      INSERT INTO #TempActiveOrders              
      SELECT        
    AdOrderDetailsId,        
    AdOrderId,                         
    SectionID,                            
    SizeTypeID,             
    AdTypeID,                            
    LogoIndicator,                            
    PositionTitle,                            
    Comments,                            
    Price,                            
    ApplyDiscount,                            
    CompIndicator,                            
    CompCode,                            
    Duration,                            
    ActivationDate,                            
    LastUpdatedOn,                            
    LastUpdatedBy,                            
    OrderType,                
    RateCardId,
    AIF_Instruction,
	AIF_Url,          
    OrderRegionId  FROM AdOrderDetails WHERE  AdOrderDetailsId = @AdOrderDetailsId         
      END        
                
      ELSE    -- for inactive order        
      BEGIN        
       INSERT INTO #TempInActiveOrders              
       SELECT        
       AdOrderDetailsId,        
       AdOrderId,                         
    SectionID,                            
    SizeTypeID,                            
    AdTypeID,                            
    LogoIndicator,                            
    PositionTitle,                            
    Comments,                            
    Price,                            
    ApplyDiscount,                            
    CompIndicator,                            
    CompCode,                            
    Duration,                            
    ActivationDate,                            
    LastUpdatedOn,                            
    LastUpdatedBy,                            
    OrderType,                
    RateCardId,
    AIF_Instruction,
	AIF_Url,             
    OrderRegionId  FROM AdOrderDetails WHERE  AdOrderDetailsId = @AdOrderDetailsId          
     END           
            
                
     FETCH curActiveOrder               
      INTO @AdOrderDetailsId,@AdOrderId,@SectionID ,@AdTypeID,@PositionTitle             
             
     END              
                
     CLOSE curActiveOrder              
     DEALLOCATE curActiveOrder              
            
      ---END  CURSOR for check active and inactive order        
          
     IF EXISTS(SELECT * FROM #TempActiveOrders WHERE AdOrderId=@AdOrderId)         
          
     BEGIN        
                              
   --copy adorder                            
   INSERT INTO adorder                            
   (                            
    SalesPersonId,                            
    CompanyId,                            
    StatusId,                            
    CoopIndicator,                            
    ContactId,                            
    BilltoId,                            
    SoldtoId,                            
    AuthorizedId,                            
    AddressProofId,                            
    CorpId,                            
    MsgCode,                            
    POnumber,                            
    Notes,                            
    Comments,                            
    BillingInstruction,                            
    RateCardYear,                            
    OrderDate,                            
    LastUpdatedOn,                            
    LastUpdatedBy,                            
    VersionNo,                            
    ExistingOrderId,                          
    GrossAmount,                        
    NetAmount,                          
    DiscountRate,              
    OverwriteDiscountFlag,
    AIF_PrintInstruction                         
   )                            
   SELECT                            
    SalesPersonId,                            
            
    CompanyId,                            
    1,                            
    CoopIndicator,                            
    ContactId,                            
    BilltoId,                            
    SoldtoId,                            
    AuthorizedId,                            
    AddressProofId,                            
    CorpId,                            
    MsgCode,                            
    POnumber,                            
    Notes,                            
    Comments,                            
    BillingInstruction,                            
    RateCardYear,                
    Getdate(),                            
    Getdate(),                            
    @CreatedBy,                            
    VersionNo,                            
    ExistingOrderId,                          
    GrossAmount,                          
    NetAmount,                     
    DiscountRate,              
    OverwriteDiscountFlag,
    AIF_PrintInstruction                   
                              
   FROM adorder                            
   WHERE  AdOrderId = @AdOrderId                            
                               
   SET @NeworderID = SCOPE_IDENTITY()              
   --set @NewAdOrderId =  @NeworderID                           
                             
                               
   UPDATE adorder SET AdOrderNumber = @NeworderID + 1000                  
   WHERE AdOrderId = @NeworderID                 
   --//History                         
   INSERT INTO AdOrderRevision VALUES(@NeworderID,1,GETDATE(), (Select DiscountRate FROM adorder              
   WHERE  AdOrderId = @AdOrderId))                
         
             
   --//copy adorderdetails       
         
    -- create temp table for  AdOrdersDetailsIdMap        
   CREATE TABLE #TempAdOrdersDetailsNewOldID                
    (                          
    AdOrderId INT,      
    AdOrderDetailsIdOld INT,        
    AdOrderDetailsIdNew INT,        
       
     )        
    ---START  CURSOR  ADORDER DETAILS ENTRY      
    DECLARE @AdOrderDetailsId_Old INT       
    DECLARE @AdOrderDetailsId_New INT        
    DECLARE curAdOrderDetails CURSOR FAST_FORWARD READ_ONLY FOR        
          
       -- select old adorder Details ID        
     SELECT AdOrderDetailsId FROM #TempActiveOrders WHERE  AdOrderId = @AdOrderId       
            
     OPEN curAdOrderDetails              
     FETCH curAdOrderDetails               
     INTO @AdOrderDetailsId_Old            
                
     WHILE @@FETCH_STATUS = 0        
     BEGIN        
            
     BEGIN   -- for Active AdOrderDetailsId          
    INSERT INTO AdOrderDetails                            
   (                            
    AdOrderId,                            
    SectionID,                            
    SizeTypeID,                            
    AdTypeID,                            
    LogoIndicator,                            
    PositionTitle,                            
    Comments,                            
    Price,                            
    ApplyDiscount,                            
    CompIndicator,                            
    CompCode,                            
    Duration,                            
    ActivationDate,                            
    LastUpdatedOn,                            
    LastUpdatedBy,                            
    OrderType,                
    RateCardId,
    AIF_Instruction,
	AIF_Url, 
    OrderRegionId                          
   )                            
   SELECT                            
    @NeworderID,                            
    SectionID,                            
    SizeTypeID,                            
    AdTypeID,                            
    LogoIndicator,             
    PositionTitle,                            
    Comments,                            
    price,                         
    ApplyDiscount,                            
    CompIndicator,                            
    CompCode,                            
    Duration,   
   (CASE WHEN OrderType = 'O' THEN dbo.[GetSalesOrderActivationDate](AdOrderDetailsId) ELSE NULL END), -- Get activation date  
	 GETDATE(),                            
    @CreatedBy,                            
    OrderType,                
    RateCardId,
    AIF_Instruction,
	AIF_Url,   
    OrderRegionId                
   FROM #TempActiveOrders                            
  WHERE  AdOrderDetailsId = @AdOrderDetailsId_Old       
          
    SET @AdOrderDetailsId_New = SCOPE_IDENTITY() -- set new adorderdetails id      
                
     INSERT INTO #TempAdOrdersDetailsNewOldID -- inserting mapping table                           
             (AdOrderId,AdOrderDetailsIdOld,AdOrderDetailsIdNew) VALUES(@NeworderID,@AdOrderDetailsId_Old,@AdOrderDetailsId_New )        
           
       END       
                    
     FETCH curAdOrderDetails               
      INTO @AdOrderDetailsId_Old             
             
     END              
                
     CLOSE curAdOrderDetails              
     DEALLOCATE curAdOrderDetails              
            
      ---END  CURSOR DETAILS      
   
                   
   DECLARE @AdOrderRevisionId INT               
   DECLARE @AdOrderRevisionCount INT              
                 
   SELECT @AdOrderRevisionId=MAX(AdOrderRevisionId) FROM AdOrderRevision WHERE AdOrderId=@NeworderID               
   INSERT INTO AdOrderDetailsRevision(AdOrderDetailsId,AdOrderId,SectionID,SizeTypeID,AdTypeID,LogoIndicator,PositionTitle,Price,ApplyDiscount,CompIndicator,CompCode,Duration,ActivationDate,OrderType,RateCardId,AdOrderRevisionId)              
   SELECT AdOrderDetailsId,@NeworderID,SectionID,SizeTypeID,AdTypeID,LogoIndicator,PositionTitle,Price,ApplyDiscount,CompIndicator,CompCode,Duration,ActivationDate,OrderType,RateCardId,@AdOrderRevisionId from AdOrderDetails where  AdOrderId= @NeworderID 

   --// copy AdOrderDetailsRegionEdition                          
   CREATE TABLE #AdOrderTEMP                         
   (                          
    AdOrderDetailsId INT,                          
    EditionID INT,                          
    RegionID INT,                          
    ADJobFolderID INT,                       
    PriorityDate DATETIME,              
    OnlineMonth  int,              
    OnlineYear   int,      
    PositionTitle int,      
    AdOrderId int              
   )                          
   INSERT INTO #AdOrderTEMP                          
   SELECT                          
  ADR.AdOrderDetailsId,                          
  (CASE WHEN AD.OrderType = 'P' THEN dbo.GetSalesOrderCurrentEditionID(ADR.RegionID) ELSE 0 END) AS EditionID,    -- get the earliest open edition in given region      
  ADR.RegionID,                          
  NULL,                          
  PriorityDate,   
 (CASE WHEN AD.OrderType = 'O' THEN ISNULL(DATEPART(MONTH,dbo.[GetSalesOrderActivationDate](ADR.AdOrderDetailsId)),OnlineMonth) ELSE OnlineMonth END)AS OnlineMonth,    
 (CASE WHEN AD.OrderType = 'O' THEN ISNULL(DATEPART(YEAR,dbo.[GetSalesOrderActivationDate](ADR.AdOrderDetailsId)),OnlineYear) ELSE OnlineYear END)AS OnlineYear,        
  AD.PositionTitle,      
  AD.AdOrderId                         
  FROM AdOrderDetailsRegionEdition ADR INNER JOIN #TempActiveOrders AD ON ADR.AdOrderDetailsId = AD.AdOrderDetailsId AND                          
  AdOrderId = @AdOrderId                          
      
         
   ---START  CURSOR  DETAILS RegionEdition       
   
    DECLARE @AdOrderDetailsIdOldEdition INT       
    DECLARE @AdOrderDetailsIdNewEdition INT        
    DECLARE curUpdateActiveOrderID CURSOR FAST_FORWARD READ_ONLY FOR       
          
     SELECT AdOrderDetailsIdOld,AdOrderDetailsIdNew FROM #TempAdOrdersDetailsNewOldID WHERE  AdOrderId = @NeworderID          
                 
                
     OPEN curUpdateActiveOrderID              
     FETCH curUpdateActiveOrderID               
     INTO @AdOrderDetailsIdOldEdition,@AdOrderDetailsIdNewEdition            
                
     WHILE @@FETCH_STATUS = 0        
     BEGIN        
            
         BEGIN      
            -- UPDATE OLD AdOrderDetailsId TO NEW  AdOrderDetailsId         
          UPDATE #AdOrderTEMP SET                          
          AdOrderDetailsId = @AdOrderDetailsIdNewEdition Where AdOrderDetailsId = @AdOrderDetailsIdOldEdition         
              
         END       
                    
     FETCH curUpdateActiveOrderID   
     INTO @AdOrderDetailsIdOldEdition,@AdOrderDetailsIdNewEdition                
             
     END              
                
     CLOSE curUpdateActiveOrderID              
     DEALLOCATE curUpdateActiveOrderID              
            
      ---END  CURSOR DETAILS EDITION      
        
                             
   INSERT INTO AdOrderDetailsRegionEdition                          
   SELECT                          
    AdOrderDetailsId,                          
    EditionID,                          
    RegionID,                          
    NULL,                          
    --PriorityDate,              
    dbo.udf_GetAdOrderPriorityDate(AdOrderId,PositionTitle,RegionID,EditionID),      
    OnlineMonth,              
    OnlineYear                           
   FROM #AdOrderTEMP                   
                 
   INSERT INTO AdOrderDetailsRegionEditionRevision(AdOrderDetailsId,RegionID,EditionID,AdOrderRevisionId,OnlineMonth,OnlineYear)              
   SELECT AdOrderDetailsId,RegionID,EditionID,@AdOrderRevisionId,OnlineMonth,OnlineYear FROM #AdOrderTEMP                               
          
   DROP TABLE #AdOrderTEMP                          
   DROP TABLE  #TempAdOrdersDetailsNewOldID                                
                             
    EXEC usp_AdOrderGrossNetAmount @NeworderID , @GrossAmountPerGuranteedLine         
                     
   END         
           
   -- slect new order id        
           
    SELECT @NeworderID as NeworderID        
            
    ---select inactive order        
            
   SELECT AdOrderDetailsId,        
   (CASE WHEN dbo.GetPositionTitle(A.PositionTitle,A.SectionID) = '-' THEN S.Description +' '+SZ.Description +' '          
     ELSE S.Description +' '+SZ.Description +' at '+ dbo.GetPositionTitle(A.PositionTitle,A.SectionID) END)           
     AS SizeSectionPosition,      
       
      (CASE WHEN A.SectionID IN (1,2,12,14,18,26,31,38) THEN (SELECT CompanyName +' - ' +'Inactive' FROM Company WHERE CompanyID=A.PositionTitle)           
              ELSE (CASE WHEN A.SectionID IN (3,4,13,16) THEN (SELECT TypeDescription  +' - ' +'Inactive' FROM  ProductType where ProductTypeId = A.PositionTitle)END) END)      
      AS Remarks       
         
             
      From #TempInActiveOrders  A                 
    INNER JOIN SalesSectionType S ON A.SectionID=S.SectionID                  
    INNER JOIN SalesSizeType SZ ON A.SizeTypeID=SZ.SizeTypeID                 
    WHERE  A.AdOrderId = @AdOrderId             
             
     DROP TABLE  #TempActiveOrders         
     DROP TABLE #TempInActiveOrders              
           
  END          
          
        
      
GO


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_seo_getSiteMapData]    Script Date: 12/19/2012 08:27:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SiteMapLoad_GetSiteMapLinks]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_SiteMapLoad_GetSiteMapLinks]
GO


/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Used to generate sitemap

Used by: 
Global.ascx

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
12.18.2012		Marcus Ruether		Created. 
04.08.2013		Marcus Ruether		Updated to use Search_PartNumber rather than remove special chars from PartNumber with a function
									Added another procedure used in the sitemap gen process - renamed this one to make them consistent
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[usp_SiteMapLoad_GetSiteMapLinks]
AS
BEGIN

	DECLARE @CurrentDate DATETIME = GETDATE();
	CREATE TABLE #tblSiteMapLink_Group 
	(
		[Url] [varchar](500) NOT NULL,
		[ChangeFrequency] [varchar](10) NULL,
		[Priority] [decimal](18, 2) NULL
	)
	
	IF EXISTS(SELECT * FROM tmp_SiteMapLoad_SiteMapLink)
	BEGIN
		
		--Deactivate links that are not in the current list of urls.		
		UPDATE 
			sml SET sml.Active = 0, DateModified = @CurrentDate
		FROM 
			SiteMapLink sml LEFT JOIN
			tmp_SiteMapLoad_SiteMapLink tsml on tsml.Url = sml.Url
		WHERE 
			tsml.Url IS NULL
		
		--Delete those because we no longer need them. (they've been disabled)
		DELETE
			tsml
		FROM 
			SiteMapLink sml LEFT JOIN
			tmp_SiteMapLoad_SiteMapLink tsml on tsml.url = sml.Url
		WHERE 
			tsml.Url IS NULL
		
		--Active inactive links that are in the current list of url.
		UPDATE 
			sml SET sml.Active = 1, DateModified = @CurrentDate
		FROM 
			SiteMapLink sml LEFT JOIN
			tmp_SiteMapLoad_SiteMapLink tsml on tsml.url = sml.Url
		WHERE 
			tsml.Url IS NOT NULL AND
			sml.Active = 0
			
		--Delete records that already exist or have just been enabled
		DELETE tsml
		FROM 
			SiteMapLink sml INNER JOIN
			tmp_SiteMapLoad_SiteMapLink tsml on tsml.url = sml.Url
		

		DECLARE @SiteMapNumber INT;
		DECLARE @SiteMapCount INT;
		SET @SiteMapNumber = (SELECT ISNULL(MAX(SiteMapNumber), 0) FROM SiteMapLink);
		--sitemap can only have 50,000 records, so limit each one to that number
		
		SET @SiteMapCount = 50000;
		if (SELECT COUNT(*) FROM SiteMapLink WHERE SiteMapNumber = @SiteMapNumber) < 50000 
			BEGIN
				SET @SiteMapCount = (SELECT TOP 1 50000 - COUNT(*) FROM SiteMapLink WHERE SiteMapNumber = @SiteMapNumber);	
			END
		
		IF OBJECT_ID('tempdb..#tmpSiteMapLinkGroup') IS NOT NULL
		BEGIN
			DROP TABLE #tmpSiteMapLinkGroup
		END
		
		CREATE TABLE #tmpSiteMapLinkGroup
		(
			[SiteMapNumber] [int] NOT NULL,
			[Url] [varchar](500) NOT NULL,
			[ChangeFrequency] [varchar](10) NULL,
			[Priority] [decimal](18, 2) NULL,
			[Active] [bit] NOT NULL,
			[DateModified] [datetime] NULL,
			[DateCreated] [datetime] NULL,
		)

		WHILE EXISTS(SELECT * FROM tmp_SiteMapLoad_SiteMapLink)
			BEGIN

				/****** Object:  Index [IX_SiteMapLink_Url_SiteMapNumber]    Script Date: 04/08/2013 18:11:08 ******/
				IF  EXISTS (SELECT * FROM tempdb.sys.indexes WHERE object_id = OBJECT_ID(N'tempdb.dbo.#tmpSiteMapLinkGroup') AND name = N'IX_SiteMapLink_Url')
					BEGIN
						DROP INDEX [IX_SiteMapLink_Url] ON [dbo].#tmpSiteMapLinkGroup;
					END

				TRUNCATE TABLE #tmpSiteMapLinkGroup;
				INSERT INTO #tmpSiteMapLinkGroup 
				(
					SiteMapNumber,
					Url,
					ChangeFrequency,
					Priority,
					Active,
					DateModified,
					DateCreated
				)
				SELECT DISTINCT TOP(@SiteMapCount) 
				@SiteMapNumber,
				Url,
				ChangeFrequency,
				[Priority],
				1,
				@CurrentDate,
				@CurrentDate
				FROM 
				tmp_SiteMapLoad_SiteMapLink
				
				CREATE NONCLUSTERED INDEX [IX_SiteMapLink_Url] ON [dbo].#tmpSiteMapLinkGroup 
				(
					[Url] ASC
				)
				
				INSERT INTO SiteMapLink
				(
					SiteMapNumber,
					Url,
					ChangeFrequency,
					Priority,
					Active,
					DateModified,
					DateCreated
				)
				SELECT 
					SiteMapNumber,
					Url,
					ChangeFrequency,
					Priority,
					Active,
					DateModified,
					DateCreated
				 FROM #tmpSiteMapLinkGroup
				
				-- select records that were just added
				DELETE smlt
				FROM 
				tmp_SiteMapLoad_SiteMapLink smlt INNER JOIN
				#tmpSiteMapLinkGroup sml on smlt.Url = sml.Url
				
				--sitemap can only have 50,000 records, so limit each one to that number
				SET @SiteMapCount = (SELECT TOP 1 COUNT(*) FROM tmp_SiteMapLoad_SiteMapLink); -- how many are left for insertion?
				if (@SiteMapCount > 50000)
					BEGIN
						SET @SiteMapCount = 50000
					END
					
				SET @SiteMapNumber = @SiteMapNumber + 1
			END
		
	END
	
	SELECT * FROM SiteMapLink 
	WHERE Active = 1
	ORDER BY SiteMapLinkId, Url
	
END

GO

/****** Object:  StoredProcedure [dbo].[usp_SiteMapLoad_GetSiteMapData]    Script Date: 12/19/2012 08:27:22 ******/

-- This is to make sure what this procedure used to be called get dropped.
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_seo_getSiteMapData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_seo_getSiteMapData]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SiteMapLoad_GetSiteMapData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_SiteMapLoad_GetSiteMapData]
GO

-- usp_SiteMapLoad_GetSiteMapData
/*------------------------------------------------------------------------------------------------------------------------------------------   
Description: 
Used to generate sitemap

Used by: 
Global.ascx

History:
Date			 Author				Notes            
--------------------------------------------------------------------------------------------------------------------------------------------
12.18.2012		Marcus Ruether		Created. 
04.08.2013		Marcus Ruether		Updated to use Search_PartNumber rather than remove special chars from PartNumber with a function
									Added another procedure used in the sitemap gen process - renamed this one to make them consistent
------------------------------------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[usp_SiteMapLoad_GetSiteMapData]
AS
BEGIN
	--TABLE 0
	--Company Details
	SELECT DISTINCT
		c.Search_CompanyName as CompanyName
	FROM
		Company c WITH (NOLOCK)
	WHERE 
		c.IsActive = 1 AND 
		c.SearchName IS NOT NULL;
		
	--TABLE 1
	--Product Details
	SELECT DISTINCT 
	pt.ProductTypeId,
	dbo.RemoveSpecialCharacter(pt.TypeDescription) as ProductTypeName
	FROM ProductType pt WITH (NOLOCK)
	WHERE 
		pt.IsServices = 0 AND
		pt.IsActive = 1 AND
		pt.TypeDescription IS NOT NULL;
	
	--TABLE 2
	--Service Details
	SELECT 
	pt.ProductTypeId,
	dbo.RemoveSpecialCharacter(pt.TypeDescription) as ServiceName
	FROM ProductType pt WITH (NOLOCK)
	WHERE 
		pt.IsServices = 1 AND
		pt.IsActive = 1 AND
		pt.TypeDescription IS NOT NULL
	ORDER BY pt.typeDescription ;
		
	--TABLE 3
	-- Part Details
	SELECT DISTINCT
	dp.Search_PartNumber AS PartNumber,
	dp.Search_MFR_Name as ManufacturerName
	FROM vw_DistributorPartsSearch dp WITH (NOLOCK)
	WHERE dp.PartNumber IS NOT NULL and dp.Search_MFR_Name IS NOT NULL
	order by Search_PartNumber
	
	IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[tmp_SiteMapLoad_SiteMapLink]') AND name = N'IX_tmp_SiteMapLoad_SiteMapLink_Url')
	BEGIN
		DROP INDEX [IX_tmp_SiteMapLoad_SiteMapLink_Url] ON [dbo].[tmp_SiteMapLoad_SiteMapLink] WITH ( ONLINE = OFF )
	END
	
	TRUNCATE TABLE tmp_SiteMapLoad_SiteMapLink; -- prepare for bulk insert into this temp table.
	
	
	CREATE NONCLUSTERED INDEX [IX_tmp_SiteMapLoad_SiteMapLink_Url] ON [dbo].[tmp_SiteMapLoad_SiteMapLink] 
	(
		[Url] ASC
	)
END

GO

/****** Object:  StoredProcedure [dbo].[usp_SearchManufacturerWithUser]    Script Date: 12/31/2012 16:37:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SearchManufacturerWithUser]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_SearchManufacturerWithUser]
GO

/****** Object:  StoredProcedure [dbo].[usp_SearchManufacturerWithUser]    Script Date: 12/31/2012 16:37:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

  
  
  /*  
  [usp_SearchManufacturerWithUser] 'Texas','','','','',''  
  */  
  -- EXEC usp_SearchManufacturerWithUser 'diode','','1','4','','','',84306  
  /*------------------------------------------------------------------------------------------------------------------------------------------     
  Description:   
  {This should be a short description about the functionality of this procedure.}  
  
  Parameters:  
  {A short description of parameters and default values if there is any.}  
  
  Used by:   
  {This could be the name of a single webpage or multiple web pages or a SSIS package or a scheduled job etc. But if this functionality is used in many places within an application then just mention the application name. Otherwise <application name>.<modu
le name or web page name>}  
  (Having this information will be very helpful to find out what all applications will get affected if we need to make a change.)  
  
  History:  
  Date    Author    Notes              
  --------------------------------------------------------------------------------------------------------------------------------------------  
  MM.DD.YYYY  <developer name>  Created.   
  12.7.2012  Marcus Ruether  Updated to properly apply region filter when determining enhancement status.  
  ------------------------------------------------------------------------------------------------------------------------------------------*/  
--   
-- exec usp_SearchManufacturerWithUser @SEARCH='altera',@DIST_ID=NULL,@USER_Region='3',@USER_ZONE='0',@DIST_AUTH=NULL,@AttributesIds=NULL,@IsFilterByRegion='1',@UserID=-1    
  CREATE PROCEDURE [dbo].[usp_SearchManufacturerWithUser]  
  (  
   @SEARCH VARCHAR(1000),  
   @DIST_ID VARCHAR(100) = '',  
   @USER_Region VARCHAR(100)= '',  
   @USER_ZONE VARCHAR(100)= '',  
   @DIST_AUTH VARCHAR(100)= '0',  
   @AttributesIds VARCHAR(100)= '',  
   @IsFilterByRegion VARCHAR(10) = '0',  
   @UserID int = 0  
  )  
  AS  
  BEGIN  
  
   set transaction isolation level read uncommitted  
  
   IF(@DIST_ID IS NULL) BEGIN SET @DIST_ID = '' END  
   IF(@USER_Region IS NULL) BEGIN SET @USER_Region = '' END  
   IF(@USER_ZONE IS NULL) BEGIN SET @USER_ZONE = '0' END  
   IF(@USER_ZONE = '') BEGIN SET @USER_ZONE = '0' END  
   IF(@DIST_AUTH IS NULL) BEGIN SET @DIST_AUTH = '' END  
   IF(@IsFilterByRegion IS NULL) BEGIN SET @IsFilterByRegion = '' END  
  
   DECLARE @MAIN_QUERY VARCHAR(MAX)  
   DECLARE @CLEANSEARCH VARCHAR(MAX)  
   DECLARE @JoinAttributes VARCHAR(3000)=''  
  
   Declare @IsEmptyDistIDs VARCHAR(1) = '0'  
   Declare @IsEmptyRegionIDs VARCHAR(1) = '0'  
   Declare @IsEmptyZoneIDs VARCHAR(1) = '0'  
        
   DECLARE @REPLACE_REGIONS_TEMP VARCHAR(MAX)  
  
  
   IF(@DIST_ID = '') BEGIN SET @IsEmptyDistIDs = 1 END  
   IF(@USER_Region = '') BEGIN SET @IsEmptyRegionIDs = 1 END  
   IF(@USER_ZONE = '0' ) BEGIN SET @IsEmptyZoneIDs = 1 END  
   IF(@DIST_AUTH = '') BEGIN SET @DIST_AUTH = '0' END  
   IF(@IsFilterByRegion = '') BEGIN SET @IsFilterByRegion = '0' END  
     
   --23657 - addresses issue with enhancements not appearing properly when clicking the US region filter.  
   -- Replaced logic that was removing region 1 or 2.  
     
   --IF (@IsFilterByRegion <> '0')  
    --BEGIN  
       
          --SET @REPLACE_REGIONS_TEMP = @USER_Region  
           SET @REPLACE_REGIONS_TEMP =  replace(@USER_Region, '1', '')  
           SET @REPLACE_REGIONS_TEMP  = replace(@REPLACE_REGIONS_TEMP, '2', '')  
           SET @REPLACE_REGIONS_TEMP  = replace(@REPLACE_REGIONS_TEMP, '''', '')  
    --   
    --END  
   --ELSE  
   -- BEGIN  
   --  SET @REPLACE_REGIONS_TEMP = '0'  
      
   -- END  
   print @REPLACE_REGIONS_TEMP  
      
   SET @DIST_ID = '' + REPLACE(@DIST_ID,',',''',''') + ''  
   SET @USER_Region = '' + REPLACE(@USER_Region,',',''',''') + ''  
   SET @USER_ZONE = '' + REPLACE(@USER_ZONE,',',''',''') + ''  
  
        
   --Attributes  
   IF((@AttributesIds IS NOT NULL) AND (@AttributesIds <> ''))  
   BEGIN  
   SET @JoinAttributes = 'INNER JOIN dbo.CompanyOwnershipMapping com  
    ON com.CompanyID=reg_auth.DistID  
    INNER JOIN (SELECT * FROM dbo.Split('''+@AttributesIds+''','','')) as Attributes  
    ON com.OwnershipID = Attributes.items'  
   END      
  
   SET @SEARCH = [dbo].VK_RemoveSpecialChars(@SEARCH)  
   SET @CLEANSEARCH = [dbo].RemoveSpecialCharacter(@SEARCH)  
  
   IF OBJECT_ID(N'tempdb..#mantemp1', N'U') IS NOT NULL   
    DROP TABLE #mantemp1  
  
   CREATE TABLE #mantemp1(  
    CompanyID INT NULL,  
    CompanyName VARCHAR(100) NULL,  
    CompanyLogo VARCHAR(100) NULL,  
    CompanyDescription VARCHAR(MAX) NULL,  
    AlsoKnownAS  VARCHAR(MAX) NULL,  
    MaxAuth INT NULL,  
    DistributorId INT NULL,  
    DistributorName VARCHAR(100)NULL,  
    DistributorLogo VARCHAR(100) NULL,  
    DistributorAttributes VARCHAR(MAX) NULL,  
    CompanyStatus INT NULL,  
    WebVersion VARCHAR(500) NULL,  
    WebVersionWOZone VARCHAR(500) NULL,   
    DistID INT NULL,  
    Total decimal NULL,  
    --Total INT NULL,  
    CheckInvURL VARCHAR(200) NULL,  
    IsFav INT NULL,  
    MatchOrder VARCHAR(200) NULL,  
    Trusted_Disty BIT NULL,  
    Priority_Date [datetime] NULL)  
  
  
  
  
  declare @splRegionQuery varchar(max) = 'select min(WebVersion) WebVersion,distmfr.DistID,distmfr.MfrID from lm_distributor_orders (nolock) distmfr  
        JOIN AdOrderDetailsRegionEdition ad_oder_reg_edit  
        ON distmfr.AdOrderDetailsId = ad_oder_reg_edit.AdOrderDetailsId  
        AND (ad_oder_reg_edit.RegionID in ('''+@USER_ZONE+''') and ad_oder_reg_edit.RegionID <> ''0'')  
        group by distmfr.DistID,distmfr.MfrID'
  if (@IsFilterByRegion = '1' and (@USER_Region like '%1%'))
  begin
     set @splRegionQuery = 'select min(WebVersion) WebVersion,distmfr.DistID,distmfr.MfrID
        from lm_distributor_orders (nolock) distmfr  
        JOIN AdOrderDetailsRegionEdition ad_oder_reg_edit  ON distmfr.AdOrderDetailsId = ad_oder_reg_edit.AdOrderDetailsId  
        AND (ad_oder_reg_edit.RegionID in ('''+@USER_ZONE+''') and ad_oder_reg_edit.RegionID <> ''0'')  
        group by WebVersion, distmfr.DistID,distmfr.MfrID
        having COUNT(ad_oder_reg_edit.RegionID) = 9'
  end
  
  SET @MAIN_QUERY = '  
  DECLARE @SEARCH_QUERY VARCHAR(300)  
  SET @SEARCH_QUERY = '''+@SEARCH+'''  
               
   SELECT DISTINCT  -- review if we can remove distinct from here  
       mfr.CompanyID,  
       mfr.CompanyName,  
       mfr.CompanyLogo,  
       mfr.CompanyDescription,  
       also_know.AlsoKnownAs AS AlsoKnownAS,  
       IsNULL(Dist_Qry.MaxAuth, 0) AS MaxAuth,  
       Dist_Qry.DistributorId,  
       Dist_Qry.DistributorName,  
       Dist_Qry.DistributorLogo,  
       Dist_Qry.DistributorAttributes,  
       mfr.CompanyStatus,  
       Dist_Qry.WebVersion,  
       Dist_Qry.WebVersionWOZone,  
       Dist_Qry.DistID,  
       IsNULL(Dist_Qry.Total, 0) AS Total,  
       Dist_Qry.CheckInvURL,  
       CASE WHEN ( uf.TypeID IS NULL ) THEN 0 ELSE 1 END  AS IsFav ,  
       CASE WHEN (mfr.Search_CompanyName LIKE '''+@CLEANSEARCH+''') THEN ''11''  
       WHEN (mfr.Search_AlsoKnownAs LIKE '''+@CLEANSEARCH+''') THEN ''12''  
       WHEN (mfr.Search_BookName1 LIKE '''+@CLEANSEARCH+'''  
       OR mfr.Search_BookName2 LIKE '''+@CLEANSEARCH+'''  
       OR mfr.Search_Keyword1 LIKE '''+@CLEANSEARCH+'''  
       OR mfr.Search_Keyword2 LIKE '''+@CLEANSEARCH+''') THEN ''13''  
  
       WHEN (mfr.Search_CompanyName LIKE '''+ @CLEANSEARCH + '%'') THEN ''21''  
       WHEN (mfr.Search_AlsoKnownAs LIKE '''+@CLEANSEARCH + '%'') THEN ''22''  
       WHEN (mfr.Search_BookName1 LIKE '''+@CLEANSEARCH + '%''  
       OR mfr.Search_BookName2 LIKE '''+@CLEANSEARCH + '%''  
       OR mfr.Search_Keyword1 LIKE '''+@CLEANSEARCH + '%''  
       OR mfr.Search_Keyword2 LIKE '''+@CLEANSEARCH + '%'') THEN ''23''  
              
       WHEN (mfr.Clean_CompanyName LIKE search_term.items + ''_%'')THEN ''31''  
       WHEN (mfr.Clean_AlsoKnownAs LIKE search_term.items + ''_%'')THEN ''32''  
       WHEN (mfr.Clean_BookName1 LIKE search_term.items + ''_%''  
       OR mfr.Clean_BookName2 LIKE search_term.items + ''_%''  
       OR mfr.Clean_Keyword1 LIKE search_term.items + ''_%''  
       OR mfr.Clean_Keyword2 LIKE search_term.items + ''_%'')THEN ''33''  
  
       WHEN (mfr.Clean_CompanyName LIKE ''_%'' + search_term.items + ''%'')THEN ''34''  
       WHEN (mfr.Clean_AlsoKnownAs LIKE ''_%'' + search_term.items + ''%'')THEN ''35''  
       WHEN (mfr.Clean_BookName1 LIKE ''_%'' + search_term.items + ''%''  
       OR mfr.Clean_BookName2 LIKE ''_%'' + search_term.items + ''%''  
       OR mfr.Clean_Keyword1 LIKE ''_%'' + search_term.items + ''%''  
       OR mfr.Clean_Keyword2 LIKE ''_%'' + search_term.items + ''%'')THEN ''36'' ELSE ''40''  
     END AS MatchOrder,   
     IsNULL(Dist_Qry.Trusted_Disty, 0) AS Trusted_Disty,  
     Dist_Qry.Priority_Date  
                 
    FROM (SELECT * FROM dbo.Split(@SEARCH_QUERY,'' '')) AS search_term  
    JOIN [dbo].[lm_seeline_manufacturer] (nolock) AS mfr  
      ON mfr.Clean_CompanyName LIKE ''%'' + search_term.items + ''%''  
      OR mfr.Clean_AlsoKnownAs LIKE ''%'' + search_term.items + ''%''  
      OR mfr.Clean_BookName1 LIKE ''%'' + search_term.items + ''%''  
      OR mfr.Clean_Keyword1 LIKE ''%'' + search_term.items + ''%''  
      OR mfr.Clean_BookName2 LIKE ''%'' + search_term.items + ''%''  
      OR mfr.Clean_Keyword2 LIKE ''%'' + search_term.items + ''%''  
    Left Join [dbo].[MFRAlsoKnownAs] (nolock) also_know on also_know.CompanyID = mfr.CompanyID  
    LEFT JOIN dbo.[UserFavorites]  uf (NOLOCK)  ON mfr.CompanyID = uf.TypeID  
      AND uf.[FavType] in (1,2,4) AND CAST(UserID AS VARCHAR)  = '''+CAST(@UserID AS VARCHAR)+'''  
            
    LEFT JOIN (  
     SELECT DISTINCT  -- review if we can remove distinct from here  
      reg_auth.MfrID AS CompanyID,  
      CASE WHEN (RZS.MaxAuth = 1 OR RZS.MaxAuth = 2 OR RZS.MaxAuth = 3 OR RZS.MaxAuth IS NULL) THEN  1  
       ELSE RZS.MaxAuth END AS MaxAuth ,  
      dist.CompanyId AS DistributorId,  
      dist.CompanyName as DistributorName,  
      dist.CompanyLogo as DistributorLogo,  
      dbo.Get_SearchCompanyOwn (reg_auth.DistID) AS DistributorAttributes,  
      dist_order.WebVersion,  
      dist_order2.WebVersionWOZone,  
      dist.CompanyID as DistID,  
      IsNULL(Spend.Total, 0) AS Total,  
      invs.CheckInvURL,  
      isnull(dist.Trusted_Disty,0) as Trusted_Disty,Spend.Priority_Date  
                 
      FROM [dbo].[RegionAuthorization] (nolock) reg_auth   
  
       LEFT JOIN [dbo].[InventorySettings] invs ON reg_auth.DistID = invs.CompanyID  
  
      left join (  
       Select  
        RZOS.MFRDistID,  
        MAX(case when (AuthStatusID  = 2 and C.Trusted_Disty=1) then 4  
         else AuthStatusID end) as MaxAuth  
       From  
        RegionZoneStatus (nolock) RZOS,  
        Company (nolock) C,  
        RegionAuthorization (nolock) RA  
       WHERE  RA.MfrDistID = RZOS.MfrDistID  
        AND RA.DistID=C.CompanyID  
        AND (RegionId in ('''+@USER_Region+''') OR '+@IsEmptyRegionIDs+' = 1)  
       group By RZOS.MfrDistID  
      ) as RZS  
       ON reg_auth.MfrDistID = RZS.MfrDistID  
                        
                        
        left join Company (nolock) dist on reg_auth.DistID = dist.CompanyID  
       and dist.IsActive =1 and dist.CompanyStatusId = 1  
       and reg_auth.IsActive = 1  and reg_auth.Publish = 1  
                        
  
        left join (  
        Select  
        MfrID,  
        DistID,  
        sum(Print_Amount+Online_Amount) as Total,  
        max(Priority_Date) as Priority_Date  
       From  
        DistMfrSpend (nolock)  
                                                   
       WHERE  (RegionId in ('''+@USER_Region+''') OR '+@IsEmptyRegionIDs+' = 1)  
        AND (ZoneId in ('''+@USER_ZONE+''') OR '+@IsEmptyZoneIDs+' = 1)  
       group By MfrID,DistID  
      ) as Spend  
       ON reg_auth.MfrID = Spend.MfrID AND reg_auth.DistID = Spend.DistID  
           
                          
      left join('+@splRegionQuery+') dist_order  
        on dist_order.DistID = reg_auth.DistID  AND dist_order.MfrID = reg_auth.MfrID  
                         
                 
      left join(select min(WebVersion) WebVersionWOZone,distmfr2.DistID,distmfr2.MfrID from lm_distributor_orders (nolock) distmfr2    
        INNER JOIN (SELECT * FROM dbo.Split('''+@REPLACE_REGIONS_TEMP+''','','')) as regid    
        ON distmfr2.OrderRegionId LIKE ''%'' + regid.items + ''%''   
        group by distmfr2.DistID,distmfr2.MfrID,distmfr2.OrderRegionId) dist_order2    
        on dist_order2.DistID = reg_auth.DistID  AND dist_order2.MfrID = reg_auth.MfrID   
        
      '+@JoinAttributes+'  
      
       WHERE  
      (reg_auth.DistID in('''+@DIST_ID+''') OR '+@IsEmptyDistIDs+' = 1)   
      AND (dist.CompanyStatusId = 1 OR reg_auth.MfrDistID is null)     
      AND ('''+@DIST_AUTH+''' = 0 or RZS.MaxAuth = 4 or reg_auth.MfrDistID is null)  
      AND ('''+@IsFilterByRegion+''' = 0 or MaxAuth = 4 or reg_auth.MfrDistID is null or Total > 0  
       OR (Select 1  
        From CompanyLocations CL, Country C  
        where  
         C.CountryID = CL.CountryID  
         AND reg_auth.DistID = CL.CompanyID  
         AND (C.RegionID IN ('''+@USER_Region+''') OR '+@IsEmptyRegionIDs+' = 1)  
         AND LocationStatusID = 1  --  in @USER_Region  
         AND CL.IsActive = 1  
        group by CompanyID) = 1)  
                
     ) as Dist_Qry on mfr.CompanyID = Dist_Qry.CompanyID'  
                
  
   INSERT INTO #mantemp1  
   Execute(@MAIN_QUERY)  
         print @MAIN_QUERY  
  
   --IF OBJECT_ID(N'tempdb..#man', N'U') IS NOT NULL   
   -- DROP TABLE #man  
   --select a.CompanyID, min(a.MatchOrder) orders,count(a.MatchOrder) counts  
   -- into #man from #mantemp1 a  
   --group by a.companyid  
  
   --IF OBJECT_ID(N'tempdb..#ManDiffTable', N'U') IS NOT NULL   
   -- DROP TABLE #ManDiffTable  
  
   --select a.*, DIFFERENCE(@SEARCH, CompanyName) as diff into #ManDiffTable from #mantemp1 a join #man b on a.companyid=b.companyid and a.matchorder=b.orders  
                      
  
   select CompanyID  
    ,CompanyName  
    ,CompanyLogo  
    ,CompanyDescription  
    ,AlsoKnownAs  
    ,MaxAuth  
    ,DistributorId  
    ,DistributorName  
    ,DistributorLogo  
    ,DistributorAttributes  
    ,CompanyStatus  
    ,WebVersion  
    ,WebVersionWOZone  
    ,DistID  
    ,Total  
    ,CheckInvURL  
    ,IsFav  
    ,MatchOrder  
    ,0--,diff  
    ,Trusted_Disty  
    ,Priority_Date  
   from #mantemp1  
   ORDER BY MatchOrder, --diff desc, 
   CompanyName, Total DESC, Priority_Date ASC, MaxAuth DESC,  DistributorName ASC  
  
  END  
  
  
GO

-------------------------------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetMonthlyBillInfoPrint]    Script Date: 04/10/2013 17:23:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetMonthlyBillInfoPrint]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetMonthlyBillInfoPrint]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetMonthlyBillInfoPrint]    Script Date: 04/10/2013 17:23:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--------------------------------------------------------------------------
-- Created By : Siva.
-- Created On : 09 Jan 2012
-- Description : Get the Bill info form Sales order
-- Modified		: By LB on 3/15/2013 to implement ESB MSG Monthly Billing report
-- Modified		: By LB on 4/10/2013 to fix issues raised by Tina in ticket comments
--------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetMonthlyBillInfoPrint]  
(
@EditionID VARCHAR(10)
)
AS
BEGIN
	   SELECT distinct
       OrderType  AS 'Revenue Stream',
       CAST(AD.AdOrderDetailsId AS VARCHAR(50))+'-'+CAST(@EditionID AS VARCHAR(50))  AS 'Source RecordID',
       'ESB' as 'Source Name',
       ISNULL(C.MSGIDNo,'') AS 'Advertiser Code',
       CASE WHEN ISNULL(A.CorpId,0) <> 0 THEN ISNULL(A.MsgCode,'') else '' end  AS 'Agency Code',
       CASE WHEN ISNULL(A.CorpId,0) <> 0 THEN (select IsNull(MSGIDNo,'') from Company where CompanyId = A.CorpId) ELSE C.MSGIDNo END AS 'Bill-To Code',
       A.SalesPersonId AS 'Salesperson ID(s)',
       'ESB' AS 'Pub Code',
       CONVERT(varchar,E.PublicationDate,101) AS 'Issue Date - MM/DD/YY',
       '' AS 'Start Date',
       '' AS 'End Date',
       (select HeadingTitle from Editions where EditionID = @EditionID) as 'Edition Code',
       'DIS' AS 'Ad Type Code',
       ''''+ST.MSGCode AS 'Ad Size',
       'ROP' AS 'Position',
       SST.SectionCode AS 'Section',
       '1' AS 'Quantity',       
       AD.Price AS 'Gross Amount',
       Convert(money,(IsNull(AD.Price,0)-(IsNull(AD.Price,0) *  (Case When AD.ApplyDiscount = 1 Then A.DiscountRate Else 0 End) )/100),2) AS 'Dollar Volume Discount',
       --A.NetAmount AS 'Net Amount',
       dbo.[udf_GetAdOrderNetAmount](AD.AdOrderId,AD.Price,AD.ApplyDiscount,A.DiscountRate,AD.OrderType) as 'Net Amount',
       'BW' AS Color,       
       'PICKUP' AS Material,
       ISNULL(A.Comments,'') AS 'Production Comments',
       ISNULL(A.POnumber,'') AS 'PO Number',
       case when (dbo.udf_CheckAdOrderPrepaid(AD.AdOrderId,AD.OrderType) = 1) then 'SP' else 'RU' end AS [Status],
       '1' AS 'Number Tearsheets',
       ISNULL(A.BillingInstruction,'') AS 'Billing Instructions',             
            'ESB'             
            + '*' + CASE WHEN (select Description from MstRateCard M 
					 join RateCardDetails R on M.RateCardMasterID = R.RateCardMasterID
                     join AdOrderDetails AOD on AOD.RateCardId = R.RateCardID 
                     where AOD.AdOrderDetailsId = AD.AdOrderDetailsId) !=''
                     THEN 
                     (select Description from MstRateCard M 
					 join RateCardDetails R on M.RateCardMasterID = R.RateCardMasterID
                     join AdOrderDetails AOD on AOD.RateCardId = R.RateCardID 
                     where AOD.AdOrderDetailsId = AD.AdOrderDetailsId) + '*' 
                     ELSE '' END
            + (select HeadingTitle from Editions where EditionID = @EditionID)
            + '*' + ST.Description AS 'Rate Code',          
        '' AS 'Surcharge Commissionable to Agency',
        '' AS 'Agency Surcharge %',
        '' AS 'Agency Surcharge $ Amount',
        '' AS 'Surcharge Production Flag'	,
        'AUTOLOAD' AS 'Entered_By'         
     FROM AdOrder A,
          Company C,
          AdOrderDetails AD,
          SalesSizeType ST,
          SalesSectionType SST,
          AdOrderDetailsRegionEdition AORE,
          Editions E
     WHERE     A.CompanyId=C.CompanyID 
           AND A.AdOrderId=AD.AdOrderId
           AND ST.SizeTypeID=AD.SizeTypeID 
           AND SST.SectionID=AD.SectionID
           AND AORE.AdOrderDetailsId = AD.AdOrderDetailsId AND AORE.EditionID=E.EditionID
           AND AD.OrderType = 'P'
           AND E.EditionID = @EditionID
           AND A.StatusId IN (3,4,5)
END


GO
-----------------------------------------------------------------------------------------------------

GO

/****** Object:  StoredProcedure [dbo].[usp_GetMonthlyBillInfoOnline]    Script Date: 04/10/2013 19:26:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetMonthlyBillInfoOnline]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetMonthlyBillInfoOnline]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetMonthlyBillInfoOnline]    Script Date: 04/10/2013 19:26:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--------------------------------------------------------------------------
-- Created By : Siva.
-- Created On : 09 Jan 2012
-- Description : Get the Bill info form Sales order
-- Modified		: By LB on 3/15/2013 to implement ESB MSG Monthly Billing report
-- Modified		: By LB on 4/10/2013 to fix issues raised by Tina in ticket comments
--------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetMonthlyBillInfoOnline] 
(
	@Month INT,
	@Year INT
)
AS
BEGIN
       SELECT distinct
       OrderType  AS 'Revenue Stream',
       CAST(AD.AdOrderDetailsId AS VARCHAR(50))+'-'+REPLACE(CONVERT(VARCHAR,AD.ActivationDate,101),'/','')  AS 'Source RecordID', 
       'ESB' as 'Source Name',
       ISNULL(C.MSGIDNo,'')  AS 'Advertiser Code',
       --ISNULL(A.MsgCode,'')  AS 'Agency Code',
       CASE WHEN ISNULL(A.CorpId,0) <> 0 THEN ISNULL(A.MsgCode,'') else '' end  AS 'Agency Code',
       CASE WHEN ISNULL(A.CorpId,0) <> 0 THEN (select MSGIDNo from Company where CompanyId = A.CorpId) ELSE C.MSGIDNo END AS 'Bill-To Code',
       A.SalesPersonId AS 'Salesperson ID(s)',
       'ESBI' AS 'Pub Code',
       case when OrderType='N' then CONVERT(varchar,AD.ActivationDate,102) else '' end AS 'Issue Date - MM/DD/YY',
       CONVERT(varchar,AD.ActivationDate,101) AS 'Start Date',
       CONVERT(varchar,DATEADD(mm,ad.Duration,ad.ActivationDate),101) AS 'End Date',
       case when OrderType ='N' then 'INET' else 'ONLN' end AS 'Edition Code',
       'INT' AS 'Ad Type Code',
       ST.MSGCode AS 'Ad Size',
       '' AS 'Position',
       SST.SectionCode AS 'Section',
       '1' as 'Quantity',       
	    A.GrossAmount  AS 'Gross Amount', 
       Convert(money,(IsNull(A.GrossAmount,0)-(IsNull(A.GrossAmount,0) *  (Case When AD.ApplyDiscount = 1 Then A.DiscountRate Else 0 End) )/100),2) AS 'Dollar Volume Discount',
       dbo.[udf_GetAdOrderNetAmount](AD.AdOrderId,A.GrossAmount,AD.ApplyDiscount,A.DiscountRate,AD.OrderType) as 'Net Amount',
       'BW' AS Color,       
       'PICKUP' AS Material,
       ISNULL(A.Comments,'') AS 'Production Comments',
       ISNULL(A.POnumber,'') AS 'PO Number',
       --'RU' AS Status,
       case when (dbo.udf_CheckAdOrderPrepaid(AD.AdOrderId,AD.OrderType) = 1) then 'SP' else 'RU' end AS [Status],
       '1' AS 'Number Tearsheets',
       ISNULL(A.BillingInstruction,'') AS 'Billing Instructions',                   
			'ESBI'            
            + '*' + CASE WHEN (select Description from MstRateCard M 
					 join RateCardDetails R on M.RateCardMasterID = R.RateCardMasterID
                     join AdOrderDetails AOD on AOD.RateCardId = R.RateCardID 
                     where AOD.AdOrderDetailsId = AD.AdOrderDetailsId) !=''
                     THEN 
                     (select Description from MstRateCard M 
					 join RateCardDetails R on M.RateCardMasterID = R.RateCardMasterID
                     join AdOrderDetails AOD on AOD.RateCardId = R.RateCardID 
                     where AOD.AdOrderDetailsId = AD.AdOrderDetailsId) + '*' 
                     ELSE '' END
            + case when OrderType ='N' then 'INET' else 'ONLN' end + '*' + ST.Description AS 'Rate Code',           
        '' AS 'Surcharge Commissionable to Agency',
        '' AS 'Agency Surcharge %',
        '' AS 'Agency Surcharge $ Amount',
        '' AS 'Surcharge Production Flag',
        'AUTOLOAD' AS 'Entered_By'         
     FROM AdOrder A,Company C,AdOrderDetails AD,SalesSizeType ST,SalesSectionType SST,
            AdOrderDetailsRegionEdition AORE--,Editions E
     WHERE  A.CompanyId=C.CompanyID AND A.AdOrderId=AD.AdOrderId
            AND ST.SizeTypeID=AD.SizeTypeID AND SST.SectionID=AD.SectionID
            AND AORE.AdOrderDetailsId = AD.AdOrderDetailsId 
            AND MONTH(AD.ActivationDate) = @Month  
            AND YEAR(AD.ActivationDate) = @Year
            AND A.StatusId IN (3,4,5)
            AND OrderType IN ('O', 'N')
END


GO

-----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_DeleteUser]    Script Date: 02/20/2013 15:09:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_DeleteUser]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_DeleteUser]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_DeleteUser]
(
	@UserIDs VARCHAR(1000)
)
AS

--DECLARE @UserIDs VARCHAR(1000) = '131013'
BEGIN
	DECLARE @tmpUser TABLE
	(
		UserID int
	)

	INSERT INTO @tmpUser
	SELECT array_data 
	FROM dbo.ReturnArray(@UserIDs, ',', NULL)

	SET IDENTITY_INSERT User_Archive ON
	INSERT INTO User_Archive
	(UserID,LoginName,LoginPassword,FirstName,LastName,IsActive,UserRegID,UserRecommendFlag,UserJobFunctionID,UserIndustryTypeID,
		Title,UserApprovalLevelID,PrimarySource,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn,SalesPersonCode,SalesManagerID,
		Contact_ID,MigratedFrom,LastLogin)
	SELECT u.UserID,LoginName,LoginPassword,FirstName,LastName,IsActive,UserRegID,UserRecommendFlag,UserJobFunctionID,UserIndustryTypeID,
		Title,UserApprovalLevelID,PrimarySource,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn,SalesPersonCode,SalesManagerID,
		Contact_ID,MigratedFrom,LastLogin
	FROM [User] u
	INNER JOIN @tmpUser t
		ON u.UserID = t.UserID

	SET IDENTITY_INSERT User_Archive OFF
	
	DELETE u 
	FROM [User] u
	INNER JOIN @tmpUser t
		ON u.UserID = t.UserID


	SET IDENTITY_INSERT UserContact_Archive ON
	INSERT INTO dbo.UserContact_Archive 
	(UserContactID, UserID, EmailAddress,CompanyName,CompanyWebsite,Address, City, StateID,Zip, CountryID, 
		Phone,PhoneExtension, Fax,	CreatedBy, CreatedOn,UpdatedBy, UpdatedOn)
	SELECT uc.UserContactID, uc.UserID, uc.EmailAddress,uc.CompanyName,uc.CompanyWebsite,uc.Address, uc.City, uc.StateID,uc.Zip, uc.CountryID, 
		uc.Phone,uc.PhoneExtension, Fax, uc.CreatedBy, uc.CreatedOn,uc.UpdatedBy, uc.UpdatedOn
	FROM [dbo].[UserContact] AS uc
	INNER JOIN @tmpUser t
		ON uc.UserID = t.UserID

	SET IDENTITY_INSERT UserContact_Archive OFF
	
	DELETE uc 
	FROM [dbo].[UserContact] AS uc
	INNER JOIN @tmpUser t
		ON uc.UserID = t.UserID

END

GO

/****** Object:  StoredProcedure [dbo].[USP_DeleteUserPreference]    Script Date: 04/12/2013 19:35:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_DeleteUserPreference]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[USP_DeleteUserPreference]
GO

/****** Object:  StoredProcedure [dbo].[USP_DeleteUserPreference]    Script Date: 04/12/2013 19:35:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_DeleteUserPreference]   
(  
 @UserFavoriteIDs VARCHAR(8000)  
)  
AS  
BEGIN  
 DECLARE @SQL VARCHAR(2000)  
  
 CREATE TABLE #tblTypeId(typeId INT,FavType INT)  
 SET @SQL = 'SELECT TypeID,FavType FROM UserFavorites WHERE UserFavoritesID IN(' + @UserFavoriteIDs + ')'  
 INSERT #tblTypeId EXEC(@SQL)  
  
  
 SET @SQL = 'DELETE FROM [UserFavorites]  
    WHERE [UserFavoritesID] IN (' + @UserFavoriteIDs + ')'  
   
 EXECUTE (@SQL)  
  
 SELECT typeId,FavType FROM #tblTypeId  
 DROP TABLE #tblTypeId  
END  
GO

---------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_Rep_DistrSummaryLeads]    Script Date: 04/17/2013 15:16:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Rep_DistrSummaryLeads]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Rep_DistrSummaryLeads]
GO

/****** Object:  StoredProcedure [dbo].[usp_Rep_DistrSummaryLeads]    Script Date: 04/17/2013 15:16:48 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

  
-- =============================================    
-- Author: Kartikeya Sinha    
-- Create date: 12/08/2011    
-- Description: Distributor Summary Leads     
-- Modified	: By Lalbahadur on 4/19/2013 to exclude category 'View RFQ' from this report     
--[usp_Rep_DistrSummaryLeads] '143679','2011','1'  
-- =============================================    
CREATE PROCEDURE  [dbo].[usp_Rep_DistrSummaryLeads]    
(     
  @MfrDistVndrIDList varchar(8000),      
  @Years varchar(10) = '',      
  @Months varchar(30) = '',      
  @StartDate varchar(20),      
  @EndDate varchar(20),      
  @UseRange bit,
  @IPAddressList varchar(8000) = '' ,         
  @EmailDomainList  varchar(8000) = ''         
 )      
AS    
BEGIN      
DECLARE @month_table table (v int)      
 DECLARE @year_table table (v int)      
 DECLARE @mdv_table table (v int) 
 DECLARE @ip_table table (ip nvarchar(100))            
 DECLARE @email_table table (email nvarchar(200))       
 INSERT INTO @month_table SELECT item FROM dbo.ufnSplit(@Months,',')      
 INSERT INTO @year_table SELECT item FROM dbo.ufnSplit(@Years,',')      
 INSERT INTO @mdv_table SELECT item FROM dbo.ufnSplit(@MfrDistVndrIDList,',')      
 INSERT INTO @ip_table SELECT item FROM dbo.ufnSplit(@IPAddressList,',')            
 INSERT INTO @email_table SELECT item FROM dbo.ufnSplit(@EmailDomainList,',') 
  IF @UseRange = 0 BEGIN      
   SELECT  [Date]=RIGHT('0' + CONVERT(varchar, [Month]), 2)+ '/' + RIGHT('0' + CONVERT(varchar, [Day]), 2) + '/' + CONVERT(varchar, [Year])   , Name, Category,  [Company Name]=company_name  , [Company Type] = company_type, City, State, Zip, Country, Title
,       
    [RFQ Email] = CASE WHEN Category = 'Send RFQ' THEN email ELSE ' ' END, Search, [Manufacturer] = Mfr, Hits         
   From vw_distributor_web_traffic_by_user WITH (NOLOCK)      
   WHERE       
    Distributor_ID IN (SELECT v FROM @mdv_table)      
    AND Month IN (SELECT v FROM @month_table)      
    AND Year IN (SELECT v FROM @year_table) 
    AND (@IPAddressList = '' OR (IPAddress NOT IN  (select * from @ip_table) ))  
   AND (@EmailDomainList = '' OR (SUBSTRING(email,CHARINDEX('@',email),LEN(email)) NOT IN  (select SUBSTRING(email,CHARINDEX('@',email),LEN(email)) from @email_table)))   
   AND (IPAddress NOT LIKE '192.168.%')  
   AND (IPAddress NOT LIKE '10.%')  
   AND id <> 2   -- To exclude category 'View RFQ'   
   ORDER BY [Year], [Month], name      
  END      
  ELSE BEGIN       
   SELECT      
    [Date] = RIGHT('0' + CONVERT(varchar, [Month]), 2) + '/' + RIGHT('0' + CONVERT(varchar, [Day]), 2) + '/' + CONVERT(varchar, [Year]), Name,       
    Category, [Company Name] = company_name, [Company Type] = company_type, City, State, Zip, Country, Title,       
    [RFQ Email] = CASE WHEN Category = 'Send RFQ' THEN email ELSE ' ' END, Search, [Manufacturer] = Mfr, Hits         
   From vw_distributor_web_traffic_by_user WITH (NOLOCK)      
   WHERE       
    Distributor_ID IN (SELECT v FROM @mdv_table)      
    AND Log_Timestamp > CAST(@StartDate as Datetime) - 1    
    AND Log_Timestamp < CAST(@EndDate as datetime) + 1 
   AND (@IPAddressList = '' OR (IPAddress NOT IN  (select * from @ip_table) ))  
   AND (@EmailDomainList = '' OR (SUBSTRING(email,CHARINDEX('@',email),LEN(email)) NOT IN  (select SUBSTRING(email,CHARINDEX('@',email),LEN(email)) from @email_table)))   
   AND (IPAddress NOT LIKE '192.168.%')  
   AND (IPAddress NOT LIKE '10.%')       
   AND id <> 2   -- To exclude category 'View RFQ'       
   ORDER BY [Year], [Month], [Day], name      
  END       
      
END  
  

GO


--------------------------------------------------------------------------------------------------------


/****** Object:  StoredProcedure [dbo].[usp_GetSearchManuDistLocation]    Script Date: 04/23/2013 19:48:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchManuDistLocation]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchManuDistLocation]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchManuDistLocation]    Script Date: 04/23/2013 19:48:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

  ----------------------------------------------------------------------------  
  -- Name   : usp_GetSearchManuDistLocation ManuDist Detailspage  
  -- Description : This Procedure Will Get the ManuDist Details.  
  -- Arguments :  
  -- Returns  : None  
  -- Modified  
  -- Author   Date  Desc  
  -- Marcus Ruether 8.15.2012 Added in WebVersion to results  
  -- Lalit Mehta      12/17/2012  Added countryID parameter to GetSearchZoneName and GetZoneNames function 
   -- Parameswar Mal 04/23/2013 Added in CheckInvURL to results   
  ----------------------------------------------------------------------------  
  CREATE PROCEDURE [dbo].[usp_GetSearchManuDistLocation]
  (  
   @CompanyID  Int  
  )  
  AS  
  --DECLARE  @CompanyID  INT = 144217  
  
  BEGIN  
    IF OBJECT_ID(N'tempdb..#COMLOCATIONTEMP', N'U') IS NOT NULL  
    DROP TABLE #COMLOCATIONTEMP  
  
   -- Load Temp Table  
   SELECT TOP 1000  
    CL.LocationID AS LocationID, CL.CompanyID AS CompanyID,C.CompanyStatusID,  
    C.CompanyName AS CompanyName, CL.Address1 AS Address1,C.CompanyLogo AS CompanyLogo,  
    CL.Address2 AS Address2,CL.City AS City,  
    MS.StateCode AS StateName,CL.Zip AS ZipCode,  
    CL.RegionID AS RegionID,MR.RegionName AS RegionName,  
    MC.CountryName AS CountryName,LT.Description AS LocationDescription,  
    CL.Phone AS PhoneNo,CL.Fax AS Fax1,CL.TollFreeNo AS TollFreeNo,CL.Email AS EMail,C.URL AS URL,  
    ISNULL(YearDescription,'-') AS EstYear,ISNULL(MNE.Description,'-') as NoOfEmployee,  
    [dbo].[Get_RepsCount] (C.CompanyID) AS RepsCount,[dbo].[GetSearchZoneName](CL.Zip, CL.CountryID) AS ZoneName,  
    [dbo].[GetZoneNames](CL.Zip, CL.CountryID) AS ZoneCode,  
    linecard.WebVersion,
    invs.CheckInvURL  
   INTO #COMLOCATIONTEMP  
   FROM CompanyLocations AS CL  
   INNER JOIN Company AS C  
    ON C.CompanyID = CL.CompanyID  
    AND C.IsActive = 1  
    AND C.CompanyStatusID IN (1,4)  
   LEFT JOIN Country AS MC  
    ON CL.CountryID = MC.CountryID  
    AND MC.IsActive = 1  
   LEFT JOIN MstEstYears AS MEY  
    ON C.EstYearID = MEY.EstYearID  
    AND MEY.isActive = 1  
   LEFT JOIN MstNoOfEmp AS MNE  
    ON C.NoOfEmployyes = MNE.NoEmpID  
    AND MNE.isActive = 1  
   LEFT JOIN CountryStates AS MS  
    ON CL.StateID = MS.StateID  
    AND MS.IsActive = 1  
   LEFT JOIN Region AS MR  
    ON MC.RegionID = MR.RegionID  
    AND MR.IsActive = 1  
   LEFT JOIN MstLocationType AS LT  
    ON CL.LocationTypeID = LT.LocationTypeID  
    AND LT.IsActive = 1
    LEFT JOIN [dbo].[InventorySettings] invs ON C.CompanyID = invs.CompanyID  
   LEFT JOIN (  
    SELECT DistId, MIN(WebVersion) AS WebVersion FROM lm_distributor_linecard_orders GROUP BY DistId  
   ) linecard on linecard.DistId = c.CompanyId  
   WHERE  CL.IsActive = 1  
    AND CL.LocationStatusID = 1  
    AND CL.DoNotPublishIndicator != 1  
    AND CL.CompanyID = @CompanyID  
  
   -- Load Headquarters Info  
   SELECT *  
   FROM #COMLOCATIONTEMP AS tmp  
   WHERE tmp.LocationDescription LIKE 'HeadQuarters'  
  
   -- Load USA Info first, order by state, city  
    SELECT *, 1 AS list_order  
    FROM #COMLOCATIONTEMP AS tmp  
    WHERE tmp.LocationDescription NOT LIKE 'HeadQuarters'  
     AND tmp.CountryName = 'UNITED STATES'  
   UNION ALL  
   -- Load International info, order by country, region  
    SELECT *, 2 AS list_order  
    FROM #COMLOCATIONTEMP AS tmp  
    WHERE tmp.LocationDescription NOT LIKE 'HeadQuarters'  
     AND tmp.CountryName NOT LIKE 'UNITED STATES'  
   ORDER BY list_order, CountryName, StateName, City  
  
   -- Load US Region  
   SELECT DISTINCT RegionName  
   FROM #COMLOCATIONTEMP AS tmp  
   WHERE tmp.RegionName = 'US'  
    AND tmp.LocationDescription NOT LIKE 'HeadQuarters'  
  
   -- Load International Regions  
   SELECT DISTINCT RegionName  
   FROM #COMLOCATIONTEMP AS tmp  
   WHERE tmp.RegionName <> 'US'  
    AND tmp.LocationDescription NOT LIKE 'HeadQuarters'  
   ORDER BY RegionName ASC  
  
  END  
  
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchMfrPartSpec]    Script Date: 07/20/2012 08:25:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchMfrPartSpec]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchMfrPartSpec]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchMfrPartSpec]    Script Date: 07/20/2012 08:25:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetSearchMfrPartSpec]
(        
 @CompanyID  int        
)        
AS        
BEGIN        
 SELECT Distinct          
  Inv.MafSpecTitle as 'PartSpec',
  Inv.MafSpecURL as 'MfrPartSpec'                   
 FROM InventorySettings Inv                 
  INNER JOIN dbo.Company c ON c.companyid =  Inv.CompanyID        
   AND c.IsActive = 1 AND c.CompanyStatusID = 1                
 WHERE Inv.companyid=@CompanyID
  
END

GO
