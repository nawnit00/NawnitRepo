/****** Object:  [AdOrder]    Script Date: 07/25/2012 09:42:54 ******/
UPDATE ao
SET OverwriteDiscountFlag = 1
FROM dbo.AdOrder AS ao
INNER JOIN dbo.AdOrderDetails AS aod
	ON ao.AdOrderId = aod.AdOrderId
WHERE ao.OverwriteDiscountFlag = 0
GO

--***************************************************************************************************************
--Update Script : Update_Script_Adjobfolder_data_issue
--Created by	: Parameswar/Lalbahadur
--Created on	: 19-Apr-2013
--Purpose		: To fix data issue - same ad job folder attached with different print/online orders
--***************************************************************************************************************
IF OBJECT_ID('tempdb..#TempAll') IS NOT NULL
	DROP TABLE #TempAll
IF OBJECT_ID('tempdb..#TempFolderID') IS NOT NULL
	DROP TABLE #TempFolderID
IF OBJECT_ID('tempdb..#TempOrders') IS NOT NULL
	DROP TABLE #TempOrders		
	
SELECT DISTINCT  
a.AdJobFolderId,
  aom.AdOrderId,
  aom.OrderDate,
  aom.StatusId
INTO #TempAll
FROM AdJobFolderMaster a  
        INNER JOIN AdOrderDetailsRegionEdition ad  
           ON a.AdJobFolderId = ad.AdJobFolderId 
  INNER JOIN AdOrderDetails aso 
           ON aso.AdOrderDetailsId = ad.AdOrderDetailsId
  INNER JOIN AdOrder aom 
           ON aom.AdOrderId = aso.AdOrderId 
  INNER JOIN company com  
           ON com.companyid = aom.companyid         
        INNER JOIN Mstadjobfolderstatus afs 
           ON afs.statusid=a.statusid 
  
ORDER BY a.AdjobFolderId
 
SELECT AdJobFolderId,COUNT(AdOrderId) AS 'Total Different Orders' INTO #TempFolderID  FROM #TempAll
GROUP BY AdJobFolderId
HAVING COUNT(adorderId)>1
 
  
--If orders found which are attached with same ad job folder
IF((SELECT COUNT(AdJobFolderId) FROM #TempFolderID) > 0)
BEGIN
  
  CREATE TABLE #TempOrders    -- create temp table for active order                 
	(                        
		AdOrderId INT,
		StatusId INT,
		Orderdate DATETIME   
	)

    DECLARE @AdJobFolderId INT   
    DECLARE @OrderId INT    
    DECLARE @StatusId INT
     --START  CURSOR     
    DECLARE curAdJobFolderId CURSOR FAST_FORWARD READ_ONLY FOR      
        
       -- select AdJobFolderId       
     SELECT AdJobFolderId FROM #TempFolderID  
          
     OPEN curAdJobFolderId            
     FETCH curAdJobFolderId INTO @AdJobFolderId          
              
     WHILE @@FETCH_STATUS = 0      
     BEGIN      
        BEGIN  
         -- select orders according to latest orderdate 
			 INSERT INTO #TempOrders SELECT AdOrderId, StatusId, Orderdate FROM #TempAll WHERE AdJobFolderId = @AdJobFolderId ORDER BY OrderDate DESC
			
			WHILE((SELECT COUNT(*) FROM #TempOrders)>1)-- same ad job folder id may attached with multiple orders like 2,3,4
			BEGIN
				SELECT TOP 1 @OrderId = AdOrderId,@StatusId = StatusId FROM #TempOrders --select orderid status id
				-----------------------------------------------
			
				-- Deleting ad job folder of orders were coppied as "Final" OR "Partial Complete" OR "Complete" from Copy Order
			    UPDATE AdOrderDetailsRegionEdition SET ADJobFolderID = NULL WHERE AdOrderDetailsId IN (SELECT AdOrderDetailsId FROM AdOrderDetails WHERE AdOrderId= @OrderId)
					
				------------------------------------------------
				-- delete the order id
				DELETE FROM #TempOrders where AdOrderId = @OrderId 
				 
				-- next order
			END
			DELETE FROM #TempOrders  --delete all orders
			
			-- next jobfolder id
        END    
		FETCH curAdJobFolderId INTO @AdJobFolderId           
     END            
              
     CLOSE curAdJobFolderId            
     DEALLOCATE curAdJobFolderId            
          
      ---END  CURSOR     
      
        -- crteate new job folder id and call SP
		 EXEC uspAdJobFolderCreatePrint  
		 EXEC uspAdJobFolderCreateOnline 
		
		DROP TABLE #TempOrders						 
END

	DROP TABLE #TempAll
	DROP TABLE #TempFolderID
	
	
GO

--***************************************************************************************************************
--Update Script : Update_Script_PriorityDates_data_issue
--Created by	: Lalbahadur
--Created on	: 19-Apr-2013
--Purpose		: To fix data issue - priority dates are null for some orders and some order's priority dates are equal to its orderdate
--Script run time: It may take more than 45 minutes to execute successfully
--***************************************************************************************************************

IF OBJECT_ID('tempdb..#TempBlnPD') IS NOT NULL
	DROP TABLE #TempBlnPD
IF OBJECT_ID('tempdb..#TempMinPd') IS NOT NULL
	DROP TABLE #TempMinPd

DECLARE @AdorderId INT
DECLARE @AdOrderDetailsId INT
DECLARE @CompanyId INT
DECLARE @PositionTitle INT
DECLARE @OrderDate DATETIME
DECLARE @EditionID INT
DECLARE @EditionYear INT
DECLARE @EditionZone INT
DECLARE @PriorityDate DATETIME

--Getting all print ad orders which are having priority date as null or priority dates are equal to order dates
SELECT DISTINCT A.AdOrderId,A.CompanyId, AOD.AdOrderDetailsId, OrderDate,AOR.PriorityDate, AOD.PositionTitle,AOR.EditionID,e.Year,e.RegionID
INTO #TempBlnPD
FROM AdOrder A  
    INNER JOIN AdOrderDetails AOD ON AOD.AdOrderId = a.AdOrderId  
    INNER JOIN AdOrderDetailsRegionEdition AOR ON AOR.AdOrderDetailsId = AOD.AdOrderDetailsId  
    INNER JOIN Editions e on e.EditionID = AOR.EditionID
WHERE AOD.OrderType='P' AND (AOR.PriorityDate IS NULL OR AOR.PriorityDate = A.OrderDate)
ORDER BY A.OrderDate 

select * from #TempBlnPD

--Getting all print ad orders with their minimim priority dates into a temp table, it will be used in loop
SELECT DISTINCT A.CompanyId, AOD.PositionTitle, AOR.EditionID, MIN(AOR.PriorityDate) as PriorityDate
INTO #TempMinPd
FROM AdOrder A
      INNER JOIN AdOrderDetails AOD ON AOD.AdOrderId = a.AdOrderId
      INNER JOIN AdOrderDetailsRegionEdition AOR ON AOR.AdOrderDetailsId = AOD.AdOrderDetailsId
WHERE AOD.OrderType='P'
GROUP BY A.CompanyId,AOD.PositionTitle,AOR.EditionID


DECLARE cur_PD  CURSOR FOR SELECT AdOrderId,AdOrderDetailsId,CompanyId,PositionTitle,OrderDate,EditionID,[Year],RegionId FROM #TempBlnPD

print '--------'+ (CONVERT( VARCHAR(24), GETDATE(), 121))+'-------------------'
declare @count int
set @count=0

--Cursor starts here
OPEN cur_PD
FETCH NEXT FROM cur_PD  INTO @AdorderId,@AdOrderDetailsId,@CompanyId,@PositionTitle,@OrderDate,@EditionID,@EditionYear,@EditionZone
WHILE @@FETCH_STATUS = 0  
BEGIN  
            SET @PriorityDate = NULL
            --To get minimum priorty date of previous year's edition and same zone for same company and same position title
            ---------------------------------------------------------------------------------
            SELECT @PriorityDate = PriorityDate
            FROM #TempMinPd
            WHERE  CompanyId = @CompanyId
            AND PositionTitle = @PositionTitle
            AND EditionID = (SELECT EditionID FROM Editions WHERE [YEAR] = @EditionYear-1 AND RegionID = @EditionZone)

            SET @PriorityDate = ISNULL(@PriorityDate,@OrderDate)
            
             --Update priority Dates in actual table
            UPDATE AdOrderDetailsRegionEdition
            SET PriorityDate = @PriorityDate
            WHERE AdOrderDetailsId = @AdOrderDetailsId AND EditionID = @EditionID AND RegionId = @EditionZone
            
            --UPDATE #TempBlnPD  --using temp table for testing
            --SET PriorityDate = @PriorityDate
            --WHERE AdOrderDetailsId = @AdOrderDetailsId AND EditionID = @EditionID AND RegionId = @EditionZone
            
            ---------------------------------------------------------------------------------
FETCH NEXT FROM cur_PD INTO @AdorderId,@AdOrderDetailsId,@CompanyId,@PositionTitle,@OrderDate,@EditionID,@EditionYear,@EditionZone
END  
--Cursor ends here
CLOSE cur_PD  
DEALLOCATE cur_PD 

PRINT '--------'+ (CONVERT( VARCHAR(24), GETDATE(), 121))+'-------------------'

SELECT * FROM #TempBlnPD

DROP TABLE #TempBlnPD
DROP TABLE #TempMinPd
