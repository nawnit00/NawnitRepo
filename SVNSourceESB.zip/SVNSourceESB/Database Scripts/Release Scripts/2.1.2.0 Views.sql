/****** Object:  View [dbo].[vw_distributor_part_stats]    Script Date: 01/16/2012 12:56:00 ******/
IF EXISTS ( SELECT  *
            FROM    sys.views
            WHERE   object_id = OBJECT_ID(N'[dbo].[vw_distributor_part_stats]') ) 
   DROP VIEW [dbo].[vw_distributor_part_stats]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_distributor_part_stats]
AS
	SELECT   dp.DistID, d.CompanyName,
		MIN(dp.Uploaded) AS oldest_part,
		MAX(dp.Uploaded) AS newest_part,
		CASE InvS.deleteOLDInv 
			WHEN 1 THEN 'Yes'
			ELSE 'No'
		END AS purge_old_inventory,
		CASE 
			WHEN InvS.AllowZeroQOH = 1 THEN 'Yes'
			ELSE 'No'
		END AS show_zero_quantity,
		CASE InvS.donotpub 
			WHEN 0 THEN 'Yes'
			ELSE 'No'
		END AS show_in_search,
		SUM
		(
			CASE 
				WHEN smx.manufacturercodeid IS NOT NULL THEN 1
				ELSE 0
			END
		) AS parts_with_manufacturer,
		SUM
		(
			CASE dp.QtyOnHand 
				WHEN 0 THEN 1
				ELSE 0
			END
		) AS zero_quantity_parts,
		COUNT(*) AS total_parts,
		InvS.MaxRecords AS limit
	FROM dbo.DistributorParts AS dp (NOLOCK)
	INNER JOIN dbo.Company AS d (NOLOCK)
		ON dp.DistID = d.CompanyID
	INNER JOIN dbo.InventorySettings AS InvS (NOLOCK)
		ON d.CompanyID = InvS.CompanyID
	LEFT OUTER JOIN dbo.ManufacturerCode_XRF AS smx (NOLOCK)
		ON dp.DistID = smx.DistributorId
		AND dp.ManufacturerCode = smx.ManufacturerCode
	GROUP BY dp.DistID, d.CompanyName, InvS.DeleteOLDInv, InvS.AllowZeroQOH, InvS.DoNotPub, InvS.MaxRecords  

GO

/****** Object:  View [dbo].[vw_DistributorPartsSearch]    Script Date: 04/10/2013 10:34:03 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vw_DistributorPartsSearch]'))
DROP VIEW [dbo].[vw_DistributorPartsSearch]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_DistributorPartsSearch]
AS
SELECT  dps.ID, dps.DistributorId, dps.DistributorName,
        dps.Search_Dist_Name, dps.DistLogo, dps.PartNumber,
        dps.Search_PartNumber, dps.ManufacturerCode,
        dps.ManufacturerId, dps.ManufacturerName,
        dps.Search_MFR_Name, dps.CompanyLogo,
        dps.PartUploadDate, dps.ProductId,
        dps.PartDescription, dps.PartQuantity, dps.QOHDisp,
        dps.Price, dps.PartDataSheet, dps.DatasheetLink,
        dps.PartSample, dps.VideoFilePathLink,
        dps.ImageFilePathLink, dps.DoNotPub,
        dps.ProductTypeId, dps.ProductTypeDesc, dps.RFQCPID,
        dps.Buy_Button, dps.DistributorPartID, dps.ROHS,
        dps.HasMfrLogoAd, dps.IsManufacturerProduct,
        dps.ManufacturerSpend
FROM dbo.DistributorPartsSearch AS dps

GO
/****** Object:  View [dbo].[vw_DistributorPartsStatic]    Script Date: 04/10/2013 09:44:56 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vw_DistributorPartsStatic]'))
DROP VIEW [dbo].[vw_DistributorPartsStatic]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_DistributorPartsStatic]
AS
SELECT  dps.ManufacturerCode, dps.PartNumber,
        dps.Description, dps.QtyOnHand, dps.Price, dps.ROHS,
        dps.BatchCode, dps.BreakLevel1, dps.Price1,
        dps.BreakLevel2, dps.Price2, dps.BreakLevel3,
        dps.Price3, dps.BreakLevel4, dps.Price4,
        dps.BreakLevel5, dps.Price5, dps.BreakLevel6,
        dps.Price6, dps.BreakLevel7, dps.Price7,
        dps.BreakLevel8, dps.Price8, dps.BreakLevel9,
        dps.Price9, dps.BreakLevel10, dps.Price10,
        dps.DistID, dps.Uploaded, dps.InvID, dps.Status,
        dps.IsManufacturerProduct, dps.Search_PartNumber,
        dps.MfrID
FROM dbo.DistributorPartsStatic AS dps

GO

/****** Object:  View [dbo].[vw_OnlineSalesByMonth]    Script Date: 10/22/2012 09:51:10 ******/
IF EXISTS ( SELECT  *
            FROM    sys.views
            WHERE   object_id = OBJECT_ID(N'[dbo].[vw_OnlineSalesByMonth]') ) 
   DROP VIEW [dbo].[vw_OnlineSalesByMonth]
GO

CREATE  VIEW [dbo].[vw_OnlineSalesByMonth]
AS
       SELECT DISTINCT
                SalesPerson_ID, FirstName, LastName,
                CompanyID, CompanyName, SizeTypeName,
                SUM(NetAmount) AS NetAmount, ActivationMonth,
                ActivationYear, AdOrderStatusId
       FROM     (
                 SELECT SA.SalesPerson_ID,
                        U.FirstName AS FirstName,
                        U.LastName AS LastName,
                        OFO.CompanyID,
                        C.CompanyName AS CompanyName,  
					 --BUSINESS RULE FOR REPORTING - Gemini ticket 12344
					 --Decided to program a giant case statement here rather than add two new tables to support this functionality.
                        dbo.udf_GetSizeTypeGroupName(OFO.SizeTypeName,
                                            OFO.SizeTypeID,
                                            OFO.SectionId)
                        AS SizeTypeName, OFO.SizeTypeId,
                        OFO.NetAmount AS NetAmount,
                        MONTH(OFO.ActivationDate) AS ActivationMonth,
                        YEAR(OFO.ActivationDate) AS ActivationYear,
                        OFO.AdOrderStatusId
                 FROM   dbo.vw_AdOrderDetailsRegionEdition OFO
                 INNER JOIN Company C
                        ON OFO.CompanyID = C.CompanyID
                 INNER JOIN SalesAssignments SA
                        ON OFO.CompanyID = SA.Company_ID
                 INNER JOIN [User] U
                        ON SA.SalesPerson_ID = U.UserID
                 WHERE  OFO.OrderType = 'O'
                        AND SA.End_Date IS NULL
                ) temp
       GROUP BY SalesPerson_ID, FirstName, LastName,
                CompanyID, CompanyName, SizeTypeName,
                ActivationMonth, ActivationYear, AdOrderStatusId

GO

/****** Object:  View [dbo].[vw_OnlineSalesReport]    Script Date: 10/22/2012 09:48:57 ******/
IF EXISTS ( SELECT  * FROM    sys.views WHERE   object_id = OBJECT_ID(N'[dbo].[vw_OnlineSalesReport]') ) 
   DROP VIEW [dbo].[vw_OnlineSalesReport]
GO

CREATE  VIEW [dbo].[vw_OnlineSalesReport]
AS
       /****************************************************************************************  
* Name:  vw_OnlineSalesReport  
* Description: This view shows sales information by salesperson, company, and month. If  
*  the salesperson had sales for that company in the previous year and/or  
*  the current year, it will show that. This view is used by the  
*  usp_OnlineSalesReport procedure and the R_OSALES report.  
*  
* Created: 15/08/2011 Ajija Fathima
Modified
Author			Date		Desc
Marcus Ruether	10.22.2012	
****************************************************************************************/  
SELECT  PY.SalesPerson_ID, PY.FirstName, PY.LastName,
        PY.CompanyID, PY.CompanyName, PY.SizeTypeName,
        CAST(PY.NetAmount AS DECIMAL) AS NetAmountPrevious,  --without cast, we were not getting a proper distinct result set after the unions
        CAST(ISNULL(CY.NetAmount, 0) AS DECIMAL) AS NetAmountCurrent,  --without cast, we were not getting a proper distinct result set after the unions
        PY.ActivationMonth,
        PY.ActivationYear + 1 AS ActivationYear
FROM    vw_OnlineSalesByMonth PY
LEFT OUTER JOIN vw_OnlineSalesByMonth CY
        ON PY.SalesPerson_ID = CY.SalesPerson_ID
           AND PY.CompanyID = CY.CompanyID
           AND PY.ActivationMonth = CY.ActivationMonth
           AND PY.ActivationYear = CY.ActivationYear - 1
           AND PY.SizeTypeName = CY.SizeTypeName
-- BUSINESS RULE FOR REPORTING - Gemini ticket 12344
-- Only orders with status of Final, Partial Complete, or Complete should be displayed
WHERE   ISNULL(CY.AdOrderStatusId, 1) IN (3, 4, 5)
UNION
SELECT  CY.SalesPerson_ID, CY.FirstName, CY.LastName,
        CY.CompanyID, CY.CompanyName, CY.SizeTypeName,
        CAST(ISNULL(PY.NetAmount, 0) AS DECIMAL) AS NetAmountPrevious,  --without cast, we were not getting a proper distinct result set after the unions
        CAST(CY.NetAmount AS DECIMAL) AS NetAmountCurrent,  --without cast, we were not getting a proper distinct result set after the unions
        CY.ActivationMonth, CY.ActivationYear
FROM    vw_OnlineSalesByMonth CY
LEFT OUTER JOIN vw_OnlineSalesByMonth PY
        ON PY.SalesPerson_ID = CY.SalesPerson_ID
           AND PY.CompanyID = CY.CompanyID
           AND PY.ActivationMonth = CY.ActivationMonth
           AND PY.ActivationYear = CY.ActivationYear - 1
           AND PY.SizeTypeName = CY.SizeTypeName
-- BUSINESS RULE FOR REPORTING - Gemini ticket 12344
-- Only orders with status of Final, Partial Complete, or Complete should be displayed
WHERE   CY.AdOrderStatusId IN (3, 4, 5)

GO
