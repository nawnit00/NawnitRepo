/****** Object:  StoredProcedure [dbo].[usp_Load_ProductLine]    Script Date: 05/01/2013 10:42:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Load_ProductLine]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Load_ProductLine]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_Load_ProductLine]
AS

BEGIN
	TRUNCATE TABLE dbo.ProductLine

	INSERT INTO dbo.ProductLine (MfrID, ProductLine, PartCount)
	SELECT  pl.ManufacturerId, pl.ProductLine, pl.PartCount
	FROM    (
			 SELECT vdps.ManufacturerId,
					LEFT(vdps.Search_PartNumber, 3) AS ProductLine,
					COUNT(*) AS PartCount,
					ROW_NUMBER() OVER (PARTITION BY vdps.ManufacturerId ORDER BY COUNT(*) DESC,LEFT(vdps.Search_PartNumber, 3))
					AS RowNum
			 FROM   dbo.vw_DistributorPartsSearch AS vdps
			 WHERE  vdps.ManufacturerId > 0
					AND vdps.Search_PartNumber IS NOT NULL
			 GROUP BY vdps.ManufacturerId, LEFT(vdps.Search_PartNumber, 3)
			) AS pl
	WHERE   pl.RowNum <= 25
	ORDER BY pl.ManufacturerId, pl.PartCount DESC, pl.ProductLine
END
GO
