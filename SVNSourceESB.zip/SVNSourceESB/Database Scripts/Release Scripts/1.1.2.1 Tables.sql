/****** Object:  Table [dbo].[ProductLine]    Script Date: 05/01/2013 10:36:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ProductLine_Company]') AND parent_object_id = OBJECT_ID(N'[dbo].[ProductLine]'))
ALTER TABLE [dbo].[ProductLine] DROP CONSTRAINT [FK_ProductLine_Company]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProductLine]') AND type in (N'U'))
DROP TABLE [dbo].[ProductLine]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ProductLine](
	[ProductLineID] [int] IDENTITY(1,1) NOT NULL,
	[MfrID] [int] NOT NULL,
	[ProductLine] [varchar](3) NOT NULL,
	[PartCount] [int] NOT NULL,
 CONSTRAINT [PK_ProductLine] PRIMARY KEY CLUSTERED 
(
	[ProductLineID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ProductLine]  WITH CHECK ADD  CONSTRAINT [FK_ProductLine_Company] FOREIGN KEY([MfrID])
REFERENCES [dbo].[Company] ([CompanyID])
GO

ALTER TABLE [dbo].[ProductLine] CHECK CONSTRAINT [FK_ProductLine_Company]
GO
