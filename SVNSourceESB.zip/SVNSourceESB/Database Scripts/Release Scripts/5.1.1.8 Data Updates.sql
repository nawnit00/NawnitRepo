
IF NOT EXISTS (SELECT * FROM MstProcess where ProcessName LIKE 'TRG_RegionZoneStatus_Insert_Update_Delete')
	BEGIN
		INSERT INTO MstProcess (ProcessName, IsEnabled) VALUES('TRG_RegionZoneStatus_Insert_Update_Delete', 1)
	END
	
IF NOT EXISTS (SELECT * FROM MstProcess where ProcessName LIKE 'TRG_CompanyProductType_Insert_Update_Delete')
	BEGIN
		INSERT INTO MstProcess (ProcessName, IsEnabled) VALUES('TRG_CompanyProductType_Insert_Update_Delete', 1)
	END	
