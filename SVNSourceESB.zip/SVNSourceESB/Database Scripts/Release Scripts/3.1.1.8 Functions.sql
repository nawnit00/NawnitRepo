GO

/****** Object:  UserDefinedFunction [dbo].[udf_GetAdOrderPriorityDate]    Script Date: 04/02/2013 20:38:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udf_GetAdOrderPriorityDate]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[udf_GetAdOrderPriorityDate]
GO

/****** Object:  UserDefinedFunction [dbo].[udf_GetAdOrderPriorityDate]    Script Date: 04/02/2013 20:38:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*---------------------------------------------------------------------------------         
Created By    : Lalbahadur                 
Created Date  : 29-Mar-2013              
Description   : This function returns priority date for previous year's edition.          
---------------------------------------------------------------------------------*/                      
CREATE FUNCTION [dbo].[udf_GetAdOrderPriorityDate]              
(             
  @AdOrderId INT,  
  @PositionTitle INT,            
  @ZoneId INT,
  @EditionId INT  
)              
 RETURNS DATETIME    
               
AS                      
BEGIN                     
 DECLARE @EditionYear INT
 DECLARE @PriorityDate DATETIME    
 DECLARE @TempPriorityDates TABLE
 (
	AdOrderId INT,
	CompanyId INT,
	PositionTitle INT,
	OrderDate DATETIME,
	PriorityDate DATETIME
 )   

	 SELECT @EditionYear=[Year] FROM Editions WHERE EditionID = @EditionId

	 INSERT INTO @TempPriorityDates
	 SELECT DISTINCT A.AdOrderId,A.CompanyId,AOD.PositionTitle,OrderDate,AOR.PriorityDate
		FROM AdOrder A
		INNER JOIN AdOrderDetails AOD ON AOD.AdOrderId = a.AdOrderId
		INNER JOIN AdOrderDetailsRegionEdition AOR ON AOR.AdOrderDetailsId = AOD.AdOrderDetailsId
		WHERE  A.CompanyId = (SELECT CompanyId FROM AdOrder WHERE AdOrderId = @AdOrderId) 
		AND AOD.PositionTitle = @PositionTitle 
		AND AOD.OrderType='P'
		AND AOR.EditionID IN (SELECT EditionID FROM Editions WHERE [YEAR] = @EditionYear-1 AND RegionID = @ZoneId)

		IF EXISTS (SELECT 1 FROM @TempPriorityDates)
		BEGIN
			SELECT @PriorityDate = MIN(PriorityDate) FROM @TempPriorityDates GROUP BY CompanyId
		END
		ELSE
		 BEGIN
			SELECT @PriorityDate = OrderDate FROM AdOrder WHERE AdOrderId = @AdOrderId
		 END
		
/*-------------------------------------------------------------------------*/
           
RETURN @PriorityDate                  
           
END

GO


---------------------------------------------


/****** Object:  UserDefinedFunction [dbo].[GetSalesOrderCurrentEditionID]    Script Date: 04/05/2013 13:40:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetSalesOrderCurrentEditionID]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[GetSalesOrderCurrentEditionID]
GO

/****** Object:  UserDefinedFunction [dbo].[GetSalesOrderCurrentEditionID]    Script Date: 04/05/2013 13:40:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 --------------------------------------------------------------------------        
 -- Created By : Parameswar Mal      
 -- Created On : 28 Feb 2013      
 -- Description : Get the Current EditionID
 --  Modify On : 5th April 2013   
   -- Description : Get the earliest open edition in given region
 --------------------------------------------------------------------------      
 CREATE FUNCTION [dbo].[GetSalesOrderCurrentEditionID]        
(        
     @RegionID INT     
)        
    RETURNS INT        
AS        
BEGIN        
    DECLARE @ReturnEditionID INT     
    DECLARE @ReturnYear DATETIME    
  
	   SELECT TOP 1 @ReturnYear =  [Year],@ReturnEditionID= EditionID 
	   FROM Editions e, MstEditionStatus es    
	   WHERE e.StatusID = es.StatusID    
	   AND es.StatusID <> 2  --2 Completed
	   AND RegionId =@RegionID
	   ORDER BY PublicationDate ASC
	  
	   RETURN ISNULL(@ReturnEditionID,0)      

    END   
    


 
GO

----------------------------------------------------------



/****** Object:  UserDefinedFunction [dbo].[GetSalesOrderActivationDate]    Script Date: 04/05/2013 15:15:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetSalesOrderActivationDate]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[GetSalesOrderActivationDate]
GO

/****** Object:  UserDefinedFunction [dbo].[GetSalesOrderActivationDate]    Script Date: 04/05/2013 15:15:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 --------------------------------------------------------------------------      
 -- Created By : Parameswar Mal    
 -- Created On : 28 Feb 2013    
 -- Description : Get the new Activationdate of a old order (Activationdate + duration) of new Activationdate    
 --------------------------------------------------------------------------    
  
CREATE FUNCTION [dbo].[GetSalesOrderActivationDate]      
(      
    @AdOrderDetailsId INT    
 
)      
    Returns datetime      
AS      
BEGIN      
      
     
 DECLARE @duration INT    
 DECLARE @activationdate DATETIME    
 DECLARE @ReturnActivationDate DATETIME    
 SET @ReturnActivationDate=NULL    
  
    --select duration and ActivationDate    
  SELECT @duration= Duration,@activationdate=ActivationDate FROM AdOrderDetails     
  WHERE AdOrderDetailsId= @AdOrderDetailsId    
 -- AND OrderType=@ordertype    
  AND ActivationDate IS NOT NULL    
        
  -- check duration not in 0,-1    
  IF @duration  NOT IN (0,-1)    
  BEGIN    
  --add the duration in month of activationdate    
  SELECT @ReturnActivationDate=DATEADD(MONTH,@duration,@activationdate)     
  END    
  ELSE    
  BEGIN    
  -- select the activation date of old order    
   SELECT @ReturnActivationDate=@activationdate    
  END    
          
      RETURN @ReturnActivationDate       
 END  
 
 
 

GO


