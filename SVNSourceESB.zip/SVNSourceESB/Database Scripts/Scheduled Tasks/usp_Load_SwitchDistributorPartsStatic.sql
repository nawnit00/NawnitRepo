ALTER VIEW [dbo].[vw_DistributorPartsStatic]
AS
SELECT  dps.ManufacturerCode, dps.PartNumber,
		dps.Description, dps.QtyOnHand, dps.Price, dps.ROHS,
		dps.BatchCode, dps.BreakLevel1, dps.Price1,
		dps.BreakLevel2, dps.Price2, dps.BreakLevel3,
		dps.Price3, dps.BreakLevel4, dps.Price4,
		dps.BreakLevel5, dps.Price5, dps.BreakLevel6,
		dps.Price6, dps.BreakLevel7, dps.Price7,
		dps.BreakLevel8, dps.Price8, dps.BreakLevel9,
		dps.Price9, dps.BreakLevel10, dps.Price10,
		dps.DistID, dps.Uploaded, dps.InvID, dps.Status,
		dps.IsManufacturerProduct, dps.Search_PartNumber,
		dps.MfrID
FROM dbo.DistributorPartsStatic AS dps
GO
