ALTER VIEW [dbo].[vw_DistributorPartsSearch]
AS
SELECT  dps.ID, dps.DistributorId, dps.DistributorName,
        dps.Search_Dist_Name, dps.DistLogo, dps.PartNumber,
        dps.Search_PartNumber, dps.ManufacturerCode,
        dps.ManufacturerId, dps.ManufacturerName,
        dps.Search_MFR_Name, dps.CompanyLogo,
        dps.PartUploadDate, dps.ProductId,
        dps.PartDescription, dps.PartQuantity, dps.QOHDisp,
        dps.Price, dps.PartDataSheet, dps.DatasheetLink,
        dps.PartSample, dps.VideoFilePathLink,
        dps.ImageFilePathLink, dps.DoNotPub,
        dps.ProductTypeId, dps.ProductTypeDesc, dps.RFQCPID,
        dps.Buy_Button, dps.DistributorPartID, dps.ROHS,
        dps.HasMfrLogoAd, dps.IsManufacturerProduct,
        dps.ManufacturerSpend
FROM dbo.DistributorPartsSearch AS dps
GO
