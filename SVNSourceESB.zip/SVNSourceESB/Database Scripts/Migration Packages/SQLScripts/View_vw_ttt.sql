/****** Object:  View [dbo].[vw_ttt]    Script Date: 12/26/2011 21:15:30 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vw_ttt]'))
DROP VIEW [dbo].[vw_ttt]
GO

/****** Object:  View [dbo].[vw_ttt]    Script Date: 12/26/2011 21:15:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create view [dbo].[vw_ttt] with schemabinding
as
select PartNumber,InvID from dbo.DistributorParts

GO


