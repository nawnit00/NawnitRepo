	SELECT DISTINCT
		p.edition_ID, 
		NULL, 
		sa.salesperson_id, 
		p.company_id, 
		p.base_Projection,
		p.sales_projection,
		p.adv_net,
		NULL,
		NULL,
		p.LastUpdated_UserID,
		p.LastUpdated_TimeStamp,
		sg.new_account_goal
	FROM projection p
	INNER JOIN edition e
		on p.edition_id = e.edition_id
	LEFT OUTER JOIN sales_assignments sa
		on p.company_ID = sa.Company_ID
	LEFT OUTER JOIN Sales_Goal sg
		ON e.Edition_ID = sg.Edition_ID
		AND sa.SalesPerson_ID = sg.SalesPerson_ID
	WHERE sa.Assignment_ID IS NULL 
		OR  (e.StartSelling_Date >= sa.Start_Date 
		AND (sa.End_Date IS NULL OR e.StartSelling_Date <= sa.End_Date))
		
