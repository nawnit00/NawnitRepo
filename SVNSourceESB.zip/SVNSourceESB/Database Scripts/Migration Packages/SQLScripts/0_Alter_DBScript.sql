/******************************************************************************************************************/
--Tables
/******************************************************************************************************************/

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Company' AND COLUMN_NAME = 'Verified')
ALTER TABLE dbo.Company add Verified bit DEFAULT 0
GO

/****** Object:  Table [dbo].[SponserLinks]    Script Date: 01/11/2012 22:22:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SponserLinks]') AND type in (N'U'))
DROP TABLE [dbo].[SponserLinks]
GO

/****** Object:  Table [dbo].[SponserLinks]    Script Date: 01/11/2012 22:22:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[SponserLinks](
    [Id] [int] IDENTITY(1,1) NOT NULL,
    [NavMenuName] [varchar](50) NULL,
    [SectionName] [varchar](50) NULL,
    [TopLinkId1] [int] NULL,
    [TopLinkId2] [int] NULL,
    [TopLinkId3] [int] NULL,
 CONSTRAINT [PK_SponserLink] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

------------------------------------------------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch1]') AND type in (N'U'))
DROP TABLE [dbo].[DistributorPartsSearch1]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[DistributorPartsSearch1](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [DistributorId] [int] NULL,
    [DistributorName] [varchar](100) NOT NULL,
    [Search_Dist_Name] [varchar](100) NULL,
    [DistLogo] [varchar](100) NULL,
    [PartNumber] [varchar](250) NULL,
    [Search_PartNumber] [varchar](256) NULL,
    [ManufacturerCode] [varchar](50) NULL,
    [ManufacturerId] [int] NULL,
    [ManufacturerName] [varchar](100) NULL,
    [Search_MFR_Name] [varchar](100) NULL,
    [CompanyLogo] [varchar](100) NULL,
    [PartUploadDate] [datetime] NULL,
    [ProductId] [int] NULL,
    [PartDescription] [varchar](500) NULL,
    [PartQuantity] [varchar](50) NULL,
    [QOHDisp] [varchar](10) NOT NULL,
    [Price] [decimal](18, 2) NULL,
    [PartDataSheet] [varchar](200) NULL,
    [DatasheetLink] [varchar](500) NULL,
    [PartSample] [varchar](500) NULL,
    [VideoFilePathLink] [varchar](500) NULL,
    [ImageFilePathLink] [varchar](500) NULL,
    [DoNotPub] [bit] NOT NULL,
    [ProductTypeId] [int] NULL,
    [ProductTypeDesc] [varchar](100) NULL,
    [RFQCPID] [int] NULL,
    [Buy_Button] [int] NOT NULL,
    [DistrbutorPartID] [int] DEFAULT 0
PRIMARY KEY CLUSTERED
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
------------------------------------------------------------------------------------------------------------------

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DistributorPartsSearch2]') AND type in (N'U'))
DROP TABLE [dbo].[DistributorPartsSearch2]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[DistributorPartsSearch2](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [DistributorId] [int] NULL,
    [DistributorName] [varchar](100) NOT NULL,
    [Search_Dist_Name] [varchar](100) NULL,
    [DistLogo] [varchar](100) NULL,
    [PartNumber] [varchar](250) NULL,
    [Search_PartNumber] [varchar](256) NULL,
    [ManufacturerCode] [varchar](50) NULL,
    [ManufacturerId] [int] NULL,
    [ManufacturerName] [varchar](100) NULL,
    [Search_MFR_Name] [varchar](100) NULL,
    [CompanyLogo] [varchar](100) NULL,
    [PartUploadDate] [datetime] NULL,
    [ProductId] [int] NULL,
    [PartDescription] [varchar](500) NULL,
    [PartQuantity] [varchar](50) NULL,
    [QOHDisp] [varchar](10) NOT NULL,
    [Price] [decimal](18, 2) NULL,
    [PartDataSheet] [varchar](200) NULL,
    [DatasheetLink] [varchar](500) NULL,
    [PartSample] [varchar](500) NULL,
    [VideoFilePathLink] [varchar](500) NULL,
    [ImageFilePathLink] [varchar](500) NULL,
    [DoNotPub] [bit] NOT NULL,
    [ProductTypeId] [int] NULL,
    [ProductTypeDesc] [varchar](100) NULL,
    [RFQCPID] [int] NULL,
    [Buy_Button] [int] NOT NULL,
    [DistrbutorPartID] [int] DEFAULT 0
PRIMARY KEY CLUSTERED
(
    [ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

------------------------------------------------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DPS_Swap]') AND type in (N'U'))
DROP TABLE [dbo].[DPS_Swap]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DPS_Swap](
    [A] [bit] NOT NULL
) ON [PRIMARY]

INSERT INTO DPS_Swap VALUES (0)

GO

/****** Object:  Table [dbo].[MFRAlsoKnownAs]    Script Date: 01/09/2012 15:05:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MFRAlsoKnownAs]') AND type in (N'U'))
DROP TABLE [dbo].[MFRAlsoKnownAs]
GO

CREATE table MFRAlsoKnownAs
(
CompanyID int,
AlsoKnownAs varchar(1000)
)
GO
------------------------------------------------------------------------------------------------------------------

/****** Object:  Table [dbo].[IPLocations]    Script Date: 02/01/2012 22:43:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPLocations]') AND type in (N'U'))
DROP TABLE [dbo].[IPLocations]
GO

/****** Object:  Table [dbo].[IPLocations]    Script Date: 02/01/2012 22:43:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[IPLocations](
    [IpFrom] [bigint] NOT NULL,
    [IpTo] [bigint] NOT NULL,
    [CountryShort] [nvarchar](2) NULL,
    [CountryLong] [nvarchar](45) NULL,
    [IpRegion] [nvarchar](128) NULL,
    [IpCity] [nvarchar](128) NULL,
    [IpLatitude] [float] NULL,
    [IpLongitude] [float] NULL,
    [IpZipcode] [nvarchar](5) NULL
) ON [PRIMARY]

GO

/******************************************************************************************************************/
--Views
/******************************************************************************************************************/
GO

/****** Object:  View [dbo].[lm_seeline_distributor]    Script Date: 01/16/2012 13:06:07 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[lm_seeline_distributor]'))
DROP VIEW [dbo].[lm_seeline_distributor]
GO

/****** Object:  View [dbo].[lm_seeline_distributor]    Script Date: 01/16/2012 13:06:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[lm_seeline_distributor] (
    [CompanyID],
    [CompanyName],[Clean_CompanyName]
      ,[AlsoKnownAs],[Clean_AlsoKnownAs]
      ,[Keyword1],[Clean_Keyword1]
      ,[Keyword2],[Clean_Keyword2]
      ,[BookName1],[Clean_BookName1]
      ,[BookName2],[Clean_BookName2]
      ,[CompanyLogo]
      ,[CompanyStatus]
)
AS
SELECT
    comp.CompanyID,
    comp.CompanyName,
    comp.Clean_CompanyName,
    comp2.CompanyName AS AlsoKnownAs,
    comp2.Clean_CompanyName AS Clean_AlsoKnownAs,
    comp.keywords AS Keyword1,
    comp.Clean_keywords AS Clean_Keyword1,
    comp2.keywords AS Keyword2,
    comp2.Clean_keywords AS Clean_Keyword2,
    comp.BookName AS BookName1,
    comp.Clean_BookName AS Clean_BookName1,
    comp2.BookName AS BookName2,
    comp2.Clean_BookName AS Clean_BookName2,
    comp.CompanyLogo,
    'Active' AS CompanyStatus
FROM
    dbo.Company AS comp LEFT OUTER JOIN
    dbo.SeeLine AS s1 ON comp.CompanyID = s1.TargetID LEFT OUTER JOIN
    dbo.Company AS comp2 ON s1.SeeLineID = comp2.CompanyID AND s1.SeeLineID IS NOT NULL INNER JOIN
    dbo.CompanyTypeMapping AS typemap ON comp.CompanyID = typemap.CompanyID
WHERE
    (comp.CompanyStatusID = 1) AND (typemap.CompanyTypeID in (2, 3)) AND (comp.IsActive = 1)

GO
---------------------------------------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[lm_seeline_manufacturer]'))
DROP VIEW [dbo].[lm_seeline_manufacturer]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE view [dbo].[lm_seeline_manufacturer](
        CompanyID
      ,CompanyName, Clean_CompanyName
      ,AlsoKnownAs, Clean_AlsoKnownAs
      ,CompanyDescription
      ,Keyword1, Clean_Keyword1
      ,Keyword2, Clean_Keyword2
      ,BookName1, Clean_BookName1
      ,BookName2, Clean_BookName2
      ,CompanyLogo
      ,CompanyStatus
)
as
    SELECT
        comp.CompanyID,
        comp.CompanyName, comp.Clean_CompanyName,
        comp2.CompanyName AS AlsoKnownAs, comp2.Clean_CompanyName as Clean_AlsoKnownAs,
        CONVERT(varchar(max), comp.CompanyDescription),
        comp.keywords AS keyword1, comp.Clean_keywords as Clean_keyword1,
        comp2.keywords AS keyword2, comp2.Clean_keywords as Clean_keyword2,
        comp.BookName AS BookName1, comp.Clean_BookName as Clean_BookName1,
        comp2.BookName AS BookName2, comp2.Clean_BookName as Clean_BookName2,
        comp.CompanyLogo, 1
    FROM
        Company comp LEFT OUTER JOIN
        SeeLine s1 ON comp.CompanyID = s1.TargetID LEFT OUTER JOIN
        Company comp2 ON s1.SeeLineID = comp2.CompanyID AND
        s1.SeeLineID IS NOT NULL,
        CompanyTypeMapping AS typemap
    WHERE
        comp.CompanyStatusID = 1 AND
        comp.CompanyID = typemap.CompanyID AND
        typemap.CompanyTypeID = 1 AND
        comp.IsActive = 1
UNION
    SELECT
        comp.CompanyID,
        comp.CompanyName, comp.Clean_CompanyName,
        comp2.CompanyName AS AlsoKnownAs, comp2.Clean_CompanyName as Clean_AlsoKnownAs,
        CONVERT(varchar(max), comp.CompanyDescription),
        comp.keywords AS keyword1, comp.Clean_keywords as Clean_keyword1,
        comp2.keywords AS keyword2, comp2.Clean_keywords as Clean_keyword2,
        comp.BookName AS BookName1, comp.Clean_BookName as Clean_BookName1,
        comp2.BookName AS BookName2, comp2.Clean_BookName as Clean_BookName2,
        comp.CompanyLogo, 4
    FROM
        Company comp LEFT OUTER JOIN
        SeeLine s1 ON comp.CompanyID = s1.TargetID LEFT OUTER JOIN
        Company comp2 ON s1.SeeLineID = comp2.CompanyID AND s1.SeeLineID IS NOT NULL
        --,CompanyTypeMapping AS typemap
    WHERE
        comp.CompanyStatusID = 4 AND
        --comp.CompanyID = typemap.CompanyID AND
        --typemap.CompanyTypeID = 1 AND
        comp.IsActive = 1
        AND 1 = (SELECT COUNT(CompanyTypeID)FROM CompanyTypeMapping WHERE CompanyID = comp.CompanyID)


GO

--------------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[VK_Vw_ProductType]'))
DROP VIEW [dbo].[VK_Vw_ProductType]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[VK_Vw_ProductType]
    AS
        SELECT [ProductTypeId]
              ,[TypeDescription]
              ,DBO.VK_RemoveSpecialChars(TypeDescription) SearchTypeDescription
        FROM [dbo].[ProductType] (NOLOCK)


GO

--------------------------------------------------------------------------

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vw_SearchPartMfr]'))
DROP VIEW [dbo].[vw_SearchPartMfr]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE view [dbo].[vw_SearchPartMfr] with schemabinding
    as
    select P.ProductID,P.ManufacturerID,C.CompanyName as Manufacturer,PartNumber,
            T.ProductTypeID,TypeDescription as ProductType from dbo.Product P
            inner join dbo.ProductType_XRF X
            on X.MfrProdTypeCode = P.ProductType
            inner join dbo.ProductType T
            on T.ProductTypeID = X.ProductTypeID
            inner join dbo.Company C
            on C.CompanyID = P.ManufacturerID

GO
/******************************************************************************************************************/
--Functions
/******************************************************************************************************************/
GO

/****** Object:  UserDefinedFunction [dbo].[Get_SeeLineCompany]    Script Date: 05/06/2012 22:32:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Get_SeeLineCompany]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[Get_SeeLineCompany]
GO

/****** Object:  UserDefinedFunction [dbo].[Get_SeeLineCompany]    Script Date: 05/06/2012 22:32:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE FUNCTION [dbo].[Get_SeeLineCompany]
(
    @CompanyID INT,
    @StatusID INT

)
RETURNS VARCHAR(1000)

AS

BEGIN
    DECLARE @IName VARCHAR(500)
    SET   @IName=''
    if @StatusID = 1
    begin
        SELECT  @IName = @IName + ISNULL(c.CompanyName,'')+', ' FROM Company c,Seeline S WHERE c.Companyid=s.SeelineID and S.TargetID=@CompanyID
    end
    else
    begin
        SELECT  @IName = @IName + ISNULL(c.CompanyName,'')+', ' FROM Company c,Seeline S WHERE s.SeeLineID = @CompanyID and s.TargetID = c.CompanyID
    end
    RETURN ISNULL(@IName,'')
END


GO
------------------------------------------------------------------------------------------------------------------
GO

/****** Object:  UserDefinedFunction [dbo].[RemoveSpecialCharacter]    Script Date: 02/29/2012 09:58:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RemoveSpecialCharacter]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RemoveSpecialCharacter]
GO

/****** Object:  UserDefinedFunction [dbo].[RemoveSpecialCharacter]    Script Date: 02/29/2012 09:58:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[RemoveSpecialCharacter]
(
    @companyName varchar(100)
)
RETURNS varchar(100)
AS
BEGIN

BEGIN
    IF @companyName IS NULL
        RETURN NULL
    DECLARE @OutputString VARCHAR(8000)
    SET @OutputString = ''
    DECLARE @l INT
    SET @l = LEN(@companyName)
    DECLARE @p INT
    SET @p = 1
    WHILE @p <= @l
        BEGIN
            DECLARE @c INT
            SET @c = ASCII(SUBSTRING(@companyName, @p, 1))
            IF @c BETWEEN 48 AND 57
                OR @c BETWEEN 65 AND 90
                OR @c BETWEEN 97 AND 122
            SET @OutputString = @OutputString + CHAR(@c)
            SET @p = @p + 1
        END
    IF LEN(@OutputString) = 0
        RETURN NULL
    RETURN @OutputString
END

END

GO
------------------------------------------------------------------------------------------------------------------
/****** Object:  UserDefinedFunction [dbo].[Get_DistPartCount]    Script Date: 02/20/2012 17:55:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Get_DistPartCount]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[Get_DistPartCount]
GO

/****** Object:  UserDefinedFunction [dbo].[Get_DistPartCount]    Script Date: 02/20/2012 17:55:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/************************************************************************************************************
Created By    : Thalai
Created Date  : 21-Apr-2011
Modified By   : Ramesh
Modified Date : 26-01-2012
Modified By   : -
Modified Date : -
Description   : This function returns total Part Count of the Distributor/Vendor
*************************************************************************************************************/
CREATE FUNCTION [dbo].[Get_DistPartCount]
(
 @CompanyID INT
)
RETURNS varchar(100)
AS
BEGIN

DECLARE @Partcount varchar(100)

SELECT @Partcount ='(' + convert(varchar(10),count(*)) + ' parts' FROM distributorparts DP
where DistID = @CompanyID AND Status = 'Active'

SELECT @Partcount = @Partcount+ ', '+convert(varchar(10),count(*)) + ' manufacturers' FROM RegionAuthorization r,company c
where c.Companyid=r.mfrid and c.isActive = 1 and c.companystatusid=1 and r.DistID=@CompanyID

SELECT  @Partcount = @Partcount +', ' +convert(varchar(10), count(*)) + ' products' from CompanyProductType with(nolock) where ProductTypeId not in(select distinct(parentid) from producttype a with(nolock),
 CompanyProductType b with(nolock) where a.producttypeid=b.producttypeid and b.companyid=@CompanyID and a.isactive=1 and a.statusid=1) and companyid=@CompanyID and isactive=1

SELECT @Partcount = @Partcount +', ' +convert(varchar(10),count(*))  + ' services' +')' from vendorservicemapping where serviceid not in(select distinct(parentID) from producttype a,
vendorservicemapping b where a.producttypeid=b.serviceID and b.vendorid=@CompanyID) and vendorid=@CompanyID

RETURN ISNULL(@Partcount,0)

END


GO
------------------------------------------------------------------------------------------------------------------

GO

/****** Object:  UserDefinedFunction [dbo].[GetEditChargesNetAmount]    Script Date: 01/29/2012 18:46:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetEditChargesNetAmount]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[GetEditChargesNetAmount]
GO

GO

/****** Object:  UserDefinedFunction [dbo].[GetEditChargesNetAmount]    Script Date: 01/29/2012 18:46:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE FUNCTION [dbo].[GetEditChargesNetAmount]
(
    @AdOrderId            int,
    @GrossPrice            money,
    @RegionId            int,
    @EditionId            int,
    @AdType                char(1),
    @DiscountGrossAmt    money,
    @Overwrite            char(1)

)
    Returns money
AS
BEGIN
    DECLARE @ReturnNetAmount money
    DECLARE @NonDiscountGrossAmount money = 0
    DECLARE @GrossDiscountAmount money
    Declare @Discount int = 0
    Declare @DiscountAmount money
    DECLARE @Prepaidamount INT
    SET @ReturnNetAmount=0

    SELECT @Overwrite =(CASE WHEN OverwriteDiscountFlag =1 then 'y' else 'n' end) from AdOrder where AdOrderId=@AdOrderId

    if @Overwrite ='n'
        SELECT @Discount = ISNULL(DiscountRate,0) from MSTDISCOUNT WHERE Status=1 and @DiscountGrossAmt between MinimumDiscount AND MaximumDiscount
    else
        SELECT @Discount = ISNULL(DiscountRate,0) from AdOrder WHERE AdOrderId=@AdOrderId


    IF @AdType = 'P'
    BEGIN
        select @NonDiscountGrossAmount=isnull(Ngr_amt,0) from    (SELECT
          adrx.RegionID,adrx.EditionId,Ngr_amt = isnull(sum(isnull(Price,0)),0)
         FROM
          AdOrder Ado
          INNER JOIN AdOrderDetails ad
           ON Ado.AdorderId = Ad.AdorderId
          INNER JOIN AdOrderDetailsRegionEdition Adrx
           ON Ad.AdOrderDetailsId = Adrx.AdOrderDetailsId
         WHERE
          Ado.adorderid = @AdOrderId  AND  ad.ApplyDiscount=0
         GROUP BY adrx.RegionID,adrx.EditionId) as TempNetTable where RegionId =@RegionId and EditionId=@EditionId
    END
    ELSE
    BEGIN
        SELECT @NonDiscountGrossAmount= isnull(Sum(dbo.ufn_GetAdOrderDetailGrossAmount(AdOrderDetailsId)),0)
         FROM
          AdOrder Ado
          INNER JOIN AdOrderDetails ad
           ON Ado.AdorderId = Ad.AdorderId
          WHERE
          Ado.adorderid = @AdOrderId  AND  ad.ApplyDiscount=0  and ad.OrderType = 'O'
          and Datepart(Month,Ad.ActivationDate) =@RegionId and Datepart(Year,Ad.ActivationDate) =@EditionId
    END


    SET @GrossDiscountAmount = @GrossPrice-@NonDiscountGrossAmount
    SET @DiscountAmount =  @Discount * (@GrossDiscountAmount/100)
    SET @ReturnNetAmount = @GrossPrice - @DiscountAmount

    RETURN ISNULL(@ReturnNetAmount,0)
END


GO

------------------------------------------------------------------------------------------------------------------
GO

/****** Object:  UserDefinedFunction [dbo].[ufn_GetAdOrderGrossAmount]    Script Date: 01/29/2012 18:59:03 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ufn_GetAdOrderGrossAmount]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ufn_GetAdOrderGrossAmount]
GO

GO

/****** Object:  UserDefinedFunction [dbo].[ufn_GetAdOrderGrossAmount]    Script Date: 01/29/2012 18:59:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:        <Author,,Name>
-- Create date: <Create Date, ,>
-- Description:    <Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[ufn_GetAdOrderGrossAmount] (@AdOrderID int)
RETURNS MONEY
AS
BEGIN

DECLARE @GrossAmount MONEY
SELECT @GrossAmount = SUM(dbo.ufn_SplitArrayLength(dbo.GetSalesOrderRegion(AdOrderDetailsId,OrderType), ',') * isnull(Price,0)) FROM AdOrderDetails
WHERE AdOrderId = @AdOrderID

RETURN @GrossAmount
END


GO
------------------------------------------------------------------------------------------------------------------
GO

/****** Object:  UserDefinedFunction [dbo].[GetEditChargesSubTotal]    Script Date: 01/29/2012 18:50:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetEditChargesSubTotal]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[GetEditChargesSubTotal]
GO

GO

/****** Object:  UserDefinedFunction [dbo].[GetEditChargesSubTotal]    Script Date: 01/29/2012 18:50:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Created On    :    11 JUNE 2010
-- Description    :    CALCULATE SubTotal Amount
--------------------------------------------------------------------------
-- Modification History
--------------------------------------------------------------------------
-- Modified By        Modified On        Description
--------------------------------------------------------------------------

CREATE FUNCTION [dbo].[GetEditChargesSubTotal]
(
    @AdOrderId            int,
    @GrossPrice            money,
    @RegionId            int,
    @EditionId            int,
    @AdType                char(1),
    @DiscountGrossAmt    money,
    @Overwrite            char(1)
)
    Returns money
AS
BEGIN
    DECLARE @ReturnNetAmount money
    DECLARE @NonDiscountGrossAmount money = 0
    DECLARE @GrossDiscountAmount money
    Declare @Discount int = 0
    Declare @DiscountAmount money
    DECLARE @Prepaidamount INT
    SET @ReturnNetAmount=0


    SELECT @Overwrite =(CASE WHEN OverwriteDiscountFlag =1 then 'y' else 'n' end) from AdOrder where AdOrderId=@AdOrderId

    if @Overwrite ='n'
    SELECT @Discount = ISNULL(DiscountRate,0) from MSTDISCOUNT WHERE Status=1 and @DiscountGrossAmt between MinimumDiscount AND MaximumDiscount
    else
    SELECT @Discount = ISNULL(DiscountRate,0) from AdOrder WHERE AdOrderId=@AdOrderId


    IF @AdType = 'P'
    BEGIN
        select @NonDiscountGrossAmount=isnull(Ngr_amt,0) from    (SELECT
          adrx.RegionID,adrx.EditionId,Ngr_amt = isnull(sum(isnull(Price,0)),0)
         FROM
          AdOrder Ado
          INNER JOIN AdOrderDetails ad
           ON Ado.AdorderId = Ad.AdorderId
          INNER JOIN AdOrderDetailsRegionEdition Adrx
           ON Ad.AdOrderDetailsId = Adrx.AdOrderDetailsId
         WHERE
          Ado.adorderid = @AdOrderId  AND  ad.ApplyDiscount=0
         GROUP BY adrx.RegionID,adrx.EditionId) as TempNetTable where RegionId =@RegionId and EditionId=@EditionId
    END
    ELSE
    BEGIN
        SELECT @NonDiscountGrossAmount= isnull(Sum(dbo.ufn_GetAdOrderDetailGrossAmount(Ad.AdOrderDetailsId)),0)
         FROM
          AdOrder Ado
          INNER JOIN AdOrderDetails ad
           ON Ado.AdorderId = Ad.AdorderId
          WHERE
          Ado.adorderid = @AdOrderId  AND  ad.ApplyDiscount=0  and ad.OrderType = 'O'
          and Datepart(Month,Ad.ActivationDate) =@RegionId and Datepart(Year,Ad.ActivationDate) =@EditionId
    END

    SET @GrossDiscountAmount = @GrossPrice-@NonDiscountGrossAmount
    SET @DiscountAmount =  @Discount * (@GrossDiscountAmount/100)
    SET @ReturnNetAmount = @GrossPrice - @DiscountAmount


    RETURN ISNULL(@ReturnNetAmount,0)
END


GO
------------------------------------------------------------------------------------------------------------------
GO

/****** Object:  UserDefinedFunction [dbo].[ufn_SplitArrayLength]    Script Date: 01/30/2012 23:18:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ufn_SplitArrayLength]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ufn_SplitArrayLength]
GO


/****** Object:  UserDefinedFunction [dbo].[ufn_SplitArrayLength]    Script Date: 01/30/2012 23:18:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE FUNCTION [dbo].[ufn_SplitArrayLength]
(
    @String varchar(8000), @Delimiter char(1)
)
returns int
as
begin
    declare @idx int
    declare @slice varchar(8000)
    declare @length int
    set @length = 0

    select @idx = 1
        if len(@String)<1 or @String is null
        begin
                set @length = 1
                return   @length
        end

    while @idx!= 0
    begin
        set @idx = charindex(@Delimiter,@String)
        if @idx!=0
            set @slice = left(@String,@idx - 1)
        else
            set @slice = @String

        if(len(@slice)>0)
          Set @length = @length + 1

        set @String = right(@String,len(@String) - @idx)
        if len(@String) = 0 break
    end
return       @length
end


GO

------------------------------------------------------------------------------------------------------------------
GO

/****** Object:  UserDefinedFunction [dbo].[ufn_GetAdOrderDetailGrossAmount]    Script Date: 01/29/2012 18:59:03 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ufn_GetAdOrderDetailGrossAmount]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ufn_GetAdOrderDetailGrossAmount]
GO

GO

/****** Object:  UserDefinedFunction [dbo].[ufn_GetAdOrderDetailGrossAmount]    Script Date: 01/29/2012 18:59:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:        <Author,,Name>
-- Create date: <Create Date, ,>
-- Description:    <Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[ufn_GetAdOrderDetailGrossAmount] (@AdOrderDetailsID int)
RETURNS MONEY
AS
BEGIN

DECLARE @GrossAmount MONEY
SELECT @GrossAmount = dbo.ufn_SplitArrayLength(dbo.GetSalesOrderRegion(AdOrderDetailsId,OrderType), ',') * isnull(Price,0) FROM AdOrderDetails
WHERE AdOrderDetailsID = @AdOrderDetailsID

RETURN @GrossAmount
END


GO

------------------------------------------------------------------------------------------------------------------
/****** Object:  UserDefinedFunction [dbo].[GetSalesOrderRegionName]    Script Date: 01/16/2012 20:28:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetSalesOrderRegionName]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[GetSalesOrderRegionName]
GO

/****** Object:  UserDefinedFunction [dbo].[GetSalesOrderRegionName]    Script Date: 01/16/2012 20:28:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--------------------------------------------------------------------------
-- Created By    :    K NAYAK
-- Created On    :    01 Sept 2011
-- Description    :    GET THE REGION LIST NAME
--------------------------------------------------------------------------
-- Modification History
--------------------------------------------------------------------------
-- Modified By        Modified On        Description
--------------------------------------------------------------------------

CREATE FUNCTION [dbo].[GetSalesOrderRegionName]
(
    @AdOrderDetailsId    int,
    @OrderType            char(1)
)
    Returns varchar(1000)
AS
BEGIN
    DECLARE @ReturnRegion VARCHAR(3000)
    SET @ReturnRegion=''

    DECLARE @Edition varchar(20)
    DECLARE @RegionID INT
    DECLARE @getRegionID CURSOR
    SET @getRegionID = CURSOR FOR

    SELECT RegionID FROM AdOrderDetailsRegionEdition WHERE AdOrderDetailsId = @AdOrderDetailsId
    OPEN @getRegionID
    FETCH NEXT
    FROM @getRegionID INTO @RegionID
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @OrderType='O'
        BEGIN
            SELECT @Edition= ZoneName FROM CountryZones where ZoneID=@RegionID
        END
        ELSE
        BEGIN
            SELECT @Edition=(CZ.ZoneCode+' '+RIGHT(E.[YEAR],2) )
            FROM EDITIONS E INNER JOIN COUNTRYZONES CZ ON E.RegionID= CZ.ZoneID WHERE E.[YEAR]=YEAR(GETDATE()) AND CZ.ZoneID=@RegionID
        END

        IF @ReturnRegion=''
            SET @ReturnRegion=@Edition
        ELSE
            SET @ReturnRegion = @ReturnRegion+','+@Edition

    FETCH NEXT
    FROM @getRegionID INTO @RegionID
    END
    CLOSE @getRegionID
    DEALLOCATE @getRegionID
    RETURN @ReturnRegion
END

GO
------------------------------------------------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ufn_DS_Get_IsDistributorOfferService]') )
DROP FUNCTION [dbo].[ufn_DS_Get_IsDistributorOfferService]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/************************************************************************************************************
Created By    : Deepti Singh
Created Date  : 20th-Dec-2011
Description   : This Function returns TRUE for matched regionid based on distributor id
*************************************************************************************************************/

CREATE FUNCTION [dbo].[ufn_DS_Get_IsDistributorOfferService]
(
    @DistributorID    INT
)
RETURNS VARCHAR (1) AS

BEGIN
    DECLARE @IsDistributorOfferService varchar(1)
    Set @IsDistributorOfferService = ''
    BEGIN
        SELECT
                @IsDistributorOfferService = CASE WHEN COUNT(compServices.VendorID)>0 THEN '1' ELSE '0' END
        FROM
                dbo.VendorServiceMapping AS compServices
        WHERE
                compServices.VendorID = @DistributorID
    END
    RETURN ISNULL(@IsDistributorOfferService,'')
END
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ufn_DS_Get_IsDistributorRegion]') )
DROP FUNCTION [dbo].[ufn_DS_Get_IsDistributorRegion]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
---------------------------------------------------------------------------------------------------------------
/************************************************************************************************************
Created By    : Deepti Singh
Created Date  : 20th-Dec-2011
Description   : This Function returns TRUE for matched regionid based on distributor id
*************************************************************************************************************/
CREATE FUNCTION [dbo].[ufn_DS_Get_IsDistributorRegion]
(
    -- Parameters for the function here
    @DistributorID    INT
    ,@RegionID VARCHAR(1000)
)
RETURNS VARCHAR (1) AS

BEGIN
    -- The return variable here
    DECLARE @IsDistributorRegion varchar(1)
    Set @IsDistributorRegion = ''

    BEGIN
    -- The T-SQL statements to compute the return value here
    SELECT @IsDistributorRegion = CASE WHEN COUNT(C.RegionID)>0 THEN '1' ELSE '0' END FROM
              dbo.CompanyLocations complocation
              join country c on c.CountryId  = complocation.countryid
              INNER JOIN (SELECT items FROM dbo.Split(@RegionID,',')) AS RegID
                    ON RegID.items = C.RegionID
        WHERE complocation.CompanyID = @DistributorID
            and LocationStatusID = 1
            and complocation.IsActive = 1
    END
    -- The result of the function
    RETURN ISNULL(@IsDistributorRegion,'')

END
GO
------------------------------------------------------------------------------------------------------------------

/****** Object:  UserDefinedFunction [dbo].[GetSalesOrderRegion]    Script Date: 01/25/2012 14:54:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetSalesOrderRegion]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[GetSalesOrderRegion]
GO


/****** Object:  UserDefinedFunction [dbo].[GetSalesOrderRegion]    Script Date: 01/25/2012 14:54:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--------------------------------------------------------------------------
-- Created By : Siva Prakash D
-- Created On : 29 May 2010
-- Description : GET THE REGION LIST
--------------------------------------------------------------------------
-- Modification History
--------------------------------------------------------------------------
-- Modified By  Modified On  Description
--------------------------------------------------------------------------

CREATE FUNCTION [dbo].[GetSalesOrderRegion]
(
    @AdOrderDetailsId int,
    @OrderType   char(1)
)
    Returns varchar(1000)
AS
BEGIN
    DECLARE @ReturnRegion VARCHAR(3000)
    SET @ReturnRegion=''
    IF @OrderType='P'
    BEGIN
        Select @ReturnRegion =
                substring((SELECT ','+HeadingTitle  from Editions es,AdOrderDetailsRegionEdition aod
            where es.editionid = aod.editionid and aod.adorderdetailsid = @AdOrderDetailsId
            for XML Path('')), 2,500)
    END
    ELSE
    BEGIN
        DECLARE @ReturnGlobalRegions VARCHAR(3000)
        declare @globalregions varchar (20)  = ''
        declare @zoneregions varchar (20)  = ''
        set @globalregions =  (select OrderRegionId from AdOrderDetails
                                        where AdOrderDetailsId = @AdOrderDetailsId)
        --print (@globalregions)
        Select @zoneregions = substring (
                    (SELECT distinct ''','''+convert (varchar(3), c.RegionId)
                            from CountryZones cz, Country c, AdOrderDetailsRegionEdition aod
                            where c.CountryID = cz.CountryID and cz.ZoneID = aod.regionid
                                and aod.adorderdetailsid = @AdOrderDetailsId
                        for XML Path('')), 3, 500) +''''
        --print (@zoneregions)
        set @ReturnRegion = isnull(substring((SELECT ','+zonecode  from CountryZones cz, AdOrderDetailsRegionEdition aod
            where cz.ZoneID = aod.regionid and aod.adorderdetailsid = @AdOrderDetailsId
            for XML Path('')), 2, 500),'')
        set @ReturnGlobalRegions = isnull(substring((SELECT ','+regionName  from Split(@globalregions,',') as orderregions join Region
                    on orderregions.items = RegionID and
                RegionID not in (select distinct c.regionid from CountryZones cz, Country c, AdOrderDetailsRegionEdition aod
                        where c.CountryID = cz.CountryID
                        and cz.ZoneID = aod.regionid
                        and aod.adorderdetailsid = @AdOrderDetailsId )
                 for XML Path ('')),2, 300),'')
        if (@ReturnRegion = '')
            set @ReturnRegion = @ReturnGlobalRegions
        else
            set @ReturnRegion = @ReturnRegion +','+@ReturnGlobalRegions
        --print (@ReturnRegion)
    END
    RETURN @ReturnRegion
END



GO
------------------------------------------------------------------------------------------------------------------
GO

/****** Object:  UserDefinedFunction [dbo].[Splitor_part]    Script Date: 03/17/2012 19:11:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Splitor_part]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[Splitor_part]
GO

/****** Object:  UserDefinedFunction [dbo].[Splitor_part]    Script Date: 03/17/2012 19:11:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE FUNCTION [dbo].[Splitor_part](@String varchar(8000), @Delimiter char(1))
returns  varchar(8000)
as
begin

    DECLARE @listStrF VARCHAR(8000)
    DECLARE @listStr VARCHAR(8000)
    DECLARE @listStr1 VARCHAR(8000)
    declare @idx int
    declare @slice varchar(8000)
    declare @slice1 varchar(8000)
    declare @count int

         set @count=1
         set @listStr =''

         set @count=1
         set @listStr =''
    select @idx = 1
        if len(@String)<1 or @String is null  return  @listStr

    while @idx!= 0
    begin
        set @idx = charindex(@Delimiter,@String)

        if @idx!=0
                set @slice = left(@String,@idx - 1)
         else
                set @slice = @String


            if(len(@slice)>0)
               set @slice= 'Clean_PartNumber like ''%' + @slice + '%'''

   if   @idx!= 0   and  @slice <> ''

    begin
        set @listStr =@listStr  + @slice + ' or '
    end
   else
        set @listStr =@listStr  + @slice


        set @String = right(@String,len(@String) - @idx)
        set @count=@count+1
        if len(@String) = 0 break
    end

    set @listStrF ='( ' + @listStr + ')'

return       @listStrF

end

--select dbo.Splitor_part('s a',' ')

GO
--------------------------------------------------------------------------------------------------------------------
/******************************************************************************************************************/
--Indexes
/******************************************************************************************************************/
--------IDX 1-------------------------------------------------------------------------------------------------------
GO

/****** Object:  Index [IDX_PartNumber]    Script Date: 02/17/2012 12:26:13 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorParts]') AND name = N'IDX_PartNumber')
DROP INDEX [IDX_PartNumber] ON [dbo].[DistributorParts] WITH ( ONLINE = OFF )
GO

/****** Object:  Index [IDX_PartNumber]    Script Date: 02/17/2012 12:26:17 ******/
CREATE NONCLUSTERED INDEX [IDX_PartNumber] ON [dbo].[DistributorParts]
(
    [Status] ASC,
    [PartNumber] ASC
)
INCLUDE ( [ManufacturerCode],
[DistID]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 2-------------------------------------------------------------------------------------------------------
GO

/****** Object:  Index [IDX_ManCode_DistID]    Script Date: 02/17/2012 12:29:18 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorParts]') AND name = N'IDX_ManCode_DistID')
DROP INDEX [IDX_ManCode_DistID] ON [dbo].[DistributorParts] WITH ( ONLINE = OFF )
GO

/****** Object:  Index [IDX_ManCode_DistID]    Script Date: 02/17/2012 12:29:21 ******/
CREATE NONCLUSTERED INDEX [IDX_ManCode_DistID] ON [dbo].[DistributorParts]
(
    [ManufacturerCode] ASC,
    [DistID] ASC,
    [Status] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 3-------------------------------------------------------------------------------------------------------
GO

/****** Object:  Index [IDX_PartNumber]    Script Date: 02/17/2012 12:30:22 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Product]') AND name = N'IDX_PartNumber')
DROP INDEX [IDX_PartNumber] ON [dbo].[Product] WITH ( ONLINE = OFF )
GO

/****** Object:  Index [IDX_PartNumber]    Script Date: 02/17/2012 12:30:26 ******/
CREATE NONCLUSTERED INDEX [IDX_PartNumber] ON [dbo].[Product]
(
    [StatusID] ASC,
    [IsActive] ASC,
    [PartNumber] ASC
)
INCLUDE ( [ManufacturerID],
[ProductTypeId]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 4-------------------------------------------------------------------------------------------------------
GO

/****** Object:  Index [IDX_ManufacurerID]    Script Date: 02/17/2012 12:31:28 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[ManufacturerCode_XRF]') AND name = N'IDX_ManufacurerID')
DROP INDEX [IDX_ManufacurerID] ON [dbo].[ManufacturerCode_XRF] WITH ( ONLINE = OFF )
GO

/****** Object:  Index [IDX_ManufacurerID]    Script Date: 02/17/2012 12:31:31 ******/
CREATE NONCLUSTERED INDEX [IDX_ManufacurerID] ON [dbo].[ManufacturerCode_XRF]
(
    [ManufacturerId] ASC,
    [IsActive] ASC
)
INCLUDE ( [DistributorId],
[ManufacturerCode]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 5-------------------------------------------------------------------------------------------------------
GO

/****** Object:  Index [IDX_CompanyName]    Script Date: 02/17/2012 12:32:23 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Company]') AND name = N'IDX_CompanyName')
DROP INDEX [IDX_CompanyName] ON [dbo].[Company] WITH ( ONLINE = OFF )
GO

/****** Object:  Index [IDX_CompanyName]    Script Date: 02/17/2012 12:32:26 ******/
CREATE NONCLUSTERED INDEX [IDX_CompanyName] ON [dbo].[Company]
(
    [CompanyName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 6-------------------------------------------------------------------------------------------------------
GO

/****** Object:  Index [IDX_CompanyID]    Script Date: 02/29/2012 12:12:36 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdOrder]') AND name = N'IDX_CompanyID')
DROP INDEX [IDX_CompanyID] ON [dbo].[AdOrder] WITH ( ONLINE = OFF )
GO

/****** Object:  Index [IDX_CompanyID]    Script Date: 02/29/2012 12:12:39 ******/
CREATE NONCLUSTERED INDEX [IDX_CompanyID] ON [dbo].[AdOrder]
(
    [CompanyId] ASC,
    [StatusId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 7-------------------------------------------------------------------------------------------------------
GO

/****** Object:  Index [IDX_CountryID]    Script Date: 02/29/2012 12:32:56 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CountryZones]') AND name = N'IDX_CountryID')
DROP INDEX [IDX_CountryID] ON [dbo].[CountryZones] WITH ( ONLINE = OFF )

GO

/****** Object:  Index [IDX_CountryID]    Script Date: 02/29/2012 12:33:01 ******/
CREATE NONCLUSTERED INDEX [IDX_CountryID] ON [dbo].[CountryZones]
(
    [CountryID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 8-------------------------------------------------------------------------------------------------------
GO

/****** Object:  Index [IDX_Region]    Script Date: 02/29/2012 12:35:16 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Country]') AND name = N'IDX_Region')
DROP INDEX [IDX_Region] ON [dbo].[Country] WITH ( ONLINE = OFF )

GO

/****** Object:  Index [IDX_Region]    Script Date: 02/29/2012 12:35:23 ******/
CREATE NONCLUSTERED INDEX [IDX_Region] ON [dbo].[Country]
(
    [RegionID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

GO
--------IDX 9-------------------------------------------------------------------------------------------------------
GO

/****** Object:  Index [cladorder_idx]    Script Date: 03/20/2012 16:06:26 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdOrderDetailsRegionEdition]') AND name = N'cladorder_idx')
DROP INDEX [cladorder_idx] ON [dbo].[AdOrderDetailsRegionEdition] WITH ( ONLINE = OFF )
GO

/****** Object:  Index [cladorder_idx]    Script Date: 03/20/2012 16:06:26 ******/
CREATE CLUSTERED INDEX [cladorder_idx] ON [dbo].[AdOrderDetailsRegionEdition]
(
    [AdOrderDetailsId] ASC,
    [RegionID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 10------------------------------------------------------------------------------------------------------
GO
--dbo.DistributorParts
/****** Object:  Index [pk_DPSInvid]    Script Date: 03/20/2012 12:22:07 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorParts]') AND name = N'pk_DPSInvid')
ALTER TABLE [dbo].[DistributorParts] DROP CONSTRAINT [pk_DPSInvid]
GO


/****** Object:  Index [pk_DPSInvid]    Script Date: 03/20/2012 12:22:07 ******/
ALTER TABLE [dbo].[DistributorParts] ADD  CONSTRAINT [pk_DPSInvid] PRIMARY KEY CLUSTERED
(
    [InvID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO

--------IDX 11------------------------------------------------------------------------------------------------------
GO
--/****** Object:  Index [DPSMDPB_idx]    Script Date: 03/20/2012 12:25:24 ******/
--IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorParts]') AND name = N'DPSMDPB_idx')
--DROP INDEX [DPSMDPB_NCidx] ON [dbo].[DistributorParts] WITH ( ONLINE = OFF )
--GO
--
--/****** Object:  Index [DPSMDPB_idx]    Script Date: 03/20/2012 12:25:24 ******/
--CREATE NONCLUSTERED INDEX [DPSMDPB_NCidx] ON [dbo].[DistributorParts]
--(
--    [ManufacturerCode] ASC,
--    [DistID] ASC,
--    [PartNumber] ASC,
--    [BatchCode] ASC
--)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 11------------------------------------------------------------------------------------------------------

GO
/****** Object:  Index [pk_AODREid]    Script Date: 03/20/2012 12:28:01 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdOrderDetailsRegionEdition]') AND name = N'pk_AODREid')
ALTER TABLE [dbo].[AdOrderDetailsRegionEdition] DROP CONSTRAINT [pk_AODREid]
GO


/****** Object:  Index [pk_AODREid]    Script Date: 03/20/2012 12:28:01 ******/
ALTER TABLE [dbo].[AdOrderDetailsRegionEdition] ADD  CONSTRAINT [pk_AODREid] PRIMARY KEY NONCLUSTERED
(
    [AdOrderDetailsRegionEditionId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 12------------------------------------------------------------------------------------------------------

GO
--/****** Object:  Index [AODIEIRIid_idx]    Script Date: 03/20/2012 12:31:44 ******/
--IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdOrderDetailsRegionEdition]') AND name = N'AODIEIRIid_idx')
--DROP INDEX [AODIEIRIid_NCidx] ON [dbo].[AdOrderDetailsRegionEdition] WITH ( ONLINE = OFF )
--GO
--
--
--
--/****** Object:  Index [AODIEIRIid_idx]    Script Date: 03/20/2012 12:31:44 ******/
--CREATE NONCLUSTERED INDEX [AODIEIRIid_NCidx] ON [dbo].[AdOrderDetailsRegionEdition]
--(
--    [AdOrderDetailsId] ASC,
--    [EditionID] ASC,
--    [RegionID] ASC
--)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 13------------------------------------------------------------------------------------------------------
--UserContact
GO
/****** Object:  Index [pk_UCid]    Script Date: 03/20/2012 12:35:37 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UserContact]') AND name = N'pk_UCid')
ALTER TABLE [dbo].[UserContact] DROP CONSTRAINT [pk_UCid]
GO



/****** Object:  Index [pk_UCid]    Script Date: 03/20/2012 12:35:37 ******/
ALTER TABLE [dbo].[UserContact] ADD  CONSTRAINT [pk_UCid] PRIMARY KEY CLUSTERED
(
    [UserContactID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO

--------IDX 14------------------------------------------------------------------------------------------------------
GO
/****** Object:  Index [UEid_NCidx]    Script Date: 03/20/2012 12:36:04 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UserContact]') AND name = N'UEid_NCidx')
DROP INDEX [UEid_NCidx] ON [dbo].[UserContact] WITH ( ONLINE = OFF )
GO


/****** Object:  Index [UEid_NCidx]    Script Date: 03/20/2012 12:36:04 ******/
CREATE NONCLUSTERED INDEX [UEid_NCidx] ON [dbo].[UserContact]
(
    [UserID] ASC,
    [EmailAddress] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 15------------------------------------------------------------------------------------------------------
--[VendorServiceMapping]
GO
/****** Object:  Index [pk_VSid]    Script Date: 03/20/2012 12:38:55 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[VendorServiceMapping]') AND name = N'pk_VSid')
ALTER TABLE [dbo].[VendorServiceMapping] DROP CONSTRAINT [pk_VSid]
GO



/****** Object:  Index [pk_VSid]    Script Date: 03/20/2012 12:38:55 ******/
ALTER TABLE [dbo].[VendorServiceMapping] ADD  CONSTRAINT [pk_VSid] PRIMARY KEY CLUSTERED
(
    [VendorID] ASC,
    [ServiceID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 16------------------------------------------------------------------------------------------------------
GO
/****** Object:  Index [VMSID_UNCidx]    Script Date: 03/20/2012 12:39:19 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[VendorServiceMapping]') AND name = N'VMSID_UNCidx')
DROP INDEX [VMSID_UNCidx] ON [dbo].[VendorServiceMapping] WITH ( ONLINE = OFF )
GO


/****** Object:  Index [VMSID_UNCidx]    Script Date: 03/20/2012 12:39:19 ******/
CREATE UNIQUE NONCLUSTERED INDEX [VMSID_UNCidx] ON [dbo].[VendorServiceMapping]
(
    [VSMID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 17------------------------------------------------------------------------------------------------------
GO
--ChkInChkOutArtWrkFiles


/****** Object:  Index [pk_CICOAWFSLNO]    Script Date: 03/20/2012 12:45:36 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[ChkInChkOutArtWrkFiles]') AND name = N'pk_CICOAWFSLNO')
ALTER TABLE [dbo].[ChkInChkOutArtWrkFiles] DROP CONSTRAINT [pk_CICOAWFSLNO]
GO



/****** Object:  Index [pk_CICOAWFSLNO]    Script Date: 03/20/2012 12:45:36 ******/
ALTER TABLE [dbo].[ChkInChkOutArtWrkFiles] ADD  CONSTRAINT [pk_CICOAWFSLNO] PRIMARY KEY CLUSTERED
(
    [SlNo] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO

--------IDX 18------------------------------------------------------------------------------------------------------
GO
/****** Object:  Index [CICOORAD_NCidx]    Script Date: 03/20/2012 12:45:48 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[ChkInChkOutArtWrkFiles]') AND name = N'CICOORAD_NCidx')
DROP INDEX [CICOORAD_NCidx] ON [dbo].[ChkInChkOutArtWrkFiles] WITH ( ONLINE = OFF )
GO

/****** Object:  Index [CICOORAD_NCidx]    Script Date: 03/20/2012 12:45:48 ******/
CREATE NONCLUSTERED INDEX [CICOORAD_NCidx] ON [dbo].[ChkInChkOutArtWrkFiles]
(
    [OrderId] ASC,
    [AdId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 19------------------------------------------------------------------------------------------------------
--[CompanyLocations]
GO

/****** Object:  Index [pk_CLLID]    Script Date: 03/20/2012 12:49:44 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CompanyLocations]') AND name = N'pk_CLLID')
ALTER TABLE [dbo].[CompanyLocations] DROP CONSTRAINT [pk_CLLID]
GO


/****** Object:  Index [pk_CLLID]    Script Date: 03/20/2012 12:49:44 ******/
ALTER TABLE [dbo].[CompanyLocations] ADD  CONSTRAINT [pk_CLLID] PRIMARY KEY CLUSTERED
(
    [LocationID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO

--------IDX 20------------------------------------------------------------------------------------------------------
GO
/****** Object:  Index [CLCDOIS_NCidx]    Script Date: 03/20/2012 12:50:05 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CompanyLocations]') AND name = N'CLCDOIS_NCidx')
DROP INDEX [CLCDOIS_NCidx] ON [dbo].[CompanyLocations] WITH ( ONLINE = OFF )
GO


/****** Object:  Index [CLCDOIS_NCidx]    Script Date: 03/20/2012 12:50:06 ******/
CREATE NONCLUSTERED INDEX [CLCDOIS_NCidx] ON [dbo].[CompanyLocations]
(
    [CompanyID] ASC,
    [DoNotPublishIndicator] ASC,
    [IsActive] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 21------------------------------------------------------------------------------------------------------
--[CompanyRating]
GO

/****** Object:  Index [pk_CRRID]    Script Date: 03/20/2012 12:53:22 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CompanyRating]') AND name = N'pk_CRRID')
ALTER TABLE [dbo].[CompanyRating] DROP CONSTRAINT [pk_CRRID]
GO

/****** Object:  Index [pk_CRRID]    Script Date: 03/20/2012 12:53:22 ******/
ALTER TABLE [dbo].[CompanyRating] ADD  CONSTRAINT [pk_CRRID] PRIMARY KEY CLUSTERED
(
    [RatingID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 22------------------------------------------------------------------------------------------------------
GO
/****** Object:  Index [CRCID_UNCidx]    Script Date: 03/20/2012 12:53:52 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CompanyRating]') AND name = N'CRCID_UNCidx')
DROP INDEX [CRCID_UNCidx] ON [dbo].[CompanyRating] WITH ( ONLINE = OFF )
GO


/****** Object:  Index [CRCID_UNCidx]    Script Date: 03/20/2012 12:53:53 ******/
CREATE UNIQUE NONCLUSTERED INDEX [CRCID_UNCidx] ON [dbo].[CompanyRating]
(
    [CompanyID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 23------------------------------------------------------------------------------------------------------
GO
--MFRAlsoKnownAs
alter table dbo.MFRAlsoKnownAs  alter  column CompanyID int  not null
GO

/****** Object:  Index [pk_MFRCID]    Script Date: 03/20/2012 13:09:46 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[MFRAlsoKnownAs]') AND name = N'pk_MFRCID')
ALTER TABLE [dbo].[MFRAlsoKnownAs] DROP CONSTRAINT [pk_MFRCID]

/****** Object:  Index [pk_MFRCID]    Script Date: 03/20/2012 13:09:46 ******/
ALTER TABLE [dbo].[MFRAlsoKnownAs] ADD  CONSTRAINT [pk_MFRCID] PRIMARY KEY CLUSTERED
(
    [CompanyID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 24------------------------------------------------------------------------------------------------------
GO
--dbo.PremiumListing
/****** Object:  Index [pk_PLAODID]    Script Date: 03/20/2012 13:18:01 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PremiumListing]') AND name = N'pk_PLAODID')
ALTER TABLE [dbo].[PremiumListing] DROP CONSTRAINT [pk_PLAODID]
GO

/****** Object:  Index [pk_PLAODID]    Script Date: 03/20/2012 13:18:01 ******/
ALTER TABLE [dbo].[PremiumListing] ADD  CONSTRAINT [pk_PLAODID] PRIMARY KEY CLUSTERED
(
    [AdOrderDetailsId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 25------------------------------------------------------------------------------------------------------
--[AdOrderRevision]
GO

/****** Object:  Index [pk_AORID]    Script Date: 03/20/2012 13:20:17 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdOrderRevision]') AND name = N'pk_AORID')
ALTER TABLE [dbo].[AdOrderRevision] DROP CONSTRAINT [pk_AORID]
GO


/****** Object:  Index [pk_AORID]    Script Date: 03/20/2012 13:20:17 ******/
ALTER TABLE [dbo].[AdOrderRevision] ADD  CONSTRAINT [pk_AORID] PRIMARY KEY CLUSTERED
(
    [AdOrderRevisionId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 26------------------------------------------------------------------------------------------------------
GO
/****** Object:  Index [AORADV_NCidx]    Script Date: 03/20/2012 13:20:37 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdOrderRevision]') AND name = N'AORADV_NCidx')
DROP INDEX [AORADV_NCidx] ON [dbo].[AdOrderRevision] WITH ( ONLINE = OFF )
GO

/****** Object:  Index [AORADV_NCidx]    Script Date: 03/20/2012 13:20:37 ******/
CREATE NONCLUSTERED INDEX [AORADV_NCidx] ON [dbo].[AdOrderRevision]
(
    [AdOrderId] ASC,
    [Version] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 27------------------------------------------------------------------------------------------------------
--[UserFavorites]
GO
/****** Object:  Index [pk_UFID]    Script Date: 03/20/2012 13:22:39 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UserFavorites]') AND name = N'pk_UFID')
ALTER TABLE [dbo].[UserFavorites] DROP CONSTRAINT [pk_UFID]
GO


/****** Object:  Index [pk_UFID]    Script Date: 03/20/2012 13:22:39 ******/
ALTER TABLE [dbo].[UserFavorites] ADD  CONSTRAINT [pk_UFID] PRIMARY KEY CLUSTERED
(
    [UserFavoritesID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 28------------------------------------------------------------------------------------------------------
GO
/****** Object:  Index [UFUFID_NCidx]    Script Date: 03/20/2012 13:23:05 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UserFavorites]') AND name = N'UFUFID_NCidx')
DROP INDEX [UFUFID_NCidx] ON [dbo].[UserFavorites] WITH ( ONLINE = OFF )
GO

/****** Object:  Index [UFUFID_NCidx]    Script Date: 03/20/2012 13:23:06 ******/
CREATE NONCLUSTERED INDEX [UFUFID_NCidx] ON [dbo].[UserFavorites]
(
    [UserID] ASC,
    [FavType] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 29------------------------------------------------------------------------------------------------------
GO
--[AdOrderDetailsRegionEditionRevision]

/****** Object:  Index [AODRERARADID_NCidx]    Script Date: 03/20/2012 13:25:42 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdOrderDetailsRegionEditionRevision]') AND name = N'AODRERARADID_NCidx')
DROP INDEX [AODRERARADID_NCidx] ON [dbo].[AdOrderDetailsRegionEditionRevision] WITH ( ONLINE = OFF )
GO

/****** Object:  Index [AODRERARADID_NCidx]    Script Date: 03/20/2012 13:25:42 ******/
CREATE NONCLUSTERED INDEX [AODRERARADID_NCidx] ON [dbo].[AdOrderDetailsRegionEditionRevision]
(
    [AdOrderRevisionId] ASC,
    [AdOrderDetailsId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 30------------------------------------------------------------------------------------------------------
--[Menu]
GO
/****** Object:  Index [MENUID_NCidx]    Script Date: 03/20/2012 13:31:06 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Menu]') AND name = N'MENUID_NCidx')
DROP INDEX [MENUID_NCidx] ON [dbo].[Menu] WITH ( ONLINE = OFF )
GO


/****** Object:  Index [MENUID_NCidx]    Script Date: 03/20/2012 13:31:06 ******/
CREATE NONCLUSTERED INDEX [MENUID_NCidx] ON [dbo].[Menu]
(
    [MenuID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 31------------------------------------------------------------------------------------------------------
--AdOrderDetailsRevision
GO
alter table dbo.AdOrderDetailsRevision alter  column AdOrderDetailsId int  not null
GO
alter table dbo.AdOrderDetailsRevision  alter  column AdOrderRevisionId int  not null
GO

/****** Object:  Index [AODRADARID_NCidx]    Script Date: 03/20/2012 13:39:19 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdOrderDetailsRevision]') AND name = N'AODRADARID_NCidx')
DROP INDEX [AODRADARID_NCidx] ON [dbo].[AdOrderDetailsRevision] WITH ( ONLINE = OFF )
GO


/****** Object:  Index [AODRADARID_NCidx]    Script Date: 03/20/2012 13:39:19 ******/
CREATE NONCLUSTERED INDEX [AODRADARID_NCidx] ON [dbo].[AdOrderDetailsRevision]
(
    [AdOrderDetailsId] ASC,
    [AdOrderRevisionId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 32------------------------------------------------------------------------------------------------------
--[Editions]
GO
/****** Object:  Index [pk_EDID]    Script Date: 03/20/2012 13:43:47 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Editions]') AND name = N'pk_EDID')
ALTER TABLE [dbo].[Editions] DROP CONSTRAINT [pk_EDID]
GO


/****** Object:  Index [pk_EDID]    Script Date: 03/20/2012 13:43:47 ******/
ALTER TABLE [dbo].[Editions] ADD  CONSTRAINT [pk_EDID] PRIMARY KEY NONCLUSTERED
(
    [EditionID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 33------------------------------------------------------------------------------------------------------
GO
--[MySourceUserPreferences]
/****** Object:  Index [MSUPID_UNCidx]    Script Date: 03/20/2012 13:47:05 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[MySourceUserPreferences]') AND name = N'MSUPID_UNCidx')
DROP INDEX [MSUPID_NCidx] ON [dbo].[MySourceUserPreferences] WITH ( ONLINE = OFF )
GO

/****** Object:  Index [MSUPID_UNCidx]    Script Date: 03/20/2012 13:47:05 ******/
CREATE NONCLUSTERED INDEX [MSUPID_NCidx] ON [dbo].[MySourceUserPreferences]
(
    [UserId] ASC,
    [PreferenceId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
--------IDX 34------------------------------------------------------------------------------------------------------
GO

/****** Object:  Index [IDX_DistID]    Script Date: 03/23/2012 11:30:25 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DistributorParts]') AND name = N'IDX_DistID')
DROP INDEX [IDX_DistID] ON [dbo].[DistributorParts] WITH ( ONLINE = OFF )
GO

/****** Object:  Index [IDX_DistID]    Script Date: 03/23/2012 11:30:25 ******/
CREATE NONCLUSTERED INDEX [IDX_DistID] ON [dbo].[DistributorParts]
(
    [DistID] ASC
)
INCLUDE ( [ManufacturerCode],
[PartNumber],
[BatchCode],
[InvID]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO

--------IDX 35------------------------------------------------------------------------------------------------------
--------IDX 36------------------------------------------------------------------------------------------------------
--------IDX 37------------------------------------------------------------------------------------------------------
--------IDX 38------------------------------------------------------------------------------------------------------
--------IDX 39------------------------------------------------------------------------------------------------------
--------IDX 40------------------------------------------------------------------------------------------------------
--------IDX 41------------------------------------------------------------------------------------------------------

/******************************************************************************************************************/
--Stored Procedures
/******************************************************************************************************************/
GO

/****** Object:  StoredProcedure [dbo].[usp_BSK_getSearchResultDesignResourceTab]    Script Date: 05/25/2012 17:10:03 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_BSK_getSearchResultDesignResourceTab]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_BSK_getSearchResultDesignResourceTab]
GO

/****** Object:  StoredProcedure [dbo].[usp_BSK_getSearchResultDesignResourceTab]    Script Date: 05/25/2012 17:10:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--SELECT * FROM ProductResources WHERE ProductId=174480
--usp_BSK_getSearchResultDesignResourceTab 'b10'

CREATE PROCEDURE [dbo].[usp_BSK_getSearchResultDesignResourceTab]
    @SearchText	 VARCHAR(80)
    ,@ManufacturerIDs VARCHAR(5000) = ''
AS
BEGIN
    DECLARE @IsEmptyManufacturerID VARCHAR(1) = '0'
    DECLARE @Query VARCHAR(8000) =''
    DECLARE @ResourceAppTitle VARCHAR(8000)=''
    declare @SearchText1 varchar(8000)

    set transaction isolation level read uncommitted
    select @SearchText1=dbo.Splitor_part(@SearchText, ' ')

    IF(@ManufacturerIDs='')
    BEGIN
        SET @IsEmptyManufacturerID = 1
    END

    SET @ManufacturerIDs = '' + REPLACE(@ManufacturerIDs,',',''',''') + ''


SET @Query ='select * into ##TEMPDR from (SELECT  DISTINCT prod.PartNumber,prod.ProductID
            ,comp.CompanyName AS ManufacturerName,comp.CompanyID
            ,CASE WHEN ISNULL(prod.DataSheet,'''') <>'''' AND ISNULL(prod.DataSheetTitle,'''')<>''''
                THEN prod.DataSheetTitle
                    ELSE
                        CASE WHEN ISNULL(inv.MafSpecURL,'''') <> '''' AND ISNULL(inv.MafSpecTitle,'''')<>''''
                            THEN inv.MafSpecTitle ELSE ''Data Sheet'' END END AS DataSheetTitle
            ,CASE WHEN ISNULL(prod.DataSheet,'''') <> '''' THEN prod.DataSheet
                ELSE
                    CASE WHEN ISNULL(inv.MafSpecURL,'''')<> '''' THEN inv.MafSpecURL END END AS DataSheetLink
            ,dbo.ufn_BSK_CommaSaparatedResourceAppType (prod.ProductID) AS AppNote
            ,dbo.ufn_BSK_CommaSaparatedResourceSoftType (prod.ProductID) AS Software
            ,prod.SampleUrl
            ,prod.VideoFilePath
            ,prod.ImageFilePath
            ,pt.TypeDescription
            ,MatchOrder
            FROM (
                    select   distinct pd.*,
                    CASE WHEN pd.Clean_PartNumber LIKE search_term.items THEN ''1'' ELSE
                    CASE WHEN pd.Clean_PartNumber LIKE search_term.items + ''_%'' THEN ''2'' ELSE
                    CASE WHEN pd.Clean_PartNumber LIKE ''_%'' + search_term.items + ''%'' THEN ''3'' END END END AS						MatchOrder
                    FROM
                    (
                        select PartNumber,ProductID,DataSheet,DataSheetTitle,SampleUrl,VideoFilePath
                        ,ImageFilePath,Clean_PartNumber,ManufacturerID,ProductType from product (nolock)
                        where ' + @SearchText1 + '
                    )pd
                   outer apply	(SELECT * FROM Split('''+@SearchText+''','' '')) AS search_term
                   where
                   (CASE WHEN pd.Clean_PartNumber LIKE search_term.items THEN ''1'' ELSE
                    CASE WHEN pd.Clean_PartNumber LIKE search_term.items + ''_%'' THEN ''2'' ELSE
                    CASE WHEN pd.Clean_PartNumber LIKE ''_%'' + search_term.items + ''%'' THEN ''3'' END END END
                    ) <> 0
              ) prod
             INNER JOIN [dbo].[Company] comp
              ON prod.ManufacturerID=comp.CompanyID
             LEFT JOIN [dbo].[InventorySettings] inv
                ON inv.CompanyID=prod.ManufacturerID
             LEFT JOIN  productType_XRF xrf ON prod.ProductType = xrf.MfrProdTypeCode
             LEFT JOIN ProductType pt on pt.ProductTypeId = xrf.ProductTypeID
             WHERE comp.IsActive=''1'' AND comp.CompanyStatusID=''1''
             AND (comp.CompanyID IN ('''+ @ManufacturerIDs +''') OR ' + @IsEmptyManufacturerID + ' = ''1'')
          ) PrimaryResults
         where (ISNULL(SampleUrl, '''') <> '''' OR ISNULL(VideoFilePath,'''') <> ''''
            OR ISNULL(DataSheetLink,'''')<>'''' OR ISNULL(ImageFilePath,'''')<>'''' OR ISNULL(AppNote,'''')<>''''
            OR ISNULL(Software,'''')<>'''')
         ORDER BY MatchOrder, PartNumber, ManufacturerName'


exec(@Query)


select a.PartNumber, min(a.MatchOrder) orders,count(a.MatchOrder) counts
        into ##TEMP from ##TEMPDR a
  group by a.PartNumber

  select a.* into ##TEMPDR2 from ##TEMPDR a join ##TEMP b on a.PartNumber=b.PartNumber and a.matchorder=b.orders
                  ORDER BY MatchOrder,PartNumber, ManufacturerName DESC



--FACET MANUFACTIRER [START]
SET @Query ='SELECT  DISTINCT comp.CompanyID AS FacetValue
          ,''<span title=''''''+comp.ManufacturerName+''''''>''+CASE WHEN LEN(comp.ManufacturerName)>16
          THEN SUBSTRING(comp.ManufacturerName,0,16)+''...'' ELSE comp.ManufacturerName END + '' ('' + CONVERT(VARCHAR, COUNT(comp.ManufacturerName)) + '')</span>'' AS FacetKey
          ,comp.ManufacturerName as CompanyName
          ,COUNT(comp.ManufacturerName) AS CountCompany
       FROM
       (
            Select * from ##TEMPDR2
       )comp

    GROUP BY comp.ManufacturerName, comp.CompanyID
    ORDER BY CountCompany DESC'
    --FACET MANUFACTIRER [END]

Select * from ##TEMPDR2

Exec (@Query)

DROP TABLE ##TEMPDR
DROP TABLE ##TEMPDR2
DROP TABLE ##TEMP


END


GO
------------------------------------------------------------------------------------------------------------------

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Usp_RejectAllZones]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Usp_RejectAllZones]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Usp_RejectAllZones]
    @MfrDistID INT
AS
BEGIN
    Update RegionZoneStatus set AuthStatusID=3, Denied_Date = GETDATE() where MfrDistID=@MfrDistID

END

GO
------------------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_SearchDistributor]    Script Date: 05/25/2012 17:05:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SearchDistributor]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_SearchDistributor]
GO

/****** Object:  StoredProcedure [dbo].[usp_SearchDistributor]    Script Date: 05/25/2012 17:05:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_SearchDistributor]
(
    @SearchCreteria  varchar(4000)
    ,@AttributesIds VARCHAR (100)
    ,@RegionIds VARCHAR (100)
    ,@UserID int
    ,@OfferServices bit
)
AS
 BEGIN
     set transaction isolation level read uncommitted

    SET @SearchCreteria = [dbo].VK_RemoveSpecialChars(@SearchCreteria)

    DECLARE @SQL1 VARCHAR(MAX),@SQLIF  VARCHAR(MAX),@SQLELSE  VARCHAR(MAX),@SQL VARCHAR(MAX)

SET @SQL1=
'SELECT DISTINCT
            seeline_view.CompanyID AS DistributorID, seeline_view.CompanyLogo AS CompanyLogo,
                seeline_view.CompanyName AS DistributorName,
        --		SearchHeaders = ''a'' ,ColumnDescription = ''col Desc'', CompanyTypeDescription = ''Co Type'',
                dbo.Get_SearchCompanyOwn (seeline_view.CompanyID) AS DistributorAttributes,
                dbo.ufn_DS_Get_DistributorSeeLines(seeline_view.CompanyID) AS AlsoKnownAs,
                CASE WHEN ( uf.TypeID IS NULL ) THEN 0 ELSE 1 END  AS IsFav ,
                CASE WHEN (seeline_view.Clean_CompanyName LIKE '''+@SearchCreteria+'''
                OR seeline_view.Clean_AlsoKnownAs LIKE '''+@SearchCreteria+'''
                OR seeline_view.Clean_BookName1 LIKE '''+@SearchCreteria+'''
                OR seeline_view.Clean_BookName2 LIKE '''+@SearchCreteria+'''
                OR seeline_view.Clean_keyword1 LIKE '''+@SearchCreteria+'''
                OR seeline_view.Clean_keyword2 LIKE '''+@SearchCreteria+''') THEN ''1'' ELSE
              CASE WHEN (seeline_view.Clean_CompanyName LIKE search_term.items + ''_%''
                OR seeline_view.Clean_AlsoKnownAs LIKE search_term.items + ''_%''
                OR seeline_view.Clean_BookName1 LIKE search_term.items + ''_%''
                OR seeline_view.Clean_BookName2 LIKE search_term.items + ''_%''
                OR seeline_view.Clean_keyword1 LIKE search_term.items + ''_%''
                OR seeline_view.Clean_keyword2 LIKE search_term.items + ''_%'')THEN ''2'' ELSE
              CASE WHEN (seeline_view.Clean_CompanyName LIKE ''_%'' + search_term.items + ''%''
                OR seeline_view.Clean_AlsoKnownAs LIKE ''_%'' + search_term.items + ''%''
                OR seeline_view.Clean_BookName1 LIKE ''_%'' + search_term.items + ''%''
                OR seeline_view.Clean_BookName2 LIKE ''_%'' + search_term.items + ''%''
                OR seeline_view.Clean_keyword1 LIKE ''_%'' + search_term.items + ''%''
                OR seeline_view.Clean_keyword2 LIKE ''_%'' + search_term.items + ''%'')THEN ''3'' END END END AS MatchOrder, invs.CheckInvURL
            FROM (SELECT * FROM dbo.Split('''+@SearchCreteria+''','' '')) AS search_term
             INNER JOIN dbo.lm_seeline_distributor  seeline_view (NOLOCK) ON
             seeline_view.Clean_CompanyName LIKE ''%'' + search_term.items + ''%''
             OR seeline_view.Clean_AlsoKnownAs LIKE ''%'' + search_term.items + ''%''
             OR seeline_view.Clean_BookName1 LIKE ''%'' + search_term.items + ''%''
             OR seeline_view.Clean_keyword1 LIKE ''%'' + search_term.items + ''%''
             OR seeline_view.Clean_BookName2 LIKE ''%'' + search_term.items + ''%''
             OR seeline_view.Clean_keyword2 LIKE ''%'' + search_term.items + ''%''
             LEFT JOIN [dbo].[InventorySettings] invs ON seeline_view.CompanyID = invs.CompanyID '

SET @SQLIF='LEFT JOIN dbo.[UserFavorites]  uf (NOLOCK)  ON seeline_view.CompanyID = uf.TypeID
             AND uf.[FavType] in (1,2,4) AND CAST(UserID AS VARCHAR)  = '''+CAST(@USERID AS VARCHAR)+'''
            WHERE
              ([dbo].[ufn_DS_Get_IsDistributorRegion] (seeline_view.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''')
              AND
              ([dbo].[ufn_DS_Get_IsDistributorOfferService] (seeline_view.CompanyID) = 1 OR '+CAST(@OfferServices AS CHAR(1))+'=''0'')'
SET @SQLELSE='INNER JOIN dbo.CompanyOwnershipMapping com (NOLOCK)
                ON com.CompanyID=seeline_view.CompanyID
            INNER JOIN (SELECT * FROM dbo.Split('''+@AttributesIds+''','','')) as Attributes
                ON com.OwnershipID = Attributes.items
            LEFT JOIN dbo.[UserFavorites]  uf (NOLOCK)  ON seeline_view.CompanyID = uf.TypeID
            AND uf.[FavType] in (1,2,4) AND CAST(UserID AS VARCHAR)  = '''+CAST(@USERID AS VARCHAR)+'''
        WHERE
              ([dbo].[ufn_DS_Get_IsDistributorRegion] (seeline_view.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''')
              AND
              ([dbo].[ufn_DS_Get_IsDistributorOfferService] (seeline_view.CompanyID) = 1 OR '+CAST(@OfferServices AS CHAR(1))+'=''0'')'

   IF(@AttributesIds='')
     BEGIN
        SET @SQL='SELECT * into ##seadist FROM ('+@SQL1+@SQLIF+') T WHERE MatchOrder IS NOT NULL ORDER BY MatchOrder, DistributorName'
        EXEC (@SQL)
        PRINT @SQL
     END
    ELSE
     BEGIN
        SET @SQL='SELECT * into ##seadist FROM ('+@SQL1++@SQLELSE+') T WHERE MatchOrder IS NOT NULL ORDER BY MatchOrder, DistributorName'
        EXEC (@SQL)
     END
    select a.DistributorID, min(a.MatchOrder) orders,count(a.MatchOrder) counts
        into ##dist from ##seadist a
    group by a.DistributorID

    select a.*, DIFFERENCE(@SearchCreteria, a.DistributorName) as diff into ##DistDiffTable from ##seadist a join ##dist b on a.DistributorID=b.DistributorID and a.matchorder=b.orders
                  ORDER BY MatchOrder,DistributorName

    select DistributorID, CompanyLogo, DistributorName,
        DistributorAttributes, AlsoKnownAs, IsFav, MatchOrder
        from ##DistDiffTable order by MatchOrder, diff desc, DistributorName

    drop table ##seadist
    drop table ##dist
    drop table ##DistDiffTable


END


GO
------------------------------------------------------------------------------------------------------------------
GO
/****** Object:  StoredProcedure [dbo].[VK_SEARCH_PROD_SERVICE]    Script Date: 03/19/2012 20:28:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[VK_SEARCH_PROD_SERVICE]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[VK_SEARCH_PROD_SERVICE]
GO

/****** Object:  StoredProcedure [dbo].[VK_SEARCH_PROD_SERVICE]    Script Date: 03/19/2012 20:28:48 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*
[VK_SEARCH_PROD_SERVICE]  'Cable','','','','',''

 144632,144631'
*/
/************************************************************************************************************
Updated By    : Deepti Singh
Updated Date  : 27th-Dec-2011
*************************************************************************************************************/
CREATE proc [dbo].[VK_SEARCH_PROD_SERVICE]
(
@PRODUCTNAME VARCHAR(MAX)
,@AttributesIds VARCHAR (100)=''
,@RegionIds VARCHAR (50)=''
,@ZoneIds VARCHAR (50)=''
,@DistributorIDs VARCHAR (100)=''
,@ManufacturerIDs VARCHAR (100)=''
)
AS
BEGIN
    set transaction isolation level read uncommitted
--DECLARE @PRODUCT VARCHAR(MAX),@STARTWITH VARCHAR(MAX),@CONTAINS VARCHAR(MAX),@SQL1 VARCHAR(MAX),@SQL2 VARCHAR(MAX),@SQL VARCHAR(MAX)
DECLARE @STARTWITH VARCHAR(MAX),@CONTAINS VARCHAR(MAX),@SQL1 VARCHAR(MAX),@SQL2 VARCHAR(MAX),@SQL VARCHAR(MAX)
DECLARE @ProdcutIds VARCHAR(MAX)  = ''
Declare @IsEmptyZoneIDs VARCHAR(1) = '0'
--SELECT @PRODUCT=dbo.VK_RemoveSpecialChars(@PRODUCTNAME)

IF(@ZoneIds = '' ) BEGIN SET @IsEmptyZoneIDs = 1 END

SELECT @STARTWITH=SUBSTRING(
(SELECT ('ptype.SearchTypeDescription LIKE '+''''+[items]+'_%'''+' OR ')
FROM Split(@PRODUCTNAME,' ') ORDER BY items FOR XML PATH('')),1,20000)
  ,@CONTAINS=SUBSTRING(
(SELECT ('ptype.SearchTypeDescription LIKE '+'''%'+[items]+'%'''+' OR ')
FROM Split(@PRODUCTNAME,' ') ORDER BY items FOR XML PATH('')),1,20000)

SELECT @SQL1='SELECT DISTINCT  ptype.TypeDescription,ptype.SearchTypeDescription,ptype.ProductTypeId
FROM VK_Vw_ProductType ptype (NOLOCK)
WHERE '+@STARTWITH+''
              +''+@CONTAINS+''
                +' ptype.SearchTypeDescription='''+@PRODUCTNAME+''''
CREATE TABLE #PRODLIST(TypeDescription VARCHAR(100) NULL,SearchTypeDescription  VARCHAR(100) NULL
,ProductTypeId INT NULL)


INSERT INTO #PRODLIST
EXEC (@SQL1)
--PRINT @SQL1
--RETURN
CREATE TABLE #TEMP1(CompanyID INT NULL,OWNERSHIPID VARCHAR(MAX) NULL)
SELECT @SQL2=
'SELECT CompanyID,OWNERSHIPID
FROM
(
SELECT CO.COMPANYID
,OWNERSHIPID=SUBSTRING(
(SELECT ('', ''+[DESCRIPTION]) FROM  dbo.CompanyOwnershipMapping CO1 (NOLOCK)
         JOIN dbo.MstCompanyOwnership O (NOLOCK) ON CO1.OwnershipID=O.OwnershipID
      WHERE CO.CompanyID=CO1.CompanyID ORDER BY CompanyID,CO1.OwnershipID FOR XML PATH('''')),3,20000)

 FROM dbo.CompanyOwnershipMapping CO (NOLOCK)
 JOIN dbo.Company (nolock) ON Company.CompanyID=CO.CompanyID
 JOIN dbo.CompanyProductType CPTYPE (NOLOCK) ON Company.CompanyID=CPTYPE.CompanyID
 JOIN #PRODLIST PL (NOLOCK) ON PL.ProductTypeId=CPTYPE.ProductTypeID
 GROUP BY CO.CompanyID
 UNION
 SELECT CO.COMPANYID
,OWNERSHIPID=SUBSTRING(
(SELECT ('', ''+[DESCRIPTION]) FROM  dbo.CompanyOwnershipMapping CO1 (NOLOCK)
         JOIN dbo.MstCompanyOwnership O (NOLOCK) ON CO1.OwnershipID=O.OwnershipID
      WHERE CO.CompanyID=CO1.CompanyID ORDER BY CompanyID,CO1.OwnershipID FOR XML PATH('''')),3,20000)

 FROM dbo.CompanyOwnershipMapping CO (NOLOCK)
 JOIN dbo.VendorServiceMapping VS(NOLOCK)  ON CO.CompanyID=VS.VendorID
 JOIN #PRODLIST PL (NOLOCK) ON PL.ProductTypeId=VS.ServiceID
 GROUP BY CO.CompanyID
) T1 '
--DROP TABLE #TEMP2
CREATE TABLE #TEMP2(TypeDescription VARCHAR(100) NULL,SearchTypeDescription  VARCHAR(100) NULL,ProductTypeId INT NULL
,CompanyName VARCHAR(100) NULL,CompanyID INT NULL,CompanyTypeID INT NULL,CompanyLogo VARCHAR(100) NULL,OwnershipID VARCHAR(MAX)NULL
,WebVersion VARCHAR(5000) NULL)

INSERT INTO #TEMP1 (CompanyID,OWNERSHIPID)
EXEC (@SQL2)
--PRINT @SQL2
--RETURN
--SELECT * FROM #TEMP2

INSERT  INTO #TEMP2 (TypeDescription,SearchTypeDescription,ProductTypeId
,CompanyName,CompanyID,CompanyTypeID,CompanyLogo ,OwnershipID
,WebVersion )
/*MANUFACTURERS*/
SELECT TypeDescription,SearchTypeDescription,ProductTypeId
,CompanyName,CompanyID,CompanyTypeID,CompanyLogo ,OwnershipID
,WebVersion
FROM
(
SELECT ptype.TypeDescription,ptype.SearchTypeDescription,ptype.ProductTypeId,COMPANY.CompanyName,COMPANY.CompanyID,CTM.CompanyTypeID,COMPANY.CompanyLogo
      ,'0' OwnershipID,NULL WebVersion
FROM #PRODLIST ptype (NOLOCK)
 JOIN dbo.CompanyProductType CPTYPE (NOLOCK) ON CPTYPE.ProductTypeID=PTYPE.ProductTypeId
 JOIN dbo.Company (nolock)  ON Company.CompanyID=CPTYPE.CompanyID
 JOIN dbo.CompanyTypeMapping CTM(NOLOCK) ON CTM.CompanyID=CPTYPE.CompanyID
WHERE CTM.CompanyTypeID=1
--ORDER BY ptype.TypeDescription,CTM.CompanyTypeID,COMPANY.CompanyName

UNION ALL
/*PRODUCTS*/
SELECT ptype.TypeDescription,ptype.SearchTypeDescription,ptype.ProductTypeId,COMPANY.CompanyName,COMPANY.CompanyID,CTM.CompanyTypeID,COMPANY.CompanyLogo
       ,CO.OwnershipID,(select top 1 PRELIST.WebVersion from dbo.PremiumListing PRELIST
       join AdOrder ad on ad.AdOrderId=PRELIST.AdOrderId
       join AdOrderDetailsRegionEdition ad_oder_reg_edit ON  PRELIST.AdOrderDetailsId = ad_oder_reg_edit.AdOrderDetailsId
       AND (ad_oder_reg_edit.RegionID in (select items from dbo.Split(@ZoneIds,',')) OR (@IsEmptyZoneIDs = 1))
       where Company.CompanyID=ad.CompanyId order by PRELIST.PremiumListingID desc )
FROM #PRODLIST ptype (NOLOCK)
 JOIN dbo.CompanyProductType CPTYPE (NOLOCK) ON CPTYPE.ProductTypeID=PTYPE.ProductTypeId
 JOIN dbo.Company (nolock)  ON Company.CompanyID=CPTYPE.CompanyID
 JOIN dbo.CompanyTypeMapping CTM(NOLOCK) ON CTM.CompanyID=CPTYPE.CompanyID
 LEFT JOIN (
                        SELECT  CPTYPE.CompanyID, PRELIST.WebVersion
                        FROM #PRODLIST ptype (NOLOCK)
                            JOIN  dbo.CompanyProductType CPTYPE (NOLOCK)  ON CPTYPE.ProductTypeID=PTYPE.ProductTypeId
                            JOIN dbo.AdOrder (NOLOCK) ON AdOrder.CompanyId=CPTYPE.CompanyID
                            JOIN dbo.AdOrderDetails OD (NOLOCK) ON
                                OD.AdOrderId = AdOrder.AdOrderId
                                and OD.PositionTitle=PTYPE.ProductTypeId
                                AND OD.ActivationDate <= GETDATE() AND GETDATE()<=DATEADD(MM,OD.Duration,OD.ActivationDate)
                            JOIN dbo.PremiumListing PRELIST ON PRELIST.AdOrderDetailsId=OD.AdOrderDetailsId
                     )PRELIST ON PRELIST.CompanyID=Company.CompanyID
 LEFT JOIN #TEMP1 CO (NOLOCK) ON CO.CompanyID=Company.CompanyID
WHERE CTM.CompanyTypeID=2
UNION ALL
/**SERVICES**/
SELECT ptype.TypeDescription,ptype.SearchTypeDescription,ptype.ProductTypeId,COMPANY.CompanyName,COMPANY.CompanyID,CTM.CompanyTypeID,COMPANY.CompanyLogo
      ,CO.OwnershipID,(select top 1 PRELIST.WebVersion from dbo.PremiumListing PRELIST
       join AdOrder ad on ad.AdOrderId=PRELIST.AdOrderId
       join AdOrderDetailsRegionEdition ad_oder_reg_edit ON  PRELIST.AdOrderDetailsId = ad_oder_reg_edit.AdOrderDetailsId
       AND (ad_oder_reg_edit.RegionID in (select items from dbo.Split(@ZoneIds,',')) OR (@IsEmptyZoneIDs = 1))
       where Company.CompanyID=ad.CompanyId order by PRELIST.PremiumListingID desc )
FROM #PRODLIST ptype (NOLOCK)
 JOIN dbo.VendorServiceMapping VS(NOLOCK) ON VS.ServiceID=PTYPE.ProductTypeId
 --JOIN dbo.CompanyProductType CPTYPE (NOLOCK) ON CPTYPE.ProductTypeID=VS.ServiceID --remove it
 JOIN dbo.Company (nolock)  ON Company.CompanyID=VS.VendorID
 JOIN dbo.CompanyTypeMapping CTM(NOLOCK) ON CTM.CompanyID=VS.VendorID
 LEFT JOIN (
                        SELECT  CPTYPE.CompanyID, PRELIST.WebVersion
                        FROM #PRODLIST ptype (NOLOCK)
                            JOIN  dbo.CompanyProductType CPTYPE (NOLOCK)  ON CPTYPE.ProductTypeID=PTYPE.ProductTypeId
                            JOIN dbo.AdOrder (NOLOCK) ON AdOrder.CompanyId=CPTYPE.CompanyID
                            JOIN dbo.AdOrderDetails OD (NOLOCK) ON
                                OD.AdOrderId = AdOrder.AdOrderId
                                and OD.PositionTitle=PTYPE.ProductTypeId
                                AND OD.ActivationDate <= GETDATE() AND GETDATE()<=DATEADD(MM,OD.Duration,OD.ActivationDate)
                            JOIN dbo.PremiumListing PRELIST ON PRELIST.AdOrderDetailsId=OD.AdOrderDetailsId
                     ) PRELIST ON PRELIST.CompanyID=Company.CompanyID
 LEFT JOIN #TEMP1 CO (NOLOCK) ON CO.CompanyID=Company.CompanyID
WHERE CTM.CompanyTypeID=3
) T
ORDER BY TypeDescription,CompanyTypeID,CompanyName

---- Filter based on DistributorId's and manufacturerId's  --------------------------
IF @ManufacturerIDs<>'' AND @DistributorIDs<>''
 BEGIN
  DECLARE @ManuIDs VARCHAR(MAX)=''
  DECLARE @DistIDs VARCHAR(MAX)=''

  SELECT @ManuIDs = SUBSTRING((SELECT DISTINCT '', ','+ISNULL(CONVERT(VARCHAR,tempTbl.ProductTypeId),'')
  FROM #TEMP2 tempTbl
   INNER JOIN Split(@ManufacturerIDs,',') spManu
   ON spManu.items = tempTbl.CompanyID
  WHERE tempTbl.CompanyTypeID='1'
   FOR XML PATH ('')),2,20000)

  SELECT @DistIDs = SUBSTRING((SELECT DISTINCT '', ','+ISNULL(CONVERT(VARCHAR,tempTbl.ProductTypeId),'')
  FROM #TEMP2 tempTbl
   INNER JOIN Split(@DistributorIDs,',') spDist
   ON spDist.items = tempTbl.CompanyID
  WHERE tempTbl.CompanyTypeID IN (2,3)
   FOR XML PATH ('')),2,20000)

  SELECT @ProdcutIds=SUBSTRING((SELECT ','+CONVERT(VARCHAR,spM.items) FROM Split(@ManuIDs,',') spM
   INNER JOIN Split(@DistIDs,',') spD
   ON spM.items=spD.items FOR XML PATH('')),2,20000)

  SELECT @ProdcutIds = ISNULL(@ProdcutIds,'0')
 END
ELSE
 BEGIN
  IF @ManufacturerIDs<>''
   BEGIN
    SELECT @ProdcutIds = SUBSTRING((SELECT DISTINCT '', ','+ISNULL(CONVERT(VARCHAR,tempTbl.ProductTypeId),'')
    FROM #TEMP2 tempTbl
     INNER JOIN Split(@ManufacturerIDs,',') spManu
     ON spManu.items = tempTbl.CompanyID
    WHERE tempTbl.CompanyTypeID='1'
     FOR XML PATH ('')),2,20000)
   END
  ELSE
   BEGIN
    IF @DistributorIDs<>''
     BEGIN
      SELECT @ProdcutIds = SUBSTRING((SELECT DISTINCT '', ','+ISNULL(CONVERT(VARCHAR,tempTbl.ProductTypeId),'')
      FROM #TEMP2 tempTbl
       INNER JOIN Split(@DistributorIDs,',') spDist
       ON spDist.items = tempTbl.CompanyID
      WHERE tempTbl.CompanyTypeID IN (2,3)
       FOR XML PATH ('')),2,20000)
     END
   END
 END
Select @ProdcutIds = ISNULL(@ProdcutIds,'')
--------------------    END of filter   ------------------------------


IF(@AttributesIds ='')
BEGIN
SELECT @SQL='SELECT DISTINCT TypeDescription,ptype.ProductTypeId,CompanyName,PTYPE.CompanyID,PTYPE.CompanyTypeID,CompanyLogo ,PTYPE.OwnershipID
,WebVersion, 1 AS MatchOrder FROM #TEMP2 PTYPE WHERE SearchTypeDescription='+''''+@PRODUCTNAME+'''
AND (dbo.ufn_DS_Get_IsDistributorRegion(PTYPE.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''') '
+ CASE WHEN @ProdcutIds<>'' THEN 'AND PTYPE.ProductTypeId IN ('+(SELECT @ProdcutIds)+')' ELSE '' END
+' AND PTYPE.CompanyTypeID IN (1,2,3) '

+ 'UNION ALL

SELECT DISTINCT TypeDescription,ptype.ProductTypeId,CompanyName,CompanyID,PTYPE.CompanyTypeID,CompanyLogo ,PTYPE.OwnershipID
,WebVersion, 2 AS MatchOrder FROM #TEMP2 PTYPE  WHERE ('+@STARTWITH+''+ '1=0' +') AND (SearchTypeDescription<>'+''''+@PRODUCTNAME+''')
AND (dbo.ufn_DS_Get_IsDistributorRegion(PTYPE.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''')'
 + CASE WHEN @ProdcutIds<>'' THEN 'AND PTYPE.ProductTypeId IN ('+(SELECT @ProdcutIds)+')' ELSE '' END
+' AND PTYPE.CompanyTypeID IN (1,2,3) '

+ 'UNION ALL

SELECT DISTINCT TypeDescription,ptype.ProductTypeId,CompanyName,PTYPE.CompanyID,CompanyTypeID,CompanyLogo ,PTYPE.OwnershipID
,WebVersion, 2 AS MatchOrder FROM #TEMP2 PTYPE WHERE ('+@CONTAINS+''+ '1=0' +') AND (SearchTypeDescription<>'+''''+@PRODUCTNAME+''')
AND ptype.ProductTypeId NOT IN(SELECT ptype.ProductTypeId FROM #TEMP2 PTYPE
WHERE ('+@STARTWITH+''+ '1=0' +') AND (SearchTypeDescription<>'+''''+@PRODUCTNAME+'''))
AND (dbo.ufn_DS_Get_IsDistributorRegion(PTYPE.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''') '
 + CASE WHEN @ProdcutIds<>'' THEN 'AND PTYPE.ProductTypeId IN ('+(SELECT @ProdcutIds)+')' ELSE '' END
+' AND PTYPE.CompanyTypeID IN (1,2,3) '
END
ELSE
BEGIN
SELECT @SQL='SELECT DISTINCT TypeDescription,ptype.ProductTypeId,CompanyName,PTYPE.CompanyID,CompanyTypeID,CompanyLogo ,PTYPE.OwnershipID
    ,WebVersion, 1 AS MatchOrder
   FROM #TEMP2 PTYPE
   JOIN dbo.CompanyOwnershipMapping CO1 (NOLOCK) ON CO1.CompanyID = PTYPE.CompanyID
   OR (CONVERT(VARCHAR,ISNULL(PTYPE.OwnershipID,''0'')) = ''0'' AND CompanyTypeID IN (1,3))
   JOIN (SELECT * FROM dbo.Split('''+@AttributesIds+''','','')) as Attributes
    ON CO1.OwnershipID = Attributes.items
   WHERE SearchTypeDescription='+''''+@PRODUCTNAME+'''
   AND (dbo.ufn_DS_Get_IsDistributorRegion(PTYPE.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''')'
 + CASE WHEN @ProdcutIds<>'' THEN 'AND PTYPE.ProductTypeId IN ('+(SELECT @ProdcutIds)+')' ELSE '' END
+' AND PTYPE.CompanyTypeID IN (1,2,3) '
+ 'UNION ALL

SELECT DISTINCT TypeDescription,ptype.ProductTypeId,CompanyName,PTYPE.CompanyID,CompanyTypeID,CompanyLogo ,PTYPE.OwnershipID
,WebVersion, 2 AS MatchOrder
FROM #TEMP2 PTYPE
 JOIN dbo.CompanyOwnershipMapping CO1 (NOLOCK) ON CO1.CompanyID = PTYPE.CompanyID  OR (CONVERT(VARCHAR,ISNULL(PTYPE.OwnershipID,''0'')) = ''0'' AND CompanyTypeID IN (1,3))
   JOIN (SELECT * FROM dbo.Split('''+@AttributesIds+''','','')) as Attributes
    ON CO1.OwnershipID = Attributes.items
WHERE ('+@STARTWITH+''+ '1=0' +') AND (SearchTypeDescription<>'+''''+@PRODUCTNAME+''')
AND (dbo.ufn_DS_Get_IsDistributorRegion(PTYPE.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''') '
 + CASE WHEN @ProdcutIds<>'' THEN 'AND PTYPE.ProductTypeId IN ('+(SELECT @ProdcutIds)+')' ELSE '' END
+' AND PTYPE.CompanyTypeID IN (1,2,3) '
+ 'UNION ALL

SELECT DISTINCT TypeDescription,ptype.ProductTypeId,CompanyName,PTYPE.CompanyID,CompanyTypeID,CompanyLogo ,PTYPE.OwnershipID
,WebVersion, 2 AS MatchOrder
FROM #TEMP2 PTYPE
 JOIN dbo.CompanyOwnershipMapping CO1 (NOLOCK) ON CO1.CompanyID = PTYPE.CompanyID  OR (CONVERT(VARCHAR,ISNULL(PTYPE.OwnershipID,''0'')) = ''0'' AND CompanyTypeID IN (1,3))
   JOIN (SELECT * FROM dbo.Split('''+@AttributesIds+''','','')) as Attributes
    ON CO1.OwnershipID = Attributes.items
WHERE ('+@CONTAINS+''+ '1=0' +') AND (SearchTypeDescription<>'+''''+@PRODUCTNAME+''')
AND ptype.ProductTypeId NOT IN(SELECT ptype.ProductTypeId FROM #TEMP2 PTYPE  WHERE ('+@STARTWITH+''+ '1=0' +')
AND (SearchTypeDescription<>'+''''+@PRODUCTNAME+'''))
AND (dbo.ufn_DS_Get_IsDistributorRegion(PTYPE.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''') '
 + CASE WHEN @ProdcutIds<>'' THEN 'AND PTYPE.ProductTypeId IN ('+(SELECT @ProdcutIds)+')' ELSE '' END
+' AND PTYPE.CompanyTypeID IN (1,2,3) '
END
EXEC (@SQL)
--PRINT @SQL
--select * from #PRODLIST where ProductTypeId=276
DROP TABLE #PRODLIST
DROP TABLE #TEMP1
DROP TABLE #TEMP2

END

GO
------------------------------------------------------------------------------------------------------------------
GO
/****** Object:  StoredProcedure [dbo].[usp_ViewProofDetails]    Script Date: 03/19/2012 20:08:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_ViewProofDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_ViewProofDetails]
GO

/****** Object:  StoredProcedure [dbo].[usp_ViewProofDetails]    Script Date: 03/19/2012 20:08:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--*****************************************************************************************************
--*   Modification        : To exclude items that has Adjob folder flag false / 0
--*   Author            : Kiran Sangoi
--*   Modify Date        : Mar/12/2012
--*****************************************************************************************************
-- [dbo].[usp_ViewProofDetails] 172,'Jann Electronics','December 1 2011'
-- A B & C1 Components   Digital Telecom
-- usp_ViewProofDetails   22,'A B & C1 Components','August 2011'
/*
exec usp_ViewProofDetails @OrderId=379748,@CompanyName='Digi-Key',@date='March 21 2012'
*/

CREATE Procedure [dbo].[usp_ViewProofDetails]
@OrderId Int,
@CompanyName Varchar(1000),
@date varchar(50)

AS

BEGIN
set transaction isolation level read uncommitted
Select  distinct
    OD.AdOrderDetailsId,
    SlsSzeTpe.Description as DescriptionHead,
    SST.Description,
    dbo.GetSalesOrderRegion(OD.AdOrderDetailsId,'O')  as ZoneName,
    OD.SectionId,
    SST.SectionCode,
    Compny.CompanyName AS CompanyName,
    chk.[FileName],
    (dbo.GetPositionTitle(OD.PositionTitle,OD.SectionID)+ ':' + ISNULL(PL.WebVersion,'')) AS SizeSectionPosition,
    (SELECT CompanyLogo FROM Company WHERE CompanyID=OD.PositionTitle AND SlsSzeTpe.SizeCodeName = 'p') as CompanyLogo
 From
    AdOrder AO INNER JOIN Company Compny on  AO.CompanyId=Compny.CompanyId
    INNER JOIN AdOrderDetails OD on AO.AdOrderId=OD.AdOrderId
    INNER JOIN AdDetails ADT ON ADT.AdTypeID = OD.AdTypeID AND ADT.AdjodFlag = 1
    INNER JOIN SalesSizeType SlsSzeTpe on SlsSzeTpe.SizeTypeId=OD.SizeTypeId
    LEFT OUTER JOIN AdOrderDetailsRegionEdition AdOrdrDtlsRegnEdn on  OD.AdOrderDetailsId = AdOrdrDtlsRegnEdn.AdOrderDetailsId
    LEFT JOIN CountryZones CntryZns on AdOrdrDtlsRegnEdn.RegionId = CntryZns.ZoneId
    INNER JOIN SalesSectionType SST on OD.SectionId=SST.SectionId
    LEFT JOIN ChkInChkOutArtWrkFiles chk on OD.AdOrderDetailsId = chk.AdId
    LEFT JOIN  PremiumListing PL ON OD.AdOrderDetailsId=PL.AdOrderDetailsId
 Where OD.AdOrderId = @OrderId
    and Compny.CompanyName =  @CompanyName and OD.OrderType = 'O'
    AND DATENAME(MM, OD.ActivationDate) + ' ' + CAST(DAY(OD.ActivationDate)AS  VARCHAR(2)) + ' ' + CAST(YEAR(OD.Activationdate) AS VARCHAR(4))=@date
 Group By SlsSzeTpe.Description,SST.Description
    ,CntryZns.ZoneName,OD.AdOrderDetailsId,OD.SectionId,SST.SectionCode,Compny.CompanyName
    ,chk.[FileName],OD.PositionTitle,PL.WebVersion,SlsSzeTpe.SizeCodeName
 Order by OD.AdOrderDetailsId ASC
END



GO
------------------------------------------------------------------------------------------------------------------

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_getRegionbyUser]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_getRegionbyUser]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- Created By : Fathima
-- Created On : 27-12-2011
-- Purpose : Get Region by passing user
-- Sample : usp_getRegionbyUser 24
CREATE proc [dbo].[usp_getRegionbyUser](@UserID int)
as
 select R.RegionID,U.Zip from Region R, Country C, UserContact U
 where U.CountryID = c.CountryID and c.RegionID = r.RegionID
 and u.UserID = @UserID


GO

------------------------------------------------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetRegionByZipcode]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetRegionByZipcode]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Author : Fathima
-- CreatedOn : 29-12-2011
-- Description : Getting region by passwing zipcode
-- Tables Used: Zipcode,Country
-- Arguments :@Zip
-- Returns  : Recordset
-- sample  : usp_GetRegionByZipcode 'a'
-------------------------------------------------------------------
CREATE procedure [dbo].[usp_GetRegionByZipcode] --'10'
(@Zip varchar(50))
as
Begin
set transaction isolation level read uncommitted
SELECT * from Zipcode z,country c,region r where z.CountryID=c.CountryID and c.RegionID = r.RegionID
AND z.ZipFrom COLLATE DATABASE_DEFAULT <= @Zip AND z.ZipTo COLLATE DATABASE_DEFAULT >= @Zip AND z.IsActive = 1
End

GO

------------------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[USP_Load_intoDistributorPartSearch]    Script Date: 03/27/2012 10:41:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_Load_intoDistributorPartSearch]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[USP_Load_intoDistributorPartSearch]
GO

/****** Object:  StoredProcedure [dbo].[USP_Load_intoDistributorPartSearch]    Script Date: 03/27/2012 10:41:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE Procedure [dbo].[USP_Load_intoDistributorPartSearch]
------------------------------Created By: Nirav Parikh------------------------
------------------------------Date ON: December 28, 2011----------------------
-------------IF AnyBody Make Changes In this 'USP' Then Please Do it Both the Set in (IF) as well as (Else)--------------

As
Set NoCount ON;
-------------------IF Logic for Create DistributorPartsSearch2 and truncate DistributorPartsSearch1--------------
IF (Select A From DPS_Swap) = 0
-------------IF AnyBody Make Changes In this 'USP' Then Please Do it Both the Set in (IF) as well as (Else)--------------
    Begin
        Insert Into DistributorPartsSearch1
        Select   ISNULL(Dist.DistID , 0) as DistributorId
                ,C.CompanyName as DistributorName
                ,C.Clean_CompanyName as Search_Dist_Name
                ,C.CompanyLogo As DistLogo
                ,ISNULL(Dist.PartNumber, '') as PartNumber
                ,dbo.VK_RemoveSpecialChars(Dist.PartNumber) as Search_PartNumber
                ,Dist.ManufacturerCode
                ,ISNULL(MFRC.ManufacturerId , 0) as ManufacturerId
                ,ISNULL(C1. CompanyName, 'zzunknown') as ManufacturerName
                ,C1.Clean_CompanyName as Search_MFR_Name
                ,C1.CompanyLogo As CompanyLogo
                ,Dist.PartUploadDate
                ,P.ProductID as ProductId
                ,P.Description as PartDescription
                ,Dist.PartQuantity
                ,InS.QOHDisp
                ,Dist.Price
                ,PartDataSheet = Case When P.DataSheet IS NULL Then Ins.MafSpecTitle Else P.DataSheetTitle End
                ,DatasheetLink = Case When P.DataSheet IS NULL Then Ins1.MafSpecURL Else P.DataSheet End
                ,P.SampleUrl as PartSample
                ,P.VideoFilePath as VideoFilePathLink
                ,P.ImageFilePath as ImageFilePathLink
                ,Ins.DoNotPub
                ,ISNULL(PT.ProductTypeId, 0) as ProductTypeId
                ,ISNULL(PT.TypeDescription, '') AS ProductTypeDesc
                ,ISNULL(Ins.RFQCPID, 0) as RFQCPID
                ,Buy_Button = Case    When Ins.BuyPentonExpire >= getdate()
                                    and Ins.BuyPentonURL1 IS Not Null and Ins.BuyPentonURL1 <>'' Then 1 Else 0 End
                ,Dist.DistrbutorPartID

        From
                (select  DistID
                        ,ManufacturerCode
                        ,PartNumber
                        ,MAX(Uploaded) as PartUploadDate
                        ,SUM(QtyOnHand) as PartQuantity
                        ,MAX(Price) As Price
                        ,MAX(InvID) As DistrbutorPartID
                  From DistributorParts
                  Group By DistID,ManufacturerCode,PartNumber
                 ) Dist
            Join InventorySettings Ins
                ON --Dist.Status = 'Active' and
                Ins.DoNotPub = 0 and Dist.DistID = Ins.CompanyID
            Join Company C
                ON C.isActive = 1 and C.companystatusid = 1 and Dist.DistID = C.CompanyID
            Left Join ManufacturerCode_XRF MFRC
                ON Dist.DistID = MFRC.DistributorId and dist.ManufacturerCode = MFRC.ManufacturerCode
            Left Join Company C1
                ON C1.IsActive =1 and MFRC.ManufacturerId = C1.CompanyID
            Left Join Product P
                ON  P.IsActive = 1 AND
                Dist.PartNumber = P.PartNumber and MFRC.ManufacturerId = P.ManufacturerID
            Left Join productType_XRF PT_X
                ON P.ManufacturerID = PT_X.ManufacturerID and P.ProductType = PT_X.MfrProdTypeCode
            Left Join ProductType PT
                ON PT.IsActive = 1 and PT_X.ProductTypeID = PT.ProductTypeId
            Left Join InventorySettings Ins1
                ON P.ManufacturerID = Ins1.CompanyID
        ORDER BY PartNumber, ManufacturerName, DistributorName;
        --------------Update A of Table DPS_Swap----------------
        Update DPS_Swap Set A = 1;
        --------------Truncate DistributorPartsSearch2----------
        Truncate Table DistributorPartsSearch2;
    End
-------------------Else Logic for Create DistributorPartsSearch1 and truncate DistributorPartsSearch2--------------
-------------IF AnyBody Make Changes In this 'USP' Then Please Do it Both the Set in (IF) as well as (Else)--------------
Else
    Begin

        Insert Into DistributorPartsSearch2
        Select   ISNULL(Dist.DistID , 0) as DistributorId
                ,C.CompanyName as DistributorName
                ,C.Clean_CompanyName as Search_Dist_Name
                ,C.CompanyLogo As DistLogo
                ,ISNULL(Dist.PartNumber, '') as PartNumber
                ,dbo.VK_RemoveSpecialChars(Dist.PartNumber) as Search_PartNumber
                ,Dist.ManufacturerCode
                ,ISNULL(MFRC.ManufacturerId , 0) as ManufacturerId
                ,ISNULL(C1. CompanyName, 'zzunknown') as ManufacturerName
                ,C1.Clean_CompanyName as Search_MFR_Name
                ,C1.CompanyLogo As CompanyLogo
                ,Dist.PartUploadDate
                ,P.ProductID as ProductId
                ,P.Description as PartDescription
                ,Dist.PartQuantity
                ,InS.QOHDisp
                ,Dist.Price
                ,PartDataSheet = Case When P.DataSheet IS NULL Then Ins.MafSpecTitle Else P.DataSheetTitle End
                ,DatasheetLink = Case When P.DataSheet IS NULL Then Ins1.MafSpecURL Else P.DataSheet End
                ,P.SampleUrl as PartSample
                ,P.VideoFilePath as VideoFilePathLink
                ,P.ImageFilePath as ImageFilePathLink
                ,Ins.DoNotPub
                ,ISNULL(PT.ProductTypeId, 0) as ProductTypeId
                ,ISNULL(PT.TypeDescription, '') AS ProductTypeDesc
                ,ISNULL(Ins.RFQCPID, 0) as RFQCPID
                ,Buy_Button = Case    When Ins.BuyPentonExpire >= getdate()
                                    and Ins.BuyPentonURL1 IS Not Null and Ins.BuyPentonURL1 <>'' Then 1 Else 0 End
                ,Dist.DistrbutorPartID

        From
                (select  DistID
                        ,ManufacturerCode
                        ,PartNumber
                        ,max(Uploaded) as PartUploadDate
                        ,sum(QtyOnHand) as PartQuantity
                        ,MAX(Price) As Price
                        ,MAX(InvID) As DistrbutorPartID
                  From DistributorParts
                  Group By DistID,ManufacturerCode,PartNumber
                 ) Dist
            Join InventorySettings Ins
                ON --Dist.Status = 'Active' and
                Ins.DoNotPub = 0 and Dist.DistID = Ins.CompanyID
            Join Company C
                ON C.isActive = 1 and C.companystatusid = 1 and Dist.DistID = C.CompanyID
            Left Join ManufacturerCode_XRF MFRC
                ON Dist.DistID = MFRC.DistributorId and dist.ManufacturerCode = MFRC.ManufacturerCode
            Left Join Company C1
                ON C1.IsActive =1 and MFRC.ManufacturerId = C1.CompanyID
            Left Join Product P
                 ON P.IsActive = 1 AND
                 Dist.PartNumber = P.PartNumber and MFRC.ManufacturerId = P.ManufacturerID
            Left Join productType_XRF PT_X
                ON P.ManufacturerID = PT_X.ManufacturerID and P.ProductType = PT_X.MfrProdTypeCode
            Left Join ProductType PT
                ON PT.IsActive = 1 and PT_X.ProductTypeID = PT.ProductTypeId
            Left Join InventorySettings Ins1
                ON P.ManufacturerID = Ins1.CompanyID
        ORDER BY PartNumber, ManufacturerName, DistributorName;
        --------------Update A of Table DPS_Swap----------------
        Update DPS_Swap Set A = 0;
        --------------Truncate DistributorPartsSearch2----------
        Truncate Table DistributorPartsSearch1;
    End
-------------IF AnyBody Make Changes In this 'USP' Then Please Do it Both the Set in (IF) as well as (Else)--------------
Set NoCount OFF;
-----------------------------------------END-------------------------

------------------Information about tables:----------------------
----DistributorParts AS Dist
----InventorySettings AS Ins
----Company AS C
----ManufacturerCode_XRF AS MFRC
----Company AS C1
----Product AS p
----ProductType AS pt
----ProductType_XRF AS PT_X
----ProductResources AS PR
----InventorySettings AS Ins1

GO
------------------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[USP_PartSearch]    Script Date: 02/07/2012 16:26:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_PartSearch]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[USP_PartSearch]

GO

/****** Object:  StoredProcedure [dbo].[USP_PartSearch]    Script Date: 02/07/2012 16:26:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
exec USP_PartSearch @SearchText='a10',@AttributeIds='',@RegionIds='',@UserID=-1,@HasDesignRes=0,@IsAuth=0,@MFRIDs='',@DistIDs='',@ProdTypeIDs='',@PriceMin=-1,@PriceMax=-1,@QTYMin=-1,@QTYMax=-1,@IsFilterByRegion=0

NP_USP_PartSearch_WIP @SearchText='a10',@AttributeIds='',@RegionIds='',@UserID=-1,@HasDesignRes=0,@IsAuth=0,@MFRIDs='',@DistIDs='',@ProdTypeIDs='',@PriceMin=-1,@PriceMax=-1,@QTYMin=94,@QTYMax=-1,@IsFilterByRegion=0
*/


CREATE Procedure [dbo].[USP_PartSearch]
(
                -------------Created By: Nirav Parikh/Mohit Garg--------------
                -------------------Date: December 26,2011----------------
-------------IF AnyBody Make Changes In this 'USP' Then Please Do it Both the Set in (IF) as well as (Else)--------------
@SearchText Varchar(8000)
,@RegionIDs Varchar(100)
,@IsAuth bit
,@MFRIDs Varchar(1000)
,@DistIDs Varchar(1000)
,@ProdTypeIDs Varchar(1000)
,@PriceMin decimal(10,2)
,@PriceMax Decimal(10,2)
,@QTYMin Int
,@QTYMax Int
,@HasDesignRes bit
,@AttributeIDs Varchar(400)
,@UserID Int
,@IsFilterByRegion bit
)
AS
Set NoCount ON
    set transaction isolation level read uncommitted
Declare @IsEmptyRegionIDs VARCHAR(1) = '0'
Declare @IsEmptyMFRIDs VARCHAR(1) = '0'
Declare @IsEmptyDistIDs VARCHAR(1) = '0'
Declare @IsEmptyProdTypeIDs VARCHAR(1) = '0'
Declare @IsEmptyAttributeIDs VARCHAR(1) = '0'


IF(@RegionIDs='') BEGIN SET @IsEmptyRegionIDs = 1 END
IF(@MFRIDs='') BEGIN SET @IsEmptyMFRIDs = 1 END
IF(@DistIDs='') BEGIN SET @IsEmptyDistIDs = 1 END
IF(@ProdTypeIDs='') BEGIN SET @IsEmptyProdTypeIDs = 1 END
IF(@AttributeIDs='') BEGIN SET @IsEmptyAttributeIDs = 1 END


SET @RegionIDs = '' + REPLACE(@RegionIDs,',',''',''') + ''
SET @MFRIDs = '' + REPLACE(@MFRIDs,',',''',''') + ''
SET @DistIDs = '' + REPLACE(@DistIDs,',',''',''') + ''
SET @ProdTypeIDs = '' + REPLACE(@ProdTypeIDs,',',''',''') + ''
SET @AttributeIDs = '' + REPLACE(@AttributeIDs,',',''',''') + ''



Declare @SQL1 varChar(8000)

------------------------------IF When A = 0, USE Table DistributorPartsSearch2--------------------------
IF(Select A from DPS_Swap) = 0
Begin
-------------IF AnyBody Make Changes In this 'USP' Then Please Do it Both the Set in (IF) as well as (Else)--------------
    SET @SQL1 =
    'Select        DISTINCT
                     DPS.ProductID As ProductID
                    ,DPS.PartNumber
                    ,DPS.ManufacturerName
                    ,DPS.ManufacturerId
                    ,DPS.DistributorName
                    ,DPS.DistributorId
                    ,DPS.PartDescription AS ColumnDescription
                    ,DPS.ManufacturerCode As DistManufacturerCode
                    ,DPS.Price AS PartPrice
                    ,ISNULL(DPS.PartQuantity,0) AS PartQuantity
                    ,ISNULL(DPS.QOHDisp,'''')  AS QOHDisp
                    ,DPS.PartUploadDate -- AS SolrUpdatedOn
                    ,DPS.PartDataSheet
                    ,DPS.DatasheetLink
                    ,DPS.PartSample
                    ,DPS.VideoFilePathLink
                    ,DPS.ImageFilePathLink
                    ,DPS.ProductTypeId
                    ,DPS.ProductTypeDesc as ProductType
                    ,DPS.RFQCPID
                    ,DPS.Buy_Button
                    ,DPS.DistrbutorPartID
                    ,ISNULL(SUBSTRING( (SELECT '', '' + PR.ProductResourcesTitle from ProductResources PR (NOLOCK)
                        where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1
                        and PR.ResourcesType = ''APP'' for XML Path ('''')),3, 2000),'''') as PartAppNotes

                    ,ISNULL(SUBSTRING( (SELECT '', '' + PR.ProductResourcesLink from ProductResources PR (NOLOCK)
                        where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1
                        and PR.ResourcesType = ''APP'' for XML Path ('''')),3, 2000),'''') as PartAppNotesLink

                    ,ISNULL(SUBSTRING( (SELECT '', '' + PR.ProductResourcesTitle from ProductResources PR (NOLOCK)
                        where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1
                        and PR.ResourcesType = ''Soft'' for XML Path ('''')),3, 2000),'''') as PartSoftTool

                    ,ISNULL(SUBSTRING( (SELECT '', '' + PR.ProductResourcesLink from ProductResources PR (NOLOCK)
                        where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1
                        and PR.ResourcesType = ''Soft'' for XML Path ('''')),3, 2000),'''') as PartSoftToolLink
                    ,UF.FavType As SolrMyFav
                    ,ISNULL(UF.UserID, 0) as UserID
                    ,DistAuthStatus = CASE WHEN RZS.MaxAuth = 4 then 1 ELSE 0 END
                    ,RZS.Total
                    ,DistLogo = Case When DPS.DistLogo IS null Then '''' Else DPS.DistLogo End
                    ,DPS.CompanyLogo As CompanyLogo
                    ,SUBSTRING( (SELECT '', '' + OWN.Description from MstCompanyOwnership OWN,
                        CompanyOwnershipMapping COM where COM.CompanyID = DPS.DistributorId
                        and COM.OwnershipID = OWN.OwnershipID for XML Path ('''')),3, 500) as CompanyOwn
                    ,MatchOrder =    CASE    WHEN DPS.Search_PartNumber LIKE search_term.items THEN 1
                                            WHEN DPS.Search_PartNumber LIKE search_term.items + ''_%'' THEN 2
                                            WHEN DPS.Search_PartNumber LIKE ''_%'' + search_term.items + ''%'' THEN 3
                                            WHEN DPS.Search_MFR_Name LIKE search_term.items THEN 4
                                            WHEN DPS.Search_MFR_Name LIKE search_term.items + ''_%'' THEN 5
                                            WHEN DPS.Search_MFR_Name LIKE ''_%'' + search_term.items + ''%'' THEN 6 END

    From
            (SELECT * FROM Split('''+@SearchText+''','' '')) AS search_term
            JOIN
            DistributorPartsSearch2 DPS (NOLOCK)
                ON    ((DPS.Search_PartNumber LIKE ''%'' + search_term.items + ''%''
                    or DPS.Search_MFR_Name LIKE ''%'' + search_term.items + ''%'')
                    and (DPS.Price >= '+CONVERT(VARCHAR(30),@PriceMin)+' or '+CONVERT(VARCHAR(30),@PriceMin)+' = -1)
                    and (DPS.Price <= '+CONVERT(VARCHAR(30),@PriceMax)+' or '+CONVERT(VARCHAR(30),@PriceMax)+' = -1)
                    and (CONVERT(FLOAT,PartQuantity) >= '+CONVERT(VARCHAR(30),@QTYMin)+' or QOHDisp != ''Actual'' or '+CONVERT(VARCHAR(30),@QTYMin)+' = -1)
                    and (CONVERT(FLOAT,PartQuantity) <= '+CONVERT(VARCHAR(30),@QTYMax)+' or QOHDisp != ''Actual'' or '+CONVERT(VARCHAR(30),@QTYMax)+' = -1))
                    and (DPS.ManufacturerId IN ('''+@MFRIDs+''') OR '+@IsEmptyMFRIDs+' = 1)
                    and (DPS.DistributorID IN ('''+@DistIDs+''') OR '+@IsEmptyDistIDs+' = 1)
                    and (DPS.ProductTypeId IN ('''+@ProdTypeIDs+''') OR '+@IsEmptyProdTypeIDs+' = 1)

            Left Join RegionAuthorization RA (NOLOCK)
                ON RA.IsActive = 1 and DPS.DistributorId = RA.DistID and DPS.ManufacturerId = RA.MfrID
            Left Join (    Select     MFRDistID
                                ,MAX(AuthStatusID) as MaxAuth
                                ,SUM(Print_Amount) As T_PA
                                ,SUM(Online_Amount) AS T_OA
                                ,sum(Print_Amount+Online_Amount) as Total
                                ,Count(*) As N_Rows From RegionZoneStatus (NOLOCK)
                        WHERE    (RegionID IN ('''+@RegionIDs+''') OR '+@IsEmptyRegionIDs+' = 1)
                        group By MfrDistID)    as RZS
                ON RA.MfrDistID = RZS.MfrDistID
            Left Join CompanyOwnerShipMapping COM1 (NOLOCK)
                ON DPS.DistributorId = COM1.CompanyID and (Com1.OwnershipID IN ('''+@AttributeIDs+''') OR '+@IsEmptyAttributeIDs+' = 1)
            Left Join UserFavorites UF (NOLOCK)
                ON UF.FavType = 3 and DPS.ProductId = UF.TypeID
                    and (UF.UserID = '+CONVERT(VARCHAR(30),@UserID)+' OR '+CONVERT(VARCHAR(30),@UserID)+' = -1)

    Where    (('+CONVERT(VARCHAR(1),@IsAuth)+' = 0 and '+CONVERT(VARCHAR(1),@IsFilterByRegion)+' = 0)
             OR('+CONVERT(VARCHAR(1),@IsAuth)+' = 0 AND '+CONVERT(VARCHAR(1),@IsFilterByRegion)+' = 1
                And (MaxAuth = 4 or Total > 0
                    or (Select    1
                        From CompanyLocations CL, Country C
                        where
                            (C.RegionID IN ('''+@RegionIDs+''') OR '+@IsEmptyRegionIDs+' = 1)
                            and
                            LocationStatusID = 1 and CL.IsActive = 1
                            and C.CountryID = CL.CountryID
                            and DPS.DistributorId = CL.CompanyID
                        group by CompanyID) = 1))
                OR('+CONVERT(VARCHAR(1),@IsAuth)+' = 1 and MaxAuth = 4))


    Order By MatchOrder, PartNumber, ManufacturerName, DistAuthStatus DESC, Total DESC, DistributorName'
Execute  (@SQL1);


End
------------------------------Else When A = 1, USE Table DistributorPartsSearch1--------------------------
-------------IF AnyBody Make Changes In this 'USP' Then Please Do it Both the Set in (IF) as well as (Else)--------------

Else
Begin
    SET @SQL1 =
    'Select         DISTINCT
                     DPS.ProductID As ProductID
                    ,DPS.PartNumber
                    ,DPS.ManufacturerName
                    ,DPS.ManufacturerId
                    ,DPS.DistributorName
                    ,DPS.DistributorId
                    ,DPS.PartDescription AS ColumnDescription
                    ,DPS.ManufacturerCode As DistManufacturerCode
                    ,DPS.Price AS PartPrice
                    ,ISNULL(DPS.PartQuantity,0) AS PartQuantity
                    ,ISNULL(DPS.QOHDisp,'''')  AS QOHDisp
                    ,DPS.PartUploadDate --  AS SolrUpdatedOn
                    ,DPS.PartDataSheet
                    ,DPS.DatasheetLink
                    ,DPS.PartSample
                    ,DPS.VideoFilePathLink
                    ,DPS.ImageFilePathLink
                    ,DPS.ProductTypeId
                    ,DPS.ProductTypeDesc as ProductType
                    ,DPS.RFQCPID
                    ,DPS.Buy_Button
                    ,DPS.DistrbutorPartID
                    ,ISNULL(SUBSTRING( (SELECT '', '' + PR.ProductResourcesTitle from ProductResources PR (NOLOCK)
                        where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1
                        and PR.ResourcesType = ''APP'' for XML Path ('''')),3, 2000),'''') as PartAppNotes

                    ,ISNULL(SUBSTRING( (SELECT '', '' + PR.ProductResourcesLink from ProductResources PR (NOLOCK)
                        where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1
                        and PR.ResourcesType = ''APP'' for XML Path ('''')),3, 2000),'''') as PartAppNotesLink

                    ,ISNULL(SUBSTRING( (SELECT '', '' + PR.ProductResourcesTitle from ProductResources PR (NOLOCK)
                        where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1
                        and PR.ResourcesType = ''Soft'' for XML Path ('''')),3, 2000),'''') as PartSoftTool

                    ,ISNULL(SUBSTRING( (SELECT '', '' + PR.ProductResourcesLink from ProductResources PR (NOLOCK)
                        where PR.ProductId = DPS.PRODUCTID AND PR.IsActive = 1
                        and PR.ResourcesType = ''Soft'' for XML Path ('''')),3, 2000),'''') as PartSoftToolLink
                    ,UF.FavType As SolrMyFav
                    ,ISNULL(UF.UserID, 0) as UserID
                    ,DistAuthStatus = CASE WHEN RZS.MaxAuth = 4 then 1 ELSE 0 END
                    ,RZS.Total
                    ,DistLogo = Case When DPS.DistLogo IS null Then '''' Else DPS.DistLogo End
                    ,DPS.CompanyLogo As CompanyLogo
                    ,SUBSTRING( (SELECT '', '' + OWN.Description from MstCompanyOwnership OWN,
                        CompanyOwnershipMapping COM where COM.CompanyID = DPS.DistributorId
                        and COM.OwnershipID = OWN.OwnershipID for XML Path ('''')),3, 500) as CompanyOwn
                    ,MatchOrder =    CASE    WHEN DPS.Search_PartNumber LIKE search_term.items THEN 1
                                            WHEN DPS.Search_PartNumber LIKE search_term.items + ''_%'' THEN 2
                                            WHEN DPS.Search_PartNumber LIKE ''_%'' + search_term.items + ''%'' THEN 3
                                            WHEN DPS.Search_MFR_Name LIKE search_term.items THEN 4
                                            WHEN DPS.Search_MFR_Name LIKE search_term.items + ''_%'' THEN 5
                                            WHEN DPS.Search_MFR_Name LIKE ''_%'' + search_term.items + ''%'' THEN 6 END

    From
            (SELECT * FROM Split('''+@SearchText+''','' '')) AS search_term
            JOIN
            DistributorPartsSearch1 DPS (NOLOCK)
                ON    ((DPS.Search_PartNumber LIKE ''%'' + search_term.items + ''%''
                    or DPS.Search_MFR_Name LIKE ''%'' + search_term.items + ''%'')
                    and (DPS.Price >= '+CONVERT(VARCHAR(30),@PriceMin)+' or '+CONVERT(VARCHAR(30),@PriceMin)+' = -1)
                    and (DPS.Price <= '+CONVERT(VARCHAR(30),@PriceMax)+' or '+CONVERT(VARCHAR(30),@PriceMax)+' = -1)
                    and (CONVERT(FLOAT,PartQuantity) >= '+CONVERT(VARCHAR(30),@QTYMin)+' or QOHDisp != ''Actual'' or '+CONVERT(VARCHAR(30),@QTYMin)+' = -1)
                    and (CONVERT(FLOAT,PartQuantity) <= '+CONVERT(VARCHAR(30),@QTYMax)+' or QOHDisp != ''Actual'' or '+CONVERT(VARCHAR(30),@QTYMax)+' = -1))
                    and (DPS.ManufacturerId IN ('''+@MFRIDs+''') OR '+@IsEmptyMFRIDs+' = 1)
                    and (DPS.DistributorID IN ('''+@DistIDs+''') OR '+@IsEmptyDistIDs+' = 1)
                    and (DPS.ProductTypeId IN ('''+@ProdTypeIDs+''') OR '+@IsEmptyProdTypeIDs+' = 1)

            Left Join RegionAuthorization RA (NOLOCK)
                ON RA.IsActive = 1 and DPS.DistributorId = RA.DistID and DPS.ManufacturerId = RA.MfrID
            Left Join (    Select     MFRDistID
                                ,MAX(AuthStatusID) as MaxAuth
                                ,SUM(Print_Amount) As T_PA
                                ,SUM(Online_Amount) AS T_OA
                                ,sum(Print_Amount+Online_Amount) as Total
                                ,Count(*) As N_Rows From RegionZoneStatus (NOLOCK)
                        WHERE    (RegionID IN ('''+@RegionIDs+''') OR '+@IsEmptyRegionIDs+' = 1)
                        group By MfrDistID)    as RZS
                ON RA.MfrDistID = RZS.MfrDistID
            Left Join CompanyOwnerShipMapping COM1 (NOLOCK)
                ON DPS.DistributorId = COM1.CompanyID and (Com1.OwnershipID IN ('''+@AttributeIDs+''') OR '+@IsEmptyAttributeIDs+' = 1)
            Left Join UserFavorites UF (NOLOCK)
                ON UF.FavType = 3 and DPS.ProductId = UF.TypeID
                    and (UF.UserID = '+CONVERT(VARCHAR(30),@UserID)+' OR '+CONVERT(VARCHAR(30),@UserID)+' = -1)

    Where    (('+CONVERT(VARCHAR(1),@IsAuth)+' = 0 and '+CONVERT(VARCHAR(1),@IsFilterByRegion)+' = 0)
             OR('+CONVERT(VARCHAR(1),@IsAuth)+' = 0 AND '+CONVERT(VARCHAR(1),@IsFilterByRegion)+' = 1
                And (MaxAuth = 4 or Total > 0
                    or (Select    1
                        From CompanyLocations CL, Country C
                        where
                            (C.RegionID IN ('''+@RegionIDs+''') OR '+@IsEmptyRegionIDs+' = 1)
                            and
                            LocationStatusID = 1 and CL.IsActive = 1
                            and C.CountryID = CL.CountryID
                            and DPS.DistributorId = CL.CompanyID
                        group by CompanyID) = 1))
                OR('+CONVERT(VARCHAR(1),@IsAuth)+' = 1 and MaxAuth = 4))


    Order By MatchOrder, PartNumber, ManufacturerName, DistAuthStatus DESC, Total DESC, DistributorName'
Execute  (@SQL1);

END
-------------------------------------End of IF/Else Logic----------------------------------
Set NOCount OFF;
-------------------------------------END--------------------------------------



GO
------------------------------------------------------------------------------------------------------------------

/******************************************************************************************************************/
--Triggers
/******************************************************************************************************************/

IF  EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Clean_Company_Data]'))
DROP TRIGGER [dbo].[Clean_Company_Data]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:        Lalit Mehta
-- Create date: Dec. 23, 2011
-- Description:    Remove special characters from Company search fields
-- =============================================
CREATE TRIGGER [dbo].[Clean_Company_Data]
   ON  [dbo].[Company]
   AFTER INSERT,UPDATE
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;
    DECLARE @vchCompanyName VARCHAR(100)
    SELECT @vchCompanyName = CompanyName from inserted
    DECLARE @vchBookName VARCHAR(600)
    SELECT @vchBookName = BookName from inserted
    DECLARE @vchKeywords VARCHAR(500)
    SELECT @vchKeywords = keywords from inserted
    DECLARE @vchCompanyID int
    SELECT @vchCompanyID = CompanyID from inserted

    if exists (
        select 'X' from inserted
        )
        begin
            update [dbo].[Company]
            set
                Clean_CompanyName = [dbo].VK_RemoveSpecialChars(@vchCompanyName),
                Clean_BookName = [dbo].VK_RemoveSpecialChars(@vchBookName),
                Clean_keywords = [dbo].VK_RemoveSpecialChars(@vchKeywords)
            where [dbo].[Company].CompanyID = @vchCompanyID;
        end
END
GO
------------------------------------------------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Clean_Product_Data]'))
DROP TRIGGER [dbo].[Clean_Product_Data]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:        Lalit Mehta
-- Create date: Dec. 23, 2011
-- Description:    Remove special characters from Product search fields
-- =============================================
CREATE TRIGGER [dbo].[Clean_Product_Data]
   ON  [dbo].[Product]
   AFTER INSERT,UPDATE
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;
    DECLARE @vchPartNumber VARCHAR(100)
    SELECT @vchPartNumber = PartNumber from inserted
    DECLARE @vchProductID int
    SELECT @vchProductID = ProductID from inserted

    if exists (
        select 'X' from inserted
        )
        begin
            update [dbo].[Product]
            set
                Clean_PartNumber = [dbo].VK_RemoveSpecialChars(@vchPartNumber)
            where [dbo].[Product].ProductID = @vchProductID;
        end
END


GO
------------------------------------------------------------------------------------------------------------------
/******************************************************************************************************************/
---Index
/******************************************************************************************************************/

IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Product]') AND name = N'MFRID_Ind')
DROP INDEX [MFRID_Ind] ON [dbo].[Product] WITH ( ONLINE = OFF )
GO
CREATE NONCLUSTERED INDEX [MFRID_Ind] ON [dbo].[Product]
(
    [ManufacturerID] ASC
)
INCLUDE ( [PartNumber]) WITH (PAD_INDEX  = ON, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = OFF, ALLOW_PAGE_LOCKS  = OFF, FILLFACTOR = 90) ON [PRIMARY]
GO
------------------------------------------------------------------------------------------------------------------
--- Jan 10 2012

----------------------------------------------------------------------------------------------------
GO

/****** Object:  Index [NCPRLI_idx]    Script Date: 03/19/2012 18:26:25 ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PremiumListing]') AND name = N'NCPRLI_idx')
DROP INDEX [NCPRLI_idx] ON [dbo].[PremiumListing] WITH ( ONLINE = OFF )
GO


/****** Object:  Index [NCPRLI_idx]    Script Date: 03/19/2012 18:26:25 ******/
CREATE NONCLUSTERED INDEX [NCPRLI_idx] ON [dbo].[PremiumListing]
(
    [AdOrderId] ASC,
    [AdOrderDetailsId] ASC,
    [PremiumListingID] ASC
)
INCLUDE ( [WebVersion]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO


/******************************************************************************************************************/
-- View Updates ---------------------------------------------------------------------------------------
/******************************************************************************************************************/
GO

/****** Object:  View [dbo].[lm_distributor_orders]    Script Date: 03/20/2012 15:56:10 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[lm_distributor_orders]'))
DROP VIEW [dbo].[lm_distributor_orders]
GO

/****** Object:  View [dbo].[lm_distributor_orders]    Script Date: 03/20/2012 15:56:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW
  [dbo].[lm_distributor_orders](DistID, AdOrderId, AdOrderDetailsId, Duration, ActivationDate, MfrID, WebVersion)
AS
SELECT DISTINCT
    reg_auth.DistID,
    ad_order.AdOrderId,
    ad_ordts.AdOrderDetailsId,
    ad_ordts.Duration,
    ad_ordts.ActivationDate,
    ad_ordts.PositionTitle,
    premu.WebVersion
FROM
    RegionAuthorization reg_auth
    LEFT OUTER JOIN AdOrder ad_order ON ad_order.CompanyId = reg_auth.DistID
    LEFT OUTER JOIN AdOrderDetails ad_ordts ON ad_order.AdOrderId = ad_ordts.AdOrderId AND ad_ordts.AdOrderId IS NOT NULL
      AND ad_ordts.ActivationDate<= GETDATE() AND GETDATE() <= DATEADD(MONTH,ad_ordts.Duration,ad_ordts.ActivationDate)
    LEFT OUTER JOIN PremiumListing premu ON ad_ordts.AdOrderDetailsId = premu.AdOrderDetailsId AND ad_ordts.AdOrderDetailsId IS NOT NULL
    JOIN SalesSectionType SST ON ad_ordts.SectionID=SST.SectionID AND SST.SectionCode in('M') And SST.Status=1
GO


/******************************************************************************************************************/
-- Stored Procedures
/******************************************************************************************************************/
-------------------------------------------------------------------------------------------------------
-- Manufacturer Search --------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_SearchManufacturerWithUser]    Script Date: 05/25/2012 17:02:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SearchManufacturerWithUser]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_SearchManufacturerWithUser]
GO

/****** Object:  StoredProcedure [dbo].[usp_SearchManufacturerWithUser]    Script Date: 05/25/2012 17:02:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
[usp_SearchManufacturerWithUser] 'Texas','','','','',''
*/
-- EXEC usp_SearchManufacturerWithUser 'diode','','','','','','',84306

CREATE PROCEDURE [dbo].[usp_SearchManufacturerWithUser]
(
    @SEARCH VARCHAR(1000),
    @DIST_ID VARCHAR(100) = '',
    @USER_Region VARCHAR(100)= '',
    @USER_ZONE VARCHAR(100)= '',
    @DIST_AUTH VARCHAR(100)= '0',
    @AttributesIds VARCHAR(100)= '',
    @IsFilterByRegion VARCHAR(10) = '0',
    @UserID int = 0
)
AS
 BEGIN

    set transaction isolation level read uncommitted

    IF(@DIST_ID IS NULL) BEGIN SET @DIST_ID = '' END
    IF(@USER_Region IS NULL) BEGIN SET @USER_Region = '' END
    IF(@USER_ZONE IS NULL) BEGIN SET @USER_ZONE = '' END
    IF(@DIST_AUTH IS NULL) BEGIN SET @DIST_AUTH = '' END
    IF(@IsFilterByRegion IS NULL) BEGIN SET @IsFilterByRegion = '' END

    DECLARE @MAIN_QUERY VARCHAR(8000)
    DECLARE @JoinAttributes VARCHAR(3000)=''

    Declare @IsEmptyDistIDs VARCHAR(1) = '0'
    Declare @IsEmptyRegionIDs VARCHAR(1) = '0'
    Declare @IsEmptyZoneIDs VARCHAR(1) = '0'


    IF(@DIST_ID = '') BEGIN SET @IsEmptyDistIDs = 1 END
    IF(@USER_Region = '') BEGIN SET @IsEmptyRegionIDs = 1 END
    IF(@USER_ZONE = '' ) BEGIN SET @IsEmptyZoneIDs = 1 END
    IF(@DIST_AUTH = '') BEGIN SET @DIST_AUTH = '0' END
    IF(@IsFilterByRegion = '') BEGIN SET @IsFilterByRegion = '0' END


    SET @DIST_ID = '' + REPLACE(@DIST_ID,',',''',''') + ''
    SET @USER_Region = '' + REPLACE(@USER_Region,',',''',''') + ''
    SET @USER_ZONE = '' + REPLACE(@USER_ZONE,',',''',''') + ''

    --Attributes
    IF((@AttributesIds IS NOT NULL) AND (@AttributesIds <> ''))
    BEGIN
    SET @JoinAttributes = 'INNER JOIN dbo.CompanyOwnershipMapping com
        ON com.CompanyID=reg_auth.DistID
        INNER JOIN (SELECT * FROM dbo.Split('''+@AttributesIds+''','','')) as Attributes
        ON com.OwnershipID = Attributes.items'
    END

    SET @SEARCH = [dbo].VK_RemoveSpecialChars(@SEARCH)

SET @MAIN_QUERY = '
DECLARE @SEARCH_QUERY VARCHAR(300)
SET @SEARCH_QUERY = '''+@SEARCH+'''
        SELECT DISTINCT  -- review if we can remove distinct from here
                mfr.CompanyID,
                mfr.CompanyName,
                mfr.CompanyLogo,
                mfr.CompanyDescription,
                also_know.AlsoKnownAs AS AlsoKnownAS,
                CASE WHEN (RZS.MaxAuth = 1 OR RZS.MaxAuth = 2 OR RZS.MaxAuth = 3 OR RZS.MaxAuth IS NULL) THEN  1
                    ELSE RZS.MaxAuth END AS MaxAuth ,
                dist.CompanyName as DistributorName,
                dist.CompanyLogo as DistributorLogo,
                dbo.Get_SearchCompanyOwn (reg_auth.DistID) AS DistributorAttributes,
                mfr.CompanyStatus,
                dist_order.WebVersion,
                dist.CompanyID as DistID,
                IsNULL(RZS2.Total, 0.00) AS Total,
                invs.CheckInvURL,
                CASE WHEN ( uf.TypeID IS NULL ) THEN 0 ELSE 1 END  AS IsFav ,
                CASE WHEN (mfr.Clean_CompanyName LIKE '''+@SEARCH+''') THEN ''11''
                     WHEN (mfr.Clean_AlsoKnownAs LIKE '''+@SEARCH+''') THEN ''12''
                     WHEN (mfr.Clean_BookName1 LIKE '''+@SEARCH+'''
                     OR mfr.Clean_BookName2 LIKE '''+@SEARCH+'''
                     OR mfr.Clean_Keyword1 LIKE '''+@SEARCH+'''
                     OR mfr.Clean_Keyword2 LIKE '''+@SEARCH+''') THEN ''13''

                     WHEN (mfr.Clean_CompanyName LIKE search_term.items + ''_%'')THEN ''21''
                     WHEN (mfr.Clean_AlsoKnownAs LIKE search_term.items + ''_%'')THEN ''22''
                     WHEN (mfr.Clean_BookName1 LIKE search_term.items + ''_%''
                     OR mfr.Clean_BookName2 LIKE search_term.items + ''_%''
                     OR mfr.Clean_Keyword1 LIKE search_term.items + ''_%''
                     OR mfr.Clean_Keyword2 LIKE search_term.items + ''_%'')THEN ''23''

                     WHEN (mfr.Clean_CompanyName LIKE ''_%'' + search_term.items + ''%'')THEN ''31''
                     WHEN (mfr.Clean_AlsoKnownAs LIKE ''_%'' + search_term.items + ''%'')THEN ''32''
                     WHEN (mfr.Clean_BookName1 LIKE ''_%'' + search_term.items + ''%''
                     OR mfr.Clean_BookName2 LIKE ''_%'' + search_term.items + ''%''
                     OR mfr.Clean_Keyword1 LIKE ''_%'' + search_term.items + ''%''
                     OR mfr.Clean_Keyword2 LIKE ''_%'' + search_term.items + ''%'')THEN ''33'' ELSE ''40''
                END AS MatchOrder, isnull(dist.Trusted_Disty,0) as Trusted_Disty
             into ##mantemp1
                FROM (SELECT * FROM dbo.Split(@SEARCH_QUERY,'' '')) AS search_term
                JOIN [dbo].[lm_seeline_manufacturer] (nolock) AS mfr
                    ON mfr.Clean_CompanyName LIKE ''%'' + search_term.items + ''%''
                    OR mfr.Clean_AlsoKnownAs LIKE ''%'' + search_term.items + ''%''
                    OR mfr.Clean_BookName1 LIKE ''%'' + search_term.items + ''%''
                    OR mfr.Clean_Keyword1 LIKE ''%'' + search_term.items + ''%''
                    OR mfr.Clean_BookName2 LIKE ''%'' + search_term.items + ''%''
                    OR mfr.Clean_Keyword2 LIKE ''%'' + search_term.items + ''%''
                Left Join [dbo].[MFRAlsoKnownAs] (nolock) also_know on also_know.CompanyID = mfr.CompanyID
                Left Join [dbo].[RegionAuthorization] (nolock) reg_auth  -- we may need left join here if we want to show mfr without distributors
                    ON reg_auth.IsActive = 1
                    AND reg_auth.MfrID = mfr.CompanyID

                    LEFT JOIN [dbo].[InventorySettings] invs ON reg_auth.DistID = invs.CompanyID

                left join (
                    Select
                        RZOS.MFRDistID,
                        MAX(case when (AuthStatusID  = 2 and C.Trusted_Disty=1) then 4
                            else AuthStatusID end) as MaxAuth
                    From
                        RegionZoneStatus (nolock) RZOS,
                        Company (nolock) C,
                        RegionAuthorization (nolock) RA
                    WHERE  RA.MfrDistID = RZOS.MfrDistID
                        AND RA.DistID=C.CompanyID
                        AND (RegionId in ('''+@USER_Region+''') OR '+@IsEmptyRegionIDs+' = 1)

                    group By RZOS.MfrDistID
                ) as RZS
                    ON reg_auth.MfrDistID = RZS.MfrDistID


               left join (
                    Select
                        RZOS.MFRDistID,
                        sum(Print_Amount+Online_Amount) as Total
                    From
                        RegionZoneStatus (nolock) RZOS,
                        Company (nolock) C,
                        RegionAuthorization (nolock) RA
                    WHERE  RA.MfrDistID = RZOS.MfrDistID
                        AND RA.DistID=C.CompanyID
                        AND (RegionId in ('''+@USER_Region+''') OR '+@IsEmptyRegionIDs+' = 1)
                        AND (ZoneId in ('''+@USER_ZONE+''') OR '+@IsEmptyZoneIDs+' = 1)
                    group By RZOS.MfrDistID
                ) as RZS2
                    ON reg_auth.MfrDistID = RZS2.MfrDistID

                left join Company (nolock) dist on reg_auth.DistID = dist.CompanyID
                    and dist.IsActive =1 and dist.CompanyStatusId = 1
                 LEFT JOIN dbo.[UserFavorites]  uf (NOLOCK)  ON mfr.CompanyID = uf.TypeID
                AND uf.[FavType] in (1,2,4) AND CAST(UserID AS VARCHAR)  = '''+CAST(@UserID AS VARCHAR)+'''
             left join(select min(WebVersion) WebVersion,distmfr.DistID,distmfr.MfrID from lm_distributor_orders (nolock) distmfr
                     JOIN AdOrderDetailsRegionEdition ad_oder_reg_edit
                     ON distmfr.AdOrderDetailsId = ad_oder_reg_edit.AdOrderDetailsId
                        AND (ad_oder_reg_edit.RegionID in ('''+@USER_ZONE+''')  OR '+@IsEmptyZoneIDs+' = 1)
                        group by distmfr.DistID,distmfr.MfrID) dist_order
                     on dist_order.DistID = reg_auth.DistID  AND dist_order.MfrID = reg_auth.MfrID
                '+@JoinAttributes+'


                WHERE
                (reg_auth.DistID in('''+@DIST_ID+''') OR '+@IsEmptyDistIDs+' = 1)	-- in @DIST_ID

                AND ('''+@DIST_AUTH+''' = 0 or RZS.MaxAuth = 4 or RZS.MfrDistID is null)
                AND ('''+@IsFilterByRegion+''' = 0 or MaxAuth = 4 or RZS.MfrDistID is null or Total > 0
                    OR (Select	1
                        From CompanyLocations CL, Country C
                        where
                            C.CountryID = CL.CountryID
                            AND reg_auth.DistID = CL.CompanyID
                            AND	(C.RegionID IN ('''+@USER_Region+''') OR '+@IsEmptyRegionIDs+' = 1)
                            AND LocationStatusID = 1  --  in @USER_Region
                            AND CL.IsActive = 1
                        group by CompanyID) = 1)'

Execute(@MAIN_QUERY)

select a.CompanyID, min(a.MatchOrder) orders,count(a.MatchOrder) counts
        into ##man from ##mantemp1 a
  group by a.companyid

  select a.*, DIFFERENCE(@SEARCH, CompanyName) as diff into ##ManDiffTable from ##mantemp1 a join ##man b on a.companyid=b.companyid and a.matchorder=b.orders
                  ORDER BY MatchOrder,CompanyName, Total DESC, MaxAuth DESC,  DistributorName ASC

      select CompanyID
        ,CompanyName
        ,CompanyLogo
        ,CompanyDescription
        ,AlsoKnownAs
        ,MaxAuth
        ,DistributorName
        ,DistributorLogo
        ,DistributorAttributes
        ,CompanyStatus
        ,WebVersion
        ,DistID
        ,Total
        ,MatchOrder
        ,diff
        ,Trusted_Disty
    from ##ManDiffTable
    ORDER BY MatchOrder, diff desc, CompanyName, Total DESC, MaxAuth DESC,  DistributorName ASC

  drop table ##mantemp1
  drop table ##man
  drop table ##ManDiffTable
END



GO

-------------------------------------------------------------------------------------------------------
-- Part Count (deprecated)-----------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[USP_PartSearchCount]    Script Date: 05/19/2012 13:26:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_PartSearchCount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[USP_PartSearchCount]
GO

/****** Object:  StoredProcedure [dbo].[USP_PartSearchCount]    Script Date: 05/19/2012 13:26:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [dbo].[USP_PartSearchCount_deprecated]
(
                -------------Created By: Nirav Parikh/Mohit Garg--------------
                -------------------Date: December 26,2011----------------
    @SearchText Varchar(8000)
    ,@RegionIDs Varchar(100)
    ,@IsAuth bit
    ,@MFRIDs Varchar(1000)
    ,@DistIDs Varchar(1000)
    ,@ProdTypeIDs Varchar(1000)
    ,@PriceMin decimal(10,2)
    ,@PriceMax Decimal(10,2)
    ,@QTYMin Int
    ,@QTYMax Int
    ,@HasDesignRes bit
    ,@AttributeIDs Varchar(400)
    ,@UserID Int
    ,@IsFilterByRegion bit
)
AS

BEGIN
    Set NoCount ON
    set transaction isolation level read uncommitted
    Declare @IsEmptyRegionIDs VARCHAR(1) = '0'
    Declare @IsEmptyMFRIDs VARCHAR(1) = '0'
    Declare @IsEmptyDistIDs VARCHAR(1) = '0'
    Declare @IsEmptyProdTypeIDs VARCHAR(1) = '0'
    Declare @IsEmptyAttributeIDs VARCHAR(1) = '0'


    IF(@RegionIDs='') BEGIN SET @IsEmptyRegionIDs = 1 END
    IF(@MFRIDs='') BEGIN SET @IsEmptyMFRIDs = 1 END
    IF(@DistIDs='') BEGIN SET @IsEmptyDistIDs = 1 END
    IF(@ProdTypeIDs='') BEGIN SET @IsEmptyProdTypeIDs = 1 END
    IF(@AttributeIDs='') BEGIN SET @IsEmptyAttributeIDs = 1 END


    SET @RegionIDs = '' + REPLACE(@RegionIDs,',',''',''') + ''
    SET @MFRIDs = '' + REPLACE(@MFRIDs,',',''',''') + ''
    SET @DistIDs = '' + REPLACE(@DistIDs,',',''',''') + ''
    SET @ProdTypeIDs = '' + REPLACE(@ProdTypeIDs,',',''',''') + ''
    SET @AttributeIDs = '' + REPLACE(@AttributeIDs,',',''',''') + ''



    Declare @SQL1 varChar(max)

    SET @SQL1 =
    'Select		 DISTINCT
                    DPS.PartNumber
                    ,DPS.ManufacturerId
    From
            (SELECT * FROM Split('''+@SearchText+''','' '')) AS search_term
            JOIN
            DistributorPartsSearch1 DPS (NOLOCK)
                ON	((DPS.Search_PartNumber LIKE ''%'' + search_term.items + ''%''
                    or DPS.Search_MFR_Name LIKE ''%'' + search_term.items + ''%'')
                    and (DPS.Price >= '+CONVERT(VARCHAR(30),@PriceMin)+' or '+CONVERT(VARCHAR(30),@PriceMin)+' = -1)
                    and (DPS.Price <= '+CONVERT(VARCHAR(30),@PriceMax)+' or '+CONVERT(VARCHAR(30),@PriceMax)+' = -1)
                    and (DPS.PartQuantity >= '+CONVERT(VARCHAR(30),@QTYMin)+' or DPS.QOHDisp != ''Actual'' or '+CONVERT(VARCHAR(30),@QTYMin)+' = -1)
                    and (DPS.PartQuantity <= '+CONVERT(VARCHAR(30),@QTYMax)+' or DPS.QOHDisp != ''Actual'' or '+CONVERT(VARCHAR(30),@QTYMax)+' = -1))
                    and (DPS.ManufacturerId IN ('''+@MFRIDs+''') OR '+@IsEmptyMFRIDs+' = 1)
                    and (DPS.DistributorID IN ('''+@DistIDs+''') OR '+@IsEmptyDistIDs+' = 1)
                    and (DPS.ProductTypeId IN ('''+@ProdTypeIDs+''') OR '+@IsEmptyProdTypeIDs+' = 1)

            Left Join RegionAuthorization RA (NOLOCK)
                ON RA.IsActive = 1 and DPS.DistributorId = RA.DistID and DPS.ManufacturerId = RA.MfrID
            Left Join (	Select	 MFRDistID
                                ,MAX(AuthStatusID) as MaxAuth
                                ,SUM(Print_Amount) As T_PA
                                ,SUM(Online_Amount) AS T_OA
                                ,sum(Print_Amount+Online_Amount) as Total
                                ,Count(*) As N_Rows From RegionZoneStatus (NOLOCK)
                        WHERE	(RegionID IN ('''+@RegionIDs+''') OR '+@IsEmptyRegionIDs+' = 1)
                        group By MfrDistID)	as RZS
                ON RA.MfrDistID = RZS.MfrDistID
            Left Join CompanyOwnerShipMapping COM1 (NOLOCK)
                ON DPS.DistributorId = COM1.CompanyID and (Com1.OwnershipID IN ('''+@AttributeIDs+''') OR '+@IsEmptyAttributeIDs+' = 1)
            Left Join UserFavorites UF (NOLOCK)
                ON UF.FavType = 3 and DPS.ProductId = UF.TypeID
                    and (UF.UserID = '+CONVERT(VARCHAR(30),@UserID)+' OR '+CONVERT(VARCHAR(30),@UserID)+' = -1)

    Where	(('+CONVERT(VARCHAR(1),@IsAuth)+' = 0 and '+CONVERT(VARCHAR(1),@IsFilterByRegion)+' = 0)
             OR('+CONVERT(VARCHAR(1),@IsAuth)+' = 0 AND '+CONVERT(VARCHAR(1),@IsFilterByRegion)+' = 1
                And (MaxAuth = 4 or Total > 0
                    or (Select	1
                        From CompanyLocations CL, Country C
                        where
                            (C.RegionID IN ('''+@RegionIDs+''') OR '+@IsEmptyRegionIDs+' = 1)
                            and
                            LocationStatusID = 1 and CL.IsActive = 1
                            and C.CountryID = CL.CountryID
                            and DPS.DistributorId = CL.CompanyID
                        group by CompanyID) = 1))
                OR('+CONVERT(VARCHAR(1),@IsAuth)+' = 1 and MaxAuth = 4)) '
DECLARE @SQLN varchar(max)

SET @SQLN='SELECT Count(8) as TotRecords  FROM ('+@SQL1+') T'

Execute  (@SQLN);

Set NOCount OFF;

END


GO

-------------------------------------------------------------------------------------------------------
-- Distributor Count ----------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_SearchDistributorCount]    Script Date: 03/17/2012 19:27:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SearchDistributorCount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_SearchDistributorCount]
GO

/****** Object:  StoredProcedure [dbo].[usp_SearchDistributorCount]    Script Date: 03/17/2012 19:27:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--[usp_SearchDistributorCount] 'texas in','','','',''
CREATE PROCEDURE [dbo].[usp_SearchDistributorCount]
(
 @SearchCreteria  varchar(4000)
 ,@AttributesIds VARCHAR (100)
 ,@RegionIds VARCHAR (100)
 ,@UserID int
 ,@OfferServices bit
)
AS
 BEGIN
    set transaction isolation level read uncommitted
    SET @SearchCreteria = REPLACE([dbo].VK_RemoveSpecialChars(@SearchCreteria),' ',',')

    DECLARE @SQL1 VARCHAR(MAX),@SQLIF  VARCHAR(MAX),@SQLELSE  VARCHAR(MAX),@SQL VARCHAR(MAX)

SET @SQL1=
'SELECT DISTINCT
            seeline_view.CompanyID AS DistributorID, seeline_view.CompanyLogo AS CompanyLogo,
                seeline_view.CompanyName AS DistributorName,
                dbo.Get_SearchCompanyOwn (seeline_view.CompanyID) AS DistributorAttributes,
                dbo.ufn_DS_Get_DistributorSeeLines(seeline_view.CompanyID) AS AlsoKnownAs,
                CASE WHEN ( uf.TypeID IS NULL ) THEN 0 ELSE 1 END  AS IsFav ,
                CASE WHEN (seeline_view.Clean_CompanyName LIKE search_term.items
                OR seeline_view.Clean_AlsoKnownAs LIKE search_term.items
                OR seeline_view.Clean_BookName1 LIKE search_term.items
                OR seeline_view.Clean_BookName2 LIKE search_term.items
                OR seeline_view.Clean_keyword1 LIKE search_term.items
                OR seeline_view.Clean_keyword2 LIKE search_term.items) THEN ''1'' ELSE
              CASE WHEN (seeline_view.Clean_CompanyName LIKE search_term.items + ''_%''
                OR seeline_view.Clean_AlsoKnownAs LIKE search_term.items + ''_%''
                OR seeline_view.Clean_BookName1 LIKE search_term.items + ''_%''
                OR seeline_view.Clean_BookName2 LIKE search_term.items + ''_%''
                OR seeline_view.Clean_keyword1 LIKE search_term.items + ''_%''
                OR seeline_view.Clean_keyword2 LIKE search_term.items + ''_%'')THEN ''2'' ELSE
              CASE WHEN (seeline_view.Clean_CompanyName LIKE ''_%'' + search_term.items + ''%''
                OR seeline_view.Clean_AlsoKnownAs LIKE ''_%'' + search_term.items + ''%''
                OR seeline_view.Clean_BookName1 LIKE ''_%'' + search_term.items + ''%''
                OR seeline_view.Clean_BookName2 LIKE ''_%'' + search_term.items + ''%''
                OR seeline_view.Clean_keyword1 LIKE ''_%'' + search_term.items + ''%''
                OR seeline_view.Clean_keyword2 LIKE ''_%'' + search_term.items + ''%'')THEN ''3'' END END END AS MatchOrder
            FROM (SELECT * FROM dbo.Split('''+@SearchCreteria+''','','')) AS search_term
             INNER JOIN dbo.lm_seeline_distributor  seeline_view (NOLOCK) ON
             seeline_view.Clean_CompanyName LIKE ''%'' + search_term.items + ''%''
             OR seeline_view.Clean_AlsoKnownAs LIKE ''%'' + search_term.items + ''%''
             OR seeline_view.Clean_BookName1 LIKE ''%'' + search_term.items + ''%''
             OR seeline_view.Clean_keyword1 LIKE ''%'' + search_term.items + ''%''
             OR seeline_view.Clean_BookName2 LIKE ''%'' + search_term.items + ''%''
             OR seeline_view.Clean_keyword2 LIKE ''%'' + search_term.items + ''%'''

SET @SQLIF='LEFT JOIN dbo.[UserFavorites]  uf (NOLOCK)  ON seeline_view.CompanyID = uf.TypeID
             AND uf.[FavType] in (1,2,4) AND CAST(UserID AS VARCHAR)  = '''+CAST(@USERID AS VARCHAR)+'''
            WHERE
              ([dbo].[ufn_DS_Get_IsDistributorRegion] (seeline_view.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''')
              AND
              ([dbo].[ufn_DS_Get_IsDistributorOfferService] (seeline_view.CompanyID) = 1 OR '+CAST(@OfferServices AS CHAR(1))+'=''0'')'
SET @SQLELSE='INNER JOIN dbo.CompanyOwnershipMapping com (NOLOCK)
                ON com.CompanyID=seeline_view.CompanyID
            INNER JOIN (SELECT * FROM dbo.Split('''+@AttributesIds+''','','')) as Attributes
                ON com.OwnershipID = Attributes.items
            LEFT JOIN dbo.[UserFavorites]  uf (NOLOCK)  ON seeline_view.CompanyID = uf.TypeID
            AND uf.[FavType] in (1,2,4) AND CAST(UserID AS VARCHAR)  = '''+CAST(@USERID AS VARCHAR)+'''
        WHERE
              ([dbo].[ufn_DS_Get_IsDistributorRegion] (seeline_view.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''')
              AND
              ([dbo].[ufn_DS_Get_IsDistributorOfferService] (seeline_view.CompanyID) = 1 OR '+CAST(@OfferServices AS CHAR(1))+'=''0'')'

   IF(@AttributesIds='')
     BEGIN
        SET @SQL='SELECT Count(distinct DistributorID) as DistCount  FROM ('+@SQL1+@SQLIF+') T WHERE MatchOrder IS NOT NULL'
        EXEC (@SQL)


     END
    ELSE
     BEGIN
        SET @SQL='SELECT Count(distinct DistributorID) as DistCount  FROM ('+@SQL1+@SQLELSE+') T WHERE MatchOrder IS NOT NULL'
        EXEC (@SQL)
     END

END

GO
-------------------------------------------------------------------------------------------------------
-- Product and Services Count -------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
GO
/****** Object:  StoredProcedure [dbo].[VK_SEARCH_PROD_SERVICE_Count]    Script Date: 03/19/2012 20:32:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[VK_SEARCH_PROD_SERVICE_Count]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[VK_SEARCH_PROD_SERVICE_Count]
GO

/****** Object:  StoredProcedure [dbo].[VK_SEARCH_PROD_SERVICE_Count]    Script Date: 03/19/2012 20:32:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
[DS_VK_SEARCH_PROD_SERVICE_Count_WIP]  'test','','','','144632,144631'
*/
/************************************************************************************************************
Created By    : Deepti Singh
Creation Date  : 9th-Jan-2012
*************************************************************************************************************/
CREATE PROCEDURE [dbo].[VK_SEARCH_PROD_SERVICE_Count]
(
@PRODUCTNAME VARCHAR(MAX)
,@AttributesIds VARCHAR (100)=''
,@RegionIds VARCHAR (50)=''
,@ZoneIds VARCHAR (50)=''
,@DistributorIDs VARCHAR (100)=''
,@ManufacturerIDs VARCHAR (100)=''
)
AS
BEGIN
    set transaction isolation level read uncommitted
    DECLARE @STARTWITH VARCHAR(MAX),@CONTAINS VARCHAR(MAX),@SQL1 VARCHAR(MAX),@SQL2 VARCHAR(MAX),@SQL VARCHAR(MAX)
    DECLARE @ProdcutIds VARCHAR(MAX)  = ''
    Declare @IsEmptyZoneIDs VARCHAR(1) = '0'
    IF(@ZoneIds = '' ) BEGIN SET @IsEmptyZoneIDs = 1 END

    SELECT @STARTWITH=SUBSTRING((SELECT ('ptype.SearchTypeDescription LIKE '+''''+[items]+'_%'''+' OR ')
        FROM Split(@PRODUCTNAME,' ') ORDER BY items FOR XML PATH('')),1,20000),
            @CONTAINS=SUBSTRING((SELECT ('ptype.SearchTypeDescription LIKE '+'''%'+[items]+'%'''+' OR ')
                                    FROM Split(@PRODUCTNAME,' ') ORDER BY items FOR XML PATH('')),1,20000)

    SELECT @SQL1 = 'SELECT DISTINCT
                        ptype.TypeDescription,
                        ptype.SearchTypeDescription,
                        ptype.ProductTypeId
                    FROM VK_Vw_ProductType ptype (NOLOCK)
                    WHERE '+@STARTWITH+''
                    +''+@CONTAINS+''
                    +' ptype.SearchTypeDescription='''+@PRODUCTNAME+''''

    CREATE TABLE #PRODLIST(TypeDescription VARCHAR(100) NULL,SearchTypeDescription  VARCHAR(100) NULL,ProductTypeId INT NULL)

    INSERT INTO #PRODLIST
    EXEC (@SQL1)


    CREATE TABLE #TEMP1(CompanyID INT NULL,OWNERSHIPID VARCHAR(MAX) NULL)

    SELECT @SQL2 = 'SELECT CompanyID,OWNERSHIPID
                    FROM
                    (
                        SELECT CO.COMPANYID
                        ,OWNERSHIPID=SUBSTRING(
                            (SELECT ('', ''+[DESCRIPTION]) FROM  dbo.CompanyOwnershipMapping CO1 (NOLOCK)
                                JOIN dbo.MstCompanyOwnership O (NOLOCK) ON CO1.OwnershipID=O.OwnershipID
                                WHERE CO.CompanyID=CO1.CompanyID ORDER BY CompanyID,CO1.OwnershipID FOR XML PATH('''')),3,20000)

                        FROM dbo.CompanyOwnershipMapping CO (NOLOCK)
                            JOIN dbo.Company (nolock) ON Company.CompanyID=CO.CompanyID
                            JOIN dbo.CompanyProductType CPTYPE (NOLOCK) ON Company.CompanyID=CPTYPE.CompanyID
                            JOIN #PRODLIST PL (NOLOCK) ON PL.ProductTypeId=CPTYPE.ProductTypeID
                            GROUP BY CO.CompanyID

                        UNION

                        SELECT CO.COMPANYID
                        ,OWNERSHIPID=SUBSTRING(
                            (SELECT ('', ''+[DESCRIPTION]) FROM  dbo.CompanyOwnershipMapping CO1 (NOLOCK)
                                JOIN dbo.MstCompanyOwnership O (NOLOCK) ON CO1.OwnershipID=O.OwnershipID
                                WHERE CO.CompanyID=CO1.CompanyID ORDER BY CompanyID,CO1.OwnershipID FOR XML PATH('''')),3,20000)

                        FROM dbo.CompanyOwnershipMapping CO (NOLOCK)
                            JOIN dbo.VendorServiceMapping VS(NOLOCK)  ON CO.CompanyID=VS.VendorID
                            JOIN #PRODLIST PL (NOLOCK) ON PL.ProductTypeId=VS.ServiceID
                            GROUP BY CO.CompanyID
                    ) T1 '


    INSERT INTO #TEMP1 (CompanyID,OWNERSHIPID)
    EXEC (@SQL2)

    CREATE TABLE #TEMP2(TypeDescription VARCHAR(100) NULL,SearchTypeDescription  VARCHAR(100) NULL,ProductTypeId INT NULL
                        ,CompanyName VARCHAR(100) NULL,CompanyID INT NULL,CompanyTypeID INT NULL,CompanyLogo VARCHAR(100) NULL,
                        OwnershipID VARCHAR(MAX)NULL,WebVersion VARCHAR(5000) NULL)

    INSERT  INTO #TEMP2 (TypeDescription,SearchTypeDescription,ProductTypeId, CompanyName,CompanyID,CompanyTypeID,CompanyLogo,
                         OwnershipID,WebVersion )


        /*MANUFACTURERS*/

    SELECT TypeDescription,
           SearchTypeDescription,
           ProductTypeId,
           CompanyName,
           CompanyID,
           CompanyTypeID,
           CompanyLogo,
           OwnershipID,
           WebVersion
    FROM (
            SELECT ptype.TypeDescription,
                   ptype.SearchTypeDescription,
                   ptype.ProductTypeId,
                   COMPANY.CompanyName,
                   COMPANY.CompanyID,
                   CTM.CompanyTypeID,
                   COMPANY.CompanyLogo,
                   '0' OwnershipID,
                   NULL WebVersion
            FROM #PRODLIST ptype (NOLOCK)
                JOIN dbo.CompanyProductType CPTYPE (NOLOCK) ON CPTYPE.ProductTypeID=PTYPE.ProductTypeId
                JOIN dbo.Company (nolock)  ON Company.CompanyID=CPTYPE.CompanyID
                JOIN dbo.CompanyTypeMapping CTM(NOLOCK) ON CTM.CompanyID=CPTYPE.CompanyID
            WHERE CTM.CompanyTypeID=1

            UNION ALL

            /*PRODUCTS*/

            SELECT ptype.TypeDescription,
                   ptype.SearchTypeDescription,
                   ptype.ProductTypeId,
                   COMPANY.CompanyName,
                   COMPANY.CompanyID,
                   CTM.CompanyTypeID,
                   COMPANY.CompanyLogo,
                   CO.OwnershipID,
                   (select top 1 PRELIST.WebVersion from dbo.PremiumListing PRELIST
                       join AdOrder ad on ad.AdOrderId=PRELIST.AdOrderId
                       join AdOrderDetailsRegionEdition ad_oder_reg_edit ON  PRELIST.AdOrderDetailsId = ad_oder_reg_edit.AdOrderDetailsId
                       AND (ad_oder_reg_edit.RegionID in (select items from dbo.Split(@ZoneIds,',')) OR (@IsEmptyZoneIDs = 1))
                       where Company.CompanyID=ad.CompanyId order by PRELIST.PremiumListingID desc )
            FROM #PRODLIST ptype (NOLOCK)
                JOIN dbo.CompanyProductType CPTYPE (NOLOCK) ON CPTYPE.ProductTypeID=PTYPE.ProductTypeId
                JOIN dbo.Company (nolock)  ON Company.CompanyID=CPTYPE.CompanyID
                JOIN dbo.CompanyTypeMapping CTM(NOLOCK) ON CTM.CompanyID=CPTYPE.CompanyID
                LEFT JOIN (
                        SELECT  CPTYPE.CompanyID, PRELIST.WebVersion
                        FROM #PRODLIST ptype (NOLOCK)
                            JOIN  dbo.CompanyProductType CPTYPE (NOLOCK)  ON CPTYPE.ProductTypeID=PTYPE.ProductTypeId
                            JOIN dbo.AdOrder (NOLOCK) ON AdOrder.CompanyId=CPTYPE.CompanyID
                            JOIN dbo.AdOrderDetails OD (NOLOCK) ON
                                OD.AdOrderId = AdOrder.AdOrderId
                                and OD.PositionTitle=PTYPE.ProductTypeId
                                AND OD.ActivationDate <= GETDATE() AND GETDATE()<=DATEADD(MM,OD.Duration,OD.ActivationDate)
                            JOIN dbo.PremiumListing PRELIST ON PRELIST.AdOrderDetailsId=OD.AdOrderDetailsId
                     ) PRELIST ON PRELIST.CompanyID=Company.CompanyID
                LEFT JOIN #TEMP1 CO (NOLOCK) ON CO.CompanyID=Company.CompanyID
            WHERE CTM.CompanyTypeID=2

            UNION ALL

            /**SERVICES**/

            SELECT ptype.TypeDescription,
                   ptype.SearchTypeDescription,
                   ptype.ProductTypeId,
                   COMPANY.CompanyName,
                   COMPANY.CompanyID,
                   CTM.CompanyTypeID,
                   COMPANY.CompanyLogo,
                   CO.OwnershipID,
                   (select top 1 PRELIST.WebVersion from dbo.PremiumListing PRELIST
                       join AdOrder ad on ad.AdOrderId=PRELIST.AdOrderId
                       join AdOrderDetailsRegionEdition ad_oder_reg_edit ON  PRELIST.AdOrderDetailsId = ad_oder_reg_edit.AdOrderDetailsId
                       AND (ad_oder_reg_edit.RegionID in (select items from dbo.Split(@ZoneIds,',')) OR (@IsEmptyZoneIDs = 1))
                       where Company.CompanyID=ad.CompanyId order by PRELIST.PremiumListingID desc )
            FROM #PRODLIST ptype (NOLOCK)
                JOIN dbo.VendorServiceMapping VS(NOLOCK) ON VS.ServiceID=PTYPE.ProductTypeId
                JOIN dbo.Company (nolock)  ON Company.CompanyID=VS.VendorID
                JOIN dbo.CompanyTypeMapping CTM(NOLOCK) ON CTM.CompanyID=VS.VendorID
                LEFT JOIN(
                        SELECT  CPTYPE.CompanyID, PRELIST.WebVersion
                        FROM #PRODLIST ptype (NOLOCK)
                            JOIN  dbo.CompanyProductType CPTYPE (NOLOCK)  ON CPTYPE.ProductTypeID=PTYPE.ProductTypeId
                            JOIN dbo.AdOrder (NOLOCK) ON AdOrder.CompanyId=CPTYPE.CompanyID
                            JOIN dbo.AdOrderDetails OD (NOLOCK) ON
                                OD.AdOrderId = AdOrder.AdOrderId
                                and OD.PositionTitle=PTYPE.ProductTypeId
                                AND OD.ActivationDate <= GETDATE() AND GETDATE()<=DATEADD(MM,OD.Duration,OD.ActivationDate)
                            JOIN dbo.PremiumListing PRELIST ON PRELIST.AdOrderDetailsId=OD.AdOrderDetailsId
                     ) PRELIST ON PRELIST.CompanyID=Company.CompanyID
                LEFT JOIN #TEMP1 CO (NOLOCK) ON CO.CompanyID=Company.CompanyID
            WHERE CTM.CompanyTypeID=3
        ) T
    ORDER BY TypeDescription,CompanyTypeID,CompanyName

---- Filter based on DistributorId's and manufacturerId's  --------------------------
IF @ManufacturerIDs<>'' AND @DistributorIDs<>''
    BEGIN
        DECLARE @ManuIDs VARCHAR(MAX)=''
        DECLARE @DistIDs VARCHAR(MAX)=''

        SELECT @ManuIDs = SUBSTRING((SELECT DISTINCT '', ','+ISNULL(CONVERT(VARCHAR,tempTbl.ProductTypeId),'')
        FROM #TEMP2 tempTbl
            INNER JOIN Split(@ManufacturerIDs,',') spManu
            ON spManu.items = tempTbl.CompanyID
        WHERE tempTbl.CompanyTypeID='1'
            FOR XML PATH ('')),2,20000)

        SELECT @DistIDs = SUBSTRING((SELECT DISTINCT '', ','+ISNULL(CONVERT(VARCHAR,tempTbl.ProductTypeId),'')
        FROM #TEMP2 tempTbl
            INNER JOIN Split(@DistributorIDs,',') spDist
            ON spDist.items = tempTbl.CompanyID
        WHERE tempTbl.CompanyTypeID IN (2,3)
            FOR XML PATH ('')),2,20000)

        SELECT @ProdcutIds=SUBSTRING((SELECT ','+CONVERT(VARCHAR,spM.items) FROM Split(@ManuIDs,',') spM
            INNER JOIN Split(@DistIDs,',') spD
            ON spM.items=spD.items FOR XML PATH('')),2,20000)

        SELECT @ProdcutIds = ISNULL(@ProdcutIds,'0')
    END
ELSE
    BEGIN
        IF @ManufacturerIDs<>''
            BEGIN
                SELECT @ProdcutIds = SUBSTRING((SELECT DISTINCT '', ','+ISNULL(CONVERT(VARCHAR,tempTbl.ProductTypeId),'')
                FROM #TEMP2 tempTbl
                    INNER JOIN Split(@ManufacturerIDs,',') spManu
                    ON spManu.items = tempTbl.CompanyID
                WHERE tempTbl.CompanyTypeID='1'
                    FOR XML PATH ('')),2,20000)
            END
        ELSE
            BEGIN
                IF @DistributorIDs<>''
                    BEGIN
                        SELECT @ProdcutIds = SUBSTRING((SELECT DISTINCT '', ','+ISNULL(CONVERT(VARCHAR,tempTbl.ProductTypeId),'')
                        FROM #TEMP2 tempTbl
                            INNER JOIN Split(@DistributorIDs,',') spDist
                            ON spDist.items = tempTbl.CompanyID
                        WHERE tempTbl.CompanyTypeID IN (2,3)
                            FOR XML PATH ('')),2,20000)
                    END
            END
    END
Select @ProdcutIds = ISNULL(@ProdcutIds,'')
--------------------    END of filter   ------------------------------


IF(@AttributesIds ='')
    BEGIN
        SELECT @SQL='SELECT DISTINCT TypeDescription,ptype.ProductTypeId,CompanyName,PTYPE.CompanyID,PTYPE.CompanyTypeID,CompanyLogo ,PTYPE.OwnershipID
        ,WebVersion, 1 AS MatchOrder FROM #TEMP2 PTYPE WHERE SearchTypeDescription='+''''+@PRODUCTNAME+'''
        AND (dbo.ufn_DS_Get_IsDistributorRegion(PTYPE.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''') '
        + CASE WHEN @ProdcutIds<>'' THEN 'AND PTYPE.ProductTypeId IN ('+(SELECT @ProdcutIds)+')' ELSE '' END
        +' AND PTYPE.CompanyTypeID IN (1,2,3) '

        + 'UNION ALL

        SELECT DISTINCT TypeDescription,ptype.ProductTypeId,CompanyName,CompanyID,PTYPE.CompanyTypeID,CompanyLogo ,PTYPE.OwnershipID
        ,WebVersion, 2 AS MatchOrder FROM #TEMP2 PTYPE  WHERE ('+@STARTWITH+''+ '1=0' +') AND (SearchTypeDescription<>'+''''+@PRODUCTNAME+''')
        AND (dbo.ufn_DS_Get_IsDistributorRegion(PTYPE.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''')'
         + CASE WHEN @ProdcutIds<>'' THEN 'AND PTYPE.ProductTypeId IN ('+(SELECT @ProdcutIds)+')' ELSE '' END
        +' AND PTYPE.CompanyTypeID IN (1,2,3) '

        + 'UNION ALL

        SELECT DISTINCT TypeDescription,ptype.ProductTypeId,CompanyName,PTYPE.CompanyID,CompanyTypeID,CompanyLogo ,PTYPE.OwnershipID
        ,WebVersion, 2 AS MatchOrder FROM #TEMP2 PTYPE WHERE ('+@CONTAINS+''+ '1=0' +') AND (SearchTypeDescription<>'+''''+@PRODUCTNAME+''')
        AND ptype.ProductTypeId NOT IN(SELECT ptype.ProductTypeId FROM #TEMP2 PTYPE
        WHERE ('+@STARTWITH+''+ '1=0' +') AND (SearchTypeDescription<>'+''''+@PRODUCTNAME+'''))
        AND (dbo.ufn_DS_Get_IsDistributorRegion(PTYPE.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''') '
         + CASE WHEN @ProdcutIds<>'' THEN 'AND PTYPE.ProductTypeId IN ('+(SELECT @ProdcutIds)+')' ELSE '' END
        +' AND PTYPE.CompanyTypeID IN (1,2,3) '
    END

ELSE
    BEGIN
        SELECT @SQL='SELECT DISTINCT TypeDescription,ptype.ProductTypeId,CompanyName,PTYPE.CompanyID,CompanyTypeID,CompanyLogo ,PTYPE.OwnershipID
        ,WebVersion, 1 AS MatchOrder
        FROM #TEMP2 PTYPE
        JOIN dbo.CompanyOwnershipMapping CO1 (NOLOCK) ON CO1.CompanyID = PTYPE.CompanyID
        OR (CONVERT(VARCHAR,ISNULL(PTYPE.OwnershipID,''0'')) = ''0'' AND CompanyTypeID IN (1,3))
        JOIN (SELECT * FROM dbo.Split('''+@AttributesIds+''','','')) as Attributes
        ON CO1.OwnershipID = Attributes.items
        WHERE SearchTypeDescription='+''''+@PRODUCTNAME+'''
        AND (dbo.ufn_DS_Get_IsDistributorRegion(PTYPE.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''')'
        + CASE WHEN @ProdcutIds<>'' THEN 'AND PTYPE.ProductTypeId IN ('+(SELECT @ProdcutIds)+')' ELSE '' END
        +' AND PTYPE.CompanyTypeID IN (1,2,3) '
        + 'UNION ALL

        SELECT DISTINCT TypeDescription,ptype.ProductTypeId,CompanyName,PTYPE.CompanyID,CompanyTypeID,CompanyLogo ,PTYPE.OwnershipID
        ,WebVersion, 2 AS MatchOrder
        FROM #TEMP2 PTYPE
        JOIN dbo.CompanyOwnershipMapping CO1 (NOLOCK) ON CO1.CompanyID = PTYPE.CompanyID  OR (CONVERT(VARCHAR,ISNULL(PTYPE.OwnershipID,''0'')) = ''0'' AND CompanyTypeID IN (1,3))
        JOIN (SELECT * FROM dbo.Split('''+@AttributesIds+''','','')) as Attributes
        ON CO1.OwnershipID = Attributes.items
        WHERE ('+@STARTWITH+''+ '1=0' +') AND (SearchTypeDescription<>'+''''+@PRODUCTNAME+''')
        AND (dbo.ufn_DS_Get_IsDistributorRegion(PTYPE.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''') '
        + CASE WHEN @ProdcutIds<>'' THEN 'AND PTYPE.ProductTypeId IN ('+(SELECT @ProdcutIds)+')' ELSE '' END
        +' AND PTYPE.CompanyTypeID IN (1,2,3) '
        + 'UNION ALL

        SELECT DISTINCT TypeDescription,ptype.ProductTypeId,CompanyName,PTYPE.CompanyID,CompanyTypeID,CompanyLogo ,PTYPE.OwnershipID
        ,WebVersion, 2 AS MatchOrder
        FROM #TEMP2 PTYPE
        JOIN dbo.CompanyOwnershipMapping CO1 (NOLOCK) ON CO1.CompanyID = PTYPE.CompanyID  OR (CONVERT(VARCHAR,ISNULL(PTYPE.OwnershipID,''0'')) = ''0'' AND CompanyTypeID IN (1,3))
        JOIN (SELECT * FROM dbo.Split('''+@AttributesIds+''','','')) as Attributes
        ON CO1.OwnershipID = Attributes.items
        WHERE ('+@CONTAINS+''+ '1=0' +') AND (SearchTypeDescription<>'+''''+@PRODUCTNAME+''')
        AND ptype.ProductTypeId NOT IN(SELECT ptype.ProductTypeId FROM #TEMP2 PTYPE  WHERE ('+@STARTWITH+''+ '1=0' +')
        AND (SearchTypeDescription<>'+''''+@PRODUCTNAME+'''))
        AND (dbo.ufn_DS_Get_IsDistributorRegion(PTYPE.CompanyID,'''+@RegionIds+''') = 1 OR '''+@RegionIds+''' = '''') '
        + CASE WHEN @ProdcutIds<>'' THEN 'AND PTYPE.ProductTypeId IN ('+(SELECT @ProdcutIds)+')' ELSE '' END
        +' AND PTYPE.CompanyTypeID IN (1,2,3) '
    END

DECLARE @SQLCount varchar(max)

SET @SQLCount='SELECT Count(8) as TotRecords  FROM
    (SELECT distinct ProductTypeId FROM ('+ @SQL +') T) T2'

PRINT @SQLCount

Execute  (@SQLCount);

DROP TABLE #PRODLIST
DROP TABLE #TEMP1
DROP TABLE #TEMP2

END



GO
-------------------------------------------------------------------------------------------------------
-- Design Resources Count -----------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_BSK_getSearchResultDesignResource_Count]    Script Date: 05/25/2012 17:11:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_BSK_getSearchResultDesignResource_Count]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_BSK_getSearchResultDesignResource_Count]
GO

/****** Object:  StoredProcedure [dbo].[usp_BSK_getSearchResultDesignResource_Count]    Script Date: 05/25/2012 17:11:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[usp_BSK_getSearchResultDesignResource_Count]
    @SearchText	 VARCHAR(80)
    ,@ManufacturerIDs VARCHAR(5000) = ''
AS

BEGIN

    set transaction isolation level read uncommitted

    DECLARE @Query VARCHAR(8000) =''
    DECLARE @Manufacturer_Query VARCHAR(200) = ''
    DECLARE @SearchText1 varchar(8000)

    select @SearchText1=dbo.Splitor_part(@SearchText, ' ')

    IF(@ManufacturerIDs <> '')
        BEGIN
            SET @ManufacturerIDs = '' + REPLACE(@ManufacturerIDs,',',''',''') + ''
            SET @Manufacturer_Query = 'AND (comp.CompanyID IN ('''+@ManufacturerIDs+'''))'
        END



SET @Query ='SELECT  COUNT(DISTINCT prod.ProductID)
    FROM
    (
     select distinct pd.*
     from
            (select
            ProductID
            ,ManufacturerID
            ,SampleUrl
            ,VideoFilePath
            ,DataSheet
            ,ImageFilePath
            ,CASE WHEN ISNULL(DataSheet,'''') <> '''' THEN DataSheet ELSE
            CASE WHEN ISNULL(inv.MafSpecURL,'''')<> '''' THEN inv.MafSpecURL END END AS DataSheetLink
            ,dbo.ufn_BSK_CommaSaparatedResourceAppType (ProductID) AS AppNote
            ,dbo.ufn_BSK_CommaSaparatedResourceSoftType (ProductID) AS Software

            from product (nolock)
            LEFT JOIN [dbo].[InventorySettings] inv ON inv.CompanyID=ManufacturerID
            where ' + @SearchText1 + '
            )pd
             outer apply	(SELECT * FROM Split('''+@SearchText+''','' '')) AS search_term
            ) prod
            INNER JOIN [dbo].[Company] comp
                ON prod.ManufacturerID=comp.CompanyID
                    WHERE comp.IsActive = ''1''
                        AND comp.CompanyStatusID=''1''
                        AND (ISNULL(prod.SampleUrl, '''') <> ''''
                            OR ISNULL(prod.VideoFilePath,'''') <> ''''
                            OR ISNULL(prod.DataSheetLink,'''')<>''''
                            OR ISNULL(prod.ImageFilePath,'''')<>''''
                            OR ISNULL(prod.AppNote,'''')<>''''
                            OR ISNULL(prod.Software,'''')<>'''')'
                        + @Manufacturer_Query
        EXECUTE(@Query)
END

GO

-------------------------------------------------------------------------------------------------------
-- Manufacturer Count ---------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_SearchManufacturerWithUser_Count]    Script Date: 03/20/2012 20:00:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SearchManufacturerWithUser_Count]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_SearchManufacturerWithUser_Count]
GO

/****** Object:  StoredProcedure [dbo].[usp_SearchManufacturerWithUser_Count]    Script Date: 03/20/2012 20:00:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

------------------------------------Created By -- Deepti -- Creation Date -- 10-01-2012 ----------------------------------

CREATE PROCEDURE [dbo].[usp_SearchManufacturerWithUser_Count]
(
    @SEARCH VARCHAR(1000),
    @DIST_ID VARCHAR(100) = '',
    @USER_Region VARCHAR(100)= '',
    @USER_ZONE VARCHAR(100)= '0',
    @DIST_AUTH VARCHAR(100)= '0',
    @AttributesIds VARCHAR(100)= '',
    @IsFilterByRegion VARCHAR(10) = '0'
)
AS
 BEGIN

    set transaction isolation level read uncommitted

    IF(@DIST_ID IS NULL) BEGIN SET @DIST_ID = '' END
    IF(@USER_Region IS NULL) BEGIN SET @USER_Region = '' END
    IF(@USER_ZONE IS NULL) BEGIN SET @USER_ZONE = '' END
    IF(@DIST_AUTH IS NULL) BEGIN SET @DIST_AUTH = '' END
    IF(@IsFilterByRegion IS NULL) BEGIN SET @IsFilterByRegion = '' END

    DECLARE @MAIN_QUERY VARCHAR(8000)
    DECLARE @JoinAttributes VARCHAR(3000)=''

    Declare @IsEmptyDistIDs VARCHAR(1) = '0'
    Declare @IsEmptyRegionIDs VARCHAR(1) = '0'
    Declare @IsEmptyZoneIDs VARCHAR(1) = '0'


    IF(@DIST_ID = '') BEGIN SET @IsEmptyDistIDs = 1 END
    IF(@USER_Region = '') BEGIN SET @IsEmptyRegionIDs = 1 END
    IF(@USER_ZONE = '' ) BEGIN SET @IsEmptyZoneIDs = 1 END
    IF(@DIST_AUTH = '') BEGIN SET @DIST_AUTH = '0' END
    IF(@IsFilterByRegion = '') BEGIN SET @IsFilterByRegion = '0' END


    SET @DIST_ID = '' + REPLACE(@DIST_ID,',',''',''') + ''
    SET @USER_Region = '' + REPLACE(@USER_Region,',',''',''') + ''
    SET @USER_ZONE = '' + REPLACE(@USER_ZONE,',',''',''') + ''

    --Attributes
    IF((@AttributesIds IS NOT NULL) AND (@AttributesIds <> ''))
    BEGIN
    SET @JoinAttributes = 'INNER JOIN dbo.CompanyOwnershipMapping com
        ON com.CompanyID=reg_auth.DistID
        INNER JOIN (SELECT * FROM dbo.Split('''+@AttributesIds+''','','')) AS Attributes
        ON com.OwnershipID = Attributes.items'
    END

    SET @SEARCH = [dbo].VK_RemoveSpecialChars(@SEARCH)

SET @MAIN_QUERY = '
DECLARE @SEARCH_QUERY VARCHAR(300)
SET @SEARCH_QUERY = '''+@SEARCH+'''
        SELECT COUNT (DISTINCT mfr.CompanyID)
            FROM (SELECT * FROM dbo.Split(@SEARCH_QUERY,'' '')) AS search_term
                JOIN [dbo].[lm_seeline_manufacturer] AS mfr
                    ON mfr.Clean_CompanyName LIKE ''%'' + search_term.items + ''%''
                    OR mfr.Clean_AlsoKnownAs LIKE ''%'' + search_term.items + ''%''
                    OR mfr.Clean_BookName1 LIKE ''%'' + search_term.items + ''%''
                    OR mfr.Clean_Keyword1 LIKE ''%'' + search_term.items + ''%''
                    OR mfr.Clean_BookName2 LIKE ''%'' + search_term.items + ''%''
                    OR mfr.Clean_Keyword2 LIKE ''%'' + search_term.items + ''%''
                Left JOIN [dbo].[MFRAlsoKnownAs] also_know ON also_know.CompanyID = mfr.CompanyID
                Left JOIN [dbo].[RegionAuthorization] reg_auth ON reg_auth.IsActive = 1 AND reg_auth.MfrID = mfr.CompanyID
                LEFT JOIN (
                    Select
                        RZOS.MFRDistID,
                        MAX(case when (AuthStatusID  = 2 and C.Trusted_Disty=1) then 4 else AuthStatusID end) as MaxAuth,
                        sum(Print_Amount+Online_Amount) as Total
                    From
                        RegionZoneStatus (nolock) RZOS,
                        Company (nolock) C,
                        RegionAuthorization (nolock) RA
                    WHERE  RA.MfrDistID = RZOS.MfrDistID
                        AND RA.DistID=C.CompanyID
                        AND (RegionId in ('''+@USER_Region+''') OR '+@IsEmptyRegionIDs+' = 1)
                        AND (ZoneId in ('''+@USER_ZONE+''') OR '+@IsEmptyZoneIDs+' = 1)
                    group By RZOS.MfrDistID
                ) AS RZS
                    ON reg_auth.MfrDistID = RZS.MfrDistID
                Left JOIN Company dist ON reg_auth.DistID = dist.CompanyID
                    AND dist.IsActive =1 AND dist.CompanyStatusId = 1
                '+@JoinAttributes+'
                WHERE
                (reg_auth.DistID in('''+@DIST_ID+''') OR '+@IsEmptyDistIDs+' = 1)
                AND ('''+@DIST_AUTH+''' = 0 or RZS.MaxAuth = 4 or RZS.MfrDistID is null)
                AND ('''+@IsFilterByRegion+''' = 0 or MaxAuth = 4 or RZS.MfrDistID is null or Total > 0
                    OR (Select    1
                        From CompanyLocations CL, Country C
                        where
                            C.CountryID = CL.CountryID
                            AND reg_auth.DistID = CL.CompanyID
                            AND    (C.RegionID IN ('''+@USER_Region+''') OR '+@IsEmptyRegionIDs+' = 1)
                            AND LocationStatusID = 1  --  in @USER_Region
                            AND CL.IsActive = 1
                        group by CompanyID) = 1)'
Execute(@MAIN_QUERY)
END

/*
 DS_usp_SearchManufacturerWithUser_Count_WIP 'texas', '101842,121145,123637,101457', '1,2,6', '', '0', ''
*/


GO

-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP1 ---------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
/****** Object:  StoredProcedure [dbo].[usp_GetSearchFirstTenCompany]    Script Date: 01/10/2012 23:24:08 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchFirstTenCompany]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchFirstTenCompany]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchFirstTenCompany]    Script Date: 01/10/2012 23:24:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- Modified By : Fathima
-- Modified On : 09 Jan 2012
-- [usp_GetSearchFirstTenCompany] 1,'internal','Manufacturers','Top Manufacturers'
CREATE PROCEDURE [dbo].[usp_GetSearchFirstTenCompany]
(
    @CompanyTypeID  Int,
    @UserRole VARCHAR(20),
    @NavMenuName varchar(100),
    @SectionName varchar(100)
)
AS
CREATE TABLE #results
(
    CompanyName varchar(100),
    DisplayName varchar(50),
    CompanyID int,
    CompanyTypeID int,
    IsSponserLink bit
)

BEGIN
set transaction isolation level read uncommitted
insert into #results
select
    C.CompanyName,
    CASE WHEN len(c.companyname)>15 THEN left(c.companyname,12) + '...'
    ELSE c.companyname END AS 'DisplayName',
    C.CompanyID,
    CompanyTypeID,
    1
from
    sponserlinks T inner join Company C on C.CompanyID = T.TopLinkId1
    inner join CompanyTypeMapping CTM on CTM.Companyid = C.Companyid and CTM.CompanyTypeID = @CompanyTypeID
where
    T.TopLinkId1 != 0  and
    NavMenuName = @NavMenuName and
    SectionName = @SectionName

insert into #results
select
    C.CompanyName,
    CASE WHEN len(c.companyname)>15 THEN left(c.companyname,12) + '...'
    ELSE c.companyname END AS 'DisplayName',
    C.CompanyID,
    CompanyTypeID,
    1
from
    sponserlinks T inner join Company C on C.CompanyID = T.TopLinkId2
    inner join CompanyTypeMapping CTM on CTM.Companyid = C.Companyid and CTM.CompanyTypeID = @CompanyTypeID
where
    T.TopLinkId2 != 0  and
    NavMenuName = @NavMenuName and
    SectionName = @SectionName

insert into #results
    select C.CompanyName, CASE WHEN len(c.companyname)>15 THEN left(c.companyname,12) + '...'
    ELSE c.companyname END AS 'DisplayName',
    C.CompanyID,
    CompanyTypeID,
    1
from
    sponserlinks T inner join Company C on C.CompanyID = T.TopLinkId3
    inner join CompanyTypeMapping CTM on CTM.Companyid = C.Companyid and CTM.CompanyTypeID = @CompanyTypeID
where
    T.TopLinkId3 != 0  and
    NavMenuName = @NavMenuName and
    SectionName = @SectionName

IF (@UserRole = 'Internal')
    BEGIN
        insert into #results
        SELECT Distinct Top 10 c.companyname AS 'CompanyName',
            CASE WHEN len(c.companyname)>15 THEN left(c.companyname,12) + '...'
            ELSE c.companyname END AS 'DisplayName',
            c.companyid as 'CompanyID',
            CTM.CompanyTypeID as 'CompanyTypeID',
            0
        FROM
            Company c INNER JOIN CompanyTypeMapping CTM on CTM.Companyid = C.Companyid and CTM.CompanyTypeID = @CompanyTypeID
        WHERE
            c.IsActive = 1 AND
            c.CompanyStatusID = 1 and
            c.CompanyID not in (select CompanyID from #results)
        ORDER BY
            CompanyName
    END
ELSE
    BEGIN
        insert into #results
        SELECT Distinct Top 10 c.companyname AS 'CompanyName',
            CASE WHEN len(c.companyname)>15 THEN left(c.companyname,12) + '...'
            ELSE c.companyname END AS 'DisplayName',
            c.companyid as 'CompanyID',
            CTM.CompanyTypeID as 'CompanyTypeID',
            0
        FROM
            Company c INNER JOIN CompanyTypeMapping CTM on CTM.Companyid = C.Companyid and CTM.CompanyTypeID = @CompanyTypeID
        WHERE
            c.IsActive = 1 AND
            c.CompanyStatusID = 1 and
            c.CompanyID not in (select CompanyID from #results)
        ORDER BY
            CompanyName
    END
    select top 10 * from #results
END
GO


-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP2 ---------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
/****** Object:  StoredProcedure [dbo].[usp_ManageSponserLink]    Script Date: 01/10/2012 23:33:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_ManageSponserLink]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_ManageSponserLink]
GO


/****** Object:  StoredProcedure [dbo].[usp_ManageSponserLink]    Script Date: 01/10/2012 23:33:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--*****************************************************************************************************
--*   Stored Procedure  : [usp_ManageSponserLink] 'b','b',1,2,4
--*   Description  : Managing Sponser Links
--*   Author   : Fathima
--*   Creation Date  : 08/01/2012

CREATE PROCEDURE [dbo].[usp_ManageSponserLink]
(
    @Flag int,
    @NavMenuName varchar(50),
    @SectionName varchar(50),
    @TopLinkId1 int,
    @TopLinkId2 int,
    @TopLinkId3 int
 )
AS
Begin
    if @Flag = 1
    Begin
        IF (SELECT count(Id) FROM SponserLinks WHERE NavMenuName = @NavMenuName and SectionName=@SectionName) = 0
        BEGIN
             insert into SponserLinks(NavMenuName,SectionName,TopLinkId1,TopLinkId2,TopLinkId3)
             values (@NavMenuName,@SectionName,@TopLinkId1,@TopLinkId2,@TopLinkId3)
        End
        Else
        Begin
            RAISERROR('Already Exists',16,1)
        End
    End
    else if @Flag = 2
    Begin
        update
            SponserLinks
        set
            TopLinkId1=@TopLinkId1,
            TopLinkId2=@TopLinkId2,
            TopLinkId3=@TopLinkId3
        where
            NavMenuName = @NavMenuName and
            SectionName=@SectionName
    End
End
GO

-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP3 ---------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetSponserLinks]    Script Date: 02/03/2012 17:45:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSponserLinks]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSponserLinks]
GO


/****** Object:  StoredProcedure [dbo].[usp_GetSponserLinks]    Script Date: 02/03/2012 17:45:48 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Created By : Fathima
-- Created On : 10 Jan 2012
-- Description : To get all sponser links from sponserlinks table
CREATE procedure [dbo].[usp_GetSponserLinks]
as
create table #results
(
    Id int,
    NavMenuName varchar(100),
    SectionName varchar(100),
    TopLinkId1 int,
    SponserLinkName1 varchar(100),
    TopLinkId2 int,
    SponserLinkName2 varchar(100),
    TopLinkId3 int,
    SponserLinkName3 varchar(100)
)

insert into #results
select
    Id,
    NavMenuName,
    SectionName,
    TopLinkId1,
    '',
    TopLinkId2,
    '',
    TopLinkId3,
    ''
from
    SponserLinks

-- Manufacturer
update
    #results
set
     SponserLinkName1 = C.CompanyName
from
    Company C,
    CompanyTypeMapping CTM
where
     C.CompanyID = #results.TopLinkId1 and
    CTM.Companyid = C.Companyid and
    CTM.CompanyTypeID in (1,2,3)

update #results
set
    SponserLinkName2 = C.CompanyName
from
    Company C,
    CompanyTypeMapping CTM
where
    C.CompanyID = #results.TopLinkId2 and
    CTM.Companyid = C.Companyid and
    CTM.CompanyTypeID in (1,2,3)

update #results
set
    SponserLinkName3 = C.CompanyName
from
    Company C,
    CompanyTypeMapping CTM
where
    C.CompanyID = #results.TopLinkId3 and
    CTM.Companyid = C.Companyid and
    CTM.CompanyTypeID in (1,2,3)

 -- ProductType
update #results
set
    SponserLinkName1 = P.TypeDescription
from
    ProductType P
 where
    P.ProductTypeId = #results.TopLinkId1

 -- ProductType
update  #results
set
    SponserLinkName2 = P.TypeDescription
from
    ProductType P
where
    P.ProductTypeId = #results.TopLinkId2

        -- ProductType
update #results
set
    SponserLinkName3 = P.TypeDescription
from
    ProductType P
 where
    P.ProductTypeId = #results.TopLinkId3

select * from #results


GO
-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP4 ---------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetSponserLinkById]    Script Date: 01/10/2012 23:43:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSponserLinkById]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSponserLinkById]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSponserLinkById]    Script Date: 01/10/2012 23:43:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- Created By : Fathima
-- Created On : 10 Jan 2012
-- Description : To get all sponser links from sponserlinks table
-- Sample : usp_GetSponserLinkById 2
CREATE procedure [dbo].[usp_GetSponserLinkById](@Id int)
as
select
    Id,
    NavMenuName,
    SectionName,
    TopLinkId1,
    TopLinkId2,
    TopLinkId3
from
    sponserlinks
where
    Id=@Id

GO

-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP5 ---------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetSearchTopTenManufacturer]    Script Date: 01/10/2012 23:45:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchTopTenManufacturer]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchTopTenManufacturer]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchTopTenManufacturer]    Script Date: 01/10/2012 23:45:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- Modified By :  Fathima
-- Modified On: 10 Jan 2012

CREATE PROCEDURE [dbo].[usp_GetSearchTopTenManufacturer]
AS
    declare @NavMenuName varchar(50) = 'Manufacturers'
    declare @SectionName varchar(50) = 'Top Manufacturers'
    CREATE TABLE #results
    (
        CompanyID int,
        CompanyName varchar(100),
        DisplayName varchar(50),
        CompanyTypeID int,
        IsSponserLink bit
    )
    BEGIN
        set transaction isolation level read uncommitted
        insert into #results
        select
            C.CompanyID,
            C.CompanyName,
            CASE WHEN len(c.companyname)>15 THEN left(c.companyname,12) + '...'
                ELSE c.companyname END AS 'DisplayName',
            CompanyTypeID,
            1
        from
            sponserlinks T inner join Company C on C.CompanyID = T.TopLinkId1
            inner join CompanyTypeMapping CTM on CTM.Companyid = C.Companyid and CTM.CompanyTypeID = 1
        where
            T.TopLinkId1 != 0  and
            NavMenuName = @NavMenuName and
            SectionName = @SectionName

        insert into #results
        select
            C.CompanyID,
            C.CompanyName,
            CASE WHEN len(c.companyname)>15 THEN left(c.companyname,12) + '...'
                ELSE c.companyname END AS 'DisplayName',
            CompanyTypeID,
            1
        from
            sponserlinks T inner join Company C on C.CompanyID = T.TopLinkId2
            inner join CompanyTypeMapping CTM on CTM.Companyid = C.Companyid and CTM.CompanyTypeID = 1
        where
            T.TopLinkId2 != 0  and
            NavMenuName = @NavMenuName and
            SectionName = @SectionName

        insert into #results
        select
            C.CompanyID,
            C.CompanyName,
            CASE WHEN len(c.companyname)>15 THEN left(c.companyname,12) + '...'
                ELSE c.companyname END AS 'DisplayName',
            CompanyTypeID,
            1
        from
            sponserlinks T inner join Company C on C.CompanyID = T.TopLinkId3
            inner join CompanyTypeMapping CTM on CTM.Companyid = C.Companyid and CTM.CompanyTypeID = 1
        where
            T.TopLinkId3 != 0  and
            NavMenuName = @NavMenuName and
            SectionName = @SectionName

        insert into #results
        SELECT
            TOP 10 CompanyID,
            CompanyName,
            CASE WHEN len(CompanyName)>15
                THEN left(CompanyName,12) + '...'
                ELSE CompanyName
                END AS 'DisplayName',
            1 as CompanyTypeID,0
        FROM
            (
                SELECT
                    top 10 AO.CompanyID as CompanyID,
                    C.CompanyName as CompanyName,
                    SUM(AO.GrossAmount) As 'Amount',
                    0 as CompOrder
                FROM
                    AdOrder AO
                    INNER JOIN Company C ON AO.CompanyID=C.CompanyID
                    INNER JOIN CompanyTypeMapping CTM ON C.CompanyID=CTM.CompanyID
                    AND CTM.CompanyTypeID = 1 --> (1: Manufacturer)
                where
                    C.IsActive = 1 AND
                    C.companyStatusID = 1 and
                    AO.StatusId = 1
                Group BY
                    C.CompanyName,AO.CompanyID ORDER BY Amount DESC
                Union ALL
                SELECT
                    top 10 C.CompanyID as CompanyID,
                    C.CompanyName as CompanyName,
                    0 As 'Amount',
                    1 as CompOrder
                FROM
                    Company C
                    INNER JOIN CompanyTypeMapping CTM ON C.CompanyID=CTM.CompanyID
                    AND CTM.CompanyTypeID = 1 --> (1: Manufacturer)
                where
                    C.IsActive = 1 AND
                    C.companyStatusID = 1
                Order BY
                    C.CompanyName
            ) as A
        where
            CompanyID not in (select CompanyID from #results)
        ORDER BY Amount DESC,CompanyName ASC

    select top 10 * from #results
END
GO

-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP6 -------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetSearchTopTenDistVendor]    Script Date: 01/31/2012 13:42:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchTopTenDistVendor]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchTopTenDistVendor]
GO
/****** Object:  StoredProcedure [dbo].[usp_GetSearchTopTenDistVendor]    Script Date: 01/31/2012 13:42:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchTopTenDistVendor]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- Modified By : Fathima
-- Modified On : 31 Jan 2012

CREATE PROCEDURE [dbo].[usp_GetSearchTopTenDistVendor]
AS
    declare @NavMenuName varchar(50) = ''Distributors / Vendors''
    declare @SectionName varchar(50) = ''Top Distributors & Vendors''
    CREATE TABLE #results
    (
        CompanyID int,
        CompanyName varchar(100),
        DisplayName varchar(50),
        CompanyTypeID int,
        Amount decimal,
        IsSponserLink bit
    )
BEGIN
    set transaction isolation level read uncommitted
    insert into #results
    select top 1
        C.CompanyID,
        C.CompanyName,
        CASE WHEN len(c.companyname)>15 THEN left(c.companyname,12) + ''...''
            ELSE c.companyname END AS ''DisplayName'',
        CompanyTypeID,
        0,
        1
    from
        sponserlinks T
        inner join Company C on C.CompanyID = T.TopLinkId1
        inner join CompanyTypeMapping CTM on CTM.Companyid = C.Companyid and CTM.CompanyTypeID in (2,3)
    where
        T.TopLinkId1 != 0  and
        NavMenuName = @NavMenuName and
        SectionName = @SectionName
        order by CTM.CompanyTypeID

    insert into #results
    select top 1
        C.CompanyID,
        C.CompanyName,
        CASE WHEN len(c.companyname)>15 THEN left(c.companyname,12) + ''...''
            ELSE c.companyname END AS ''DisplayName'',
        CompanyTypeID,
        0,
        1
    from
        sponserlinks T
        inner join Company C on C.CompanyID = T.TopLinkId2
        inner join CompanyTypeMapping CTM on CTM.Companyid = C.Companyid and CTM.CompanyTypeID in (2,3)
    where
        T.TopLinkId2 != 0  and
        NavMenuName = @NavMenuName and
        SectionName = @SectionName
        order by CTM.CompanyTypeID

    insert into #results
    select top 1
        C.CompanyID,
        C.CompanyName,
        CASE WHEN len(c.companyname)>15 THEN left(c.companyname,12) + ''...''
            ELSE c.companyname END AS ''DisplayName'',
        CompanyTypeID,
        0,
        1
    from
        sponserlinks T
        inner join Company C on C.CompanyID = T.TopLinkId3
        inner join CompanyTypeMapping CTM on CTM.Companyid = C.Companyid and CTM.CompanyTypeID in (2,3)
    where
        T.TopLinkId3 != 0  and
        NavMenuName = @NavMenuName and
        SectionName = @SectionName
        order by CTM.CompanyTypeID

    insert into #results
    SELECT
        TOP 10 CompanyID,
        CompanyName AS CompanyName,
        CASE WHEN len(CompanyName)>15
            THEN left(CompanyName,12) + ''...'' ELSE CompanyName END AS ''DisplayName'',
        max(CompanyTypeID) as CompanyTypeID,
        max(Amount) as Amount,
        0
    FROM
        (
            SELECT
                TOP 10 AO.CompanyID,
                C.CompanyName,
                SUM(AO.GrossAmount) As ''Amount'',
                0 as CompOrder,
                max(CompanyTypeID) as CompanyTypeID
            FROM
                AdOrder AO
                INNER JOIN Company C ON AO.CompanyID=C.CompanyID
                INNER JOIN CompanyTypeMapping CTM ON C.CompanyID=CTM.CompanyID
                    AND CTM.CompanyTypeID in (2,3) --> (2: Distributor / 3: Vendors)
            WHERE
                C.IsActive = 1 AND
                C.companyStatusID = 1 and
                AO.StatusId = 1
            GROUP BY
                C.CompanyName,AO.CompanyID
            ORDER BY
                Amount DESC
            Union ALL
            SELECT
                TOP 10 C.CompanyID as CompanyID,
                C.CompanyName as CompanyName,
                0 As ''Amount'',
                1 as CompOrder,
                max(CompanyTypeID) as CompanyTypeID
            FROM
                Company C
                INNER JOIN CompanyTypeMapping CTM ON C.CompanyID=CTM.CompanyID AND CTM.CompanyTypeID in (2,3) --> (1: Manufacturer)
            WHERE
                C.IsActive = 1 AND
                C.companyStatusID = 1
            GROUP BY
                C.CompanyName,C.CompanyID
            ORDER BY
                C.CompanyName
        ) as A
    where
        CompanyID not in (select CompanyID from #results)
    GROUP BY
        CompanyID, CompanyName
    ORDER BY
        Amount DESC, CompanyName
 select top 10 * from #results

END  '
END
GO

-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP7 -------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetSearchFirstTenProductTypeService]    Script Date: 01/13/2012 13:57:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchFirstTenProductTypeService]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchFirstTenProductTypeService]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchFirstTenProductTypeService]    Script Date: 01/13/2012 13:57:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- Modified By : Fathima
-- Modified On : 12 Jan 2012

CREATE PROCEDURE [dbo].[usp_GetSearchFirstTenProductTypeService]
AS
declare @NavMenuName varchar(100) = 'Distributors / Vendors'
declare @SectionName varchar(100) = 'By Products & Services'

CREATE TABLE #results
(
    ProductTypeID int,
    ProductType varchar(100),
    DisplayName varchar(50),
    [Master] varchar(50),
    IsSponserLink bit
)

BEGIN
set transaction isolation level read uncommitted
insert into #results
select
    ProductTypeID,
    ltrim(rtrim(TypeDescription)) as ProductType,
    CASE WHEN len(ltrim(rtrim(TypeDescription)))>15 THEN left(TypeDescription,12) + '...' ELSE TypeDescription END AS 'DisplayName','ProductTypeMaster',1
from
    sponserlinks T inner join ProductType P on P.ProductTypeId = T.TopLinkId1
where
    T.TopLinkId1 != 0  and
    NavMenuName = @NavMenuName and
    SectionName = @SectionName

insert into #results
select
    ProductTypeID,
    ltrim(rtrim(TypeDescription)) as ProductType,
    CASE WHEN len(ltrim(rtrim(TypeDescription)))>15 THEN left(TypeDescription,12) + '...' ELSE TypeDescription END AS 'DisplayName','ProductTypeMaster',1
from
    sponserlinks T inner join ProductType P on P.ProductTypeId = T.TopLinkId2
where
    T.TopLinkId2 != 0  and
    NavMenuName = @NavMenuName and
    SectionName = @SectionName

insert into #results
select
    ProductTypeID,
    ltrim(rtrim(TypeDescription)) as ProductType,
    CASE WHEN len(ltrim(rtrim(TypeDescription)))>15 THEN left(TypeDescription,12) + '...' ELSE TypeDescription END AS 'DisplayName','ProductTypeMaster',1
from
    sponserlinks T  inner join ProductType P on P.ProductTypeId = T.TopLinkId3
where
    T.TopLinkId3 != 0  and
    NavMenuName = @NavMenuName and
    SectionName = @SectionName

insert into #results
 SELECT TOP 10 ProductTypeID,ProductType,DisplayName,Master,0 from (
 SELECT TOP 10 ProductTypeID as 'ProductTypeID', TypeDescription as 'ProductType',
 CASE WHEN len(TypeDescription)>15 THEN left(TypeDescription,12) + '...'
 ELSE TypeDescription END AS 'DisplayName','ProductTypeMaster' as 'Master'
 FROM ProductType
 WHERE IsActive = 1 AND StatusID=1
 Union ALL
 SELECT TOP 10 ProductTypeId as 'ProductTypeID',TypeDescription as 'ProductType',
 CASE WHEN len(TypeDescription)>15 THEN left(TypeDescription,12) + '...' ELSE TypeDescription END AS 'DisplayName',
 'ServicesMaster' as 'Master'
 FROM ProductType
 WHERE IsServices = 1) as A
 where ProductTypeId not in (select ProductTypeId from #results)
 ORDER BY ProductType

select top 10 * from #results

END
GO

-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP8 -------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetZonelStatus]    Script Date: 01/14/2012 21:22:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetZonelStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetZonelStatus]
GO


/****** Object:  StoredProcedure [dbo].[usp_GetZonelStatus]    Script Date: 01/14/2012 21:22:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- Modified By : Fathima
-- Modified On : 13-01-2012

CREATE PROCEDURE [dbo].[usp_GetZonelStatus]
(
    @Manufacturer int,
    @Distributor int,
    @RegionID int
)
AS
create table #results
(
    RegionId int,
    RegionName varchar(100),
    ZoneId int,
    ZoneName varchar(100),
    AuthStatusID int,
    DDays int
)
BEGIN
set transaction isolation level read uncommitted
/* Added by fathima */
insert into #results
select
    R.RegionID,
    RegionName,
    ZoneID,
    ZoneName,
    cast(1 as int) as AuthStatusID,
    null as 'DDays'
from
    Region R
    left outer join Country C on C.RegionID = R.RegionID
    inner join CountryZones CZ on CZ.CountryID = C.CountryID

insert into #results
select
    C.RegionID,
    RegionName,
    CountryID as ZoneId,
    CountryName as ZoneName,
    cast(1 as int) as AuthStatusID,
    null as 'DDays'
from
    Country C with(nolock) inner join Region R on R.RegionID = C.RegionID
where
    C.RegionID not in (select RegionID from #results)
    and C.RegionID not in (0,2)

select
    distinct RS.RegionId,
    ZoneID,
    AuthStatusID,
    'DDays' = DATEDIFF(day, RS.Denied_Date, GETDATE()),
    RA.MfrID,RA.DistID
into
    #b
from
    RegionZoneStatus RS
    inner join RegionAuthorization RA on RA.MfrDistID = RS.MfrDistID
where
    distid=@Distributor
    and MfrID=@Manufacturer

update #results
set
    AuthStatusID = b.AuthStatusID,
    DDays= b.DDays
from
    #b b
where
    #results.RegionId = b.RegionId
    and #results.ZoneId = b.ZoneId

select
    RegionId,
    ZoneID,
    AuthStatusID,
    isnull(DDays,0) as 'Days'
from
    #results
where
    RegionID =  @RegionID
order by
    ZoneName

End
GO
-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP9 -------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetDistLineCards]    Script Date: 01/14/2012 21:32:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetDistLineCards]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetDistLineCards]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetDistLineCards]    Script Date: 01/14/2012 21:32:48 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- Created By: Fathima
-- Created On: 20-10-2011
-- Purpose: Getting Distributor line cards.
-- Sample: [usp_GetDistLineCards] 100068

CREATE PROCEDURE [dbo].[usp_GetDistLineCards] --130237
(
    @distID int
)
AS
BEGIN
set transaction isolation level read uncommitted
CREATE TABLE #tempTable
(
    mfrid int,
    distid int,
    regionid int,
    regionname varchar(100),
    zoneid int,
    zonename varchar(100),
    authstatusid int,
    [days] int
)

create table #tmpZ
(
    RegionID int,
    RegionName varchar(100),
    ZoneCnt int
)

insert into #tmpZ
select
    R.RegionID,
    RegionName,
    COUNT(zoneId) as ZoneCnt
from
    Region R with(nolock)
    inner join Country C with(nolock) on C.RegionID = R.RegionID
    inner join CountryZones CZ with(nolock) on CZ.CountryID = C.CountryID
where
    R.RegionID != 0
group by
    R.RegionID,RegionName

insert into #tmpZ
select
    C.RegionID,
    RegionName,
    count(CountryID) as ZoneCnt
from
    Country C with(nolock),
    Region R with(nolock)
where
    C.RegionID not in (select RegionID from #tmpZ)
    and C.RegionID != 0
    and C.RegionID = R.RegionID
group by
    C.RegionID,RegionName

insert into #tmpZ
select
    RegionId,
    RegionName,0 as ZoneCnt
from
    Region with(nolock)
where
    RegionID != 0
    and RegionID not in (select RegionID from #tmpZ)

DECLARE @mfrid INT
DECLARE @regionname varchar(100)

if (select COUNT(*) from RegionAuthorization where DistID = @distID) > 0
begin
    DECLARE CursorRegionZoneStatus CURSOR FAST_FORWARD FOR
    SELECT DISTINCT MfrID
    FROM
        RegionZoneStatus rz with(nolock)
        INNER JOIN RegionAuthorization ra with(nolock) ON rz.MfrDistID = ra.MfrDistID
    WHERE
        DistID = @distid

    OPEN CursorRegionZoneStatus
    FETCH NEXT FROM CursorRegionZoneStatus INTO @mfrid

    WHILE @@FETCH_STATUS = 0
    BEGIN
        insert into #tempTable
        select
            ra.mfrid,
            ra.distid,
            rz.regionid,
            r.regionname,
            rz.zoneid,
            'zonename'=null,
            rz.authstatusid,
            'Days' = DATEDIFF(day, rz.Denied_Date, GETDATE())
        from
            regionzonestatus rz with(nolock)
            inner join region r with(nolock) on rz.regionid = r.regionid
            inner join regionauthorization ra with(nolock) on rz.mfrdistid = ra.mfrdistid
        where
            ra.mfrid = @mfrid
            AND ra.distid = @distid

        insert into #tempTable
        select
            'mfrid'=@mfrid,
            'distid'=@distid,
            r.regionid,
            r.regionname,
            'zoneid'=null,
            'zonename'=null,
            'authstatusid'=0,
            'days'=0
        from
            region r with(nolock)
        where
            regionname COLLATE DATABASE_DEFAULT not in (select regionname from #tempTable t where mfrid = @mfrid and distid = @distid)

        FETCH NEXT FROM CursorRegionZoneStatus INTO @mfrid
    END
    CLOSE CursorRegionZoneStatus

    DEALLOCATE CursorRegionZoneStatus


CREATE TABLE #tempZone
(
    mfrid int,
    distid int,
    regionid int,
    regionname varchar(100),
    zoneid int,
    zonename varchar(100),
    authstatusid int,
    [days] int
)

DECLARE @mid INT
DECLARE @did INT
DECLARE @regid INT
DECLARE @regname varchar(100)

DECLARE CursorZone CURSOR FAST_FORWARD FOR
SELECT DISTINCT
    mfrid,
    distid,
    regionid,
    regionname
FROM
    #tempTable --#tempZone2

OPEN CursorZone
FETCH NEXT FROM CursorZone INTO @mid, @did, @regid, @regname

WHILE @@FETCH_STATUS = 0
BEGIN
    INSERT INTO #tempZone
    SELECT
        mfrid, distid, regionid,
        RegionName, zoneid, ZoneName, authstatusid, [days]
    FROM #tempTable --#tempZone2
    WHERE mfrid = @mid and distid = @did and regionid = @regid and regionname = @regname

    declare @cnt int
    select
        @cnt=count(zoneid)
    from
        countryzones with(nolock),
        country with(nolock)
    where
        countryzones.countryid=country.countryid
        and country.regionid !=0
        and country.regionid=@regid
    if(@cnt=0)
    begin
        insert into #tempZone
        select
            'mfrid' = @mid,
            'distid' = @did,
            'regiondid' =@regid,
            'RegionName' = @regname,
            countryid as zoneid,
            countryname as zonename,
            'authstatusid'=0,
            'days'=0
        from
            country with(nolock)
        where
            country.regionid !=0 and
            country.regionid !=2 and
            country.regionid=@regid and
            isActive=1 and
            countryid not in (select zoneid from #tempZone where mfrid = @mid and distid = @did and regionid = @regid and regionname = @regname)
    end
    else
    begin
        insert into #tempZone
        select
            'mfrid' = @mid,
            'distid' = @did,
            'regiondid' =@regid,
            'RegionName' = @regname,
            zoneid,
            zonename,
            'authstatusid'=0,
            'days'=0
        from
            countryzones with(nolock),
            country with(nolock)
        where
            countryzones.countryid=country.countryid and
            country.regionid !=0 and
            country.regionid !=2 and
            country.regionid=@regid and
            zoneid not in (select zoneid from #tempZone where mfrid = @mid and distid = @did and regionid = @regid and regionname = @regname)
    end

    FETCH NEXT FROM CursorZone
    INTO @mid, @did, @regid, @regname
END

CLOSE CursorZone
DEALLOCATE CursorZone


 select
    mfrid,
    distid,
    b.regionid,
    b.RegionName,
    case when (AuthSub = 2 and (c.ZoneCnt - b.AuthSubCnt) = 0) then 4 --'countryblue'
        when  (AuthSub = 2 and (c.ZoneCnt - b.AuthSubCnt) > 0 and b.regionid <> 2) then 3--'Partialyauthorize'
        when (AuthSub = 3 and (c.ZoneCnt - b.AuthSubCnt) = 0) then 2 --'countryred'
        when (AuthSub = 2 and (c.ZoneCnt - b.AuthSubCnt) = c.ZoneCnt)
    then case when (AuthSub = 3 and (c.ZoneCnt - b.AuthSubCnt) = 0) then 2--'countryred'
    else 1--'countrywhite'
    end
        when (AuthSub = 2 and (c.ZoneCnt - b.AuthSubCnt) = 0 and b.regionid =2) then 4  --'countryblue'
        when  (AuthSub = 2 and (c.ZoneCnt - b.AuthSubCnt) > 0 and b.regionid = 2) then 4--'countryblue'
        when  (AuthSub = 3 and (c.ZoneCnt - b.AuthSubCnt) = 0 and b.regionid = 2) then 3--'countryred'
    else 1--'countrywhite'
    end as AuthImageStatus
into #t
from
    (select MfrID,distid,regionid,RegionName,AuthSub,COUNT(isnull(AuthSub,0)) as AuthSubCnt
    from (SELECT
        mfrid, distid, regionid,
        'RegionName' = REPLACE(RegionName, ' ', ''),
        zoneid,
        'ZoneName'= ISNULL([dbo].[GetZoneName](regionid, zoneid), Zonename),
        authstatusid,
        case when (authstatusid = 1 OR authstatusid = 5)
        then 1
        when (authstatusid = 2 OR authstatusid = 4) then 2
        when authstatusid = 3 then 3
        else 1 end as AuthSub,
        [days]
        FROM #tempZone
    )
    a
    group by distid,mfrid,regionid,RegionName,AuthSub) b
    inner join (select * from #tmpZ) c on c.RegionID = b.regionid


select distinct RegionId,RegionName into #tcol from #t


select mfrid,RegionName,max(AuthImageStatus) as ImageStatus into #tt from #t group by mfrid,RegionName

DECLARE @cols NVARCHAR(2000)
SELECT  @cols = COALESCE(@cols + ',[' + RegionName + ']',
                         '[' + RegionName + ']')
FROM    #tcol
order by regionid




declare @str as varchar(max)
set @str = 'select mfrid,companyname as MfrName,CompanyDescription as MfrDesc,distid,' + @cols + ',publish
into #rr from (select t.mfrid,t1.distid,t.regionname,t1.regionId,ImageStatus,companyname,publish,cast(CompanyDescription as varchar) as CompanyDescription
 from #tt t inner join #t t1 on t1.mfrid = t.mfrid inner join Company C with(nolock) on C.companyId = t.mfrid inner join RegionAuthorization r with(nolock) on r.MfrID = t.mfrid and r.DistID = t1.distid '
 set @str = @str + ' where c.companystatusid=1 and c.isactive=1 and r.isactive=1)'
 set @str = @str + ' p pivot (max(ImageStatus) for RegionName in (' + @cols + ') ) as pvt '
set @str = @str + 'select distinct * from #rr order by MfrName'
print(@str)
exec(@str)





DROP TABLE #tempZone


DROP TABLE #tempTable
end

else
begin

select distinct RegionId,RegionName into #tcol1 from #tmpZ order by RegionID

DECLARE @cols1 NVARCHAR(2000)
SELECT  @cols1 = COALESCE(@cols1 + ',[' + RegionName + ']',
                         '[' + RegionName + ']')
FROM    #tcol1
order by regionid
declare @str1 as varchar(max)
set @str1 = 'select 0 as mfrid,'''' as MfrName,'''' as MfrDesc,0 as distid,' + @cols1 + ',0 as publish
into #rr from (select t.regionid,t.regionname from #tcol1 t)'
set @str1 = @str1 + ' p pivot (max(regionid) for RegionName in (' + @cols1 + ') ) as pvt '

set @str1 = @str1 + 'delete from #rr '
set @str1 = @str1 + 'select * from #rr'

exec(@str1)
end

END


GO


-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP 10 -----------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetZonesFromRegion]    Script Date: 01/13/2012 15:00:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetZonesFromRegion]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetZonesFromRegion]
GO


/****** Object:  StoredProcedure [dbo].[usp_GetZonesFromRegion]    Script Date: 01/13/2012 15:00:49 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:        Kiran. B. S
-- Create date: 30/10/2011
-- Description:    This procedure is to get zones from Region
-- =============================================
-- =============================================
-- Author:        Kiran Sangoi
-- Modify date: 13/Jan/2012
-- Description:    Edited so that distinct values of ZoneID are returned &
-- removed ZipTo & ZipFrom which are not used in the front end
-- =============================================
-- usp_GetZonesFromRegion ',1'
CREATE PROCEDURE [dbo].[usp_GetZonesFromRegion]
(
    @RegionID VARCHAR(1000)
)
AS
BEGIN
    SET NOCOUNT ON;
    set transaction isolation level read uncommitted
SELECT RegionID, Z.CountryID, C.CountryCode, C.CountryName, ZoneID FROM Country C
    INNER JOIN CountryZones Z
    ON Z.CountryID = C.CountryID
    WHERE CONVERT(VARCHAR, C.RegionID) IN (SELECT items FROM Split(@RegionID,','))
END

GO
-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP 11 -----------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetZoneList]    Script Date: 01/16/2012 20:35:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetZoneList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetZoneList]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetZoneList]    Script Date: 01/16/2012 20:35:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- Modified By : Fathima
-- Modified On : 16-01-2012

CREATE procedure [dbo].[usp_GetZoneList](@RegionID int)
as

create table #results
(
    RegionId int,
     ZoneId int,
    ZoneName varchar(100)
 )
BEGIN
set transaction isolation level read uncommitted
/* Added by fathima */
insert into #results
select
    R.RegionId,
    ZoneID,
    ZoneName
from
    Region R
    left outer join Country C on C.RegionID = R.RegionID
    inner join CountryZones CZ on CZ.CountryID = C.CountryID

insert into #results
select
    C.RegionID,
    CountryID as ZoneId,
    CountryName as ZoneName
 from
    Country C with(nolock) inner join Region R on R.RegionID = C.RegionID
where
    C.RegionID not in (select RegionID from #results)
    and C.RegionID not in (0,2)

select ZoneId,ZoneName from #results where RegionId != 2 and RegionId = @RegionID
order by ZoneName
end
GO

-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP 12 -----------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_UpdateDistRegionZoneStatus]    Script Date: 01/19/2012 15:35:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_UpdateDistRegionZoneStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_UpdateDistRegionZoneStatus]
GO


/****** Object:  StoredProcedure [dbo].[usp_UpdateDistRegionZoneStatus]    Script Date: 01/19/2012 15:35:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- Created By: Fathima
-- Created On: 29-11-2011
-- Purpose: Updating zone status thro distributors page.
-- Sample: usp_UpdateDistRegionZoneStatus

CREATE proc [dbo].[usp_UpdateDistRegionZoneStatus](@MfrId int,@DistZoneList varchar(max))
as
Begin
-- @importData XML <- stored procedure param
DECLARE @l_index1 INT

create table #tmp
(
    DistId int,
    RegionName varchar(100),
    ZoneId int,
    AuthStatusId int
)


 EXECUTE sp_xml_preparedocument @l_index1 OUTPUT, @DistZoneList

INSERT INTO #tmp (DistId,RegionName,ZoneId,AuthStatusId)
SELECT
    DistId,
    RegionName,
    ZoneId,
    AuthStatusId
FROM OPENXML(@l_index1, 'NewDataSet/ZoneList', 2)
    WITH
    (DistId int,RegionName varchar(100),ZoneId int,AuthStatusId int)

EXECUTE sp_xml_removedocument @l_index1

 insert into RegionZoneStatus
select
    a.MfrDistID,
    a.RegionID,
    a.ZoneId,
    1,
    null,
    null,
    null,
    null
from
    (select z1.MfrDistID,r.RegionID,t1.ZoneId,
        cast(MfrDistID as varchar) + '-' + cast(r.RegionID as varchar) + '-' + cast(t1.ZoneID as varchar) as RegZone from #tmp t1,region r,RegionAuthorization z1
    where
        t1.DistId = z1.DistID and
        z1.MfrID = @MfrId and
        Rtrim(REPLACE(t1.RegionName COLLATE DATABASE_DEFAULT, ' ', '')) = Rtrim(REPLACE(r.RegionName COLLATE DATABASE_DEFAULT, ' ', ''))

    ) a
where
    a.RegZone not in
        (select cast(s.MfrDistID as varchar)+ '-' + cast(s.RegionID as varchar) + '-' + cast(s.ZoneID as varchar) as RegZone from RegionZoneStatus s, RegionAuthorization z
        where
            s.MfrDistID = z.MfrDistID
            and z.MfrDistID in (select MfrDistID from #tmp t, RegionAuthorization a
                                where a.DistID = t.DistId and a.MfrID = @MfrId)
        )

select
    R.MfrDistID,
    t.ZoneId,
    S.RegionID,
    t.AuthStatusID,
    t.DistId,
    R.MfrID into #tt
from
    #tmp t
    inner join Region G on Rtrim(REPLACE(G.RegionName COLLATE DATABASE_DEFAULT, ' ', '')) = Rtrim(REPLACE(t.RegionName COLLATE DATABASE_DEFAULT, ' ', ''))
    inner join RegionAuthorization R on R.DistID = t.DistId
    inner join  RegionZoneStatus S on S.RegionID = G.RegionID and S.MfrDistID = R.MfrDistID and S.ZoneID = t.ZoneId
where
    R.MfrID = @MfrId

select
    R.MfrDistID,
    t.ZoneId,
    S.RegionID,
    t.AuthStatusID,
    t.DistId,
    R.MfrID into #ttC
from #tmp t
    inner join Region G on Rtrim(REPLACE(G.RegionName COLLATE DATABASE_DEFAULT, ' ', '')) = Rtrim(REPLACE(t.RegionName COLLATE DATABASE_DEFAULT, ' ', ''))
    inner join RegionAuthorization R on R.DistID = t.DistId
    inner join  RegionZoneStatus S on S.RegionID = G.RegionID and S.MfrDistID = R.MfrDistID-- and S.ZoneID = t.ZoneId
where
    R.MfrID = @MfrId and
    S.RegionID = 2

update RegionZoneStatus
set AuthStatusID=t.AuthStatusId,Authorized_Date=getdate()
from #tt t
where
    RegionZoneStatus.MfrDistID=t.MfrDistID and
    RegionZoneStatus.RegionID = t.RegionID and
    RegionZoneStatus.ZoneID = t.ZoneId and
    RegionZoneStatus.AuthStatusID != t.AuthStatusId and
    t.AuthStatusId = 4

update RegionZoneStatus
set AuthStatusID=t.AuthStatusId,Denied_Date=getdate()
from #tt t
where
    RegionZoneStatus.MfrDistID=t.MfrDistID and
    RegionZoneStatus.RegionID = t.RegionID and
    RegionZoneStatus.ZoneID = t.ZoneId and
    RegionZoneStatus.AuthStatusID != t.AuthStatusId and
    t.AuthStatusId = 3

update RegionZoneStatus
set AuthStatusID=t.AuthStatusId
from #tt t
where
    RegionZoneStatus.MfrDistID=t.MfrDistID and
    RegionZoneStatus.RegionID = t.RegionID and
    RegionZoneStatus.ZoneID = t.ZoneId and
    RegionZoneStatus.AuthStatusID != t.AuthStatusId and
    t.AuthStatusId not in (3,4)

update RegionZoneStatus
set AuthStatusID=t.AuthStatusId,Authorized_Date=getdate()
from #ttC t
where
    RegionZoneStatus.MfrDistID=t.MfrDistID and
    RegionZoneStatus.RegionID = t.RegionID and
    RegionZoneStatus.AuthStatusID != t.AuthStatusId
    and RegionZoneStatus.RegionID = 2 and
    t.AuthStatusId = 4

update RegionZoneStatus
set AuthStatusID=t.AuthStatusId,Denied_Date=getdate()
from #ttC t
where
    RegionZoneStatus.MfrDistID=t.MfrDistID and
    RegionZoneStatus.RegionID = t.RegionID and
    RegionZoneStatus.AuthStatusID != t.AuthStatusId and
    RegionZoneStatus.RegionID = 2 and
    t.AuthStatusId = 3

update RegionZoneStatus
set AuthStatusID=t.AuthStatusId
from #ttC t
where
    RegionZoneStatus.MfrDistID=t.MfrDistID and
    RegionZoneStatus.RegionID = t.RegionID and
    RegionZoneStatus.AuthStatusID != t.AuthStatusId and
    RegionZoneStatus.RegionID = 2 and
    t.AuthStatusId not in (3,4)

End

GO


-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP 13 -----------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_UpdateMfrRegionZoneStatus]    Script Date: 01/19/2012 15:36:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_UpdateMfrRegionZoneStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_UpdateMfrRegionZoneStatus]
GO


/****** Object:  StoredProcedure [dbo].[usp_UpdateMfrRegionZoneStatus]    Script Date: 01/19/2012 15:36:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- Created By: Fathima
-- Created On: 03-11-2011
-- Purpose: Updating zone status thro line card page.
-- Sample: usp_UpdateMfrRegionZoneStatus

CREATE proc [dbo].[usp_UpdateMfrRegionZoneStatus](@DistId int,@MfrZoneList varchar(max),@MfrPubList varchar(max))
as
Begin
-- @importData XML <- stored procedure param
DECLARE @l_index1 INT
DECLARE @l_index2 INT

create table #tmp
(
    MfrId int,
    RegionName varchar(100),
    ZoneId int,
    AuthStatusId int
)

create table #tmpPub
(
    MfrId int,
    Publish int
)

 EXECUTE sp_xml_preparedocument @l_index1 OUTPUT, @MfrZoneList

INSERT INTO #tmp (MfrId,RegionName,ZoneId,AuthStatusId)
SELECT
    MfrId,
    RegionName,
    ZoneId,
    AuthStatusId
FROM OPENXML(@l_index1, 'NewDataSet/ZoneList', 2)
    WITH
    (MfrId int,RegionName varchar(100),ZoneId int,AuthStatusId int)

EXECUTE sp_xml_removedocument @l_index1

insert into RegionZoneStatus
select
    a.MfrDistID,
    a.RegionID,
    a.ZoneId,
    1,
    null,
    null,
    null,
    null
from
    (select
        z1.MfrDistID,
        r.RegionID,
        t1.ZoneId,
        cast(MfrDistID as varchar) + '-' + cast(r.RegionID as varchar) + '-' + cast(t1.ZoneID as varchar) as RegZone
    from
        #tmp t1,
        region r,
        RegionAuthorization z1
    where
        t1.MfrId = z1.MfrID and
        z1.DistID = @DistId and
        Rtrim(REPLACE(t1.RegionName COLLATE DATABASE_DEFAULT, ' ', '')) = Rtrim(REPLACE(r.RegionName COLLATE DATABASE_DEFAULT, ' ', ''))
    ) a
where
    a.RegZone not in
        (select
            cast(s.MfrDistID as varchar)+ '-' + cast(s.RegionID as varchar) + '-' + cast(s.ZoneID as varchar) as RegZone
        from
            RegionZoneStatus s,
            RegionAuthorization z
        where
            s.MfrDistID = z.MfrDistID and
            z.MfrDistID in
                (select MfrDistID
                from #tmp t, RegionAuthorization a
                where a.MfrID = t.MfrId and a.DistID = @DistId)
        )

select
    R.MfrDistID,
    t.ZoneId,
    S.RegionID,
    t.AuthStatusID,
    t.MfrId,R.DistID into #tt
from #tmp t
    inner join Region G on Rtrim(REPLACE(G.RegionName COLLATE DATABASE_DEFAULT, ' ', '')) = Rtrim(REPLACE(t.RegionName COLLATE DATABASE_DEFAULT, ' ', ''))
    inner join RegionAuthorization R on R.MfrID = t.MfrId
    inner join  RegionZoneStatus S on S.RegionID = G.RegionID and S.MfrDistID = R.MfrDistID and S.ZoneID = t.ZoneId
where
    R.DistID = @DistId

select
    R.MfrDistID,
    t.ZoneId,
    S.RegionID,
    t.AuthStatusID,
    t.MfrId,R.DistID into #ttC
from
    #tmp t
    inner join Region G on Rtrim(REPLACE(G.RegionName COLLATE DATABASE_DEFAULT, ' ', '')) = Rtrim(REPLACE(t.RegionName COLLATE DATABASE_DEFAULT, ' ', ''))
    inner join RegionAuthorization R on R.MfrID = t.MfrId
    inner join  RegionZoneStatus S on S.RegionID = G.RegionID and S.MfrDistID = R.MfrDistID-- and S.ZoneID = t.ZoneId
where
    R.DistID = @DistId and
    S.RegionID = 2

update RegionZoneStatus
set AuthStatusID=t.AuthStatusId,Authorized_Date=getdate()
from #tt t
where
    RegionZoneStatus.MfrDistID=t.MfrDistID and
    RegionZoneStatus.RegionID = t.RegionID and
    RegionZoneStatus.ZoneID = t.ZoneId and
    RegionZoneStatus.AuthStatusID != t.AuthStatusId and
    t.AuthStatusId = 4

update RegionZoneStatus
set AuthStatusID=t.AuthStatusId,Denied_Date=getdate()
from #tt t
where
    RegionZoneStatus.MfrDistID=t.MfrDistID and
    RegionZoneStatus.RegionID = t.RegionID and
    RegionZoneStatus.ZoneID = t.ZoneId and
    RegionZoneStatus.AuthStatusID != t.AuthStatusId and
    t.AuthStatusId = 3

update RegionZoneStatus
set AuthStatusID=t.AuthStatusId
from #tt t
where
    RegionZoneStatus.MfrDistID=t.MfrDistID and
    RegionZoneStatus.RegionID = t.RegionID and
    RegionZoneStatus.ZoneID = t.ZoneId and
    RegionZoneStatus.AuthStatusID != t.AuthStatusId and
    t.AuthStatusId not in (3,4)

update RegionZoneStatus
set AuthStatusID=t.AuthStatusId,Authorized_Date=getdate()
from #ttC t
where
    RegionZoneStatus.MfrDistID=t.MfrDistID and
    RegionZoneStatus.RegionID = t.RegionID and
    RegionZoneStatus.AuthStatusID != t.AuthStatusId and
    RegionZoneStatus.RegionID = 2 and
    t.AuthStatusId = 4

update RegionZoneStatus
set AuthStatusID=t.AuthStatusId,Denied_Date=getdate()
from #ttC t
where
    RegionZoneStatus.MfrDistID=t.MfrDistID and
    RegionZoneStatus.RegionID = t.RegionID and
    RegionZoneStatus.AuthStatusID != t.AuthStatusId and
    RegionZoneStatus.RegionID = 2 and
    t.AuthStatusId = 3

update RegionZoneStatus
set AuthStatusID=t.AuthStatusId
from #ttC t
where
    RegionZoneStatus.MfrDistID=t.MfrDistID and
    RegionZoneStatus.RegionID = t.RegionID and
    RegionZoneStatus.AuthStatusID != t.AuthStatusId and
    RegionZoneStatus.RegionID = 2 and
    t.AuthStatusId not in (3,4)

EXECUTE sp_xml_preparedocument @l_index2 OUTPUT, @MfrPubList

INSERT INTO #tmpPub(MfrId,Publish)
SELECT
    MfrId,
    Publish
FROM OPENXML(@l_index2, 'NewDataSet/MfrPublish', 2)
    WITH
    (
     MfrId int,Publish int
     )

EXECUTE sp_xml_removedocument @l_index2

update RegionAuthorization
set Publish =t.Publish,UpdatedOn = GETDATE()
from #tmpPub t
where
    RegionAuthorization.MfrID = t.MfrId and
    RegionAuthorization.DistID = @DistId and
    RegionAuthorization.Publish != t.Publish

End

GO



-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP 14 -----------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_AddDistMfr_Auth]    Script Date: 01/18/2012 23:44:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_AddDistMfr_Auth]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_AddDistMfr_Auth]
GO


/****** Object:  StoredProcedure [dbo].[usp_AddDistMfr_Auth]    Script Date: 01/18/2012 23:44:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--select * from Company c with(nolock) where CompanyName='merge three'
-- select * from regionauthorization where mfrid=144825 and distid =130237
-- delete from regionauthorization where mfrdistid=114457
-- select * from regionzonestatus where mfrdistid=114459

--------------------------------------------------------------------------------------------------------------
-- Created By : Fathima
-- Created On : 10-Nov-2011
-- Description : Adding manufacturer for Distributor as Authorized Mfr.
-- Arguments :
-- Returns  : None
-- Sample : [usp_AddDistMfr_Auth] 'merge three',130237,1
--------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[usp_AddDistMfr_Auth]
(
    @MfrName varchar(100),
    @DistId int,@CreatedBy int
)
as
declare @MfrId int
declare @MfrDistId int

Begin Transaction
if    (select CompanyId from Company with(nolock) where CompanyName = LTRIM(RTRIM(@MfrName))) > 0
begin
set @MfrId = (select CompanyId from Company with(nolock) where CompanyName = LTRIM(RTRIM(@MfrName)) and IsActive =1)
if (select COUNT(MfrDistId) from RegionAuthorization with(nolock) where DistID = @DistId and MfrID = @MfrId) > 0
Raiserror('Already Exists',16,-1)

else
Begin
 --Inserting new record in RegionAuthorization table

insert into RegionAuthorization (MfrID,DistID,CreatedBy,CreatedOn,IsActive,Publish)
values (@MfrId,@DistId,@CreatedBy,GETDATE(),1,1)
set @MfrDistId = (select MfrDistId from RegionAuthorization with(nolock) where DistID = @DistId and MfrID = @MfrId)

--Inserting new records in RegionZoneStatus table
--SELECT RegionID,RegionName,Rank,replace(regionname, ' ', '') as newregionname FROM Region with(nolock) WHERE isActive=1 Order By Rank

select
    COUNT(zoneId) as ZoneCnt,
    C.RegionID
    into #tmpZ
from
    CountryZones Z with(nolock)
    inner join Country C with(nolock) on C.CountryID =Z.CountryID
    inner join Region R with(nolock) on R.RegionID = C.RegionID
where
    C.RegionID not in(0,2)
group by
    C.RegionID

insert into RegionZoneStatus (MfrDistID,RegionID,ZoneID,AuthStatusID)
select
    @MfrDistId,
    C.RegionID,
    ZoneID,
    1
from
    CountryZones Z with(nolock)
    inner join Country C with(nolock) on C.CountryID =Z.CountryID
    inner join #tmpZ R on R.RegionID = C.RegionID
union
select
    @MfrDistId,
    C.RegionID,
    CountryID as ZoneId,
    1
from
    Country C with(nolock)
where
    RegionID not in (select RegionID from #tmpZ)
    and RegionID not in (0,2)
union
select
    @MfrDistId,
    RegionID,
    10,
    1
from
    Region with(nolock)
where
    RegionID not in (select RegionID from #tmpZ)
    and RegionID != 0 and RegionName = 'Canada'

INSERT INTO CompanyProductType(CompanyID,ProductTypeID,IsActive,CreatedBy,Createdon)
select
    @DistID,
    ProductTypeID,
    IsActive,
    CreatedBy,
    GetDate()
from
    CompanyProductType
where
    companyid=@MfrId
    and ProductTypeID not in
        (select ProductTypeID from CompanyProductType where companyid=@DistID)

select @MfrId

End
End
else
Raiserror('Not Valid',16,-1)

Commit Transaction
IF @@Error <> 0
BEGIN
ROLLBACK TRANSACTION
RETURN @@Error
END
GO

-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP 15 -----------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
GO
/****** Object:  StoredProcedure [dbo].[usp_AddDistributor_DirectAuth]    Script Date: 01/18/2012 23:51:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_AddDistributor_DirectAuth]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_AddDistributor_DirectAuth]
GO

/****** Object:  StoredProcedure [dbo].[usp_AddDistributor_DirectAuth]    Script Date: 01/18/2012 23:51:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- select * from Company c with(nolock) where CompanyName='merge three'
-- select * from regionauthorization where mfrid=144825 and distid =130237
-- delete from regionauthorization where mfrdistid=114457
-- select * from regionzonestatus where mfrdistid=114459

--------------------------------------------------------------------------------------------------------------
-- Created By : Fathima
-- Created On : 30-Nov-2011
-- Description : Adding Distributor by Manufacturer.
-- Arguments :
-- Returns  : None
-- Sample : [usp_AddDistributor_DirectAuth] 'tex',130237,1
--------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_AddDistributor_DirectAuth]
(
    @DistName varchar(100),
    @MfrId int,
    @CreatedBy int,
    @UserRole varchar(10)
)
as
declare @DistId int
declare @MfrDistId int
declare @IsAlreadyExist bit
declare @IsUpdated bit
SET @IsUpdated = 0
SET @IsAlreadyExist = 0
Begin Transaction
    if(select CompanyId from Company with(nolock) where CompanyName = LTRIM(RTRIM(@DistName))) > 0
    begin
    set @DistId = (select CompanyId from Company with(nolock) where CompanyName = LTRIM(RTRIM(@DistName)) and IsActive =1)

    select
        COUNT(zoneId) as ZoneCnt,
        C.RegionID into #tmpZ
    from
        CountryZones Z with(nolock)
        inner join Country C with(nolock) on C.CountryID =Z.CountryID
        inner join Region R with(nolock) on R.RegionID = C.RegionID
    where
        C.RegionID not in(0,2)
    group by C.RegionID

    IF(SELECT COUNT(MfrDistId) FROM RegionAuthorization WITH(NOLOCK) WHERE DistID = @DistId and MfrID = @MfrId) > 0
    BEGIN
        IF(UPPER(@UserRole)='INTERNAL')
        BEGIN
            SET @IsAlreadyExist = 1
        END
        ELSE
        BEGIN
            IF(SELECT COUNT(*) FROM RegionZoneStatus rz with(nolock)
                    INNER JOIN RegionAuthorization ra with(nolock)
                        ON rz.MfrDistID = ra.MfrDistID
                            AND (rz.AuthStatusID=2 OR rz.AuthStatusID=4 AND UPPER(@UserRole)='EXTERNAL')
                WHERE MfrID = @mfrID AND DistID = @DistId )>= (SELECT COUNT(*) FROM #tmpZ)
            BEGIN
                SET @IsAlreadyExist=1
            END
            ELSE
            BEGIN
                SET @MfrDistId = (select MfrDistId from RegionAuthorization with(nolock) where DistID = @DistId and MfrID = @MfrId)

                UPDATE RegionZoneStatus SET
                    AuthStatusID=4
                WHERE MfrDistID=@MfrDistId
                select @DistId

                SET @IsUpdated = 1
            END
        END
    END
    ELSE
    BEGIN
        SET @IsAlreadyExist = 0
    END

    if(@IsAlreadyExist = 1)
    Raiserror('Already Exists',16,-1)
    else
    Begin
        IF (@IsUpdated = 0)
        BEGIN
            --Inserting new record in RegionAuthorization table

            insert into RegionAuthorization(MfrID,DistID,CreatedBy,CreatedOn,IsActive,Publish)
            values(@MfrId,@DistId,@CreatedBy,GETDATE(),1,1)

            set @MfrDistId = (select MfrDistId from RegionAuthorization with(nolock) where DistID = @DistId and MfrID = @MfrId)

            --Inserting new records in RegionZoneStatus table

            insert into RegionZoneStatus (MfrDistID,RegionID,ZoneID,AuthStatusID)
            select
                @MfrDistId,
                C.RegionID,
                ZoneID,4
            from
                CountryZones Z with(nolock)
                inner join Country C with(nolock) on C.CountryID =Z.CountryID
                inner join #tmpZ R on R.RegionID = C.RegionID
            union
            select
                @MfrDistId,
                C.RegionID,
                CountryID as ZoneId,
                4
            from
                Country C with(nolock)
            where
                RegionID not in (select RegionID from #tmpZ)
                and RegionID not in (0,2)
            union
            select
                @MfrDistId,
                RegionID,
                10,
                4
            from
                Region with(nolock)
            where
                RegionID not in (select RegionID from #tmpZ)
                and RegionID != 0
                and RegionName = 'Canada'


            INSERT INTO CompanyProductType(CompanyID,ProductTypeID,IsActive,CreatedBy,Createdon)
            select
                @DistID,
                ProductTypeID,
                IsActive,
                CreatedBy,
                GetDate()
            from CompanyProductType
            where
                companyid=@MfrId
                and ProductTypeID
                    not in(select ProductTypeID from CompanyProductType where companyid=@DistID)

            select @DistId
        END
    End
End
else
Raiserror('Not Valid',16,-1)

Commit Transaction
IF @@Error <> 0
BEGIN
ROLLBACK TRANSACTION
RETURN @@Error
END
GO

-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP 16 -----------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetAlertCompanyMfr]    Script Date: 01/19/2012 13:20:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAlertCompanyMfr]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAlertCompanyMfr]
GO


/****** Object:  StoredProcedure [dbo].[usp_GetAlertCompanyMfr]    Script Date: 01/19/2012 13:20:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =========================================================================================
-- Author  : Siva
-- Create date : 18-Jan-2012
-- Updated  :
--
-- Description : To get the Mfr Company Details for alert to 'Company Info Verification'
-- ==========================================================================================
CREATE PROCEDURE [dbo].[usp_GetAlertCompanyMfr]

AS
BEGIN
    set transaction isolation level read uncommitted
    SELECT  DISTINCT
        dbo.Company.CompanyID,
        dbo.Company.CompanyName,
        DBO.Get_CompanyTypeName (Company.CompanyID) AS CType,
        Description AS Status,
        ISNULL(dbo.Country.CountryName,'') AS CountryName,
        [USER].FirstName,
        [USER].LastName,
        [USER].UserregID,
        UserContact.EmailAddress,
        CompanyLocations.Zip,
        [dbo].[GetSearchZoneName](CompanyLocations.Zip) As ZoneName,
        [dbo].[GetZoneCodes](CompanyLocations.Zip) As ZoneCode

    FROM
        dbo.Company
        INNER JOIN dbo.CompanyLocations ON dbo.Company.CompanyID = dbo.CompanyLocations.CompanyID
            AND dbo.CompanyLocations.LocationTypeID=1
        INNER JOIN MstCompanyStatus AS S ON Company.CompanyStatusID = S.CompanyStatusID
            AND S.IsActive = 1  AND Company.CompanyStatusID=1
        INNER JOIN dbo.CompanyTypeMapping ON dbo.Company.CompanyID=dbo.CompanyTypeMapping.CompanyID
            AND CompanyTypeID=1
        INNER JOIN dbo.country ON dbo.CompanyLocations.CountryID = dbo.country.CountryID
        INNER JOIN UserRole ON  UserRole.CompanyID=dbo.Company.CompanyID AND UserRole.RoleID=10
        INNER JOIN [USER] ON [USER].UserID=UserRole.UserID
        INNER JOIN UserContact ON  UserContact.UserID=[USER].UserID AND UserContact.EmailAddress<>''
    WHERE
        dbo.Company.IsActive=1 AND
        Company.Verified=0 AND
        Company.CompanyID NOT IN(SELECT CompanyID from AlertLog Where AlertID=36 AND YEAR(AlertOn)=YEAR(getdate()))
 END

GO

-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP 17 -----------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetAlertCompany]    Script Date: 01/19/2012 13:24:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAlertCompany]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAlertCompany]
GO


/****** Object:  StoredProcedure [dbo].[usp_GetAlertCompany]    Script Date: 01/19/2012 13:24:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =========================================================================================
-- Author  : Siva
-- Create date : 09-Oct-2011
-- Updated  : Siva
-- Updated date : 09-Oct-2011
-- Description : To get the Company Details for alert to 'Company Info Verification'
-- ==========================================================================================
CREATE PROCEDURE [dbo].[usp_GetAlertCompany]  --'CA'
    @ZoneCode  Varchar(3)
AS
BEGIN
    set transaction isolation level read uncommitted
    SELECT  DISTINCT
        dbo.Company.CompanyID,
        dbo.Company.CompanyName,
        DBO.Get_CompanyTypeName (Company.CompanyID) AS CType,
        Description AS Status,
        ISNULL(dbo.Country.CountryName,'') AS CountryName,
        [USER].FirstName,
        [USER].LastName,
        [USER].UserregID,
        UserContact.EmailAddress,
        CompanyLocations.Zip,
        [dbo].[GetSearchZoneName](CompanyLocations.Zip) As ZoneName,
        [dbo].[GetZoneCodes](CompanyLocations.Zip) As ZoneCode
    FROM
        dbo.Company
        INNER JOIN dbo.CompanyLocations ON dbo.Company.CompanyID = dbo.CompanyLocations.CompanyID
            AND dbo.CompanyLocations.LocationTypeID=1
        INNER JOIN MstCompanyStatus AS S ON Company.CompanyStatusID = S.CompanyStatusID
            AND S.IsActive = 1  AND Company.CompanyStatusID=1
        INNER JOIN dbo.CompanyTypeMapping ON dbo.Company.CompanyID=dbo.CompanyTypeMapping.CompanyID
            AND CompanyTypeID in (2,3)
        INNER JOIN dbo.country ON dbo.CompanyLocations.CountryID = dbo.country.CountryID
        INNER JOIN UserRole ON  UserRole.CompanyID=dbo.Company.CompanyID AND UserRole.RoleID=10
        INNER JOIN [USER] ON [USER].UserID=UserRole.UserID
        INNER JOIN UserContact ON  UserContact.UserID=[USER].UserID AND UserContact.EmailAddress<>''
    WHERE
        dbo.Company.IsActive=1 AND
        Company.Verified=0 AND
        [dbo].[GetZoneCodes](CompanyLocations.Zip)=@ZoneCode
        AND LEN([dbo].[GetZoneCodes](CompanyLocations.Zip))>0
 END

GO

-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP 18 -----------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetAllCompany]    Script Date: 05/24/2012 19:34:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAllCompany]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAllCompany]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetAllCompany]    Script Date: 05/24/2012 19:34:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


----------------------------------------------------------------------------------------------------------
-- Created By		: Ashok
-- Modified Date	: 09th-May-2011
-- Description		: Get Company details based on startindex and pagsize parameter for sorting
--					  Based on sortBy parameter and also return totaluser count as output
-- Arguments		: StartIndex,PageSize,Sortby
-- Returns			: Total Company
-- usp_GetAllCompany 0, 50, 'c.companyname','companyname','sou',0, ' AND 1 = 1' ,'0','True'
----------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetAllCompany] --0,50,'c.companyname','Email','joshi.c@aequor.com',0, ' AND 1 = 1' ,'0','True'
(
  @startIndex  int,
  @pageSize  int,
  @sortBy   varchar(30),
  @searchBy  varchar(30),
  @searchText  VarChar(30),
  @totalCompany  int OUTPUT,
  @searchcondition varchar(50),
  @searchOptional VarChar(50),
  @startswith VarChar(50)
)
AS
BEGIN
 set transaction isolation level read uncommitted
 SET NOCOUNT ON
 DECLARE

  @upperBound int,
  @totalCompany1  int,
  @strCriteria varchar(max),
  @strGetTotCount NVARCHAR(max),
  @strBuildSQL varchar(max)

  select @strCriteria =''
  select @strBuildSQL=''

  -- Originally Done
  --set @searchText = replace(ltrim(rtrim(@searchText)),'''','')
  --set @searchOptional = replace(ltrim(rtrim(@searchOptional)),'''','')

  set @searchText = ltrim(rtrim(@searchText))
  set @searchOptional = ltrim(rtrim(@searchOptional))

  IF (@startswith = 'True')
    BEGIN
        set @searchText = @searchText+'%'
        set @searchOptional = @searchOptional+'%'
    END
  Else
    BEGIN
        set @searchText = '%'+@searchText+'%'
         set @searchOptional = '%'+@searchOptional+'%'
    END

  IF @startIndex  < 1
    SET @startIndex = 1
  ELSE
    SET @startIndex=@startIndex+1

  IF @pageSize < 1 SET @pageSize = 1

  SET @upperBound = @startIndex + @pageSize

  IF(@searchBy = 'CompanyName')
    BEGIN
      IF(@searchOptional ='optional keywords' or @searchOptional ='0%' or @searchOptional ='%0%')
         BEGIN
            SET @strCriteria=' AND C.CompanyName LIKE '''+@searchText+''''
         END
      ELSE
         BEGIN
            SET @strCriteria=' AND (C.CompanyName LIKE '''+@searchText+'''  OR  C.CompanyName LIKE '''
                + @searchOptional +''')'
         END
    END
  ELSE IF (@searchBy = 'Email')
    BEGIN
      IF(@searchOptional ='optional keywords' or @searchOptional ='0%' or @searchOptional ='%0%')
        BEGIN
            SET @strCriteria=' AND (ICL.Email LIKE '''+@searchText+''' OR UC.EmailAddress LIKE ''' +@searchText+''')'
        END
      ELSE
        BEGIN
            SET @strCriteria=' AND (ICL.Email LIKE '''+@searchText+''' OR ICL.Email LIKE '''
                + @searchOptional + ''' OR UC.EmailAddress LIKE ''' + @searchText
                +''' OR UC.EmailAddress LIKE ''' + @searchOptional +''')'
        END
    END
  ELSE IF (@searchBy = 'phone')
    BEGIN
      IF(@searchOptional ='optional keywords' or @searchOptional ='0%' or @searchOptional ='%0%')
        BEGIN
            SET @searchText = replace(@searchText,'-','')

            SET @strCriteria=' AND (ICL.Phone LIKE '''+@searchText+''' OR UC.Phone LIKE ''' +@searchText+''')'
        END
      ELSE
        BEGIN
            SET @searchText = replace(@searchText,'-','')
            SET @searchOptional = replace(@searchOptional,'-','')

            SET @strCriteria=' AND (ICL.Phone LIKE '''+@searchText+''' OR ICL.Phone LIKE '''
                + @searchOptional + ''' OR UC.Phone LIKE ''' + @searchText +''' OR UC.Phone LIKE '''
                + @searchOptional +''')'
        END
    END
  ELSE IF (@searchBy = 'contactname')
    BEGIN
      IF(@searchOptional ='optional keywords' or @searchOptional ='0%' or @searchOptional ='%0%')
        BEGIN
            IF (@startswith = 'True')
                BEGIN
                    set @searchText = left(@searchText,len(@searchText)-1)
                END
            Else
                BEGIN
                    set @searchText = left(@searchText,len(@searchText)-1)
                    set @searchText = Right(@searchText,len(@searchText)-1)
                END

            set @strCriteria = ' AND('

            IF (@startswith = 'True')
                BEGIN
                    Select @strCriteria = @strCriteria + ' [user].FirstName like ''' + a.items + '%'' or'
                    + ' [user].LastName like ''' + a.items + '%'' or' from dbo.[Split]( @searchText,' ') a
                    inner join dbo.[Split](@searchText,' ') b  on a.items = b.items
                END
            ELSE
                BEGIN
                    Select @strCriteria = @strCriteria + ' [user].FirstName like ''%' + a.items + '%'' or'
                    + ' [user].LastName like ''%' + a.items + '%'' or' from dbo.[Split]( @searchText,' ') a
                    inner join dbo.[Split](@searchText,' ') b  on a.items = b.items
                END

            Set @strCriteria = left(@strCriteria,len(@strCriteria)-2) + ')'
        END
      ELSE
        BEGIN
            IF (@startswith = 'True')
                BEGIN
                    set @searchText = left(@searchText,len(@searchText)-1)
                    set @searchOptional = left(@searchOptional,len(@searchOptional)-1)
                END
            Else
                BEGIN
                    set @searchText = left(@searchText,len(@searchText)-1)
                    set @searchOptional = left(@searchOptional,len(@searchOptional)-1)

                    set @searchText = Right(@searchText,len(@searchText)-1)
                    set @searchOptional = Right(@searchOptional,len(@searchOptional)-1)
                END

            SET @strCriteria = ' AND('

            IF (@startswith = 'True')
                BEGIN
                    Select @strCriteria = @strCriteria + ' [user].FirstName like ''' + a.items + '%'' or'
                    + ' [user].LastName like ''' + a.items + '%'' or' from dbo.[Split]( @searchText,' ') a
                    inner join dbo.[Split](@searchText,' ') b  on a.items = b.items

                    Select @strCriteria = @strCriteria + ' [user].FirstName like ''' + a.items + '%'' or'
                    + ' [user].LastName like ''' + a.items + '%'' or' from dbo.[Split]( @searchOptional,' ') a
                    inner join dbo.[Split](@searchOptional,' ') b  on a.items = b.items
                END
            ELSE
                BEGIN
                    Select @strCriteria = @strCriteria + ' [user].FirstName like ''%' + a.items + '%'' or'
                    + ' [user].LastName like ''%' + a.items + '%'' or' from dbo.[Split]( @searchText,' ') a
                    inner join dbo.[Split](@searchText,' ') b  on a.items = b.items

                    Select @strCriteria = @strCriteria + ' [user].FirstName like ''%' + a.items + '%'' or'
                    + ' [user].LastName like ''%' + a.items + '%'' or' from dbo.[Split]( @searchOptional,' ') a
                    inner join dbo.[Split](@searchOptional,' ') b  on a.items = b.items
                END

            Set @strCriteria = left(@strCriteria,len(@strCriteria)-2) + ')'

        END
    END
  ELSE
     BEGIN
        SET @strCriteria= ' AND 1 = 1'
     END


  IF(@searchBy = 'phone' OR @searchBy = 'Email')
    BEGIN

      Select @strGetTotCount = N'SELECT @totalCompany1 = count(*) From Company AS C
        INNER JOIN MstCompanyStatus AS S ON C.CompanyStatusID = S.CompanyStatusID
            and S.isactive = 1
        LEFT JOIN COMPANYLOCATIONS CL ON C.COMPANYID = CL.COMPANYID
            AND CL.LOCATIONTYPEID = 1 and CL.isactive =1
        LEFT JOIN country As MC On CL.CountryID = MC.CountryID
            and MC.isactive =1
        Where C.CompanyID in (
        Select IC.companyid from company IC
        LEFT JOIN COMPANYLOCATIONS ICL ON IC.COMPANYID = ICL.COMPANYID
        and ICL.isactive =1
        LEFT JOIN UserRole ON IC.companyid = UserRole.companyid
        AND UserRole.UserTypeID = 1
        LEFT JOIN UserContact UC ON UC.UserID = UserRole.UserID
        WHERE C.IsActive = 1 ' + @strCriteria + ' )'
    END
  ELSE IF (@searchBy = 'contactname')
    BEGIN
      Select @strGetTotCount = N'SELECT @totalCompany1 = count(*) From Company AS C
        INNER JOIN MstCompanyStatus AS S ON C.CompanyStatusID = S.CompanyStatusID
            and S.isactive = 1
        LEFT JOIN COMPANYLOCATIONS CL ON C.COMPANYID = CL.COMPANYID
            AND CL.LOCATIONTYPEID = 1 and CL.isactive =1
        LEFT JOIN country As MC On CL.CountryID = MC.CountryID
            and MC.isactive =1
        Where C.CompanyID in (
        Select distinct companyid from [User]
        INNER JOIN UserRole ON [User].UserID = UserRole.UserID AND UserRole.UserTypeID = 1
        WHERE C.IsActive = 1 ' + @strCriteria + ' )'
    END
  ELSE	/* for normal condition */
    BEGIN
      Select @strGetTotCount = N'SELECT @totalCompany1 = count(*) From Company AS C
        INNER JOIN MstCompanyStatus AS S ON C.CompanyStatusID = S.CompanyStatusID
            and S.isactive = 1
        LEFT JOIN COMPANYLOCATIONS CL ON C.COMPANYID = CL.COMPANYID
            AND CL.LOCATIONTYPEID = 1 and CL.isactive =1
        LEFT JOIN country As MC On CL.CountryID = MC.CountryID
            and MC.isactive =1
        Where C.IsActive = 1 ' + @strCriteria +' '
   END

  exec sp_executeSQl @strGetTotCount, N'@totalCompany1 int output', @totalCompany1 = @totalCompany output

  IF(@totalCompany < @startIndex)
    SET @startIndex =1

  IF(@searchBy = 'phone' OR @searchBy = 'Email')
    BEGIN
      SET @strBuildSQL = 'SELECT CompanyID,CompanyName,CompanyStatusID,
        CompanyType,SStatusID as StatusID,SDescription as Status,rowNumber,
        (Select top 1 U.SalesPersonCode from dbo.SalesAssignments SA
        INNER JOIN [User] U ON SA.SalesPerson_ID = U.UserID
        WHERE SA.Company_ID = D.CompanyID AND SA.Status = 1 ) as SalesPerson,
        CountryName,CountryCode,CASE WHEN (Select count(*) from Adorder AO
        where AO.Companyid = D.CompanyID and AO.StatusId in(3,4)) <=0 THEN ''N'' ELSE ''Y'' END as Advertiser
        FROM (SELECT ROW_NUMBER() OVER(ORDER BY ' + @sortBy + ') AS rowNumber,
        [dbo].[Get_CompanyTypeName](C.CompanyID) as CompanyType,c.*,S.CompanyStatusID as SStatusID,
        S.Description as SDescription,CountryName,CountryCode
        From Company AS C
        INNER JOIN MstCompanyStatus AS S ON C.CompanyStatusID = S.CompanyStatusID
            and S.isactive = 1
        LEFT JOIN COMPANYLOCATIONS CL ON C.COMPANYID = CL.COMPANYID
            AND CL.LOCATIONTYPEID = 1 and CL.isactive =1
        LEFT JOIN country As MC On CL.CountryID = MC.CountryID
            and MC.isactive =1
        Where C.CompanyID in (
        Select IC.companyid from company IC
        LEFT JOIN COMPANYLOCATIONS ICL ON IC.COMPANYID = ICL.COMPANYID
        and ICL.isactive =1
        LEFT JOIN UserRole ON IC.companyid = UserRole.companyid
         AND UserRole.UserTypeID = 1
        LEFT JOIN UserContact UC ON UC.UserID = UserRole.UserID
        WHERE 1 = 1 ' + @strCriteria + ') AND C.IsActive = 1 ) AS D
        WHERE  rowNumber >= ' + CONVERT(varchar(9), @startIndex) + ' AND
        rowNumber <  ' + CONVERT(varchar(9), @upperBound)
    END
  ELSE IF (@searchBy = 'contactname')
    BEGIN
      SET @strBuildSQL = 'SELECT CompanyID,CompanyName,CompanyStatusID,
        CompanyType,SStatusID as StatusID,SDescription as Status,rowNumber,
        (Select top 1 U.SalesPersonCode from dbo.SalesAssignments SA
        INNER JOIN [User] U ON SA.SalesPerson_ID = U.UserID
        WHERE SA.Company_ID = D.CompanyID AND SA.Status = 1 ) as SalesPerson,
        CountryName,CountryCode,CASE WHEN (Select count(*) from Adorder AO
        where AO.Companyid = D.CompanyID and AO.StatusId in(3,4)) <=0 THEN ''N'' ELSE ''Y'' END as Advertiser
        FROM (SELECT ROW_NUMBER() OVER(ORDER BY ' + @sortBy + ') AS rowNumber,
        [dbo].[Get_CompanyTypeName](C.CompanyID) as CompanyType,c.*,S.CompanyStatusID as SStatusID,
        S.Description as SDescription,CountryName,CountryCode
        From Company AS C
        INNER JOIN MstCompanyStatus AS S ON C.CompanyStatusID = S.CompanyStatusID
            and S.isactive = 1
        LEFT JOIN COMPANYLOCATIONS CL ON C.COMPANYID = CL.COMPANYID
            AND CL.LOCATIONTYPEID = 1 and CL.isactive =1
        LEFT JOIN country As MC On CL.CountryID = MC.CountryID
            and MC.isactive =1
        Where C.CompanyID in (
        Select distinct companyid from [User]
        INNER JOIN UserRole ON [User].UserID = UserRole.UserID AND UserRole.UserTypeID = 1
        WHERE C.IsActive = 1 ' + @strCriteria + ') ) AS D
        WHERE  rowNumber >= ' + CONVERT(varchar(9), @startIndex) + ' AND
        rowNumber <  ' + CONVERT(varchar(9), @upperBound)
    END
  ELSE	/* for normal condition */
    BEGIN
      SET @strBuildSQL = 'SELECT CompanyID,CompanyName,CompanyStatusID,
        CompanyType,SStatusID as StatusID,SDescription as Status,rowNumber,
        (Select top 1 U.SalesPersonCode from dbo.SalesAssignments SA
        INNER JOIN [User] U ON SA.SalesPerson_ID = U.UserID
        WHERE SA.Company_ID = D.CompanyID AND SA.Status = 1 ) as SalesPerson,
        CountryName,CountryCode,CASE WHEN (Select count(*) from Adorder AO
        where AO.Companyid = D.CompanyID and AO.StatusId in(3,4)) <=0 THEN ''N'' ELSE ''Y'' END as Advertiser
        FROM (SELECT ROW_NUMBER() OVER(ORDER BY ' + @sortBy + ') AS rowNumber,
        [dbo].[Get_CompanyTypeName](C.CompanyID) as CompanyType,c.*,S.CompanyStatusID as SStatusID,
        S.Description as SDescription,CountryName,CountryCode
        From Company AS C
        INNER JOIN MstCompanyStatus AS S ON C.CompanyStatusID = S.CompanyStatusID
            and S.isactive = 1
        LEFT JOIN COMPANYLOCATIONS CL ON C.COMPANYID = CL.COMPANYID
            AND CL.LOCATIONTYPEID = 1 and CL.isactive =1
        LEFT JOIN country As MC On CL.CountryID = MC.CountryID
            and MC.isactive =1
        Where C.IsActive = 1 ' + @strCriteria +' ) AS D
        WHERE  rowNumber >= ' + CONVERT(varchar(9), @startIndex) + ' AND
        rowNumber <  ' + CONVERT(varchar(9), @upperBound)
   END

    --print(@strCriteria)
    --print(@strBuildSQL)

    EXEC(@strBuildSQL)
    exec sp_executeSQl @strGetTotCount, N'@totalCompany1 int output', @totalCompany1 = @totalCompany output
    Select @totalCompany
    --PRINT(@strGetTotCount)
    --PRINT(@totalCompany)
END


GO
-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP 19 -----------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetCompany]    Script Date: 05/21/2012 02:09:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetCompany]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetCompany]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetCompany]    Script Date: 05/21/2012 02:09:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


------------------------------------------------------------------------------------------
-- Created By		: P.Ashok Kumar
-- Procedure Name	: usp_GetCompany
-- Created Date		: 23rd-June-2010
-- Updated Date		: 6th-October-2010
-- Description		: The Company Informations will be display.
-- Arguments		: List is given below
-- Returns			: None  usp_GetCompany 100692
------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetCompany]  --46
(
 @CompanyID Int
)
AS
BEGIN
set transaction isolation level read uncommitted
 SELECT
  CompanyID,
  CompanyName,
  CompanyDescription,
  Abbreviation,
  CompanyStatusID,
  CompanyLogo,
  Address,
  City,
  StateID,
  CountryID,
  Zip,
  Email,
  SICCode,
  NAICSCode,
  BookName,
  URL,
  AssocLogos1,
  AssocLogos2,
  AssocLogos3,
  AssocLogos4,
  AssocLogos5,
  SearchName,
  ProductLine,
  SpecialHandling,
  SpecialHandlingInstruction,
  Comment,
  [dbo].[Get_CompanyTypeName](CompanyID) as CompanyType,

CASE WHEN (Select count(*) from Adorder AO
where AO.Companyid = Company.CompanyID and AO.StatusId in(3,4)) <=0 THEN 'N' ELSE 'Y' END as Advertiser,

    (Select top 1 U.SalesPersonCode from dbo.SalesAssignments SA
        INNER JOIN [User] U ON SA.SalesPerson_ID = U.UserID
        WHERE SA.Company_ID = @CompanyID AND SA.Status = 1 ) as SalesPerson,

  convert(varchar(10),InactivationTimestamp,101)as InactivationTimestamp,
  convert(varchar(10),ApprovedTimeStamp,101)as ApprovedTimeStamp,
  IsActive,
  SeeLine,
  --CONVERT(VARCHAR(10),updatedon,101) as UpdatedOn,
  --CONVERT(VARCHAR(10),createdon,101) as Createdon,
  [dbo].[Get_CompanyLastUploadedDate](CompanyID) as UpdatedOn,
  Keywords,
  BrandCode

FROM Company
WHERE CompanyID = @CompanyID

END


GO
-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP 20 -----------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetCompanyOverview]    Script Date: 05/21/2012 02:18:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetCompanyOverview]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetCompanyOverview]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetCompanyOverview]    Script Date: 05/21/2012 02:18:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



--------------------------------------------------------------------------------
-- Created By  : P.Ashok Kumar
-- Procedure Name : usp_GetCompany
-- Created Date  : 23rd-June-2010
-- Updated Date  : 6th-October-2010
-- Description  : The Company Informations will be display.
-- Arguments  : List is given below
-- Returns   : None
--------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetCompanyOverview] -- 46
(
  @CompanyID Int
)
AS
BEGIN
 set transaction isolation level read uncommitted
 SELECT
   C.CompanyID,
   C.CompanyName,
   C.CompanyStatusID,
   C.CompanyLogo,
   (Select top 1 U.SalesPersonCode from dbo.SalesAssignments SA
        INNER JOIN [User] U ON SA.SalesPerson_ID = U.UserID
        WHERE SA.Company_ID = @CompanyID AND SA.Status = 1 ) as SalesPerson,

   C.AllowInventoryUpload,
   C.CountryID,
   C.AssocLogos6,
   C.Trusted_Disty,
   C.NoAuthClaims,
   C.MSGIDNo,
   C.EstYearID,
   C.NoOfEmployyes,
   S.Description as CompanyStatus,
  [dbo].[Get_CompanyTypeName](C.CompanyID) as CompanyType,

    CASE WHEN (Select count(*) from Adorder AO
    where AO.Companyid = C.CompanyID and AO.StatusId in(3,4)) <=0 THEN 'N' ELSE 'Y' END as Advertiser,

   MC.CountryName,
   MC.CountryCode

 FROM  Company C
 Left join CompanyLocations CL on C.CompanyID=CL.CompanyID And LocationTypeID=1
 Left Join  Country MC On Cl.CountryID = MC.CountryID, MstCompanyStatus S
 WHERE C.CompanyStatusID = S.CompanyStatusID
 AND C.CompanyID = @CompanyID

END


GO
-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP 21 -----------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAllCompanyReps]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAllCompanyReps]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetAllCompanyReps] --0,10,'C.CompanyID',2,0
(
  @startIndex             int,
  @pageSize                 int,
  @sortBy                 varchar(30),
  @CompanyID             int,
  @totalCompanyReps      int OUTPUT
)
AS
SET NOCOUNT ON
BEGIN
 set transaction isolation level read uncommitted
 DECLARE    @upperBound int,
            @strBuildSQL varchar(max)

 SELECT @strBuildSQL=''

 IF @startIndex  < 1 SET @startIndex = 1 ELSE SET @startIndex=@startIndex+1
 IF @pageSize < 1 SET @pageSize = 1

 SET @upperBound = @startIndex + @pageSize
 SELECT @totalCompanyReps=Count(*) FROM Reps WHERE CompanyID=@CompanyID AND IsActive=1


 SET @strBuildSQL = 'SELECT
        C.RepID,
        C.CompanyID,
        C.ContactName,
        C.Address,
        C.City,
        C.Phone,
        C.Fax,
        C.Email,
        C.Website,
        S.StateCode,
        CNTRY.CountryCode

        FROM (SELECT  ROW_NUMBER() OVER (ORDER BY ' + @sortBy + ') AS rowNumber,CR.*
        FROM Reps CR,Company C WHERE CR.CompanyID=' + CONVERT(varchar(9), @CompanyID) + '
        AND C.CompanyID = CR.CompanyID AND CR.IsActive = 1 ) As C left join CountryStates S on C.StateID = S.StateID
        left join Country CNTRY on C.CountryID = CNTRY.CountryID

        WHERE rowNumber >= ' + CONVERT(varchar(9), @startIndex) + ' AND
        rowNumber <  ' + CONVERT(varchar(9), @upperBound) +  ' AND  C.IsActive=1 order by C.Contactname '

--PRINT(@strBuildSQL)
EXEC(@strBuildSQL)
END

GO
-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP 22 -----------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetMonthlyBillInfo]    Script Date: 01/19/2012 15:45:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetMonthlyBillInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetMonthlyBillInfo]
GO


/****** Object:  StoredProcedure [dbo].[usp_GetMonthlyBillInfo]    Script Date: 01/19/2012 15:45:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--------------------------------------------------------------------------
-- Created By : Siva.
-- Created On : 09 Jan 2012
-- Description : Get the Monthly Bill info form Sales order
--------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetMonthlyBillInfo]
AS
IF (SELECT DAY(GETDATE()))=1
    BEGIN
    set transaction isolation level read uncommitted
      SELECT
       OrderType  AS RevenueStream,
       A.AdOrderId  AS SourceRecordID,
       C.MSGIDNo  AS AdvertiserCode,
       C.MSGIDNo  AS AgencyCode,
       C.MSGIDNo  AS BillToCode,
       SalesPersonId AS SalespersonID,
       GrossAmount  AS GrossAmount,
       ApplyDiscount,
       Convert(money,(A.GrossAmount *  A.DiscountRate)/100,2) AS DollarVolumeDiscount,
       NetAmount AS NetAmount,
       A.Comments AS ProductionComments,
       PONumber AS PONumber,
       BillingInstruction AS BillingInstructions,
       CASE WHEN OrderType='P' OR OrderType='N' THEN 'ESB' ELSE 'ESBI' END AS PubCode,
       CASE WHEN OrderType='P' THEN 'ROP' ELSE '' END AS Position,
       'ESB' AS SourceName,
       '1' AS Quantity,
       'BW' AS Color,
       'PICKUP' AS Material,
       'RU' AS Status,
       '1' AS NumberTearsheets,
       '' AS SurchargeCommissionabletoAgency,
       '' AS AgencySurchargeP,
       '' AS AgencySurchargeA,
       '' AS SurchargeProductionFlag,
       '' AS EnteredBy,
       ST.MSGCode AS AdSize,
       SST.SectionCode AS Section,
       CONVERT(varchar,E.PublicationDate,101) AS IssueDate,
       CONVERT(varchar,AD.ActivationDate,101) AS StartDate,
        CASE WHEN OrderType='P' THEN
            CONVERT(varchar,DATEADD(mm,ad.Duration,ad.ActivationDate),101)
        ELSE '' END  AS EndDate,
       CASE WHEN OrderType='P' THEN E.HeadingTitle ELSE '' END AS EditionCode,
       CASE WHEN OrderType='P' OR OrderType='N' THEN 'DIS' ELSE 'INT' END AS AdTypeCode,
           CASE WHEN OrderType='P' THEN 'ESB' + '*' + E.HeadingTitle + '*' + ST.Description
                ELSE 'ESB1' + '*' + '' + '*' + ST.Description
           END AS RateCode
     FROM AdOrder A,Company C,AdOrderDetails AD,SalesSizeType ST,SalesSectionType SST,
            AdOrderDetailsRegionEdition ADRE,Editions E
     WHERE  A.CompanyId=C.CompanyID AND A.AdOrderId=AD.AdOrderId
            AND ST.SizeTypeID=AD.SizeTypeID AND SST.SectionID=AD.SectionID
            AND ADRE.AdOrderDetailsId=AD.AdOrderDetailsId AND ADRE.EditionID=E.EditionID
            AND MONTH(A.OrderDate)=DATEPART(month, A.OrderDate)-1
    END


GO
-------------------------------------------------------------------------------------------------------
-- Ticket related Updates SP 23 -----------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetSearchFirstTenProductTypes]    Script Date: 01/19/2012 19:12:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchFirstTenProductTypes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchFirstTenProductTypes]
GO


/****** Object:  StoredProcedure [dbo].[usp_GetSearchFirstTenProductTypes]    Script Date: 01/19/2012 19:12:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Modified By : Fathima
-- Modified On : 11 Jan 2012
-- Sample : [usp_GetSearchFirstTenProductTypes] 'Manufacturers','By Product'

CREATE PROCEDURE [dbo].[usp_GetSearchFirstTenProductTypes] (@NavMenuName varchar(100),@SectionName varchar(100))
AS
CREATE TABLE #results
(
    ProductTypeID int,
    ProductType varchar(100),
    DisplayName varchar(50),
    IsSponserLink bit
)

BEGIN
set transaction isolation level read uncommitted
insert into #results
select
    ProductTypeID,
    ltrim(rtrim(TypeDescription)) as ProductType,
    CASE WHEN len(ltrim(rtrim(TypeDescription)))>15 THEN left(TypeDescription,12) + '...' ELSE TypeDescription END AS 'DisplayName',1
from
    sponserlinks T inner join ProductType P on P.ProductTypeId = T.TopLinkId1
where
    T.TopLinkId1 != 0  and
    NavMenuName = @NavMenuName and
    SectionName = @SectionName

insert into #results
select
    ProductTypeID,
    ltrim(rtrim(TypeDescription)) as ProductType,
    CASE WHEN len(ltrim(rtrim(TypeDescription)))>15 THEN left(TypeDescription,12) + '...' ELSE TypeDescription END AS 'DisplayName',1
from
    sponserlinks T inner join ProductType P on P.ProductTypeId = T.TopLinkId2
where
    T.TopLinkId2 != 0  and
    NavMenuName = @NavMenuName and
    SectionName = @SectionName

insert into #results
select
    ProductTypeID,
    ltrim(rtrim(TypeDescription)) as ProductType,
    CASE WHEN len(ltrim(rtrim(TypeDescription)))>15 THEN left(TypeDescription,12) + '...' ELSE TypeDescription END AS 'DisplayName',1
from
    sponserlinks T  inner join ProductType P on P.ProductTypeId = T.TopLinkId3
where
    T.TopLinkId3 != 0  and
    NavMenuName = @NavMenuName and
    SectionName = @SectionName

insert into #results
Select
    top 10 ProductTypeID,
    ltrim(rtrim(TypeDescription)) as ProductType,
    CASE WHEN len(ltrim(rtrim(TypeDescription)))>15 THEN left(TypeDescription,12) + '...' ELSE TypeDescription END AS 'DisplayName',0
FROM
    ProductType
WHERE
    IsActive = 1 AND StatusID=1
    and TypeDescription is not null
    and ProductTypeId not in (select ProductTypeId from #results)
ORDER BY ProductType

select top 10 * from #results

END


GO
-----------------------------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAlertActiveEditionList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAlertActiveEditionList]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =========================================================================================
-- Author  : Siva
-- Create date : 13-Oct-2011
-- Description : To Get Latest Edition List
-- Arguments : None
-- ==========================================================================================

CREATE PROCEDURE [dbo].[usp_GetAlertActiveEditionList]
AS
BEGIN
    set transaction isolation level read uncommitted
      SELECT (ZoneCode+SUBSTRING(Year,2,2)) As Edition,EditionID FROM
      Editions,CountryZones Where Editions.RegionID=CountryZones.ZoneID
      AND Year=Year(GetDate()) AND StatusID in(3,4)
END
GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchManufDistName]    Script Date: 03/05/2012 18:38:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchManufDistName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchManufDistName]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchManufDistName]    Script Date: 03/05/2012 18:38:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



--------------------------------------------------------------------------
-- Name   : usp_GetSearchManuDistName ManuDist Detailspage
-- Description  : This Procedure Will Get the ManuDist Details.
-- created By   :  Ramesh
-- Arguments :  CompanyID,CompanyTypeID
-- Returns  : None
-- Modified By : Mohit
-- Modified On : 29 Feb 2012  for Ticket 16555 and 14211 - Logic for Auth flag for MFR and Dist Landing pages
-- Sample : [usp_GetSearchManufDistName] 101842, 2
--------------------------------------------------------------------------


CREATE  PROCEDURE [dbo].[usp_GetSearchManufDistName]  --144752,1
(
    @CompanyID  Int,
    @CompanyTypeID  Int
)
AS
BEGIN
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

    IF(@CompanyTypeID='1')
        SELECT
            c.companyname AS 'DistributorName',
            ra.DistID AS 'DistributorID',
            4 AS AuthStatus,
            dbo.[Get_SearchCompanyOwn] (ra.DistID) AS CompanyOwn,
            C.Trusted_Disty ,
            ra.MfrDistID
        FROM
            RegionAuthorization ra
            INNER JOIN Company c ON c.companyid=ra.DistID AND c.IsActive = 1 AND c.CompanyStatusID = 1
            INNER JOIN REGIONZONESTATUS RS on RS.MFRDISTID=ra.MFRDISTID
                    and (AuthStatusiD =4 Or (AuthStatusid  = 2 and C.Trusted_Disty = 1))
        WHERE
            ra.IsActive = 1 AND
            ra.mfrid = @CompanyID AND
            ra.Publish =1
        group by
            ra.MfrDistID,
            c.companyname ,
            ra.DistID ,
            C.Trusted_Disty
        ORDER BY
            DistributorName ASC
    ELSE IF(@CompanyTypeID='2')
    Begin
       Declare @TrustedDistributor int = 0;
       Select @TrustedDistributor = Trusted_Disty from Company where CompanyID = @CompanyID
       SELECT
            c.companyname AS 'ManufacturerName',
            ra.mfrid AS 'ManufacturerID',
            (SELECT MAX(case when (AuthStatusid  = 2 and @TrustedDistributor = 1) then 4 else AuthStatusid end) FROM REGIONZONESTATUS RS
            WHERE RS.MFRDISTID=ra.MFRDISTID) AS AuthStatus,
            0 as CompanyOwn,
            @TrustedDistributor as Trusted_Disty,
            ra.MFRDISTID
        FROM
            RegionAuthorization ra
            INNER JOIN Company c ON c.companyid=ra.mfrid AND c.IsActive = 1 AND c.CompanyStatusID = 1
        WHERE
            ra.IsActive = 1 AND
            ra.distid = @CompanyID AND
            ra.Publish =1
        group by
            ra.MFRDISTID ,
            c.companyname ,
            ra.mfrid
        ORDER BY
            ManufacturerName ASC
     END
   END


GO
----------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetCompanySuggestionListForCAdmin]    Script Date: 01/20/2012 18:46:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetCompanySuggestionListForCAdmin]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetCompanySuggestionListForCAdmin]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetCompanySuggestionListForCAdmin]    Script Date: 01/20/2012 18:46:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--------------------------------------------------------------------------------------------------------------
-- Created By  : P .Ashok kumar
-- Modified By : T. Balamurugan
-- Created On  : 11-Oct-2010
-- Description : Getting Distributor list to add in Distributor Page.
-- Arguments   : CompanyTypeId,PrefixText,Count,CompanyID,UserId,RoleTypeID
-- Returns     : None
-- Modified By : Fathima
-- Modified On : 19 Jan 2012
-- Sample :  usp_GetCompanySuggestionListForCAdmin 2,'s',20,144397,144839,144397
--------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetCompanySuggestionListForCAdmin]
(
    @CompanyTypeId  int,
    @PrefixText  varchar(300),
    @Count  int,
    @CompanyID INT,
    @UserId    int,
    @RoleTypeID   int
)
AS
BEGIN
    DECLARE @strSQL Varchar(max)
    SELECT  @strSQL = ''
    set transaction isolation level read uncommitted

 SET @strSQL ='SELECT DISTINCT TOP '+CONVERT(varchar(9), @Count)+' C.CompanyName AS CompanyName ,C.CompanyID
    FROM  Company AS C,CompanyTypeMapping CTM
    WHERE Lower(C.CompanyName) LIKE '''+@PrefixText+'%'' AND C.Isactive = 1 AND C.CompanyStatusID=1  AND C.CompanyID = CTM.CompanyID
    AND CTM.CompanyTypeId = 2 AND C.CompanyID <> '+CONVERT(varchar(Max),@CompanyID)

 /* Commented by Fathima on 19 Jan 2012 */

 --   set @strSQL =  @strSQL + ' AND C.CompanyID in(
 --SELECT UR.CompanyID
 -- FROM userRole UR
 -- INNER JOIN  Company C ON  UR.CompanyID = C.CompanyID
 -- INNER JOIN companylocations CL ON C.CompanyID = CL.CompanyID
 -- LEFT JOIN  Country Co ON  Co.CountryID=  CL.CountryID
 -- INNER JOIN  [User] U ON U.UserID = UR.UserID AND UR.UserID=' + convert(varchar(20),@UserId) + '
 -- AND UR.UserTypeID =1)'

EXEC(@strSQL)
END
GO
----------------------------------------------------------------------------------------------------------

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetOrderTemplateDetail]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetOrderTemplateDetail]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--[usp_GetOrderTemplateDetail] 191

CREATE PROC [dbo].[usp_GetOrderTemplateDetail] --379726
(
  @OrderId INT
)
As
BEGIN

 -- // modified by sakula for print related tickets 13330\12746\13328\14168

    SELECT
    A.AdOrderId as AdOrderId,
    A.AdOrderNumber As OrderNumber,
    case when AT.AdTypeDescription like '%premium%' OR AT.AdTypeDescription like '%PNS%'
    then AT.AdTypeDescription
    else ''
    end
    As AdDescription,
    Convert(varchar,A.LastUpdatedon,101) as RevisedDate,
    AD.AdOrderDetailsId as AdOrderDetailsId,
    USP.FirstName +' '+USP.LastName As Salespersonname,
    UAP.FirstName +' '+UAP.LastName As Contactname,
    C.CompanyName As SoldTo,
    C.CompanyName As SoldToCompany,
    UCST.Address AS SoldAddress,
    UCST.EmailAddress as SoldContactEmail,
    UST.FirstName +' '+UST.LastName As SoldContact,
    UCST.City as SoldCity,
    CSS.StateName as SoldState,
    UCST.Zip as SoldZip,
    UCST.Phone AS SoldPhone,
    UCST.Fax AS SoldFax,

    (CASE WHEN A.BilltoId = 0 THEN BTAgency.CompanyName ELSE C.CompanyName END) AS BillTo,
    (CASE WHEN A.BilltoId = 0 THEN BTAgency.CompanyName ELSE C.CompanyName END) As BillToCompany,
    (CASE WHEN A.BilltoId = 0 THEN UCCORP.Address ELSE UCBT.Address END) as BilledAddress,
    (CASE WHEN A.BilltoId = 0 THEN UCCORP.EmailAddress ELSE UCBT.EmailAddress END) as BillContactEmail,
    (CASE WHEN A.BilltoId = 0  THEN UCORP.FirstName+ ' ' + UCORP.LAstName ELSE UBT.FirstName + ' '+ UBT.LastName END) As BillContact,
    (CASE WHEN A.BilltoId = 0 THEN UCCORP.City ELSE UCBT.City END) as BillCity,
    (CASE WHEN A.BilltoId  = 0 THEN UStateCorp.StateName ELSE CSB.StateName END) as BillState,
    (CASE WHEN A.BilltoId = 0 THEN UCCORP.Zip ELSE UCBT.Zip END) as BillZip,
    (CASE WHEN A.BilltoId = 0 THEN UCCORP.Phone ELSE UCBT.Phone END) as BilledPhone,
    (CASE WHEN A.BilltoId = 0 THEN UCCORP.Fax ELSE UCBT.Fax END) as BilledFax,

    (CASE WHEN dbo.GetPositionTitle(AD.PositionTitle,AD.SectionID) = '-' THEN S.Description +' '+SZ.Description + ' '
    ELSE S.Description +' '+SZ.Description + ' at ' + dbo.GetPositionTitle(AD.PositionTitle,AD.SectionID) END) AS AdPosition,
     ISNULL(Case when Ad.OrderType='P'
     Then
        'Edition :'+' '+ dbo.GetSalesOrderRegion(AD.AdOrderDetailsId,AD.OrderType)
     else
        'Region/Zone :'+' '+dbo.GetSalesOrderRegion(AD.AdOrderDetailsId,AD.OrderType) +' - ' +
        Convert(varchar(12),Ad.ActivationDate,101)+ ' & '+Convert(varchar(2),AD.Duration)+ ' Month(s)'
     end,'')
    AS Regionlist,
    Case When LogoIndicator= 0 Then 'N' else 'Y' END as Logo,
    Price,
    ISNULL((SELECT count(*) FROM AdOrderDetailsRegionEdition WHERE AdOrderDetailsId = AD.AdOrderDetailsId),0) AS NoOfAd,
    Price * ISNULL((SELECT count(*) FROM AdOrderDetailsRegionEdition WHERE AdOrderDetailsId = AD.AdOrderDetailsId),0) AS Total,
    A.GrossAmount as GrossAmount,
    Case When AD.ApplyDiscount = 1 Then 'Y' Else 'N' End as ApplyDiscount,
    '$ Volume Discount ('+convert(varchar,convert(int,A.DiscountRate))+'%)' as DiscountRate,
    A.DiscountRate as   DiscountRateNumber ,
    Convert(money,(A.GrossAmount *  A.DiscountRate)/100,2) as Discount,
    Convert(money,(A.GrossAmount - ((A.GrossAmount *  A.DiscountRate)/100)),2) as Subtotal,
    (select  Convert(money,sum(Isnull(DepositAmount,0)),2) from dbo.AdOrderRegionEdition where AdOrderId  = @OrderId) as Deposit,
    A.Notes as Comments,
    UCAP.EmailAddress as ADPemail,
 Convert(money,A.NetAmount,2) as TotalAmount,
 (Select Convert(money,(SUM((Isnull(SubTotal,0) * Isnull(PrepaidDiscountRate,0))/100)),2) FROM dbo.AdOrderRegionEdition Where AdOrderID = @OrderId ) as Prepaid,
 Convert(money,(A.NetAmount - (Select SUM(Isnull(DepositAmount,0)) from dbo.AdOrderRegionEdition where AdOrderId  = @OrderId ) ),2) as TotalBalance,
 AD.Comments as OrderComments,dbo.GetSalesOrderZoneName(@OrderId) as ZoneName

  FROM Adorder A LEFT JOIN Company C ON A.CompanyID = C.CompanyID
  LEFT JOIN [User] USP ON A.SalesPersonId = USP.UserID
  LEFT JOIN UserContact UCST ON UCST.UserContactID = A.SoldtoId
  LEFT JOIN UserContact UCBT ON UCBT.UserContactID = A.BilltoId
  LEFT JOIN UserContact UCAP ON UCAP.UserContactID = A.AddressproofId
  LEFT JOIN Countrystates CSS ON UCST.StateID = CSS.StateID
  LEFT JOIN Countrystates CSB ON UCBT.StateID = CSB.StateID
  LEFT JOIN AdorderDetails AD ON A.AdOrderId = AD.AdOrderId
  LEFT JOIN SalesSectionType S ON AD.SectionID=S.SectionID     --INNER to LEFT
  LEFT JOIN SalesSizeType SZ ON AD.SizeTypeID=SZ.SizeTypeID  --INNER to LEFT
  LEFT JOIN  [user] UST ON  UCST.userid   = UST.userid         --INNER to LEFT
  LEFT JOIN [User] UAP ON UAP.userid= UCAP.UserID             --INNER to LEFT
  LEFT JOIN  [user] UBT ON  UBT.userid   = UCBT.userid
  LEFT JOIN UserContact UCCORP ON  A.CorpId  = UCCORP.UserContactID
  LEFT JOIN [User] UCORP ON UCORP.UserID = UCCORP.UserID
  LEFT JOIN UserRole URCORP ON URCORP.UserID = UCORP.UserID
  LEFT JOIN Company BTAgency ON BTAgency.CompanyID = URCORP.CompanyID
  LEFT JOIN Countrystates UStateCorp ON UStateCorp.StateID = UCCORP.StateID
  LEFT JOIN  dbo.AdDetails AT ON  AT.AdTypeID=ad.AdTypeID and AT.AdSizeID=SZ.SizeTypeID and At.SectionID=s.SectionID
 WHERE A.AdOrderId = @OrderId order by AD.OrderType

END

GO
----------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_UpdateAdDetails]    Script Date: 01/25/2012 16:48:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_UpdateAdDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_UpdateAdDetails]
GO
/****** Object:  StoredProcedure [dbo].[usp_UpdateAdDetails]    Script Date: 01/25/2012 16:48:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_UpdateAdDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

--*****************************************************************************************************
--*   Stored Procedure : usp_UpdateAdDetails
--*   Description  : The Ad Informations will be updated into AdDetails table.
--*   Creation Date  : 07/05/2010
--*   Modified By : Fathima
--*   Modified On : 25 Jan 2012
--*   Purpose : To update Ad type details for all active rate cards.

--*****************************************************************************************************
CREATE PROCEDURE [dbo].[usp_UpdateAdDetails]
(
  @AdTypeID    INT,
  @AdDescription   VARCHAR(100),
  @OneAdPerEdition  BIT,
  @RequiredPerEdition  BIT,
  @HeadingTitle   BIT,
  @WorkOrderBilling  BIT,
  @SectionID    INT,
  @AdSizeID    INT,
  @PricePerRegion   MONEY,
  @AifFlag    BIT,
  @RegionalFlag    BIT,
  @AdjodFlag    BIT,
  @TaggingFlag   BIT,
  @ApplyPriceToActiveCard BIT,
  @Status    INT,
  @ESBCode varchar(2),
  @MSGCode varchar(4),
  @PricePerRegionFlag BIT,
  @UpdatedBy    INT,
  @Value     INT OUTPUT
)
AS
BEGIN
Declare @Flag char(1)
 Set @Flag = ''T''
 IF EXISTS (SELECT 1 FROM AdDetails WHERE AdTypeDescription LIKE @AdDescription AND AdTypeID = @AdTypeID AND Status <> 6 )
 BEGIN
    IF EXISTS (SELECT 1 FROM AdDetails WHERE AdSizeID = @AdSizeID AND SectionID = @SectionID AND AdTypeID = @AdTypeID AND Status <> 6 )

     BEGIN
      Set @Flag = ''T''
     END
    ELSE
     IF EXISTS (SELECT 1 FROM AdDetails WHERE AdSizeID = @AdSizeID AND SectionID = @SectionID AND Status <> 6 )
      BEGIN
       Set @Flag = ''F''
       SET @Value = 3
       RETURN @Value
      END
     ELSE
      BEGIN
       Set @Flag = ''T''
      END
 END
 ELSE
  BEGIN
   IF EXISTS (SELECT 1 FROM AdDetails WHERE AdTypeDescription LIKE @AdDescription AND Status <> 6)
     BEGIN
      Set @Flag = ''F''
      SET @Value = 2
      RETURN @Value
     END
    ELSE
     BEGIN
      IF EXISTS (SELECT 1 FROM AdDetails WHERE AdSizeID = @AdSizeID AND SectionID = @SectionID AND AdTypeID = @AdTypeID AND Status <> 6 )
       BEGIN
        Set @Flag = ''T''
       END
      ELSE
       IF EXISTS (SELECT 1 FROM AdDetails WHERE AdSizeID = @AdSizeID AND SectionID = @SectionID AND Status <> 6 )
        BEGIN
         Set @Flag = ''F''
         SET @Value = 3
         RETURN @Value
        END
       ELSE
        BEGIN
         Set @Flag = ''T''
 END
     END
  END
IF(@Flag = ''T'')
  BEGIN
    UPDATE AdDetails
    SET AdTypeDescription = @AdDescription,
    OnePerEdition = @OneAdPerEdition, RequiredPerEdition = @RequiredPerEdition,
    HeadingTitle = @HeadingTitle, WorkOrderBilling = @WorkOrderBilling,
    SectionID = @SectionID, AdSizeID = @AdSizeID, PricePerRegion = @PricePerRegion,
    AifFlag = @AifFlag, RegionalFlag = @RegionalFlag, AdjodFlag = @AdjodFlag, TaggingFlag = @TaggingFlag,
    ApplyPriceToActiveCard = @ApplyPriceToActiveCard, ESBCode=@ESBCode,MSGCode=@MSGCode,Status = @Status,
    UpdatedBy = @UpdatedBy, UpdatedOn = GETDATE(),PricePerRegionFlag=@PricePerRegionFlag
    WHERE AdTypeID = @AdTypeID

    if(@ApplyPriceToActiveCard = 1)
  Begin
  UPDATE RateCardDetails SET AdTypeID = @AdTypeID, SectionID = @SectionID,
    SizeTypeID=@AdSizeID,  Price =  @PricePerRegion, UpdatedBy = @UpdatedBy, UpdatedOn =  GETDATE()
    from MstRateCard where [Status] = 1  and MstRateCard.RateCardMasterID in (select RateCardMasterID from RateCardDetails where AdTypeID = @AdTypeID)
    and RateCardDetails.AdTypeID   = @AdTypeID

   INSERT INTO RateCardDetails select @AdTypeID , @SectionID, @AdSizeID, @PricePerRegion, RateCardMasterID, @UpdatedBy, GETDATE(),null,null
    FROM MstRateCard where [Status] = 1  and RateCardMasterID not in (select RateCardMasterID from RateCardDetails where AdTypeID = @AdTypeID)

    End


    SET @Value = 1
    RETURN @Value
  END
END '
END
GO


----------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetAdTypeIDbyOrder]    Script Date: 01/25/2012 16:50:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAdTypeIDbyOrder]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAdTypeIDbyOrder]
GO
/****** Object:  StoredProcedure [dbo].[usp_GetAdTypeIDbyOrder]    Script Date: 01/25/2012 16:50:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAdTypeIDbyOrder]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-------------------------------------------------------------------
-- Name   : usp_GetAdTypeByID
-- Description : Get Ad Type details by ID
-- Arguments : AdTypeID
-- Returns  : Returns the Ad Type details
--*   Modified By : Fathima
--*   Modified On : 25 Jan 2012
--*   Purpose : To apply isnull condition.

-------------------------------------------------------------------

CREATE PROCEDURE [dbo].[usp_GetAdTypeIDbyOrder]
(
  @AdTypeID INT
)
AS
 BEGIN
 set transaction isolation level read uncommitted
 SELECT AdTypeID,AdTypeDescription,OnePerEdition,RequiredPerEdition,HeadingTitle,WorkOrderBilling,SectionID,AdSizeID,
 isnull(PricePerRegion,0) as PricePerRegion,AifFlag,RegionalFlag,AdjodFlag,TaggingFlag,isnull(ApplyPriceToActiveCard,0) as ApplyPriceToActiveCard,
 Status,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn,ESBCode,MSGCode,isnull(PricePerRegionFlag,0) as PricePerRegionFlag
 from AdDetails where AdTypeID=@AdTypeID
 END  '
END
GO


----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetMultipleRFQ]    Script Date: 03/20/2012 11:05:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetMultipleRFQ]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetMultipleRFQ]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetMultipleRFQ]    Script Date: 03/20/2012 11:05:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
declare @p1 xml
set @p1=convert(xml,N'<DocumentElement><Table1><ManufacturerId>0</ManufacturerId><PartNumber>A100</PartNumber><MyQty>0</MyQty><PartId>0</PartId><DistributorId>0</DistributorId><DistributorPartID>272707254</DistributorPartID></Table1><Table1><ManufacturerId>0</ManufacturerId><PartNumber>A-1-003</PartNumber><MyQty>0</MyQty><PartId>0</PartId><DistributorId>0</DistributorId><DistributorPartID>272793955</DistributorPartID></Table1><Table1><ManufacturerId>0</ManufacturerId><PartNumber>A-1.007-B</PartNumber><MyQty>0</MyQty><PartId>0</PartId><DistributorId>0</DistributorId><DistributorPartID>265033142</DistributorPartID></Table1></DocumentElement>')
exec usp_GetMultipleRFQ @mytable=@p1

declare @p1 xml
set @p1=convert(xml,N'<DocumentElement><Table1><ManufacturerId>0</ManufacturerId><PartNumber>A100</PartNumber><MyQty>260</MyQty><PartId>0</PartId><DistributorId>0</DistributorId><DistributorPartID>272707254</DistributorPartID></Table1></DocumentElement>')
exec usp_GetMultipleRFQ @mytable=@p1

declare @p1 xml
set @p1=convert(xml,N'<DocumentElement><Table1><ManufacturerId>100322</ManufacturerId><PartNumber>1234</PartNumber><MyQty>0</MyQty><PartId>0</PartId><DistributorId>0</DistributorId><DistributorPartID>273819704</DistributorPartID></Table1></DocumentElement>')
exec usp_GetMultipleRFQ @mytable=@p1

Gets 2 records for Alpha Wire

declare @p1 xml
set @p1=convert(xml,N'<DocumentElement><Table1><ManufacturerId>0</ManufacturerId><PartNumber>1234</PartNumber><MyQty>10</MyQty><PartId>0</PartId><DistributorId>0</DistributorId><DistributorPartID>284722184</DistributorPartID></Table1></DocumentElement>')
exec usp_GetMultipleRFQ @mytable=@p1

Gets 2 records Manufacturer Not Identified

*/

CREATE PROC [dbo].[usp_GetMultipleRFQ]
(
    @mytable XML
)
AS
BEGIN
    set transaction isolation level read uncommitted
DECLARE @count INT
DECLARE @rowID INT
DECLARE @SQL VARCHAR(1000)
DECLARE @ManuID int = 0
DECLARE @PartNum VARCHAR(1000)


 SET @count = 0
 SET @rowID = 1

SELECT
   CAST(colx.query('data(ManufacturerId) ') as varchar(max)) as ManufacturerId,
   CAST(colx.query('data(PartNumber) ') as varchar(max)) as PartNumber,
   CAST(colx.query('data(MyQty) ') as varchar(max)) as MyQty,
   CAST(colx.query('data(DistributorPartID) ') as varchar(max)) as PartId,
   IDENTITY( INT ) AS ID
INTO #TEMP FROM @mytable.nodes('DocumentElement/Table1') AS Tabx(Colx)
--Select * FROM #TEMP
CREATE TABLE #MultipleRFQ
(
 [PartNumber]  VARCHAR(200),
 [ManufacturerId] INT,
 [Manufacturer]  VARCHAR(200),
 [DistributorId]  INT,
 [Distributor]  VARCHAR(200),
 [MyQty]    INT,
 [AvailableQty]  INT
)

-- Manufacturer Parts --
INSERT INTO #MultipleRFQ
SELECT
  T.PartNumber,
  ISNULL(T.ManufacturerId,0),
  C.Companyname as Manufacturer,
  0 as DistributorId,
  ---'No Distributor' as Distributor,
'' as Distributor,
  T.MyQty,
  0 as AvailableQty
FROM #Temp T LEFT JOIN Product P ON T.PartId = P.ProductID
  LEFT JOIN COMPANY C ON C.CompanyID = T.ManufacturerId
WHERE ISNULL(T.ManufacturerId, 0) >= 0
--Select * from #MultipleRFQ
SELECT @count = count(*) FROM #Temp

-- While Loop Begins --
WHILE(@count >= @rowID)
BEGIN

    -- Distributor's PartID
    SELECT @PartNum = PartNumber, @SQL = PartId, @ManuID = ManufacturerId FROM #TEMP WHERE ID = @rowID

    Print 'PartID ' + Convert(varchar(30), @SQL) + 'PartID End'

    CREATE TABLE #TempDistpartID
    (
     PartNum  varchar(1000)
    )
    INSERT INTO  #TempDistpartID SELECT * FROM dbo.split(@PartNum,',')
    IF @ManuID = 0
    BEGIN
        INSERT INTO  #MultipleRFQ
        SELECT
          C.PartNumber,
          ISNULL(MC.ManufacturerId,0),
          'Manufacturer Not Identified',      --C.ManufacturerCode
          C.DistID,
          D.Companyname as Distributor,
          (SELECT MyQty FROM #TEMP WHERE ManufacturerId = @ManuID AND ID = @rowID ) as MyQty,
          C.QtyOnHand as AvailableQty
        FROM (select
                    PartNumber
                    ,ManufacturerCode
                    ,QtyOnHand = (CASE WHEN Upper(Ins.QOHDisp) = 'ACTUAL' THEN QtyOnHand ELSE 2147483646 END)
                    ,DistID
                      From DistributorParts DP
                    Join InventorySettings Ins
                    ON Ins.DoNotPub = 0 and DP.DistID = Ins.CompanyID
                    AND ISNULL(Ins.RFQCPID, 0) <> 0
                        WHERE   PartNumber IN (Select PartNum FROM #TempDistpartID )
                     Group By DistID,ManufacturerCode,PartNumber, Ins.QOHDisp, QtyOnHand
         ) as C LEFT JOIN Company D ON C.DistID = D.CompanyID
          LEFT JOIN ManufacturerCode_XRF MC ON C.DistID = MC.DistributorId AND C.ManufacturerCode LIKE MC.ManufacturerCode
          WHERE  ISNULL(MC.ManufacturerId,0)= 0
      END
    ELSE
    BEGIN
        INSERT INTO  #MultipleRFQ
        SELECT
          C.PartNumber,
          ISNULL(MC.ManufacturerId,0),
          ISNULL(MF.Companyname,'Manufacturer Not Identified'),      --C.ManufacturerCode
          C.DistID,
          D.Companyname as Distributor,
          (SELECT MyQty FROM #TEMP WHERE ManufacturerId = @ManuID AND ID = @rowID ) as MyQty,
          C.QtyOnHand as AvailableQty
        FROM (select
                    PartNumber
                    ,ManufacturerCode
                    ,QtyOnHand = (CASE WHEN Upper(Ins.QOHDisp) = 'ACTUAL' THEN QtyOnHand ELSE 2147483646 END)
                    ,DistID
                      From DistributorParts DP
                    Join InventorySettings Ins
                    ON Ins.DoNotPub = 0 and DP.DistID = Ins.CompanyID
                    AND ISNULL(Ins.RFQCPID, 0) <> 0
                        WHERE   PartNumber IN (Select PartNum FROM #TempDistpartID )
                     Group By DistID,ManufacturerCode,PartNumber, Ins.QOHDisp, QtyOnHand
         ) as C LEFT JOIN Company D ON C.DistID = D.CompanyID
          LEFT JOIN ManufacturerCode_XRF MC ON C.DistID = MC.DistributorId AND C.ManufacturerCode LIKE MC.ManufacturerCode
          JOIN Company MF ON ISNULL(MC.ManufacturerId,0) = ISNULL(MF.companyID,0)    AND  ISNULL(MF.companyID,0) = @ManuID

      END
     SET @rowID = @rowID + 1
     SET @SQL = ''
     SET @ManuID = 0
     --Select * FROM #TempDistpartID
     DROP TABLE #TempDistpartID

END
Delete #MultipleRFQ where  DistributorId = 0 and  AvailableQty = 0
SELECT DISTINCT DistributorId,REPLACE(REPLACE(REPLACE(REPLACE(Distributor,'''',' '),'%',' '),'*',' '),':',' ') as Distributor from #MultipleRFQ
Where Distributor <> ''
SELECT DISTINCT Manufacturer,ManufacturerId,PartNumber,MyQty from #MultipleRFQ
SELECT PartNumber,ManufacturerId,Manufacturer,DistributorId,
     REPLACE(REPLACE(REPLACE(REPLACE(Distributor,'''',' '),'%',' '),'*',' '),':',' ') as Distributor,MyQty,AvailableQty FROM #MultipleRFQ
--SELECT * FROM #MultipleRFQ
--SELECT * FROM #TEMP

DROP TABLE #MultipleRFQ
DROP TABLE #TEMP
END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[uspAdJobFolderCreateOnline]    Script Date: 02/27/2012 17:58:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAdJobFolderCreateOnline]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspAdJobFolderCreateOnline]

GO

/****** Object:  StoredProcedure [dbo].[uspAdJobFolderCreateOnline]    Script Date: 02/27/2012 17:58:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--*****************************************************************************************************
--*   Stored Procedure  : [uspAdJobFolderCreateOnline]
--*   Description        : Insert JobFolder
--*   Author            : SIVA PRAKASH D
--*   Creation Date        : 07/13/2011
--*****************************************************************************************************
--*   Modification        : To implement changes according to flags on AdDetails AdjobFlag  mis spelled as AdJodFlag
--*   Author            : Kiran Sangoi
--*   Modify Date        : 11/28/2011
--*****************************************************************************************************
--*   Modification        : To implement changes  issue 14136 and 13268
--*   Author            : Kiran Sangoi
--*   Modify Date        : Jan/30/2012
--*****************************************************************************************************
--*   Modification        : To avoid duplicate job folder creation for each AdOrdrrDetail
--*   Author            : Kiran Sangoi
--*   Modify Date        : Feb/24/2012
--*****************************************************************************************************
--*   Modification        : To include Partial Complete & do optimization for updating AdJobfolderID
--*   Author            : Kiran Sangoi
--*   Modify Date        : Feb/27/2012
--*****************************************************************************************************


--*****************************************************************************************************

CREATE PROCEDURE  [dbo].[uspAdJobFolderCreateOnline]
AS
BEGIN

    DECLARE @AdOrderID int
    DECLARE @AdApprovalID int
    DECLARE @OnlineMonth int
    DECLARE @OnlineYear int
    DECLARE @ADJobFolderID int
    DECLARE @AdOrderDetailsId int

    -- find ads with missing ad job folders
    DECLARE adordercur CURSOR FOR
        SELECT DISTINCT
            AO.AdOrderID,
            ADR.OnlineMonth,
            ADR.OnlineYear,
            ADR.AdOrderDetailsId
        FROM
            AdOrder AO
            INNER JOIN AdOrderDetails AD
                ON AD.AdOrderID = AO.AdOrderID
            INNER JOIN AdOrderDetailsRegionEdition ADR
                ON ADR.AdOrderDetailsId = AD.AdOrderDetailsId
            INNER JOIN AdDetails ADT
                ON ADT.AdTypeID = AD.AdTypeID
--            LEFT JOIN AIF
--                ON AIF.AdOrder_ID = AO.AdOrder_ID
        WHERE
            AO.StatusId in (3,4)     -- Final / Partial Complete
            AND ADR.ADJobFolderID IS NULL
            AND ADR.EditionID=0
            AND ADT.AdjodFlag = 1
--            AND (AIF.AIF_ID IS NOT NULL OR ADT.AIF_Flag = 0)

    -- process orders not having ad job folders
    OPEN adordercur
    FETCH adordercur INTO @AdOrderID,@OnlineMonth,@OnlineYear,@AdOrderDetailsId

    WHILE @@Fetch_Status = 0
    BEGIN
        -- find out if there is an ad job folder for same order
        -- if not, create a new ad job folder
        -- if yes, than use the same ad job folder for the new ads
        SELECT @ADJobFolderID = ISNULL(
                    (SELECT
                        MAX(ADR.ADJobFolderID)
                    FROM
                        AdOrderDetails AD
                        INNER JOIN AdOrderDetailsRegionEdition ADR
                            ON ADR.AdOrderDetailsId = AD.AdOrderDetailsId
                    WHERE
                        AD.AdOrderID = @AdOrderID AND
                        ADR.OnlineMonth = @OnlineMonth AND
                        ADR.OnlineYear = @OnlineYear AND
                        --ADR.AdOrderDetailsId = @AdOrderDetailsId AND *****Commented to avoid duplicate job folder creation
                         ADR.ADJobFolderID IS NOT NULL), 0)

        IF @ADJobFolderID = 0
        BEGIN
            INSERT INTO AdJobFolderMaster(AdJobFolderTypeID,StatusId) VALUES('O',1)
            SET @ADJobFolderID  = SCOPE_IDENTITY()
        END

        UPDATE ADR
            SET AdJobFolderId = @ADJobFolderID
            FROM
                AdOrderDetails AD
                INNER JOIN AdOrderDetailsRegionEdition ADR
                    ON ADR.AdOrderDetailsId = AD.AdOrderDetailsId
            WHERE
                AD.AdOrderID = @AdOrderID AND
                ADR.OnlineMonth = @OnlineMonth AND
                ADR.OnlineYear = @OnlineYear AND
                ADR.AdOrderDetailsId = @AdOrderDetailsId AND
                ADR.ADJobFolderID IS NULL

        FETCH adordercur INTO @AdOrderID,@OnlineMonth,@OnlineYear,@AdOrderDetailsId
    END
    CLOSE adordercur
    DEALLOCATE adordercur
END


GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetDistSelection]    Script Date: 03/27/2012 12:43:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetDistSelection]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetDistSelection]
GO


/****** Object:  StoredProcedure [dbo].[usp_GetDistSelection]    Script Date: 03/27/2012 12:43:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



------------------------------------------------------------------------------------------
-- Created By  : Karthik P
-- Created Date  : 24-Mar-2010
-- Description  : The bulk Product Informations will be inserted into Product table.
-- Arguments  : List is given below
-- Returns   : None
-----------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------
-- Updated By  : Kiran Sangoi
-- Created Date  : 20-Mar-2012
-- Description  :Added Date Code to show when Inventory was uploaded on \SalesMgmt\MultiRFQ.aspx.
---------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------
-- Updated By  : Kiran Sangoi
-- Created Date  : 27-Mar-2012
-- Description  :Added Left join Code to show Inventory 'In stock' & 'Inquire' \SalesMgmt\MultiRFQ.aspx size increased to accomodate the text.
---------------------------------------------------------------------------------------------------
/*

declare @p1 xml
set @p1=convert(xml,N'<DocumentElement><Table1><ManufacturerId>0</ManufacturerId><PartNumber>A-1-003</PartNumber><MyQty>0</MyQty><DistId>102516</DistId><ManufacturerCode>Manufacturer Not Identified</ManufacturerCode></Table1><Table1><ManufacturerId>0</ManufacturerId><PartNumber>A100</PartNumber><MyQty>0</MyQty><DistId>135845</DistId><ManufacturerCode>Manufacturer Not Identified</ManufacturerCode></Table1><Table1><ManufacturerId>0</ManufacturerId><PartNumber>A100</PartNumber><MyQty>0</MyQty><DistId>100786</DistId><ManufacturerCode>Manufacturer Not Identified</ManufacturerCode></Table1></DocumentElement>')
exec usp_GetDistSelection @mytable=@p1,@UserID=84306,@FavType=1

 declare @p1 xml
set @p1=convert(xml,N'<DocumentElement><Table1><ManufacturerId>101671</ManufacturerId><PartNumber>A100</PartNumber><MyQty>0</MyQty><DistId>101457</DistId><ManufacturerCode>Daniels Mfg.</ManufacturerCode></Table1></DocumentElement>')
exec usp_GetDistSelection @mytable=@p1,@UserID=84306,@FavType=1


*/

CREATE PROCEDURE [dbo].[usp_GetDistSelection]
(
    @mytable XML,
    @UserID INT,
    @FavType INT
)
AS
BEGIN
set transaction isolation level read uncommitted
SELECT
    cast(colx.query('data(ManufacturerId) ') as varchar(max)) as ManufacturerId,
    cast(colx.query('data(PartNumber) ') as varchar(max)) as PartNumber,
    cast(colx.query('data(MyQty) ') as varchar(max)) as MyQty,
    cast(colx.query('data(DistId) ') as varchar(max)) as DistId,
    cast(colx.query('data(ManufacturerCode) ') as varchar(max)) as ManufacturerCode
    INTO #TEMP FROM @mytable.nodes('DocumentElement/Table1') AS Tabx(Colx)

SELECT DISTINCT
    DistId,CompanyName AS Distributor,
    [dbo].[RFQFavoriteMail](DistId,@FavType,@UserID) as EMail,
    ISNULL(I.companyid,0) as Buybutton,
    buypentonurl1 as PrefixURL,
    buypentonurl2 as MidURL1,
    buypentonurl3 as MidURL2,
    buypentonurl4 as MidURL3,
    buypentonurl5 as SuffixURL,
    I.RFQCPEmail, buypentonexpire
FROM
    #TEMP T
    INNER JOIN Company CO ON T.DistId = CO.companyID
    LEFT JOIN InventorySettings I ON T.DistId = I.companyid

SELECT
    T.ManufacturerId,
    T.Partnumber,
    ISNULL(T.ManufacturerCode,'') AS Manufacturer,
    T.DistId,
    CO.CompanyName as Distributor,
    ISNULL(CASE WHEN UPPER(I.QOHDisp) = 'ACTUAL' THEN  COnvert(varchar(25), QtyOnHand) ELSE I.QOHDisp END,COnvert(varchar(25), QtyOnHand))  as AvailableQTY,
    ISNULL(DP.Uploaded, '1900-01-01') as DateCode ,
    Price,
    T.MyQty
FROM
    #TEMP T
    INNER JOIN Company CO ON T.DistId = CO.companyID
    INNER JOIN distributorparts DP ON DP.PartNumber = T.PartNumber AND DP.DistID = T.DistID AND DP.ManufacturerCode = T.ManufacturerCode
    LEFT JOIN InventorySettings I on I.CompanyID = T.DistId
WHERE T.ManufacturerId = 0

UNION

SELECT
    T.ManufacturerId,
    T.Partnumber,
    C.CompanyName AS Manufacturer,
    T.DistId,CO.CompanyName as Distributor,
    ISNULL(CASE WHEN UPPER(I.QOHDisp) = 'ACTUAL' THEN  COnvert(varchar(25), QtyOnHand) ELSE I.QOHDisp END,COnvert(varchar(25), QtyOnHand))  as AvailableQTY,
    ISNULL(DP.Uploaded, '1900-01-01') as DateCode ,
    Price,
    T.MyQty
FROM
    #TEMP T
    INNER JOIN Company C ON T.ManufacturerId = C.companyID
    INNER JOIN Company CO ON T.DistId = CO.companyID
    INNER JOIN distributorparts DP ON DP.PartNumber = T.PartNumber AND DP.DistID = T.DistID
    LEFT JOIN InventorySettings I on I.CompanyID = T.DistId
WHERE
    T.ManufacturerId > 0

UNION

SELECT
    T.ManufacturerId,
    T.Partnumber,
    'Manufacturer Not Identified' AS Manufacturer,
    T.DistId,
    CO.CompanyName as Distributor,
    ISNULL(CASE WHEN UPPER(I.QOHDisp) = 'ACTUAL' THEN  COnvert(varchar(25), QtyOnHand) ELSE I.QOHDisp END,COnvert(varchar(25), QtyOnHand))  as AvailableQTY,
    ISNULL(DP.Uploaded, '1900-01-01') as DateCode ,
    Price,
    T.MyQty
FROM
    #TEMP T
    INNER JOIN Company CO ON T.DistId = CO.companyID
    INNER JOIN distributorparts DP ON DP.PartNumber = T.PartNumber AND DP.DistID = T.DistID  AND DP.ManufacturerCode <> T.ManufacturerCode
     LEFT JOIN InventorySettings I on I.CompanyID = T.DistId
WHERE
    T.ManufacturerId = 0

SELECT
    T.DistId,
    T.Partnumber,
    CL.Fax,
    CL.Phone,
    CL.EMail,
    C.CompanyName AS Distributor
FROM
    #TEMP T
    INNER JOIN CompanyLocations CL ON CL.CompanyID = T.DistId
    INNER JOIN Company C ON C.CompanyID = CL.CompanyID
WHERE
    CL.CompanyID = T.DistId
    AND CL.LocationTypeID = 1
    AND CL.IsActive = 1

END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_AdOrderGrossNetAmount]    Script Date: 01/29/2012 18:23:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_AdOrderGrossNetAmount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_AdOrderGrossNetAmount]
GO

GO

/****** Object:  StoredProcedure [dbo].[usp_AdOrderGrossNetAmount]    Script Date: 01/29/2012 18:23:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--*****************************************************************************************************
--*   Stored Procedure  : [usp_AdOrderGrossNetAmount]
--*   Description  : Insert Ad Order Details
--*   Author   : SIVA PRAKASH D
--*   Creation Date  : 05/27/2011
--*****************************************************************************************************
CREATE PROCEDURE [dbo].[usp_AdOrderGrossNetAmount]
(
 @AdOrderId INT
)
AS
BEGIN
  DECLARE @RegionCOUNT int
  Declare @GrossAmount money
  Declare @GrossNonDiscountAmount money
  Declare @DiscountRate int
  Declare @NetAmount money
  DECLARE @AddNetAmount MONEY
  DECLARE @OverwriteDiscount char(1)

 ---Get GrossAmount of the order
  select @GrossAmount = Sum(dbo.ufn_GetAdOrderDetailGrossAmount(AdOrderDetailsId))
        from AdOrderDetails Ad where ad.AdOrderId =  @AdOrderId

 -- Get the dscount rate based on the gross amount and the OverwriteDiscountFlag
 SELECT @OverwriteDiscount =(CASE WHEN OverwriteDiscountFlag =1 then 'y' else 'n' end) from AdOrder where AdOrderId=@AdOrderId
 IF @OverwriteDiscount ='N'
  SELECT @DiscountRate = ISNULL(DiscountRate,0) from MSTDISCOUNT WHERE Status=1 and @GrossAmount between MinimumDiscount AND MaximumDiscount
 ELSE
  SELECT @DiscountRate = DiscountRate from AdOrder where AdOrderId=@AdOrderId

 ---Store perivous orderregiondetails to temp table. We use this temp table to  move the values of Prepaid and deposit amounts later
 SELECT * INTO #TEMPORDER FROM AdOrderRegionEdition WHERE AdOrderID = @AdOrderId
    DELETE FROM AdOrderRegionEdition WHERE AdOrderID = @AdOrderId

 -- Insert the entries for Print Ads grouping them by Print Edition
  INSERT INTO AdOrderRegionEdition(RegionID,EditionID,AdOrderID,GrossAmount,NetAmount,SubTotal,PrepaidDiscountRate)
    SELECT RegionId,EditionId,@AdOrderId,sum(Price),
        [dbo].GetEditChargesNetAmount(@AdOrderId,sum(Price),RegionId,EditionId,'P',@GrossAmount,'n'),
        [dbo].GetEditChargesSubTotal(@AdOrderId,sum(Price),RegionId,EditionId,'P',@GrossAmount,'n'),0
     FROM AdOrderDetailsRegionEdition AE
        INNER JOIN  AdOrderDetails Ad ON  AD.AdOrderDetailsId = AE.AdOrderDetailsId
    WHERE Ad.AdOrderId=@AdOrderId and Ad.OrderType='P' GROUP BY RegionId,EditionId

-- Insert the entries for Online Ads grouping them by Activation date Month and Year
INSERT INTO AdOrderRegionEdition(RegionID,EditionID,AdOrderID,GrossAmount,NetAmount,SubTotal,PrepaidDiscountRate,OnlineMonth,OnlineYear)
    SELECT 0,0,@AdOrderId,Sum(dbo.ufn_GetAdOrderDetailGrossAmount(Ad.AdOrderDetailsId)),
        [dbo].GetEditChargesNetAmount(@AdOrderId,Sum(dbo.ufn_GetAdOrderDetailGrossAmount(Ad.AdOrderDetailsId)),
            DATEPART(MONTH,ActivationDate),DATEPART(YEAR,ActivationDate),'O',@GrossAmount,'n'),
        [dbo].GetEditChargesSubTotal(@AdOrderId,Sum(dbo.ufn_GetAdOrderDetailGrossAmount(Ad.AdOrderDetailsId)),
            DATEPART(MONTH,ActivationDate),DATEPART(YEAR,ActivationDate),'O',@GrossAmount,'n'),
        0,DATEPART(MONTH,ActivationDate),DATEPART(YEAR,ActivationDate)
 FROM AdOrderDetails Ad
 WHERE AD.AdOrderId=@AdOrderId and OrderType='O' GROUP BY DATEPART(MONTH,ActivationDate),DATEPART(YEAR,ActivationDate)


-- Update the AdOrderRegionEdition table with the previous value of Prepaid Discount Rate and Deposit Amount
UPDATE AdOrderRegionEdition SET
    DepositAmount = T.DepositAmount,
    PrepaidDiscountRate = T.PrepaidDiscountRate,
    NetAmount = A.SubTotal-(isnull(T.PrepaidDiscountRate,0) * (A.SubTotal / 100))
from #TEMPORDER T ,AdOrderRegionEdition A
WHERE T.RegionId = A.RegionId AND T.EditionId = A.EditionId AND T.AdOrderId = A.AdOrderId
    and (T.DepositAmount>0 OR T.PrepaidDiscountRate>0 )

 DROP TABLE #TEMPORDER

 --Get sum of gross amount and netamount and update into order table
 SELECT @GrossAmount =SUM(GrossAmount) FROM AdOrderRegionEdition WHERE AdOrderID=@AdOrderId


 UPDATE AdOrder SET  GrossAmount = (SELECT SUM(GrossAmount) FROM AdOrderRegionEdition WHERE AdOrderID=@AdOrderId),
      NetAmount = (SELECT SUM(NetAmount) FROM AdOrderRegionEdition WHERE AdOrderID=@AdOrderId),
      DiscountRate = @DiscountRate WHERE AdOrderID=@AdOrderId
END


GO
----------------------------------------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAdFiles]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAdFiles]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =========================================================================================
-- Author   : Sudha
-- Modified By   :
-- Create date   : 17-June-2011
-- Modified Date :
-- Description   : Get AdFile
-- ==========================================================================================

 --exec usp_GetAdFiles 1,'August 2011'
 /*
 exec usp_GetAdFiles 379756,'February 12 2012'
   */
CREATE PROCEDURE [dbo].[usp_GetAdFiles]
(
@orderid int,
@date varchar(50)
)
AS
 BEGIN


set transaction isolation level read uncommitted
SELECT DISTINCT


          SZ.SizeCodeName,
          S.SectionCode,
          (SELECT CASE WHEN [CheckInStatus]='I' THEN 'YES' ELSE 'NO' END FROM ChkInChkOutArtWrkFiles WHERE AdId=A.AdOrderDetailsId) AS CheckInStatus,
          (SELECT CASE WHEN [CheckOutStatus]='O' THEN 'YES' ELSE 'NO' END FROM ChkInChkOutArtWrkFiles WHERE AdId=A.AdOrderDetailsId) AS CheckOutStatus,
          convert(varchar, A.ActivationDate, 101)AS ActivationDate ,(dbo.GetPositionTitle(A.PositionTitle,A.SectionID)) AS SizeSectionPosition ,
          A.AdOrderId ,AD.CompanyId,Cmpny.CompanyName,A.AdOrderDetailsId,(SELECT  [FileName] FROM ChkInChkOutArtWrkFiles WHERE AdId=A.AdOrderDetailsId) AS ImageName

FROM
   AdOrderDetails A
         INNER JOIN AdOrder AD ON A.AdOrderId=AD.AdOrderId
         INNER JOIN Company Cmpny ON AD.CompanyId = Cmpny.CompanyId
         INNER JOIN SalesSectionType S ON A.SectionID=S.SectionID
         INNER JOIN SalesSizeType SZ ON A.SizeTypeID=SZ.SizeTypeID
         INNER JOIN AdOrderDetailsRegionEdition ADR ON ADR.AdOrderDetailsId = A.AdOrderDetailsId
         INNER JOIN AdDetails ADDtls ON ADDtls.AdTypeID=A.AdTypeID

 WHERE   A.AdOrderId =@orderid and A.ordertype='O' and DATENAME(MM, A.ActivationDate) + ' ' + CAST(DAY(A.Activationdate)AS  VARCHAR(2)) + ' ' + CAST(YEAR(A.Activationdate) AS VARCHAR(4))=@date
 AND ADR.ADJobFolderID is NOT NULL

END
GO
----------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[Load_Seelines_4Mfr]    Script Date: 01/31/2012 12:11:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Load_Seelines_4Mfr]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Load_Seelines_4Mfr]
GO

/****** Object:  StoredProcedure [dbo].[Load_Seelines_4Mfr]    Script Date: 01/31/2012 12:11:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:        Lalit Mehta
-- Create date: Jan 31, 2012
-- Description:    Load Seeline for Manufacturers
-- =============================================
CREATE PROCEDURE [dbo].[Load_Seelines_4Mfr]
AS
BEGIN
    TRUNCATE TABLE MFRAlsoKnownAs

    INSERT INTO MFRAlsoKnownAs
    SELECT
        c.CompanyID,
        dbo.ufn_DS_Get_ManufacturerSeeLines(c.CompanyID) as AlsoKnownAs
    FROM
        Company c,
        CompanyTypeMapping ctm
    WHERE
        c.CompanyID = ctm.CompanyID
        and Ctm.CompanyTypeID = 1
    SET NOCOUNT ON;
END


GO

----------------------------------------------------------------------------------------------------------
/****** Object:  StoredProcedure [dbo].[usp_GetLocationFromIP]    Script Date: 01/27/2012 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetLocationFromIP]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetLocationFromIP]
GO
/****** Object:  StoredProcedure [dbo].[usp_GetLocationFromIP]    Script Date: 01/27/2012 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetLocationFromIP]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-------------------------------------------------------------------
-- Name            : Kiran B. S
-- Date            : 27/JAN/2012
-- Description  : To get Location details from IP
-- Arguments    : IpDecimal (Converted the original IP)
-- Returns      : Returns the Country Short form and full form, Region, City, Latitude, Longitude and Zip code
-------------------------------------------------------------------

CREATE PROCEDURE [dbo].[usp_GetLocationFromIP]
    @IpDecimal    BIGINT
AS
BEGIN
    set transaction isolation level read uncommitted
    SELECT
        CountryShort
        ,CountryLong
        ,IpRegion
        ,IpCity
        ,IpLatitude
        ,IpLongitude
        ,IpZipcode
    FROM IPLocations
    WHERE @IpDecimal BETWEEN IpFrom AND IpTo
END'
END
GO

----------------------------------------------------------------------------------------------------------

GO

/****** Object:  StoredProcedure [dbo].[usp_GetEditionList]    Script Date: 02/01/2012 14:46:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetEditionList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetEditionList]
GO

GO

/****** Object:  StoredProcedure [dbo].[usp_GetEditionList]    Script Date: 02/01/2012 14:46:02 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




-- =========================================================================================
-- Author   : Sudha
-- Modified By   :
-- Create date   : 26-May-2011
-- Modified Date :
-- Description   : Get Edition list
-- ==========================================================================================



CREATE PROCEDURE [dbo].[usp_GetEditionList]

AS

BEGIN
  set transaction isolation level read uncommitted
  SELECT E.EditionID, HeadingTitle as Edition from Editions E WHERE E.StatusID<>2 order by PublicationDate

END
GO
----------------------------------------------------------------------------------------------------------
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAdDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAdDetails]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-------------------------------------------------------------------
-- Name   : SATHEESH KUMAR .S
-- Description  : Get AD list
-- Arguments    : ORDER ID
-- Returns      : Returns Advertisement list
-------------------------------------------------------------------
-- Modified By  : Kiran Sangoi
-- Description  : Added logic to use AifFlag Flags on  AdDetails
-- Modify Date  : Nov. 28 2011

-------------------------------------------------------------------

CREATE PROCEDURE [dbo].[usp_GetAdDetails]
(
 @AdOrderId INT
)
AS
BEGIN
    set transaction isolation level read uncommitted

     SELECT A.OrderType,A.AdOrderId,
     A.AdOrderDetailsId,
      ADE.AdTypeId,
     ADE.AdTypeDescription,
     S.SECTIONID,
     S.DESCRIPTION as Sectiondescription,
  A.AdOrderDetailsId,
 -- (S.Description +' '+SZ.Description +' at '+dbo.GetPositionTitle(A.PositionTitle,A.SectionID)) AS SizeSectionPosition,
 (dbo.GetPositionTitle(A.PositionTitle,A.SectionID)) AS SizeSectionPosition,
  AD.AIF_PrintInstruction,A.AIF_Instruction,
  --case when A.AIF_Instruction IS NULL
  --then PL.WebVersion
  --else A.AIF_Instruction
  --end as AIF_Instruction,
  A.AIF_Url
 FROM  AdOrderDetails A
   INNER JOIN AdOrder AD ON A.AdOrderId=AD.AdOrderId
   INNER JOIN SalesSectionType S ON A.SectionID=S.SectionID
   INNER JOIN SalesSizeType SZ ON A.SizeTypeID=SZ.SizeTypeID
   INNER JOIN AdDetails ADE ON ADE.AdTypeID  = A.AdTypeID  AND ADE.AifFlag = 1
   LEFT JOIN PremiumListing PL ON PL.AdOrderId=AD.AdOrderId and PL.AdOrderDetailsId=A.AdOrderDetailsId
  WHERE  A.AdOrderId =@AdOrderId AND A.OrderType ='O'

END
GO
----------------------------------------------------------------------------------------------------------
GO
/****** Object:  StoredProcedure [dbo].[usp_GetAdDetailsPremiumListing]    Script Date: 03/19/2012 20:10:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAdDetailsPremiumListing]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAdDetailsPremiumListing]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetAdDetailsPremiumListing]    Script Date: 03/19/2012 20:10:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-------------------------------------------------------------------
-- Name   : SATHEESH KUMAR .S
-- Description  : Get Advertisement list for Premium Listing
-- Arguments    : ORDER ID
-- Returns      : Returns Advertisement list
-------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetAdDetailsPremiumListing] --379715,'P,PNS,ML','February 14 2012 ' ---1,',bu,p,ww22,3423,234,234234,'
(
 @orderid INT,
 @sizecodename varchar(100),
 @date varchar(50)
)
AS
BEGIN
    set transaction isolation level read uncommitted

SET @sizecodename = ''''+Replace(@sizecodename,',',''',''')+''''

DECLARE @SQLQUERY vARCHAR(2000)
set @SQLQUERY = 'SELECT DISTINCT A.AdOrderId,
     A.AdOrderDetailsId,
     ADE.AdTypeId,
     ADE.AdTypeDescription,
     S.SECTIONID,
     S.DESCRIPTION as Sectiondescription,
     SZ.Description As SizeDesc,
     SZ.SizeTypeID,
     dbo.GetSalesOrderRegion(A.AdOrderDetailsId,A.OrderType) AS Regionlist,
     PL.WebVersion,(dbo.GetPositionTitle(A.PositionTitle,A.SectionID) +'' : '') As PositionTitle,
     PL.WebVersion As PositionWebVersion,A.OrderType

 FROM  AdOrderDetails A
         INNER JOIN SalesSectionType S ON A.SectionID=S.SectionID
         INNER JOIN AdDetails ADE ON ADE.ADTYPEID=A.ADTYPEID
         INNER JOIN SalesSizeType SZ ON A.SizeTypeID=SZ.SizeTypeID AND SZ.SizeCodeName IN ('+ @sizecodename + ') OR ( SZ.SizeCodeName=''B'' AND ade.MSGCode=''PNSB'')
         LEFT JOIN PremiumListing PL ON PL.AdOrderDetailsId=A.AdOrderDetailsId
 WHERE  A.AdOrderId = ' + convert(varchar,@orderid) + ' AND A.OrderType =''O'' and DATENAME(MM, A.ActivationDate) + '' '' + CAST(DAY(A.Activationdate)AS  VARCHAR(2)) + '' '' + CAST(YEAR(A.Activationdate) AS VARCHAR(4))='''+@date+''''
exec(@SQLQUERY)
END
GO
----------------------------------------------------------------------------------------------------------
GO
/****** Object:  StoredProcedure [dbo].[usp_DeleteDistOldDaysParts]    Script Date: 03/23/2012 10:34:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_DeleteDistOldDaysParts]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[usp_DeleteDistOldDaysParts]
GO

/****** Object:  StoredProcedure [dbo].[usp_DeleteDistOldDaysParts]    Script Date: 03/23/2012 10:34:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =========================================================================================
-- Author        :    Siva
-- Create date    :    11-DEC-2011
-- Description    :    To delete distributor's old parts from some days eg. 3,4,5 weeks, passing 1 week means 7days
-- Updated : Siva Batch delete implemented on 03-Mar-2012
-- ==========================================================================================
CREATE PROCEDURE [dbo].[usp_DeleteDistOldDaysParts]
    @OldDays int
AS
--WHILE EXISTS ( SELECT InvID FROM DistributorParts_Siva WHERE Uploaded < CONVERT(Varchar(10),GetDate()-4,101))
BEGIN
    DELETE TOP (100000)
    FROM DistributorParts
    WHERE Uploaded < CONVERT(Varchar(10),GetDate()-@OldDays,101)
END
GO
----------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetSearchDistVendor]    Script Date: 02/03/2012 17:53:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchDistVendor]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchDistVendor]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchDistVendor]    Script Date: 02/03/2012 17:53:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-----------------------------------------------------------------------------------------
-- Author  : Fathima
-- Description : Get distributors and vendors List
-- Arguments : @CompanyTypeID
-- Returns  : Returns the Manufacturer Name
------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetSearchDistVendor]
AS
BEGIN
    set transaction isolation level read uncommitted
    SELECT
        C.CompanyId,
        C.CompanyName
    FROM
        CompanyTypeMapping CTM,
        Company C
    WHERE
        CTM.CompanyID=C.CompanyID
        AND  CTM.CompanyTypeID in (2,3)
        AND  C.isActive=1
        AND     C.CompanyName <>''
    group by
        c.CompanyID,
        c.CompanyName
    Order BY
        C.CompanyName ASC
END
GO
----------------------------------------------------------------------------------------------------------
GO
/****** Object:  StoredProcedure [dbo].[usp_GetAllProductTypes]    Script Date: 02/03/2012 19:16:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAllProductTypes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAllProductTypes]
GO
/****** Object:  StoredProcedure [dbo].[usp_GetAllProductTypes]    Script Date: 02/03/2012 19:16:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAllProductTypes]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:  Kartikeya Sinha
-- Create date: 1 Sep 2011
-- Description: Gets the ProductTypes
--[dbo].[usp_GetAllProductTypes]
-- Modified By : Fathima
-- Modified On : 03 Feb 2012
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetAllProductTypes]

AS
BEGIN

 SET NOCOUNT ON;
set transaction isolation level read uncommitted
 SELECT
     Ltrim(TypeDescription) as TypeDescription,
     BookName,
     ProductTypeID
 from
     Producttype P,
     MstStatus MS
 where
     MS.StatusID=P.StatusID and
     P.Isactive=1 and
     lower(ltrim(Rtrim(MS.Description))) = ''active'' and
     TypeDescription is not null
order by
    TypeDescription

END  '
END
GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetWelcomeCompanyInfo]    Script Date: 05/07/2012 00:51:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetWelcomeCompanyInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetWelcomeCompanyInfo]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetWelcomeCompanyInfo]    Script Date: 05/07/2012 00:51:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-----------------------------------------------------------------------------
--- Created By  : Bala and Ashok Kumar
--- Created Date : 6th-April-2011
-- Modified By  : Karthik P ,Ramesh K, Lalit Mehta
--- Modified Date : 29-Apr-2010,02-02-2012, 05-May-2012
--- Description  : The Company Welcome page data will be display
--- Arguments  : None
--- Returns   : None
-----------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetWelcomeCompanyInfo] ---132317
(
    @CompanyID int
)
AS
BEGIN
    set transaction isolation level read uncommitted
    SELECT c.CompanyID,
        c.CompanyName,
          c.URL,
          CASE WHEN c.Bookname IS NULL
          THEN [dbo].[Get_SeeLineCompany](@CompanyID, c.CompanyStatusID)
          ELSE  c.Bookname +', '+[dbo].[Get_SeeLineCompany](@CompanyID, c.CompanyStatusID)
          END AS Bookname,
        c.SalesPerson,
          CONVERT(VARCHAR(10),c.updatedon,110) as UpdatedOn,
          CONVERT(VARCHAR(10),c.createdon,110) as Createdon,
          c.companylogo,
          cl.LocationID,
          cl.Address1,
          cl.Address2,
          cl.City,
          cl.EMail,
          cl.phone,
          cl.TollFreeNo,
          cl.fax,
          cl.zip,
          s.StateName,
          s.StateCode,
          LT.Description as LocationType,
          ST.Description as Status,
          cn.countryname as countryname,
          CASE cl.donotpublishindicator WHEN 0 THEN 'N' WHEN 1 THEN 'Y' END as donotpublishindicator
    FROM
        Company C LEFT JOIN  CompanyLocations CL ON C.CompanyID = CL.CompanyID AND CL.IsActive =1  AND LocationTypeID = 1 and LocationStatusID = 1
          left join MstStatus ST on c.CompanyStatusID = st.StatusID
          LEFT JOIN MstLocationType LT ON CL.LocationTypeID  = LT.LocationTypeID
          LEFT JOIN CountryStates s ON CL.StateID = S.StateID
          LEFT JOIN Country CN ON CL.countryid = CN.countryid
    WHERE
        C.CompanyID = @CompanyID

        Select firstname,lastname from [user] where userID = (Select top 1 SalesPerson_ID FROM SalesAssignments where company_id  = @CompanyID and Status=1)
END

GO

----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetManufacturerCodeList]    Script Date: 02/22/2012 20:51:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetManufacturerCodeList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetManufacturerCodeList]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetManufacturerCodeList]    Script Date: 02/22/2012 20:51:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-------------------------------------------------------------
-- Created By : Balakrishna
-- Date Created : 09-Dec-2010
-- Description :
-- Arguments : None
-- Returns  : None
-- Modified By : Mohit on 2/22/2012 to change the joins and Add NoLock to increase performance of this SP.
---------------------------------------------------------------
CREATE  PROCEDURE [dbo].[usp_GetManufacturerCodeList]
(
 @CompanyId int
)
AS
BEGIN
    set transaction isolation level read uncommitted
Select @CompanyId as DistId, CompanyName,
    (SELECT Count(DISTINCT DP.ManufacturerCode) AS UnMapped
        FROM Distributorparts DP with (NoLock)  WHERE  DP.ManufacturerCode<>'' AND DP.ManufacturerCode NOT IN
            (SELECT MCXF.ManufacturerCode FROM ManufacturerCode_XRF MCXF with (NoLock) WHERE DP.DistID=MCXF.DistributorID)
        AND DP.DistID=@CompanyId) as UNMapped,
    ( SELECT Count(DISTINCT MC.ManufacturerCode)
        FROM ManufacturerCode_XRF MC with (NoLock),Distributorparts DIP with (NoLock)
        WHERE DIP.DistID=MC.DistributorID AND DIP.DistID=@CompanyId)as Mapped
 from Company with (NoLock) where Company.companyid =  @CompanyId

END

GO

----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_DeleteContactRole]    Script Date: 02/15/2012 01:42:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_DeleteContactRole]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_DeleteContactRole]
GO


/****** Object:  StoredProcedure [dbo].[usp_DeleteContactRole]    Script Date: 02/15/2012 01:42:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_DeleteContactRole]
(
    @CompanyID     int,
    @RoleID      int,
    @UserID      int
)
as
BEGIN

delete from userRole where userid=@UserID and RoleID=@RoleID and companyid=@CompanyID

END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSalesCompDetails]    Script Date: 02/14/2012 15:16:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSalesCompDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSalesCompDetails]
GO

GO

/****** Object:  StoredProcedure [dbo].[usp_GetSalesCompDetails]    Script Date: 02/14/2012 15:16:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

------------------------------------------------------------------------------------------
-- Created By  : Siva Prakash
-- Procedure Name : usp_GetSalesCompDetails
-- Created Date  : 24th-May-2011
-- Description  : The Company Informations will be display in sales lookup screen.
-- Arguments  : List is given below
-- Returns   : Company Details
-- Example   : exec usp_GetSalesCompDetails 'a'
-- Modified By : Mohit Garg  Date  2/14/2012  - added condition (SA.End_Date is null) to get only current SalesPerson

------------------------------------------------------------------------------------------
CREATE  PROCEDURE [dbo].[usp_GetSalesCompDetails]
(
@CompanyName nvarchar(100)
)
AS
BEGIN

select DISTINCT c.CompanyID,  c.CompanyName ,u.FirstName+' '+u.LastName as salesperson,u.userid from Company c
inner join SalesAssignments SA on SA.Company_Id =c.CompanyID and SA.End_Date is null
inner join [User] U  on u.userid = SA.SalesPerson_ID
where c.CompanyName like @CompanyName+'%' AND C.CompanyStatusID=1
order by C.companyName

End

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[Usp_GetSalesOrderCompanyDetails]    Script Date: 02/14/2012 15:37:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Usp_GetSalesOrderCompanyDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Usp_GetSalesOrderCompanyDetails]
GO

GO

/****** Object:  StoredProcedure [dbo].[Usp_GetSalesOrderCompanyDetails]    Script Date: 02/14/2012 15:37:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

------------------------------------------------------------------------------------------
-- Created By  : Siva Prakash
-- Procedure Name : Usp_GetSalesOrderCompanyDetails
-- Created Date  : 24th-May-2011
-- Description  : The Company Informations will be display.
-- Arguments  : List is given below
-- Returns   : Company Details
-- Example   : exec [Usp_GetSalesOrderCompanyDetails] 100845
-- Modified By : Mohit Garg  Date  2/14/2012  - added condition (SA.End_Date is null) to get only current SalesPerson
------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Usp_GetSalesOrderCompanyDetails]-- 98
(
 @CompanyID Int
)
AS
BEGIN
  set transaction isolation level read uncommitted
  SELECT  C.CompanyID, C.CompanyName,C.MSGIDNo AS MsgCode,C.BrandCode,(U.FirstName +' '+ U.LastName) AS SalesPerson,UC.EmailAddress,U.UserId
  FROM
  Company  C INNER JOIN Salesassignments SA ON  C.CompanyId =SA.Company_ID and SA.End_Date is null
  INNER JOIN  [USER] U ON U.UserId = SA.SalesPerson_ID
  INNER JOIN UserContact UC ON U.UserId =UC.UserID
  WHERE CompanyID = @CompanyID  AND C.CompanyStatusID=1

  SELECT Left(Description,1) CompanyType,
  (SELECT COUNT(*) FROM CompanyTypeMapping WHERE CompanyID = @CompanyID  AND MstCompanyType.CompanyTypeID=CompanyTypeID) AS TypeStatus
  FROM dbo.MstCompanyType

  SELECT UC.UserContactID,U.FirstName +' '+ U.LastName AS Contact FROM
  UserContact UC INNER JOIN UserRole UR ON  UC.USERID = UR.USERID
  INNER JOIN [USER] U ON UR.USERID = U.USERID
  INNER JOIN COMPANY C ON C.COMPANYID = UR.COMPANYID
  WHERE UR.COMPANYID = @CompanyID AND C.CompanyStatusID=1


END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchAllDistVendor]    Script Date: 02/20/2012 17:46:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchAllDistVendor]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[usp_GetSearchAllDistVendor]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchAllDistVendor]    Script Date: 02/20/2012 17:46:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--------------------------------------------------------------------------
-- Created By : Thalai
-- Created On : 21-Apr-2011
-- Returns   : None
-- Purpose   : To Get All Distributor and Vendor with Related facet count
-----------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetSearchAllDistVendor]
(
    @CompanyName VARCHAR(3),
     @UserRole VARCHAR(20)
)
AS
BEGIN
  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
  IF(@CompanyName='0-9')
    BEGIN
        SELECT distinct C.CompanyID,CompanyName,[dbo].[Get_DistPartCount] (C.CompanyID) as PartCount
        FROM Company C(nolock),CompanyTypeMapping CTM(nolock)
        WHERE C.CompanyID = CTM.CompanyID
            AND CTM.CompanyTypeID in (2,3)
            AND CompanyName NOT LIKE '[a-z]%'
            AND companyStatusID = 1
        ORDER BY CompanyName
     END
  ELSE
    BEGIN
        SET @CompanyName =  @CompanyName+'%'
        SELECT distinct C.CompanyID,CompanyName,[dbo].[Get_DistPartCount] (C.CompanyID) as PartCount
        FROM Company C(nolock), CompanyTypeMapping CTM(nolock)
        WHERE C.CompanyID = CTM.CompanyID
            AND CTM.CompanyTypeID in (2,3)
            AND CompanyName LIKE @CompanyName
            --AND Isactive IN (Select StatusID FROM Mststatus(nolock) WHERE Description = 'Active' AND isActive = 1)
            AND companyStatusID = 1
        ORDER BY CompanyName
    END
END
GO
----------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_GetWelcomeCompanyDataInfo]    Script Date: 02/20/2012 17:44:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetWelcomeCompanyDataInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetWelcomeCompanyDataInfo]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetWelcomeCompanyDataInfo]    Script Date: 02/20/2012 17:44:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetWelcomeCompanyDataInfo]
(
      @CompanyID int
)
AS
set transaction isolation level read uncommitted
------------------Manufacturer Count for Welcome Page------------------------------
BEGIN

SELECT COUNT(*) as MfrCount FROM RegionAuthorization r with(nolock),company c with(nolock) WHERE c.Companyid=r.mfrid and c.isActive = 1 and c.companystatusid=1 and r.DistID=@CompanyID
END
-----------------Distributor Count for Welcome Page--------------------------------
BEGIN
select  count(CompanyName) as DistCount from Company with(nolock) where Companystatusid=1 and isActive=1 and CompanyID in(select DistID from RegionAuthorization a with(nolock),RegionZoneStatus b with(nolock) where MfrID=@CompanyID and IsActive=1 and b.mfrdistid = a.mfrdistid)-- and b.authstatusid not in(3,1,5))

END
--------------------Products Count for Welcome Page--------------------------------
begin
--Count the downstream level products
 select count(*) as PrdCount from CompanyProductType with(nolock) where ProductTypeId not in(select distinct(parentid) from producttype a with(nolock),
 CompanyProductType b with(nolock) where a.producttypeid=b.producttypeid and b.companyid=@CompanyID and a.isactive=1 and a.statusid=1) and companyid=@CompanyID and isactive=1

end
--------------------Service Count for Welcome Page---------------------------------
begin
   select count(*) as SerCount from vendorservicemapping with(nolock) where serviceid not in(select distinct(parentID) from producttype a with(nolock),
   vendorservicemapping b with(nolock) where a.producttypeid=b.serviceID and b.vendorid=@CompanyID) and vendorid=@CompanyID

end
--------------------Reps Count for Welcome Page------------------------------------
begin
      select count(*) as RepsCount from reps with(nolock) where companyid=@CompanyID  and isactive=1
end
-------------------Distributor Parts Count for Welcome Page---------------------------
BEGIN
  SELECT [dbo].[Get_SearchPartsCount] (@CompanyID) as PartCount

END
BEGIN
       SELECT [dbo].[Get_CompanyLastUploadedDate](@CompanyID) as LastUploadDate
END
GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetContactId]    Script Date: 02/21/2012 18:38:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetContactId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetContactId]

GO

/****** Object:  StoredProcedure [dbo].[usp_GetContactId]    Script Date: 02/21/2012 18:38:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =========================================================================================
-- Author         : Sudha
-- Modified By   : Siva
-- Create date   : 6-June-2011
-- Modified Date : 21-Feb-2012
-- Description   : Get ContactId
-- ==========================================================================================

CREATE  PROCEDURE [dbo].[usp_GetContactId]
   @orderid int

AS
BEGIN

SELECT
    AddressProofId AS contactid,
    convert(varchar, OrderDate, 101)AS OrderDate
FROM
    Adorder
WHERE
    AddressProofId is not null
    AND adorderid=@orderid

END
GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetContactDetails]    Script Date: 02/21/2012 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetContactDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetContactDetails]

GO

/****** Object:  StoredProcedure [dbo].[usp_GetContactDetails]    Script Date: 02/21/2012 18:41:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =========================================================================================
-- Author   : Sudha
-- Modified By   :
-- Create date   : 6-June-2011
-- Modified Date :
-- Description   : Get Contact Details
-- ==========================================================================================

--exec usp_GetContactDetails 491

CREATE  PROCEDURE [dbo].[usp_GetContactDetails]

   @contactid int

AS
BEGIN
    SELECT
        DISTINCT u.firstname + ' ' + u.lastname as loginname,
        uc.userid,
        u.userregid,
        uc.emailaddress
    from
        [user] u
        INNER JOIN usercontact uc on uc.userid=u.userid
        INNER JOIN adorder ao on ao.AddressProofId=uc.usercontactid
        INNER JOIN [user]  on u.userid=uc.userid
    where
        UserContactID=@contactid

END
GO
----------------------------------------------------------------------------------------------------------
GO
/****** Object:  StoredProcedure [dbo].[usp_Rep_DistFewerLinesInBook]    Script Date: 09/24/2011 22:27:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Rep_DistFewerLinesInBook]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Rep_DistFewerLinesInBook]
GO
/****** Object:  StoredProcedure [dbo].[usp_Rep_DistFewerLinesInBook]    Script Date: 09/24/2011 22:27:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Rep_DistFewerLinesInBook]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-------------------------------------------------------------------
-- Name   : [usp_Rep_DistFewerLinesInBook]  10
-- Author : Fathima
-- CreatedOn : 26-07-2011
-- Description : Distributors with Fewer Lines in Book than Guaranteed
-- Tables Used: Editions,CompanyTypeMapping,Company,MstCompanyStatus,CompanyLocations,MstEditionStatus
-- Arguments :@Region_ID
-- Returns  : Recordset
-------------------------------------------------------------------
CREATE PROC [dbo].[usp_Rep_DistFewerLinesInBook] --10
(
@Region_ID int
)
AS

BEGIN
 SET NOCOUNT ON
DECLARE @EditionId INT
SET @EditionId =(SELECT MIN(E.EditionID) FROM Editions E
           WHERE E.RegionID = @Region_ID
            AND NOT E.StatusID = (SELECT StatusID
   FROM MstEditionStatus where Description=''Complete''))

Select
 AO.CompanyID,
   --case when (CONVERT(varchar(250),isnull(C.BookName,''''))) = '''' then (CONVERT(varchar(250),C.CompanyName)) else (CONVERT(varchar(250),C.BookName)) end AS Book_Name,
   C.CompanyName AS Book_Name,
   dbo.Get_CompanyTypeName(AO.CompanyID) as Company_Type,
isnull(AOR.GuranteeLines,0) as Guranteed_Lines,
(isnull(AOR.GuranteeLines,0)+isnull(AOR.GLinesManual,0)) as  Cnt_Book_Mfr,
 E.Title AS Edition_Title,
 (SELECT COUNT(*) FROM RegionAuthorization RA WHERE RA.DistID = C.CompanyID AND RA.Publish=0) AS CutLine
 from ADOrder AO
 inner join AdOrderRegionEdition AOR
  on AOR.ADOrderID = AO.ADOrderID
 inner join Editions E
  on E.EditionID = AOR.EditionID AND E.EditionID = @EditionId
 inner join Company C
  on C.CompanyID = AO.CompanyID
 inner join MstCompanyType MCT
  on MCT.[Description] in (''Distributor'',''Value Added Vendor'')
 inner join CompanyTypeMapping CTM
  on CTM.CompanyID = C.CompanyID AND MCT.CompanyTypeID = CTM.CompanyTypeID
 where AOR.RegionID = 10
 and (isnull(AOR.GuranteeLines,0)+isnull(AOR.GLinesManual,0)) <=  isnull(AOR.GuranteeLines,0)
order by Book_Name

 /* If no company found generate a NO CASES FOUND row */
 IF @@ROWCOUNT = 0
  SELECT

    NULL Company_ID, ''No Cases Found'' Book_Name,
    NULL Company_Type,
    NULL Cnt_Book_Mfr,
    NULL Guaranteed_Lines,
    Title Edition_Title
   FROM Editions
   WHERE EditionID = @EditionId
END'
END
GO
----------------------------------------------------------------------------------------------------------
GO
/****** Object:  StoredProcedure [dbo].[usp_GetRFQParts]    Script Date: 02/22/2012 17:06:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetRFQParts]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetRFQParts]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetRFQParts]    Script Date: 02/22/2012 17:06:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--------------------------------------------------------------------------------------
-- Created BY : Karthik P
-- Created ON : 28-Jun-2011
-- Description  : This procedure will return RFQ detail.
-- Arguments : ManufacturerId, PartNumber
-- Returns  : None
--------------------------------------------------------------------------------------
CREATE PROC [dbo].[usp_GetRFQParts] --21,71,'1086,3151183,22722',1,24
(
 @ManufacturerId INT,
 @DistributorId INT,
 @DistpartIds Varchar(2000),
 @FavType INT,
 @UserID INT
)
AS
BEGIN
DECLARE @SQL VARCHAR(2000)

SET @SQL = 'SELECT DistID AS DistributorId,PartNumber,
   CompanyName AS Distributor,QtyOnHand AS AvailableQty,
   [dbo].[RFQFavoriteMail]( DistID , ' + Convert(varchar,@FavType) + ' , ' + Convert(varchar,@UserID) + ' ) AS EMail
   FROM distributorparts INNER JOIN Company C ON DistID = CompanyID
   WHERE InvID IN (' +  @DistpartIds + ') order by CompanyName'
EXEC(@SQL)

SELECT CompanyName as Manufacturer,CompanyDescription as Description FROM Company where companyID = @ManufacturerId
END
GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_InitProjectionsByCompanySalesPersonYear]    Script Date: 02/22/2012 12:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_InitProjectionsByCompanySalesPersonYear]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_InitProjectionsByCompanySalesPersonYear]
GO


/****** Object:  StoredProcedure [dbo].[usp_InitProjectionsByCompanySalesPersonYear]    Script Date: 02/22/2012 12:33:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



----------------------------------------------------------------------------------------------
-- Created By : Kartikeya Sinha
-- Created On : 07-Feb-2011
-- Modified By : Karthik
-- Modified On : 9-Aug-2011
-- Description : Get SalesProjections for a Company & SalesPerson
-- Arguments : @ProjectionCompanyID, @ProjectionSalesPersonID
-- Returns  : Returns Current and Previous 3 years Projections
----------------------------------------------------------------------------------------------
CREATE PROC [dbo].[usp_InitProjectionsByCompanySalesPersonYear]
(
  @ProjectionSalesPersonID int,
  @ProjectionCompanyID int,
  @ProjectionFiscalYear int
)
AS

BEGIN
    --- For Edition
    DECLARE @TempEdition TABLE (    EditionID int,PreviousYearAmount money )
    INSERT INTO @TempEdition (EditionID, PreviousYearAmount)
        (SELECT Editions.EditionID, SUM(ISNULL(AdOrderRegionEditionBySalesCompany.NetAmount, 0))
        FROM Editions
        LEFT JOIN
            (SELECT AdOrderRegionEdition.EditionID, AdOrderRegionEdition.RegionID, AdOrderRegionEdition.NetAmount, AdOrder.CompanyId, AdOrder.SalesPersonId, Editions.Year FROM AdOrderRegionEdition
                JOIN AdOrder on AdOrder.AdOrderID = AdOrderRegionEdition.AdOrderID
                JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND AdOrderRegionEdition.RegionID = Editions.RegionID
            WHERE Editions.Year = @ProjectionFiscalYear AND AdOrder.CompanyId = @ProjectionCompanyID AND AdOrder.SalesPersonId = @ProjectionSalesPersonID
            ) AS AdOrderRegionEditionBySalesCompany
        ON Editions.EditionID = AdOrderRegionEditionBySalesCompany.EditionID AND Editions.RegionID = AdOrderRegionEditionBySalesCompany.RegionID
        WHERE Editions.Year = @ProjectionFiscalYear
        GROUP BY Editions.EditionID)
        ORDER BY EditionID

    DECLARE @EditionID int
    DECLARE @PreviousYearAmount money
    DECLARE cursor_projection CURSOR FOR
            SELECT EditionID, PreviousYearAmount
            FROM @TempEdition

    OPEN cursor_projection
    FETCH NEXT FROM cursor_projection INTO @EditionID, @PreviousYearAmount

    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF NOT EXISTS(select Projections.*, Editions.Year
                            FROM Projections
                            JOIN Editions ON Projections.EditionID = Editions.EditionID
                            WHERE SalesPersonID = @ProjectionSalesPersonID
                                AND CompanyID = @ProjectionCompanyID
                                AND Projections.OnlineYear =@ProjectionFiscalYear
                                AND Editions.EditionID = @EditionID)
        BEGIN
                INSERT INTO Projections(
                   [EditionID]
                  ,[RegionID]
                  ,[SalesPersonID]
                  ,[CompanyID]
                  ,[BaseProjection]
                  ,[SalesProjection]
                  ,[OnLineYear]
                  ,[OnlineMonth])
                VALUES (
                    @EditionID
                    , 0            -- Region
                    , @ProjectionSalesPersonID        -- SalesPersonID
                    , @ProjectionCompanyID        -- CompanyID
                    , ISNULL(@PreviousYearAmount, 0 )
                    ,0                    -- SalesProjection
                    ,@ProjectionFiscalYear
                    ,0
                );


        END

        FETCH NEXT FROM cursor_projection INTO @EditionID, @PreviousYearAmount
    END
    CLOSE cursor_projection
    DEALLOCATE cursor_projection

    -- For Print

    DECLARE @OnlineMonth int
    DECLARE @PreviousYearAmountPrint money
    DECLARE @TempPrint TABLE (OnlineMonth int,PreviousYearAmount money )

    INSERT INTO @TempPrint (OnlineMonth, PreviousYearAmount)
        (SELECT OrderMonth.MID, SUM(ISNULL(NetAmount,0))
        FROM OrderMonth
        LEFT JOIN
        (SELECT AdOrderRegionEdition.OnlineMonth, AdOrderRegionEdition.OnlineYear, AdOrderRegionEdition.NetAmount
        FROM AdOrderRegionEdition
        JOIN AdOrder ON AdOrderRegionEdition.AdOrderID = AdOrder.AdOrderID
        WHERE AdOrderRegionEdition.OnlineMonth is not null AND AdOrderRegionEdition.OnlineYear is not null
        AND AdOrder.SalesPersonID = @ProjectionSalesPersonID AND AdOrder.CompanyId = @ProjectionCompanyID AND AdOrderRegionEdition.OnlineYear = @ProjectionFiscalYear) AS AdOrderRegionEditionBySalesCompany
        ON OrderMonth.MID = AdOrderRegionEditionBySalesCompany.OnlineMonth
        GROUP BY OrderMonth.MID    )
        ORDER BY OrderMonth.MID

    DECLARE cursor_print CURSOR FOR
            SELECT OnlineMonth, PreviousYearAmount
            FROM @TempPrint

    OPEN cursor_print
    FETCH NEXT FROM cursor_print INTO @OnlineMonth, @PreviousYearAmountPrint

    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF NOT EXISTS(select Projections.*
                        FROM Projections
                        WHERE SalesPersonID = @ProjectionSalesPersonID
                            AND CompanyID = @ProjectionCompanyID
                            AND OnlineYear = @ProjectionFiscalYear
                            AND OnlineMonth = @OnlineMonth)
        BEGIN
            INSERT INTO Projections(
                [EditionID]
              ,OnlineMonth
              ,OnlineYear
              ,[RegionID]
              ,[SalesPersonID]
              ,[CompanyID]
              ,[BaseProjection]
              ,[SalesProjection])
            VALUES (
                0
                ,@OnlineMonth
                ,@ProjectionFiscalYear
                , 0                    -- Region
                , @ProjectionSalesPersonID    -- SalesPersonID
                , @ProjectionCompanyID        -- CompanyID
                , ISNULL(@PreviousYearAmountPrint, 0 )
                ,0
            );


        END
        FETCH NEXT FROM cursor_print INTO @OnlineMonth, @PreviousYearAmountPrint
    END
    CLOSE cursor_print
    DEALLOCATE cursor_print

END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetProjection]    Script Date: 02/22/2012 12:31:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetProjection]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetProjection]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetProjection]    Script Date: 02/22/2012 12:31:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



----------------------------------------------------------------------------------------------
-- Created By : Kartikeya Sinha
-- Created On : 07-Feb-2011
-- Modified By : Karthik
-- Modified On : 9-Aug-2011
-- Description : Get SalesProjections for a Company & SalesPerson
-- Arguments : @CompanyID, @SalesPersonID
-- Returns  : Returns Current and Previous 3 years Projections
----------------------------------------------------------------------------------------------
CREATE PROC [dbo].[usp_GetProjection]
(
    @SalesPersonID int,
    @CompanyID int,
    @FiscalYear int
)
AS
BEGIN
    SELECT P.[ProjectionID] as ProjectionID,
            P.EditionID,
            P.RegionID,
            CZ.ZoneCode + CONVERT(varchar,@FiscalYear) as 'Edition',
            ISNULL(P.BaseProjection,0) as Base,
            ISNULL(P.SalesProjection,0) as [SalesProjections],
            ISNULL(P.AdvNet,0) as [AdvertisingNet],
            (D.FirstName + ' ' + D.LastName) as [SalesPerson],
            (CASE WHEN  GETDATE() >= E.PublicationDate AND ProjectionID > 0 THEN 0 ELSE 1 END) as ReadOnlyRecord,
            D.UserID,
            F.EmailAddress as EmailID,
            0 as MID
    FROM
            Projections P
            JOIN Editions E ON P.EditionID = E.EditionID
            JOIN Countryzones CZ ON CZ.ZoneID = E.RegionID
            LEFT JOIN [User] D ON D.UserId = P.SalesPersonID
            LEFT JOIN UserContact F ON F.UserId = D.UserId
    WHERE P.CompanyID = @CompanyID AND P.SalesPersonID = @SalesPersonID AND E.Year =  @FiscalYear

    UNION

    SELECT
            ISNULL(P.[ProjectionID],0) as ProjectionID,
            0 AS EditionID,
            0 AS RegionID,
            MName+' '+CONVERT(varchar,@FiscalYear) as 'Edition',
            ISNULL(P.BaseProjection,0) as Base,
            ISNULL(P.SalesProjection,0) as [SalesProjections],
            ISNULL(P.AdvNet,0) as [AdvertisingNet],
            (D.FirstName + ' ' + D.LastName) as [SalesPerson],
            (CASE WHEN MONTH(GETDATE()) >= ISNULL(OnlineMonth,0) AND ProjectionID > 0 AND YEAR(GETDATE()) <=  @FiscalYear THEN 0 ELSE 1 END) as ReadOnlyRecord,
            D.UserID,
            F.EmailAddress as EmailID,
            OM.MID as MID
    FROM OrderMonth OM
             LEFT JOIN Projections P ON OnlineYear = @FiscalYear AND OnlineMonth > 0
             AND P.SalesPersonID = @SalesPersonID AND P.CompanyID = @CompanyID AND  OnlineMonth = OM.MID
             LEFT JOIN [User] D ON D.UserID = P.SalesPersonID
             LEFT JOIN [UserContact] F ON F.UserID = D.UserID
    ORDER BY MID  , P.EditionID

    DECLARE @DescriptionList varchar(500)    -- 2/14/12 copy from old code. check whether we need it.
    DECLARE @Company varchar(100)

    SELECT @Company =  B.CompanyName,@DescriptionList = COALESCE(@DescriptionList + ', ', '') + CAST(D.Description AS nvarchar(300))
    FROM Company B,CompanyTypeMapping C,MstCompanyType D
    WHERE C.CompanyID=B.CompanyId and B.CompanyID=@CompanyID and D.CompanyTypeID = C.CompanyTypeID
    SELECT '<b>Company : </b>' + @Company,'<b>Company Type: </b>' + @DescriptionList

END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetProjectionWithAdvNet]    Script Date: 02/22/2012 12:34:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetProjectionWithAdvNet]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetProjectionWithAdvNet]
GO


/****** Object:  StoredProcedure [dbo].[usp_GetProjectionWithAdvNet]    Script Date: 02/22/2012 12:34:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



----------------------------------------------------------------------------------------------
-- Created By : Kartikeya Sinha
-- Created On : 07-Feb-2011
-- Modified By : Karthik
-- Modified On : 9-Aug-2011
-- Description : Get SalesProjections for a Company & SalesPerson
-- Arguments : @CompanyID, @SalesPersonID
-- Returns  : Returns Current and Previous 3 years Projections
----------------------------------------------------------------------------------------------
CREATE PROC [dbo].[usp_GetProjectionWithAdvNet]
(
  @SalesPersonID int,
  @CompanyID int,
  @FiscalYear int
)
AS
BEGIN

    DECLARE @SalesPersonName VARCHAR = ''
    SELECT @SalesPersonName = FirstName + ' ' + LastName FROM [User] WHERE  UserID = @SalesPersonID
    DECLARE @EmailID VARCHAR = ''
    SELECT @EmailID = EmailAddress FROM UserContact WHERE  UserID = @SalesPersonID

    DECLARE    @return_value int
    EXEC    @return_value = [dbo].[usp_InitProjectionsByCompanySalesPersonYear]
            @ProjectionSalesPersonID = @SalesPersonID,
            @ProjectionCompanyID = @CompanyID,
            @ProjectionFiscalYear = @FiscalYear
    IF (@return_value = 0)
    BEGIN

        SELECT PJ.ProjectionID
            , PJ.EditionID
            , PJ.RegionID
            , PJ.Edition
            , PJ.BaseProjection AS Base
            , PJ.[SalesProjections]
            , OnlineYearAmount.YearAmount AS [AdvertisingNet]
            , @SalesPersonName AS [SalesPerson]
            , PJ.ReadOnlyRecord
            , @SalesPersonID AS UserID
            , @EmailID AS EmailID
            , PJ.MID
        FROM
            (SELECT P.[ProjectionID] as ProjectionID,
                P.EditionID,
                E.RegionID,
                CZ.ZoneCode + CONVERT(varchar,@FiscalYear) as 'Edition',
                ISNULL(P.BaseProjection,0) as BaseProjection,
                ISNULL(P.SalesProjection,0) as [SalesProjections],
                ISNULL(P.AdvNet,0) as [AdvertisingNet],
                (CASE WHEN  GETDATE() >= E.PublicationDate AND ProjectionID > 0 THEN 0 ELSE 1 END) as ReadOnlyRecord,
                0 as MID
            FROM
                Projections P
                JOIN Editions E ON P.EditionID = E.EditionID
                JOIN Countryzones CZ ON CZ.ZoneID = E.RegionID
            WHERE P.CompanyID = @CompanyID AND P.SalesPersonID = @SalesPersonID AND E.Year =  @FiscalYear) AS PJ
            JOIN
                (SELECT Editions.EditionID, SUM(ISNULL(AdOrderRegionEditionBySalesCompany.NetAmount, 0) ) as YearAmount
                        FROM Editions
                        LEFT JOIN
                            (SELECT AdOrderRegionEdition.EditionID, AdOrderRegionEdition.RegionID, AdOrderRegionEdition.NetAmount, AdOrder.CompanyId, AdOrder.SalesPersonId FROM AdOrderRegionEdition
                                JOIN AdOrder on AdOrder.AdOrderID = AdOrderRegionEdition.AdOrderID
                            WHERE AdOrder.CompanyId = @CompanyID AND AdOrder.SalesPersonId = @SalesPersonID
                            ) AS AdOrderRegionEditionBySalesCompany
                        ON Editions.EditionID = AdOrderRegionEditionBySalesCompany.EditionID
                        WHERE Editions.Year = @FiscalYear
                        GROUP BY Editions.EditionID) AS OnlineYearAmount
            ON PJ.EditionID = OnlineYearAmount.EditionID

        UNION

        SELECT PJ.ProjectionID
            , 0 AS EditionID
            , 0 AS RegionID
            , PJ.Edition
            , PJ.Base
            , PJ.[SalesProjections]
            , PrintYearAmount.YearAmount AS [AdvertisingNet]
            , @SalesPersonName AS [SalesPerson]
            , PJ.ReadOnlyRecord
            , @SalesPersonID AS UserID
            , @EmailID AS EmailID
            , PJ.MID
        FROM
            (SELECT
                ISNULL(P.[ProjectionID],0) as ProjectionID,
                0 AS EditionID,
                MName+' '+CONVERT(varchar,@FiscalYear) as 'Edition',
                ISNULL(P.BaseProjection,0) as Base,
                ISNULL(P.SalesProjection,0) as [SalesProjections],
                ISNULL(P.AdvNet,0) as [AdvertisingNet],
                (CASE WHEN MONTH(GETDATE()) >= ISNULL(OnlineMonth,0) AND ProjectionID > 0 AND YEAR(GETDATE()) <=  @FiscalYear THEN 0 ELSE 1 END) as ReadOnlyRecord,
                OM.MID as MID
            FROM OrderMonth OM
                 LEFT JOIN Projections P ON OnlineYear = @FiscalYear AND OnlineMonth > 0
                 AND P.SalesPersonID = @SalesPersonID AND P.CompanyID = @CompanyID AND  OnlineMonth = OM.MID
            ) AS PJ
            JOIN
            (SELECT OrderMonth.MID, SUM(ISNULL(NetAmount,0)) AS YearAmount
                    FROM OrderMonth
                    LEFT JOIN
                    (SELECT AdOrderRegionEdition.OnlineMonth, AdOrderRegionEdition.OnlineYear, AdOrderRegionEdition.NetAmount
                    FROM AdOrderRegionEdition
                    JOIN AdOrder ON AdOrderRegionEdition.AdOrderID = AdOrder.AdOrderID
                    WHERE AdOrderRegionEdition.OnlineMonth is not null
                        AND AdOrderRegionEdition.OnlineYear is not null
                        AND AdOrder.SalesPersonID = @SalesPersonID
                        AND AdOrder.CompanyId = @CompanyID
                        AND AdOrderRegionEdition.OnlineYear = @FiscalYear) AS AdOrderRegionEditionBySalesCompany
                    ON OrderMonth.MID = AdOrderRegionEditionBySalesCompany.OnlineMonth
                    GROUP BY OrderMonth.MID) AS PrintYearAmount
            ON PJ.MID = PrintYearAmount.MID
        ORDER BY PJ.MID, PJ.RegionID

        DECLARE @DescriptionList varchar(500)
        DECLARE @Company varchar(100)

        SELECT @Company =  B.CompanyName,@DescriptionList = COALESCE(@DescriptionList + ', ', '') + CAST(D.Description AS nvarchar(300))
        FROM Company B,CompanyTypeMapping C,MstCompanyType D
        WHERE C.CompanyID=B.CompanyId and B.CompanyID=@CompanyID and D.CompanyTypeID = C.CompanyTypeID
        SELECT '<b>Company : </b>' + @Company,'<b>Company Type: </b>' + @DescriptionList

    END

END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetProjectionWithBase]    Script Date: 02/22/2012 12:35:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetProjectionWithBase]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetProjectionWithBase]
GO


/****** Object:  StoredProcedure [dbo].[usp_GetProjectionWithBase]    Script Date: 02/22/2012 12:35:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


----------------------------------------------------------------------------------------------
-- Created By : Kartikeya Sinha
-- Created On : 07-Feb-2011
-- Modified By : Karthik
-- Modified On : 9-Aug-2011
-- Description : Get SalesProjections for a Company & SalesPerson
-- Arguments : @CompanyID, @SalesPersonID
-- Returns  : Returns Current and Previous 3 years Projections
----------------------------------------------------------------------------------------------
CREATE PROC [dbo].[usp_GetProjectionWithBase]
(
  @SalesPersonID int,
  @CompanyID int,
  @FiscalYear int
)
AS
BEGIN

    DECLARE @SalesPersonName VARCHAR = ''
    SELECT @SalesPersonName = FirstName + ' ' + LastName FROM [User] WHERE  UserID = @SalesPersonID
    DECLARE @EmailID VARCHAR = ''
    SELECT @EmailID = EmailAddress FROM UserContact WHERE  UserID = @SalesPersonID

    DECLARE    @return_value int
    EXEC    @return_value = [dbo].[usp_InitProjectionsByCompanySalesPersonYear]
            @ProjectionSalesPersonID = @SalesPersonID,
            @ProjectionCompanyID = @CompanyID,
            @ProjectionFiscalYear = @FiscalYear

    IF (@return_value = 0)
    BEGIN

        SELECT PJ.ProjectionID
            , PJ.EditionID
            , PJ.RegionID
            , PJ.Edition
            , OnlineYearAmount.YearAmount AS Base
            , PJ.[SalesProjections]
            , PJ.[AdvertisingNet]
            , @SalesPersonName AS [SalesPerson]
            , PJ.ReadOnlyRecord
            , @SalesPersonID AS UserID
            , @EmailID AS EmailID
            , PJ.MID
        FROM
            (SELECT P.[ProjectionID] as ProjectionID,
                P.EditionID,
                E.RegionID,
                CZ.ZoneCode + CONVERT(varchar,@FiscalYear) as 'Edition',
                ISNULL(P.BaseProjection,0) as BaseProjection,
                ISNULL(P.SalesProjection,0) as [SalesProjections],
                ISNULL(P.AdvNet,0) as [AdvertisingNet],
                (CASE WHEN  GETDATE() >= E.PublicationDate AND ProjectionID > 0 THEN 0 ELSE 1 END) as ReadOnlyRecord,
                0 as MID
            FROM
                Projections P
                JOIN Editions E ON P.EditionID = E.EditionID
                JOIN Countryzones CZ ON CZ.ZoneID = E.RegionID
            WHERE P.CompanyID = @CompanyID AND P.SalesPersonID = @SalesPersonID AND E.Year =  @FiscalYear) AS PJ
            JOIN
                (SELECT Editions.RegionID, SUM(ISNULL(AdOrderRegionEditionBySalesCompany.NetAmount, 0) ) as YearAmount
                        FROM Editions
                        LEFT JOIN
                            (SELECT AdOrderRegionEdition.EditionID, AdOrderRegionEdition.RegionID, AdOrderRegionEdition.NetAmount, AdOrder.CompanyId, AdOrder.SalesPersonId FROM AdOrderRegionEdition
                                JOIN AdOrder on AdOrder.AdOrderID = AdOrderRegionEdition.AdOrderID
                            WHERE AdOrder.CompanyId = @CompanyID AND AdOrder.SalesPersonId = @SalesPersonID
                            ) AS AdOrderRegionEditionBySalesCompany
                        ON Editions.EditionID = AdOrderRegionEditionBySalesCompany.EditionID
                        WHERE Editions.Year = @FiscalYear - 1
                        GROUP BY Editions.RegionID) AS OnlineYearAmount
            ON PJ.RegionID = OnlineYearAmount.RegionID

        UNION

        SELECT PJ.ProjectionID
            , 0 AS EditionID
            , 0 AS RegionID
            , PJ.Edition
            , PrintYearAmount.YearAmount AS Base
            , PJ.[SalesProjections]
            , PJ.[AdvertisingNet]
            , @SalesPersonName AS [SalesPerson]
            , PJ.ReadOnlyRecord
            , @SalesPersonID AS UserID
            , @EmailID AS EmailID
            , PJ.MID
        FROM
            (SELECT
                ISNULL(P.[ProjectionID],0) as ProjectionID,
                0 AS EditionID,
                MName+' '+CONVERT(varchar,@FiscalYear) as 'Edition',
                ISNULL(P.BaseProjection,0) as Base,
                ISNULL(P.SalesProjection,0) as [SalesProjections],
                ISNULL(P.AdvNet,0) as [AdvertisingNet],
                (CASE WHEN MONTH(GETDATE()) >= ISNULL(OnlineMonth,0) AND ProjectionID > 0 AND YEAR(GETDATE()) <=  @FiscalYear THEN 0 ELSE 1 END) as ReadOnlyRecord,
                OM.MID as MID
            FROM OrderMonth OM
                 LEFT JOIN Projections P ON OnlineYear = @FiscalYear AND OnlineMonth > 0
                 AND P.SalesPersonID = @SalesPersonID AND P.CompanyID = @CompanyID AND  OnlineMonth = OM.MID
            ) AS PJ
            JOIN
            (SELECT OrderMonth.MID, SUM(ISNULL(NetAmount,0)) AS YearAmount
                    FROM OrderMonth
                    LEFT JOIN
                    (SELECT AdOrderRegionEdition.OnlineMonth, AdOrderRegionEdition.OnlineYear, AdOrderRegionEdition.NetAmount
                    FROM AdOrderRegionEdition
                    JOIN AdOrder ON AdOrderRegionEdition.AdOrderID = AdOrder.AdOrderID
                    WHERE AdOrderRegionEdition.OnlineMonth is not null
                        AND AdOrderRegionEdition.OnlineYear is not null
                        AND AdOrder.SalesPersonID = @SalesPersonID
                        AND AdOrder.CompanyId = @CompanyID
                        AND AdOrderRegionEdition.OnlineYear = @FiscalYear - 1) AS AdOrderRegionEditionBySalesCompany
                    ON OrderMonth.MID = AdOrderRegionEditionBySalesCompany.OnlineMonth
                    GROUP BY OrderMonth.MID) AS PrintYearAmount
            ON PJ.MID = PrintYearAmount.MID
        ORDER BY PJ.MID, PJ.RegionID

        DECLARE @DescriptionList varchar(500)        -- 2/14/12 copy from old code. check whether we need it.
        DECLARE @Company varchar(100)

        SELECT @Company =  B.CompanyName,@DescriptionList = COALESCE(@DescriptionList + ', ', '') + CAST(D.Description AS nvarchar(300))
        FROM Company B,CompanyTypeMapping C,MstCompanyType D
        WHERE C.CompanyID=B.CompanyId and B.CompanyID=@CompanyID and D.CompanyTypeID = C.CompanyTypeID
        SELECT '<b>Company : </b>' + @Company,'<b>Company Type: </b>' + @DescriptionList

    END

END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetProjectionsForCompanySalesPerson]    Script Date: 02/22/2012 12:36:56 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetProjectionsForCompanySalesPerson]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetProjectionsForCompanySalesPerson]
GO


/****** Object:  StoredProcedure [dbo].[usp_GetProjectionsForCompanySalesPerson]    Script Date: 02/22/2012 12:36:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------------------------------
-- Created By : Kartikeya Sinha
-- Created On : 07-Feb-2011
-- Modified By : Karthik
-- Modified On : 9-Aug-2011
-- Description : Get SalesProjections for a Company & SalesPerson
-- Arguments : @CompanyID, @SalesPersonID
-- Returns  : Returns Current and Previous 3 years Projections
----------------------------------------------------------------------------------------------
CREATE PROC [dbo].[usp_GetProjectionsForCompanySalesPerson]
(
  @SalesPersonID int,
  @CompanyID int,
  @FiscalYear int
)
AS
BEGIN

SELECT DISTINCT ISNULL(A.[ProjectionID],0) as ProjectionID,
    E.EditionID,
    CZ.ZoneCode + CONVERT(varchar,@FiscalYear) as 'Edition',
    ISNULL(A.BaseProjection,0) as Base,
    ISNULL(A.SalesProjection,0) as [SalesProjections],
    ISNULL(A.AdvNet,0) as [AdvertisingNet],
    (D.FirstName + ' ' + D.LastName) as [SalesPerson],
    (CASE WHEN  GETDATE() >= E.PublicationDate AND ProjectionID > 0 THEN 0 ELSE 1 END) as ReadOnlyRecord,
    D.UserID,
    F.EmailAddress as EmailID,
    0 as MID

FROM Countryzones CZ LEFT JOIN Editions E ON CZ.ZoneID = E.RegionID AND E.[Year] = @FiscalYear AND E.AdJobTypeID = 'P'
     LEFT JOIN Projections A ON A.EditionID = E.EditionID AND A.CompanyID = @CompanyID AND A.SalesPersonID = @SalesPersonID
     LEFT JOIN [User] D ON D.UserId = A.SalesPersonID
     LEFT JOIN UserContact F ON F.UserId = D.UserId
--- LEFT JOIN Adorder AO ON  AO.CompanyID = A.CompanyID AND AO.SalesPersonID = A.SalesPersonID
WHERE CZ.CountryID IN(197,35)

UNION

SELECT DISTINCT ISNULL(A.[ProjectionID],0) as ProjectionID,
    0,
    MName+' '+CONVERT(varchar,@FiscalYear) as 'Edition',
    ISNULL(A.BaseProjection,0) as Base,
    ISNULL(A.SalesProjection,0) as [SalesProjections],
    ISNULL(A.AdvNet,0) as [AdvertisingNet],
    (D.FirstName + ' ' + D.LastName) as [SalesPerson],
    (CASE WHEN MONTH(GETDATE()) >= ISNULL(OnlineMonth,0) AND ProjectionID > 0 AND YEAR(GETDATE()) <=  @FiscalYear THEN 0 ELSE 1 END) as ReadOnlyRecord,
    D.UserID,
    F.EmailAddress as EmailID,
    OM.MID as MID

FROM OrderMonth OM --LEFT JOIN AdOrderDetails AOD ON OM.MID = MONTH(AOD.ActivationDate) AND
    -- YEAR(AOD.ActivationDate) = @FiscalYear
    -- LEFT JOIN Adorder AO ON  AO.SalesPersonID = @SalesPersonID AND AO.CompanyID = @CompanyID AND AO.AdOrderId = AOD.AdOrderId
     LEFT JOIN Projections A ON OnlineYear = @FiscalYear AND OnlineMonth > 0
     AND A.SalesPersonID = @SalesPersonID AND A.CompanyID = @CompanyID AND  OnlineMonth = OM.MID
     LEFT JOIN [User] D ON D.UserID = A.SalesPersonID
     LEFT JOIN [UserContact] F ON F.UserID = D.UserID

ORDER BY MID

DECLARE @DescriptionList varchar(500)
DECLARE @Company varchar(100)

SELECT @Company =  B.CompanyName,@DescriptionList = COALESCE(@DescriptionList + ', ', '') + CAST(D.Description AS nvarchar(300))
FROM Company B,CompanyTypeMapping C,MstCompanyType D
WHERE C.CompanyID=B.CompanyId and B.CompanyID=@CompanyID and D.CompanyTypeID = C.CompanyTypeID

SELECT '<b>Company : </b>' + @Company,'<b>Company Type: </b>' + @DescriptionList

END
GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetProjectionPassedYear]    Script Date: 02/22/2012 12:37:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetProjectionPassedYear]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetProjectionPassedYear]
GO


/****** Object:  StoredProcedure [dbo].[usp_GetProjectionPassedYear]    Script Date: 02/22/2012 12:37:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




----------------------------------------------------------------------------------------------
-- Created By : Kartikeya Sinha
-- Created On : 07-Feb-2011
-- Modified By : Karthik
-- Modified On : 9-Aug-2011
-- Description : Get SalesProjections for a Company & SalesPerson
-- Arguments : @CompanyID, @SalesPersonID
-- Returns  : Returns Current and Previous 3 years Projections
----------------------------------------------------------------------------------------------
CREATE PROC [dbo].[usp_GetProjectionPassedYear]
(
    @SalesPersonID int,
    @CompanyID int,
    @FiscalYear int
)
AS
BEGIN
    SELECT P.[ProjectionID] as ProjectionID,
            P.EditionID,
            P.RegionID,
            CZ.ZoneCode + CONVERT(varchar,@FiscalYear) as 'Edition',
            ISNULL(P.BaseProjection,0) as Base,
            ISNULL(P.SalesProjection,0) as [SalesProjections],
            ISNULL(P.AdvNet,0) as [AdvertisingNet],
            (D.FirstName + ' ' + D.LastName) as [SalesPerson],
            1 as ReadOnlyRecord,
            D.UserID,
            F.EmailAddress as EmailID,
            0 as MID
    FROM
            Projections P
            JOIN Editions E ON P.EditionID = E.EditionID
            JOIN Countryzones CZ ON CZ.ZoneID = E.RegionID
            LEFT JOIN [User] D ON D.UserId = P.SalesPersonID
            LEFT JOIN UserContact F ON F.UserId = D.UserId
    WHERE P.CompanyID = @CompanyID AND P.SalesPersonID = @SalesPersonID AND E.Year =  @FiscalYear

    UNION

    SELECT
            ISNULL(P.[ProjectionID],0) as ProjectionID,
            0 AS EditionID,
            0 AS RegionID,
            MName+' '+CONVERT(varchar,@FiscalYear) as 'Edition',
            ISNULL(P.BaseProjection,0) as Base,
            ISNULL(P.SalesProjection,0) as [SalesProjections],
            ISNULL(P.AdvNet,0) as [AdvertisingNet],
            (D.FirstName + ' ' + D.LastName) as [SalesPerson],
            1 as ReadOnlyRecord,
            D.UserID,
            F.EmailAddress as EmailID,
            OM.MID as MID
    FROM OrderMonth OM
             LEFT JOIN Projections P ON OnlineYear = @FiscalYear AND OnlineMonth > 0
             AND P.SalesPersonID = @SalesPersonID AND P.CompanyID = @CompanyID AND  OnlineMonth = OM.MID
             LEFT JOIN [User] D ON D.UserID = P.SalesPersonID
             LEFT JOIN [UserContact] F ON F.UserID = D.UserID
    ORDER BY MID  , P.EditionID

    DECLARE @DescriptionList varchar(500)    -- 2/14/12 copy from old code. check whether we need it.
    DECLARE @Company varchar(100)

    SELECT @Company =  B.CompanyName,@DescriptionList = COALESCE(@DescriptionList + ', ', '') + CAST(D.Description AS nvarchar(300))
    FROM Company B,CompanyTypeMapping C,MstCompanyType D
    WHERE C.CompanyID=B.CompanyId and B.CompanyID=@CompanyID and D.CompanyTypeID = C.CompanyTypeID
    SELECT '<b>Company : </b>' + @Company,'<b>Company Type: </b>' + @DescriptionList

END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSalesProjectionList]    Script Date: 02/22/2012 12:39:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSalesProjectionList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSalesProjectionList]
GO


/****** Object:  StoredProcedure [dbo].[usp_GetSalesProjectionList]    Script Date: 02/22/2012 12:39:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/******************************************************************
-- Created By : Karthik P
-- Created On : 16-Jul-2011
-- Created By : Karthik P
-- Created On : 9-Aug-2011
-- Description : Get SalesProjections for a Company & SalesPerson
-- Arguments : @CompanyID, @SalesPersonID,@FiscalYear
-- Returns  : Returns Current and Previous 3 years Projections
-- @lngEdition_ID INT is actually getting the value of RegionId from Edition Table or the MonthId from OrderMonth
*******************************************************************/
CREATE PROCEDURE [dbo].[usp_GetSalesProjectionList] --2,4,0,p,24,2011,sc
(
  @intOptionSelected SMALLINT,
  @lngEdition_ID INT,
  @lngSalesPerson_ID INT,
  @Type CHAR(1),
  @UserID INT,
  @YearID INT,
  @EditionValue VARCHAR(50)
)
AS
BEGIN
    set transaction isolation level read uncommitted
    DECLARE @strExec VARCHAR(6000)
    DECLARE @EditionID INT

    IF(@Type = 'B')
    BEGIN
        IF EXISTS(SELECT 1 FROM OrderMOnth WHERE MName like @EditionValue)
            SET @Type = 'O'
        ELSE
            SET @Type = 'P'
    END

    IF(@Type = 'P')
    BEGIN
        SELECT @EDITIONID =ISNULL(EDITIONID,0) FROM EDITIONS WHERE REGIONID = @LNGEDITION_ID AND [YEAR] = @YEARID
        -- Get company list for all advertisers
        IF @intOptionSelected = 1
        BEGIN
            SELECT
                Company.CompanyID,
                Company.CompanyName,
                [USER].FirstName,
                [USER].LastName,
                AllAdvertiserSummary.SalesPersonId,
                AllAdvertiserSummary.AdvNet
            FROM

                (SELECT
                    AllAdvertisers.CompanyId,
                    AllAdvertisers.SalesPersonId,
                    SUM(AdvNet) AS AdvNet
                FROM
                    (SELECT Adorder.CompanyId,
                                    Adorder.SalesPersonId,
                                    SUM(ISNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                            FROM [AdOrderRegionEdition]
                            JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND Editions.StatusID != 2
                            JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                Adorder.StatusId >= 3
                            GROUP BY Adorder.CompanyId, Adorder.SalesPersonId
                    Union
                    SELECT Adorder.CompanyId,
                                    Adorder.SalesPersonId,
                                    SUM(ISNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                            FROM [AdOrderRegionEdition]
                            JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                Adorder.StatusId >= 3 AND
                                AdOrderRegionEdition.OnlineMonth IS NOT NULL AND
                                AdOrderRegionEdition.OnlineYear IS NOT NULL
                            GROUP BY Adorder.CompanyId, Adorder.SalesPersonId) AS AllAdvertisers
                GROUP BY CompanyId, SalesPersonId) AS AllAdvertiserSummary
            JOIN Company on AllAdvertiserSummary.CompanyId = Company.CompanyId
            JOIN [USER] on AllAdvertiserSummary.SalesPersonId = [USER].UserID
            ORDER BY CompanyName
        END

        -- Get company list for current advertisers for an edition
        If @intOptionSelected = 2
        BEGIN
            SELECT Company.CompanyID,
                    Company.CompanyName,
                    [USER].FirstName,
                    [USER].LastName,
                    CompanySalsePersonNetAmount.SalesPersonId,
                    CompanySalsePersonNetAmount.AdvNet
            FROM
                (SELECT DISTINCT Adorder.CompanyId,
                                Adorder.SalesPersonId,
                                SUM(ISNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                FROM [AdOrderRegionEdition]
                JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND
                    Editions.Year = @YearID AND
                    Editions.RegionID = @lngEdition_ID
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                    Adorder.StatusId >= 3
                GROUP BY Adorder.CompanyId, Adorder.SalesPersonId) AS CompanySalsePersonNetAmount
            JOIN Company on CompanySalsePersonNetAmount.CompanyId = Company.CompanyId
            JOIN [USER] on CompanySalsePersonNetAmount.SalesPersonId = [USER].UserID
            ORDER BY CompanyName
        END

        -- Get company list for current advertisers for an edition and sales person
        IF (@intOptionSelected = 3)
        BEGIN
            SELECT Company.CompanyID,
                    Company.CompanyName,
                    [USER].FirstName,
                    [USER].LastName,
                    CompanySalsePersonNetAmount.SalesPersonId,
                    CompanySalsePersonNetAmount.AdvNet
            FROM
                (SELECT DISTINCT Adorder.CompanyId,
                                Adorder.SalesPersonId,
                                SUM(ISNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                FROM [AdOrderRegionEdition]
                JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND
                    Editions.Year = @YearID AND
                    Editions.RegionID = @lngEdition_ID
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                    Adorder.StatusId >= 3 AND Adorder.SalesPersonId = @lngSalesPerson_ID
                GROUP BY Adorder.CompanyId, Adorder.SalesPersonId) AS CompanySalsePersonNetAmount
            JOIN Company on CompanySalsePersonNetAmount.CompanyId = Company.CompanyId
            JOIN [USER] on CompanySalsePersonNetAmount.SalesPersonId = [USER].UserID
            ORDER BY CompanyName
        END

        -- Get company list for new advertisers for an edition
        IF (@intOptionSelected = 4)
        BEGIN
            SELECT
                ThisYear.CompanyId,
                Company.CompanyName,
                [USER].FirstName,
                [USER].LastName,
                ThisYear.SalesPersonId,
                ThisYear.AdvNet
            FROM
                (SELECT Adorder.CompanyId,
                    Adorder.SalesPersonId,
                    SUM(IsNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                FROM [AdOrderRegionEdition]
                    JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND
                                Editions.Year = @YearID AND
                                Editions.RegionID = @lngEdition_ID
                    JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                Adorder.StatusId >= 3
                GROUP BY CompanyId, SalesPersonId) AS ThisYear
                JOIN Company on ThisYear.CompanyId = Company.CompanyId
                JOIN [USER] on ThisYear.SalesPersonId = [USER].UserID
            WHERE NOT EXISTS
                (SELECT Distinct Adorder.CompanyId,
                                Adorder.SalesPersonId
                FROM [AdOrderRegionEdition]
                JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND
                                Editions.Year = @YearID - 1 AND
                                Editions.RegionID = @lngEdition_ID
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                Adorder.StatusId >= 3
                WHERE ThisYear.CompanyId = CompanyId)
            ORDER BY CompanyName
        END

        -- Get company list for new advertisers for an edition and sales person
        IF (@intOptionSelected = 5)
        BEGIN
            SELECT
                ThisYear.CompanyId,
                Company.CompanyName,
                [USER].FirstName,
                [USER].LastName,
                ThisYear.SalesPersonId,
                ThisYear.AdvNet
            FROM
                (SELECT Adorder.CompanyId,
                    Adorder.SalesPersonId,
                    SUM(IsNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                FROM [AdOrderRegionEdition]
                    JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND
                                Editions.Year = @YearID AND
                                Editions.RegionID = @lngEdition_ID
                    JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                Adorder.StatusId >= 3
                WHERE AdOrder.SalesPersonId = @lngSalesPerson_ID
                GROUP BY CompanyId, SalesPersonId) AS ThisYear
                JOIN Company on ThisYear.CompanyId = Company.CompanyId
                JOIN [USER] on ThisYear.SalesPersonId = [USER].UserID
            WHERE NOT EXISTS
                (SELECT Distinct Adorder.CompanyId,
                                Adorder.SalesPersonId
                FROM [AdOrderRegionEdition]
                JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND
                                Editions.Year = @YearID - 1 AND
                                Editions.RegionID = @lngEdition_ID
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                Adorder.StatusId >= 3
                WHERE AdOrder.SalesPersonId = @lngSalesPerson_ID AND ThisYear.CompanyId = CompanyId)
            ORDER BY CompanyName
        END

        -- Get company list for advertisers with projection and no net for an edition
        -- This should get all the companies and sales person combination that has a sales projection value > zero
        -- for the edition selected (i.e. region and year) and that company has no finalized order (>=3)
        -- in the selected region and year.
        If (@intOptionSelected = 8)
        BEGIN
            SELECT
                 Company.CompanyID,
                 Company.CompanyName,
                 [User].FirstName,
                 [User].LastName ,
                 T.ProjectAdvNet AS Amount,
                 0 as Edi_Net,
                 T.SalesPersonID,
                 0 AS AdvNet            -- cannot get any summary from AdOrderRegionEdition ???
            FROM
                (SELECT
                    ProjectionAmout.CompanyId,
                    ProjectionAmout.SalesPersonId,
                    ProjectionAmout.ProjectAdvNet
                FROM
                    (SELECT
                          [SalesPersonID]
                          ,[CompanyID]
                          ,SUM(ISNULL([AdvNet], 0)) AS ProjectAdvNet
                    FROM [SourceESB].[dbo].[Projections]
                    WHERE OnlineYear = @YearID AND  @lngEdition_ID = RegionID and AdvNet > 0
                    GROUP BY [CompanyID],[SalesPersonID]) AS ProjectionAmout
                    WHERE NOT EXISTS
                        (SELECT Distinct Adorder.CompanyId,
                                    Adorder.SalesPersonId
                        FROM [AdOrderRegionEdition]
                        JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND
                                    Editions.Year = @YearID - 1 AND
                                    Editions.RegionID = @lngEdition_ID
                        JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                    Adorder.StatusId >= 3
                        WHERE ProjectionAmout.CompanyId = CompanyId)) AS T
            JOIN Company on Company.CompanyID = T.CompanyID
            JOIN [USER] on T.SalesPersonId = [USER].UserID
            ORDER BY Company.CompanyName
        END

        -- Get company list for advertisers with projection and no net for an edition and sales person
        -- This should get all the companies and sales person combination that has a sales projection value > zero
        -- for the edition selected (i.e. region and year) and the selected sales person and that company has no
        -- finalized order (>=3) in the selected region and year and the selected salesperson.
        If (@intOptionSelected = 9)
        BEGIN
            SELECT
                 Company.CompanyID,
                 Company.CompanyName,
                 [User].FirstName,
                 [User].LastName ,
                 T.ProjectAdvNet AS Amount,
                 0 as Edi_Net,
                 T.SalesPersonID,
                 0 AS AdvNet            -- cannot get any summary from AdOrderRegionEdition ???
            FROM
                (SELECT
                    ProjectionAmout.CompanyId,
                    ProjectionAmout.SalesPersonId,
                    ProjectionAmout.ProjectAdvNet
                FROM
                    (SELECT
                          [SalesPersonID]
                          ,[CompanyID]
                          ,SUM(ISNULL([AdvNet], 0)) AS ProjectAdvNet
                    FROM [SourceESB].[dbo].[Projections]
                    WHERE OnlineYear = @YearID AND  @lngEdition_ID = RegionID and AdvNet > 0
                    GROUP BY [CompanyID],[SalesPersonID]) AS ProjectionAmout
                    WHERE NOT EXISTS
                        (SELECT Distinct Adorder.CompanyId,
                                    Adorder.SalesPersonId
                        FROM [AdOrderRegionEdition]
                        JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND
                                    Editions.Year = @YearID - 1 AND
                                    Editions.RegionID = @lngEdition_ID
                        JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                    Adorder.StatusId >= 3
                        WHERE AdOrder.SalesPersonId = @lngSalesPerson_ID AND ProjectionAmout.CompanyId = CompanyId)) AS T
            JOIN Company on Company.CompanyID = T.CompanyID
            JOIN [USER] on T.SalesPersonId = [USER].UserID
            ORDER BY Company.CompanyName
        END

        -- Get company list for Non-Advertisers for an edition and sales person
        -- This should get all the companies and sales person combination that has pending or draft (<3) order for the
        -- edition selected (i.e. region and year) and the salesperson selected (i.e. sales person id)
        -- but that company did not have any finalized order (>=3) in this year or the previous year.

        If (@intOptionSelected = 10)
        BEGIN
            SELECT DISTINCT
                ThisYear.CompanyId,
                Company.CompanyName,
                [USER].FirstName,
                [USER].LastName,
                ThisYear.SalesPersonId
            FROM
                (SELECT Adorder.CompanyId,
                        Adorder.SalesPersonId,
                        SUM(IsNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                FROM [AdOrderRegionEdition]
                JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND
                        Editions.Year = @YearID AND
                        Editions.RegionID = @lngEdition_ID
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                        Adorder.StatusId < 3
                WHERE AdOrder.SalesPersonId = @lngSalesPerson_ID
                GROUP BY CompanyId, SalesPersonId) AS ThisYear
                JOIN Company on ThisYear.CompanyId = Company.CompanyId
                JOIN [USER] on ThisYear.SalesPersonId = [USER].UserID
            WHERE NOT EXISTS
                (SELECT DISTINCT Adorder.CompanyId,
                        Adorder.SalesPersonId
                FROM [AdOrderRegionEdition]
                JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND
                            (Editions.Year = @YearID OR Editions.Year = @YearID - 1) AND
                            Editions.RegionID = @lngEdition_ID
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                            Adorder.StatusId >= 3
                WHERE AdOrder.SalesPersonId = @lngSalesPerson_ID AND ThisYear.CompanyId = CompanyId)
            ORDER BY CompanyName

        END
        -- Get company list for Non-Advertisers for an edition and sales person,
        -- might habe been advertising before, but not in the previous year
        -- This should get all the companies and sales person combination that has pending or draft (<3) order
        -- for the edition selected (i.e. region and year) and the salesperson selected (i.e. sales person id)
        -- but that company did not have any finalized order (>=3) in this year or the previous year,
        -- however that companies does have finalized order in years prior to last year. E.g. Digikey have a draft order
        -- in MA 2012 but no finalized order in 2011 or 2012 however they had order in year 2005 and 2008.

        If (@intOptionSelected = 11)
        BEGIN
        SELECT
                Company.CompanyID,
                Company.CompanyName,
                [USER].FirstName,
                [USER].LastName,
                MergeYears.SalesPersonId,
                MergeYears.AdvNet
        FROM
            (SELECT
                ThisYear.CompanyId,
                ThisYear.SalesPersonId,
                ThisYear.AdvNet
            FROM
                (SELECT Adorder.CompanyId,
                        Adorder.SalesPersonId,
                        SUM(IsNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                FROM [AdOrderRegionEdition]
                JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND
                        Editions.Year = @YearID AND
                        Editions.RegionID = @lngEdition_ID
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                        Adorder.StatusId < 3
                WHERE AdOrder.SalesPersonId = @lngSalesPerson_ID
                GROUP BY CompanyId, SalesPersonId) AS ThisYear
            JOIN
                (SELECT Adorder.CompanyId,
                        Adorder.SalesPersonId,
                        SUM(IsNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                FROM [AdOrderRegionEdition]
                JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND
                        Editions.Year <= (@YearID - 3) AND
                        Editions.RegionID = @lngEdition_ID
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                        Adorder.StatusId >= 3
                WHERE AdOrder.SalesPersonId = @lngSalesPerson_ID
                GROUP BY CompanyId, SalesPersonId) AS ThreeYearsAgo
            ON ThisYear.CompanyId = ThreeYearsAgo.CompanyId AND ThisYear.SalesPersonId = ThreeYearsAgo.SalesPersonId )AS MergeYears
            JOIN Company on MergeYears.CompanyId = Company.CompanyId
            JOIN [USER] on MergeYears.SalesPersonId = [USER].UserID
            WHERE NOT EXISTS
                (SELECT DISTINCT Adorder.CompanyId,
                        Adorder.SalesPersonId
                FROM [AdOrderRegionEdition]
                JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND
                            (Editions.Year = @YearID OR Editions.Year = @YearID - 1) AND
                            Editions.RegionID = @lngEdition_ID
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                            Adorder.StatusId >= 3
                WHERE AdOrder.SalesPersonId = @lngSalesPerson_ID AND MergeYears.CompanyId = CompanyId)
            ORDER BY CompanyName

        END

        -- new assigned companies
        If (@intOptionSelected = 12)
        BEGIN
           SELECT DISTINCT
             CO.CompanyID,
             CO.CompanyName,
             US.FirstName,
             US.LastName,
             SA.SalesPerson_ID as salesPersonID
          FROM
            SalesAssignments SA INNER JOIN Company CO ON SA.Company_ID = CO.CompanyID
            AND SA.Company_ID NOT IN (SELECT companyID FROM Projections Where EditionID = @EditionID )
            INNER JOIN [User] US ON SA.Salesperson_ID = US.UserId
            INNER JOIN Editions ED ON ED.EditionID = SA.EditionID AND ED.EditionID = @EditionID
          ORDER BY CO.CompanyName
        END
        ELSE
        BEGIN
              SELECT DISTINCT
                     CO.CompanyID,
                     CO.CompanyName,
                     US.FirstName,
                     US.LastName,
                     SA.SalesPerson_ID as salesPersonID
              FROM
                    SalesAssignments SA INNER JOIN Company CO ON SA.Company_ID = CO.CompanyID AND SA.Salesperson_ID = @lngSalesPerson_ID
                    AND SA.Company_ID NOT IN (SELECT companyID FROM Projections Where EditionID = @EditionID )
                    INNER JOIN [User] US ON SA.Salesperson_ID = US.UserId
                    INNER JOIN Editions ED ON ED.EditionID = SA.EditionID AND ED.EditionID = @EditionID
              ORDER BY CO.CompanyName
         END
        END

    IF(@Type = 'O')
    BEGIN
        IF @intOptionSelected = 1
        BEGIN
            SELECT
                Company.CompanyID,
                Company.CompanyName,
                [USER].FirstName,
                [USER].LastName,
                AllAdvertiserSummary.SalesPersonId,
                AllAdvertiserSummary.AdvNet
            FROM

                (SELECT
                    AllAdvertisers.CompanyId,
                    AllAdvertisers.SalesPersonId,
                    SUM(AdvNet) AS AdvNet
                FROM
                    (SELECT Adorder.CompanyId,
                                    Adorder.SalesPersonId,
                                    SUM(ISNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                            FROM [AdOrderRegionEdition]
                            JOIN Editions on AdOrderRegionEdition.EditionID = Editions.EditionID AND Editions.StatusID != 2
                            JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                Adorder.StatusId >= 3
                            GROUP BY Adorder.CompanyId, Adorder.SalesPersonId
                    Union
                    SELECT Adorder.CompanyId,
                                    Adorder.SalesPersonId,
                                    SUM(ISNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                            FROM [AdOrderRegionEdition]
                            JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                Adorder.StatusId >= 3 AND
                                AdOrderRegionEdition.OnlineMonth IS NOT NULL AND
                                AdOrderRegionEdition.OnlineYear IS NOT NULL
                            GROUP BY Adorder.CompanyId, Adorder.SalesPersonId) AS AllAdvertisers
                GROUP BY CompanyId, SalesPersonId) AS AllAdvertiserSummary
            JOIN Company on AllAdvertiserSummary.CompanyId = Company.CompanyId
            JOIN [USER] on AllAdvertiserSummary.SalesPersonId = [USER].UserID
            ORDER BY CompanyName
        END

        -- Get company list for current advertisers for an month
        If @intOptionSelected = 2
        BEGIN
            SELECT Company.CompanyID,
                    Company.CompanyName,
                    [USER].FirstName,
                    [USER].LastName,
                    CompanySalsePersonNetAmount.SalesPersonId,
                    CompanySalsePersonNetAmount.AdvNet
            FROM
                (SELECT  AdOrder.CompanyId,
                        Adorder.SalesPersonId,
                        SUM(ISNULL(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet FROM
                AdOrderRegionEdition
                JOIN Adorder ON Adorder.AdorderID = AdOrderRegionEdition.AdorderID AND
                    Adorder.StatusId >= 3 AND
                    AdOrderRegionEdition.OnlineMonth = @lngEdition_ID  AND
                    AdOrderRegionEdition.OnlineYear = @YearID
                GROUP BY AdOrder.CompanyId, Adorder.SalesPersonId) AS CompanySalsePersonNetAmount
            JOIN Company on CompanySalsePersonNetAmount.CompanyId = Company.CompanyId
            JOIN [USER] on CompanySalsePersonNetAmount.SalesPersonId = [USER].UserID
            ORDER BY CompanyName
        END

        -- Get company list for current advertisers for an edition and sales person
        IF (@intOptionSelected = 3)
        BEGIN
            SELECT Company.CompanyID,
                    Company.CompanyName,
                    [USER].FirstName,
                    [USER].LastName,
                    CompanySalsePersonNetAmount.SalesPersonId,
                    CompanySalsePersonNetAmount.AdvNet
            FROM
                (SELECT  AdOrder.CompanyId,
                        Adorder.SalesPersonId,
                        SUM(ISNULL(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet FROM
                AdOrderRegionEdition
                JOIN Adorder ON Adorder.AdorderID = AdOrderRegionEdition.AdorderID AND
                                Adorder.StatusId >= 3 AND
                                Adorder.SalesPersonID = @lngSalesPerson_ID AND
                                AdOrderRegionEdition.OnlineMonth = @lngEdition_ID  AND
                                AdOrderRegionEdition.OnlineYear = @YearID
                GROUP BY AdOrder.CompanyId, Adorder.SalesPersonId) AS CompanySalsePersonNetAmount
            JOIN Company on CompanySalsePersonNetAmount.CompanyId = Company.CompanyId
            JOIN [USER] on CompanySalsePersonNetAmount.SalesPersonId = [USER].UserID
            ORDER BY CompanyName
        END

        -- Get company list for new advertisers for an edition
        IF (@intOptionSelected = 4)
        BEGIN
            SELECT
                ThisYear.CompanyId,
                Company.CompanyName,
                [USER].FirstName,
                [USER].LastName,
                ThisYear.SalesPersonId,
                ThisYear.AdvNet
            FROM
                (SELECT Adorder.CompanyId,
                    Adorder.SalesPersonId,
                    SUM(IsNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                FROM [AdOrderRegionEdition]
                    JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                Adorder.StatusId >= 3 AND
                                AdOrderRegionEdition.OnlineYear = @YearID AND
                                AdOrderRegionEdition.OnlineMonth = @lngEdition_ID
                GROUP BY CompanyId, SalesPersonId) AS ThisYear
                JOIN Company on ThisYear.CompanyId = Company.CompanyId
                JOIN [USER] on ThisYear.SalesPersonId = [USER].UserID
            WHERE NOT EXISTS
                (SELECT Distinct Adorder.CompanyId,
                                Adorder.SalesPersonId
                FROM [AdOrderRegionEdition]
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                Adorder.StatusId >= 3 AND
                                AdOrderRegionEdition.OnlineYear = (@YearID - 1) -- AND
--                                AdOrderRegionEdition.OnlineMonth = @lngEdition_ID
                WHERE ThisYear.CompanyId = CompanyId)
            ORDER BY CompanyName
        END

        -- Get company list for new advertisers for an edition and sales person
        IF (@intOptionSelected = 5)
        BEGIN
            SELECT
                ThisYear.CompanyId,
                Company.CompanyName,
                [USER].FirstName,
                [USER].LastName,
                ThisYear.SalesPersonId,
                ThisYear.AdvNet
            FROM
                (SELECT Adorder.CompanyId,
                    Adorder.SalesPersonId,
                    SUM(IsNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                FROM [AdOrderRegionEdition]
                    JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                Adorder.StatusId >= 3 AND
                                AdOrderRegionEdition.OnlineYear = @YearID AND
                                AdOrderRegionEdition.OnlineMonth = @lngEdition_ID AND
                                Adorder.SalesPersonId = @lngSalesPerson_ID
                GROUP BY CompanyId, SalesPersonId) AS ThisYear
                JOIN Company on ThisYear.CompanyId = Company.CompanyId
                JOIN [USER] on ThisYear.SalesPersonId = [USER].UserID
            WHERE NOT EXISTS
                (SELECT Distinct Adorder.CompanyId,
                                Adorder.SalesPersonId
                FROM [AdOrderRegionEdition]
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                Adorder.StatusId >= 3 AND
                                AdOrderRegionEdition.OnlineYear = (@YearID - 1) -- AND
--                                AdOrderRegionEdition.OnlineMonth = @lngEdition_ID
                WHERE ThisYear.CompanyId = CompanyId)
            ORDER BY CompanyName
        END

        -- Get company list for advertisers with projection and no net for an edition
        If (@intOptionSelected = 8)
        BEGIN
            SELECT
                 Company.CompanyID,
                 Company.CompanyName,
                 [User].FirstName,
                 [User].LastName ,
                 T.ProjectAdvNet AS Amount,
                 0 as Edi_Net,
                 T.SalesPersonID,
                 0 AS AdvNet            -- cannot get any summary from AdOrderRegionEdition ???
            FROM
                (SELECT
                    ProjectionAmout.CompanyId,
                    ProjectionAmout.SalesPersonId,
                    ProjectionAmout.ProjectAdvNet
                FROM
                    (SELECT
                          [SalesPersonID]
                          ,[CompanyID]
                          ,SUM(ISNULL([AdvNet], 0)) AS ProjectAdvNet
                    FROM [SourceESB].[dbo].[Projections]
                    WHERE OnlineYear = @YearID AND  @lngEdition_ID = RegionID and AdvNet > 0
                    GROUP BY [CompanyID],[SalesPersonID]) AS ProjectionAmout
                    WHERE NOT EXISTS
                        (SELECT Distinct Adorder.CompanyId,
                                    Adorder.SalesPersonId
                        FROM [AdOrderRegionEdition]
                        JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                        AdOrderRegionEdition.OnlineYear = (@YearID - 1) AND
                                        AdOrderRegionEdition.OnlineMonth = @lngEdition_ID AND
                                        Adorder.StatusId >= 3
                        WHERE
                                 ProjectionAmout.CompanyId = CompanyId)) AS T
            JOIN Company on Company.CompanyID = T.CompanyID
            JOIN [USER] on T.SalesPersonId = [USER].UserID
            ORDER BY Company.CompanyName
        END

        -- Get company list for advertisers with projection and no net for an edition and sales person
        If (@intOptionSelected = 9)
        BEGIN
            SELECT
                 Company.CompanyID,
                 Company.CompanyName,
                 [User].FirstName,
                 [User].LastName ,
                 T.ProjectAdvNet AS Amount,
                 0 as Edi_Net,
                 T.SalesPersonID,
                 0 AS AdvNet            -- cannot get any summary from AdOrderRegionEdition ???
            FROM
                (SELECT
                    ProjectionAmout.CompanyId,
                    ProjectionAmout.SalesPersonId,
                    ProjectionAmout.ProjectAdvNet
                FROM
                    (SELECT
                          [SalesPersonID]
                          ,[CompanyID]
                          ,SUM(ISNULL([AdvNet], 0)) AS ProjectAdvNet
                    FROM [SourceESB].[dbo].[Projections]
                    WHERE OnlineYear = @YearID AND  @lngEdition_ID = RegionID and AdvNet > 0
                    GROUP BY [CompanyID],[SalesPersonID]) AS ProjectionAmout
                    WHERE NOT EXISTS
                        (SELECT Distinct Adorder.CompanyId,
                                    Adorder.SalesPersonId
                        FROM [AdOrderRegionEdition]
                        JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                                    Adorder.StatusId >= 3 AND
                                    AdOrderRegionEdition.OnlineYear = (@YearID - 1) AND
                                    AdOrderRegionEdition.OnlineMonth = @lngEdition_ID
                        WHERE AdOrder.SalesPersonId = @lngSalesPerson_ID AND ProjectionAmout.CompanyId = CompanyId)) AS T
            JOIN Company on Company.CompanyID = T.CompanyID
            JOIN [USER] on T.SalesPersonId = [USER].UserID
            ORDER BY Company.CompanyName
        END

        -- Get company list for Non-Advertisers for an edition and sales person
        If (@intOptionSelected = 10)
        BEGIN
            SELECT DISTINCT
                ThisYear.CompanyId,
                Company.CompanyName,
                [USER].FirstName,
                [USER].LastName,
                ThisYear.SalesPersonId
            FROM
                (SELECT Adorder.CompanyId,
                        Adorder.SalesPersonId,
                        SUM(IsNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                FROM [AdOrderRegionEdition]
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                        Adorder.StatusId < 3 AND
                        AdOrderRegionEdition.OnlineYear = @YearID AND
                        AdOrderRegionEdition.OnlineMonth = @lngEdition_ID
                WHERE AdOrder.SalesPersonId = @lngSalesPerson_ID
                GROUP BY CompanyId, SalesPersonId) AS ThisYear
                JOIN Company on ThisYear.CompanyId = Company.CompanyId
                JOIN [USER] on ThisYear.SalesPersonId = [USER].UserID
            WHERE NOT EXISTS
                (SELECT DISTINCT Adorder.CompanyId,
                        Adorder.SalesPersonId
                FROM [AdOrderRegionEdition]
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                            Adorder.StatusId >= 3 AND
                            (AdOrderRegionEdition.OnlineYear = @YearID OR AdOrderRegionEdition.OnlineYear = (@YearID - 1)) AND
                            AdOrderRegionEdition.OnlineMonth = @lngEdition_ID
                WHERE AdOrder.SalesPersonId = @lngSalesPerson_ID AND ThisYear.CompanyId = CompanyId)
            ORDER BY CompanyName
        END

        -- Get company list for Non-Advertisers for an edition and sales person,
        -- might have been advertising before, but not in the previous year
        If (@intOptionSelected = 11)
        BEGIN
        SELECT
                Company.CompanyID,
                Company.CompanyName,
                [USER].FirstName,
                [USER].LastName,
                MergeYears.SalesPersonId,
                MergeYears.AdvNet
        FROM
            (SELECT
                ThisYear.CompanyId,
                ThisYear.SalesPersonId,
                ThisYear.AdvNet
            FROM
                (SELECT Adorder.CompanyId,
                        Adorder.SalesPersonId,
                        SUM(IsNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                FROM [AdOrderRegionEdition]
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                        Adorder.StatusId < 3 AND
                        AdOrderRegionEdition.OnlineYear = @YearID AND
                        AdOrderRegionEdition.OnlineMonth = @lngEdition_ID
                WHERE AdOrder.SalesPersonId = @lngSalesPerson_ID
                GROUP BY CompanyId, SalesPersonId) AS ThisYear
            JOIN
                (SELECT Adorder.CompanyId,
                        Adorder.SalesPersonId,
                        SUM(IsNull(AdOrderRegionEdition.NetAmount, 0)) AS AdvNet
                FROM [AdOrderRegionEdition]
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                        Adorder.StatusId >= 3 AND
                        AdOrderRegionEdition.OnlineYear <= (@YearID - 3) AND
                        AdOrderRegionEdition.OnlineMonth = @lngEdition_ID
                WHERE AdOrder.SalesPersonId = @lngSalesPerson_ID
                GROUP BY CompanyId, SalesPersonId) AS ThreeYearsAgo
            ON ThisYear.CompanyId = ThreeYearsAgo.CompanyId AND ThisYear.SalesPersonId = ThreeYearsAgo.SalesPersonId )AS MergeYears
            JOIN Company on MergeYears.CompanyId = Company.CompanyId
            JOIN [USER] on MergeYears.SalesPersonId = [USER].UserID
            WHERE NOT EXISTS
                (SELECT DISTINCT Adorder.CompanyId,
                        Adorder.SalesPersonId
                FROM [AdOrderRegionEdition]
                JOIN AdOrder on AdOrderRegionEdition.AdOrderID = Adorder.AdOrderId AND
                            (AdOrderRegionEdition.OnlineYear = @YearID OR AdOrderRegionEdition.OnlineYear = (@YearID - 1)) AND
                            Adorder.StatusId >= 3
                WHERE AdOrder.SalesPersonId = @lngSalesPerson_ID AND MergeYears.CompanyId = CompanyId)
            ORDER BY CompanyName
        END

        -- new assigned companies
        If (@intOptionSelected = 12)
        BEGIN
             SELECT DISTINCT
               CO.CompanyID,
               CO.CompanyName,
               US.FirstName,
               US.LastName,
               SA.SalesPerson_ID as salesPersonID
            FROM
              SalesAssignments SA INNER JOIN Company CO ON SA.Company_ID = CO.CompanyID
              AND SA.Company_ID NOT IN (SELECT DISTINCT CompanyID FROM ADOrder )
              INNER JOIN [User] US ON SA.Salesperson_ID = US.UserId Where Month(SA.createdon) = @lngEdition_ID AND Year(SA.createdon) = @YearID
            ORDER BY
                CO.CompanyName
        END
        ELSE
        BEGIN
            SELECT DISTINCT
                 CO.CompanyID,
                 CO.CompanyName,
                 US.FirstName,
                 US.LastName,
                 SA.SalesPerson_ID as salesPersonID
            FROM
                SalesAssignments SA INNER JOIN Company CO ON SA.Company_ID = CO.CompanyID AND SA.Salesperson_ID = @lngSalesPerson_ID
                AND SA.Company_ID NOT IN (SELECT DISTINCT CompanyID FROM ADOrder)
                INNER JOIN [User] US ON SA.Salesperson_ID = US.UserId  Where Month(SA.createdon) = @lngEdition_ID AND Year(SA.createdon) = @YearID
            ORDER BY
                CO.CompanyName
         END
    END

END


GO
----------------------------------------------------------------------------------------------------------
/****** Object:  StoredProcedure [dbo].[usp_GetManufacturersDistributor]    Script Date: 09/24/2011 22:10:54 ******/
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetManufacturersDistributor]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetManufacturersDistributor]

GO
/****** Object:  StoredProcedure [dbo].[usp_GetManufacturersDistributor]    Script Date: 09/24/2011 22:10:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetManufacturersDistributor]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- Created By: Fathima
-- Created On: 20-10-2011
-- Modified By: Kiran BS
-- Modified On: 28-02-2012
-- Purpose: Getting Manufacturer''s Distributors.
-- Sample: [usp_GetManufacturersDistributor] 144397

--usp_GetManufacturersDistributor 134413
CREATE PROCEDURE [dbo].[usp_GetManufacturersDistributor]
(
    @mfrID int,
    @UserRole varchar(10)
)
AS
BEGIN

    set transaction isolation level read uncommitted
CREATE TABLE #tempTable
(
    mfrid int,
     distid int,
     regionid int,
     regionname varchar(100),
     zoneid int,
     zonename varchar(100),
     authstatusid int,
     [days] int
)

/* Start Getting exact zone counts under region */
create table #tmpZ
(
    RegionID int,
    RegionName varchar(100),
    ZoneCnt int
)

insert into #tmpZ
select
    R.RegionID,
    RegionName,
    COUNT(zoneId) as ZoneCnt
from Region R with(nolock)
    inner join Country C with(nolock) on C.RegionID = R.RegionID
    inner join CountryZones CZ with(nolock) on CZ.CountryID = C.CountryID
where
    R.RegionID != 0
group by R.RegionID,RegionName

insert into #tmpZ
select
    C.RegionID,
    RegionName,
    count(CountryID) as ZoneCnt
from
    Country C with(nolock),
    Region R with(nolock)
where
    C.RegionID not in (select RegionID from #tmpZ)
    and C.RegionID != 0 and C.RegionID = R.RegionID
group by C.RegionID,RegionName

insert into #tmpZ
select
    RegionId,
    RegionName,
    0 as ZoneCnt
from Region with(nolock)
where
    RegionID != 0
    and RegionID not in (select RegionID from #tmpZ)

/* End Getting exact zone counts under region */


DECLARE @distid INT
DECLARE @regionname varchar(100)

if (select COUNT(*) from RegionAuthorization ra
    -- KIRAN Issue:9828 [START]
    INNER JOIN RegionZoneStatus rzs
        ON ra.MfrDistID=rzs.MfrDistID AND (rzs.AuthStatusID=2 OR rzs.AuthStatusID=4 AND UPPER(@UserRole)=''EXTERNAL'') OR (UPPER(@UserRole)=''INTERNAL'')
    -- KIRAN Issue:9828 [END]
    where MfrID = @mfrID) > 0
begin
DECLARE CursorRegionZoneStatus CURSOR FAST_FORWARD FOR
    SELECT DISTINCT DistID
    FROM RegionZoneStatus rz with(nolock)
    INNER JOIN RegionAuthorization ra with(nolock)
     ON rz.MfrDistID = ra.MfrDistID AND (rz.AuthStatusID=2 OR rz.AuthStatusID=4 AND UPPER(@UserRole)=''EXTERNAL'') OR (UPPER(@UserRole)=''INTERNAL'') -- KIRAN Issue:9828
    WHERE MfrID = @mfrID

    OPEN CursorRegionZoneStatus
    FETCH NEXT FROM CursorRegionZoneStatus INTO @distid

    WHILE @@FETCH_STATUS = 0
    BEGIN
         insert into #tempTable
         select ra.mfrid, ra.distid,
              rz.regionid,
              r.regionname,
              rz.zoneid,
              ''zonename''=null,
              rz.authstatusid, ''Days'' = DATEDIFF(day, rz.Denied_Date, GETDATE())
         from
             regionzonestatus rz with(nolock)
             inner join region r with(nolock) on rz.regionid = r.regionid
             inner join regionauthorization ra with(nolock) on rz.mfrdistid = ra.mfrdistid
         where
             ra.mfrid = @mfrid
             AND ra.distid = @distid
            AND (rz.AuthStatusID=2 OR rz.AuthStatusID=4)

        insert into #tempTable
         select
              ''mfrid''=@mfrid,
              ''distid''=@distid,
              r.regionid,
              r.regionname,
              ''zoneid''=null,
              ''zonename''=null,
              ''authstatusid''=0,
              ''days''=0
         from
             region r with(nolock)
         where
             regionname COLLATE DATABASE_DEFAULT not in (select regionname from #tempTable t where mfrid = @mfrid and distid = @distid)

    FETCH NEXT FROM CursorRegionZoneStatus INTO @distid
END

CLOSE CursorRegionZoneStatus

DEALLOCATE CursorRegionZoneStatus
----------------------------------

CREATE TABLE #tempZone
(
    mfrid int,
     distid int,
     regionid int,
     regionname varchar(100),
     zoneid int,
     zonename varchar(100),
     authstatusid int,
     [days] int
)

DECLARE @mid INT
DECLARE @did INT
DECLARE @regid INT
DECLARE @regname varchar(100)

DECLARE CursorZone CURSOR FAST_FORWARD FOR
SELECT DISTINCT
    mfrid,
     distid,
     regionid,
     regionname
FROM #tempTable --#tempZone2

OPEN CursorZone
FETCH NEXT FROM CursorZone INTO @mid, @did, @regid, @regname

WHILE @@FETCH_STATUS = 0
BEGIN
    INSERT INTO #tempZone
     SELECT
           mfrid,
           distid,
           regionid,
           RegionName,
           zoneid,
           ZoneName,
           authstatusid, [days]
     FROM #tempTable
     WHERE
         mfrid = @mid
         and distid = @did
         and regionid = @regid
         and regionname = @regname

 declare @cnt int
 select @cnt=count(zoneid)
 from countryzones with(nolock), country with(nolock)
 where countryzones.countryid=country.countryid and country.regionid !=0 and country.regionid=@regid
 if(@cnt=0)
     begin
         insert into #tempZone
         select
               ''mfrid'' = @mid,
               ''distid'' = @did,
               ''regiondid'' =@regid,
               ''RegionName'' = @regname,
               countryid as zoneid,
               countryname as zonename,
               ''authstatusid''=0,
               ''days''=0
         from
             country with(nolock)
         where
             country.regionid !=0
             and country.regionid !=2
             and country.regionid=@regid and isActive=1
             and countryid not in (select zoneid from #tempZone where mfrid = @mid and distid = @did and regionid = @regid and regionname = @regname)
      end
 else
      begin
     insert into #tempZone
     select
           ''mfrid'' = @mid,
           ''distid'' = @did,
           ''regiondid'' =@regid,
           ''RegionName'' = @regname,
           zoneid,
           zonename,
           ''authstatusid''=0,
           ''days''=0
     from
         countryzones with(nolock),
         country with(nolock)
     where
         countryzones.countryid=country.countryid
         and country.regionid !=0
         and country.regionid !=2
         and country.regionid=@regid
         and zoneid not in (select zoneid from #tempZone where mfrid = @mid and distid = @did and regionid = @regid and regionname = @regname)
      end

     FETCH NEXT FROM CursorZone
     INTO @mid, @did, @regid, @regname
END

CLOSE CursorZone

DEALLOCATE CursorZone

select
    mfrid,
    distid,
    b.regionid,
    b.RegionName,
     case when (AuthSub = 3 and (c.ZoneCnt - b.AuthSubCnt) = 0) then 4 --''countryblue''
         when (AuthSub = 3 and (c.ZoneCnt - b.AuthSubCnt) > 0) then 3 --''Partialyauthorize''
          when  (AuthSub = 2 and (c.ZoneCnt - b.AuthSubCnt) = 0 and b.regionid <> 2) then 2--''countryred''
         when  (AuthSub = 2 and (c.ZoneCnt - b.AuthSubCnt) > 0 and b.regionid <> 2) then 2--''countryred''
         when (AuthSub = 2 and (c.ZoneCnt - b.AuthSubCnt) = c.ZoneCnt) then case
         when (AuthSub = 2 and (c.ZoneCnt - b.AuthSubCnt) = 0) then 2--''countryred''
         else 1--''countrywhite''
     end
     when  (AuthSub = 3 and (c.ZoneCnt - b.AuthSubCnt) = 0 and b.regionid = 2) then 4--''countryblue''
      when  (AuthSub = 3 and (c.ZoneCnt - b.AuthSubCnt) > 0 and b.regionid = 2) then 4--''countryblue''
     when (AuthSub = 2 and (c.ZoneCnt - b.AuthSubCnt) = 0 and b.regionid =2) then 2  --''countryred''
     when  (AuthSub = 2 and (c.ZoneCnt - b.AuthSubCnt) > 0 and b.regionid = 2) then 2--''countryred''
     else 1--''countrywhite''
     end as AuthImageStatus
into #t
from
    (select
        MfrID,distid,regionid,RegionName,AuthSub,COUNT(isnull(AuthSub,0)) as AuthSubCnt
    from
        (SELECT
             mfrid,
             distid,
             regionid,
             ''RegionName'' = REPLACE(RegionName, '' '', ''''),
             zoneid,
             ''ZoneName''= ISNULL([dbo].[GetZoneName](regionid, zoneid), Zonename),
             authstatusid,
             case when (authstatusid = 1 OR authstatusid = 3 OR authstatusid = 5) then 1 when authstatusid = 2 then 2 when authstatusid = 4 then 3  else 1 end as AuthSub,
            [days]
        FROM #tempZone ) a
    group by distid,mfrid,regionid,RegionName,AuthSub) b
    inner join (select * from #tmpZ) c on c.RegionID = b.regionid

select distinct RegionId,RegionName into #tcol from #t

select distid,RegionName,max(AuthImageStatus) as ImageStatus into #tt from #t group by distid,RegionName

DECLARE @cols NVARCHAR(2000)
SELECT  @cols = COALESCE(@cols + '',['' + RegionName + '']'', ''['' + RegionName + '']'')
FROM    #tcol
order by regionid

declare @str as varchar(max)
set @str = ''select DistId,companyname as DistName,CompanyDescription as DistDesc,MfrId,'' + @cols + ''
into #rr from (select t1.mfrid,t.distid,t.regionname,t1.regionId,ImageStatus,companyname,cast(CompanyDescription as varchar) as CompanyDescription
from #tt t inner join #t t1 on t1.distID = t.distId inner join Company C with(nolock) on C.companyId = t.DistId inner join RegionAuthorization r with(nolock) on r.MfrID = t1.mfrid and r.DistID = t.distid ''

set @str = @str + '' where c.companystatusid=1 and c.isactive=1 and r.isactive=1)''
set @str = @str + '' p pivot (max(ImageStatus) for RegionName in ('' + @cols + '') ) as pvt ''
set @str = @str + ''select distinct * from #rr order by DistName''

print(@str)
exec(@str)

DROP TABLE #tempZone
DROP TABLE #tempTable

End
Else
begin
select distinct RegionId,RegionName into #tcol1 from #tmpZ order by RegionID

DECLARE @cols1 NVARCHAR(2000)
SELECT  @cols1 = COALESCE(@cols1 + '',['' + RegionName + '']'', ''['' + RegionName + '']'')
FROM    #tcol1
order by regionid

declare @str1 as varchar(max)
set @str1 = ''select 0 as DistId,'''''''' as DistName,'''''''' as DistDesc,0 as MfrId,'' + @cols1 + ''
into #rr from (select t.regionid,t.regionname from #tcol1 t)''
set @str1 = @str1 + '' p pivot (max(regionid) for RegionName in ('' + @cols1 + '') ) as pvt ''
set @str1 = @str1 + ''delete from #rr ''
set @str1 = @str1 + ''select * from #rr''

exec(@str1)
end

END
'
END
GO

----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_AddContactRole]    Script Date: 02/28/2012 17:30:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_AddContactRole]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_AddContactRole]
GO

GO

/****** Object:  StoredProcedure [dbo].[usp_AddContactRole]    Script Date: 02/28/2012 17:30:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_AddContactRole]
(
    @FirstName                    varchar(100),
    @LastName                    varchar(100),
    @CreatedBy                    int,
    @Email                        varchar(100)=NULL,
    @CompanyID                    int=1,
    @RoleID                        int,
    @UserRegID                    int output
)
AS
BEGIN
    DECLARE @UserId varchar(10)
    DECLARE @UserTypeID INT
    SET @UserTypeID=1

    INSERT INTO  [User]
    (FirstName,LastName,CreatedBy,CreatedOn,isActive)
    VALUES(@FirstName,@LastName,@CreatedBy,getdate(),0)

    SELECT @UserId=scope_identity()

    IF(@UserId > 0)
        BEGIN
            SET    @UserRegID = 100000000+@UserId
            UPDATE [User] SET UserRegID = @UserRegID,
                CreatedBy = CASE WHEN @Createdby > 0 THEN  @Createdby ELSE @UserId END
                Where UserID = @UserId
        END

    IF(@UserId<>0)
        BEGIN
            INSERT INTO  UserContact
            (
                UserID,
                EmailAddress,
                CreatedBy,
                CreatedOn
            )
            VALUES
            (
                @UserId,
                @Email,
                CASE WHEN @Createdby > 0 THEN  @Createdby ELSE @UserId END,
                getdate()
            )

        insert into dbo.userRole(UserID,RoleID,CompanyID,CreatedBy,CreatedOn,UserTypeID)
        values(@UserId,@RoleID,@CompanyID,@CreatedBy,getdate(),@UserTypeID)

        END

END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[uspAdJobFolderCreatePrint]    Script Date: 02/27/2012 18:16:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAdJobFolderCreatePrint]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspAdJobFolderCreatePrint]

GO

/****** Object:  StoredProcedure [dbo].[uspAdJobFolderCreatePrint]    Script Date: 02/27/2012 18:16:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--*****************************************************************************************************
--*   Modification        : To include Partial Complete & do optimization for updating AdJobfolderID
--*   Author            : Kiran Sangoi
--*   Modify Date        : Feb/27/2012
--*****************************************************************************************************

CREATE PROCEDURE  [dbo].[uspAdJobFolderCreatePrint]
AS
BEGIN

    DECLARE @AdOrderID int
    DECLARE @EditionID int
    DECLARE @AdApprovalID int
    DECLARE @ADJobFolderID int

    -- find ads with missing ad job folders
    DECLARE adordercur CURSOR FOR
        SELECT DISTINCT
            AO.AdOrderID,
            ADR.EditionID
        FROM
            AdOrder AO
            INNER JOIN AdOrderDetails AD
                ON AD.AdOrderID = AO.AdOrderID
            INNER JOIN AdOrderDetailsRegionEdition ADR
                ON ADR.AdOrderDetailsId = AD.AdOrderDetailsId

        WHERE
            AO.StatusId in (3,4)     -- Final OR Partial Complete
            AND ADR.EditionID>0
            AND ADR.ADJobFolderID IS NULL

    -- process orders/edi not having ad job folder
    OPEN adordercur
    FETCH adordercur INTO @AdOrderID, @EditionID

    WHILE @@Fetch_Status = 0
    BEGIN
        -- find out if there is an ad job folder for same order, same edition
        -- if not, create a new ad job folder
        -- if yes, than use the same ad job folder for the new ads
        SELECT @ADJobFolderID = ISNULL(
                            (SELECT
                                MAX(ADR.ADJobFolderID)
                            FROM
                                AdOrder AO
                                INNER JOIN AdOrder AO1
                                    ON AO1.AdOrderNumber = AO.AdOrderNumber
                                INNER JOIN AdOrderDetails AD
                                    ON AO1.AdorderID = AD.AdOrderID
                                INNER JOIN AdOrderDetailsRegionEdition ADR
                                    ON ADR.AdOrderDetailsId = AD.AdOrderDetailsId
                            WHERE
                                AO.AdOrderID = @AdOrderID
                                AND ADR.EditionID = @EditionID
                                AND ADR.ADJobFolderID IS NOT NULL), 0)

        IF @ADJobFolderID = 0
        BEGIN
            INSERT INTO AdJobFolderMaster(AdJobFolderTypeID,StatusId) VALUES('P',1)
            SET @ADJobFolderID  = SCOPE_IDENTITY()
        END
        UPDATE AdOrderDetailsRegionEdition
                SET AdJobFolderId = @ADJobFolderID
                FROM
                    AdOrderDetailsRegionEdition ADR
                    INNER JOIN AdOrderDetails AD
                        ON ADR.AdOrderDetailsId = AD.AdOrderDetailsId
                WHERE
                    AD.AdOrderID = @AdOrderID
                    AND ADR.EditionID = @EditionID

        FETCH adordercur INTO @AdOrderID, @EditionID
    END

    CLOSE adordercur
    DEALLOCATE adordercur

END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetProductionRoleAlert]    Script Date: 03/03/2012 00:30:13 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetProductionRoleAlert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetProductionRoleAlert]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetProductionRoleAlert]    Script Date: 03/03/2012 00:30:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

------------------------------------------------------------------------------------------
-- Created By  : P.Ashok Kumar
-- Procedure Name : usp_GetProductionRoleAlert
-- Created Date  : 6th-June-2011
-- Description  : Production Role User will populate and sending e-mails.
-- Arguments  : None
-- Returns   : None
-- Modified by SivaV and Mohit to get emails for Alert by comparing the Role Name not RoleId
------------------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[usp_GetProductionRoleAlert]
AS
BEGIN

set transaction isolation level read uncommitted

 SELECT DISTINCT UC.EmailAddress,U.UserRegID,UR.RoleID,UR.UserTypeID,U.UserID
 FROM [User] U,UserRole UR,UserContact UC,MstRole MR
 WHERE  U.UserID = UC.UserID
 AND UC.UserID = UR.UserID
 AND UR.UserTypeID = 2
 AND UR.RoleID=MR.RoleID
 AND MR.RoleName ='Production'
 --AND UR.RoleID = 45 As suggested by Mohit This is updated
 AND U.IsActive =1
END

GO
----------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[usp_AssignCompany]    Script Date: 03/14/2012 12:28:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_AssignCompany]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_AssignCompany]
GO

/****** Object:  StoredProcedure [dbo].[usp_AssignCompany]    Script Date: 03/14/2012 12:28:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-----------------------------------------------------------------------------------------------
-- Created By  : Karthik.P
-- Create Date  : 15-May-2011
-- Description   : Get Edition based on the edition mode
-----------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_AssignCompany]
(
 @SalesPersonId INT,
-- @EditionID INT,
 @CompanyIdCollection VARCHAR(1000),
 @CreatedBy VARCHAR(50)
)
AS
BEGIN
SET NOCOUNT ON
 DECLARE @CompanyId CHAR(25)
 DECLARE @AssignmentId CHAR(25)

 DECLARE curCompanyId CURSOR FOR
 SELECT  * FROM dbo.split(@CompanyIdCollection,',')

 OPEN curCompanyId
 FETCH curCompanyId INTO @CompanyId

 WHILE(@@FETCH_STATUS=0)
  BEGIN
  SELECT @AssignmentId = Assignment_ID FROM SalesAssignments WHERE Company_ID=@CompanyId and End_Date is null
  UPDATE SalesAssignments  SET  UpdateOn=getdate(), UpdatedBy=@CreatedBy, End_Date=getdate(), [Status] = 0 where Assignment_ID = @AssignmentId
  INSERT INTO SalesAssignments ( SalesPerson_ID, Company_ID, CreatedBy, CreatedOn, [Status], [Start_Date], End_Date, UpdateOn, UpdatedBy)
    VALUES( @SalesPersonId,@CompanyId,@CreatedBy,GETDATE(), 1, GETDATE(), null, GETDATE(), @CreatedBy)
  FETCH curCompanyId INTO @CompanyId
  END

CLOSE curCompanyId
DEALLOCATE curCompanyId
SET NOCOUNT OFF

END
GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_BSK_getSearchResultDesignResource_Count]    Script Date: 03/17/2012 19:00:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_BSK_getSearchResultDesignResource_Count]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_BSK_getSearchResultDesignResource_Count]
GO

/****** Object:  StoredProcedure [dbo].[usp_BSK_getSearchResultDesignResource_Count]    Script Date: 03/17/2012 19:00:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[usp_BSK_getSearchResultDesignResource_Count]
    @SearchText     VARCHAR(80)
    ,@ManufacturerIDs VARCHAR(5000) = ''
AS

BEGIN

    set transaction isolation level read uncommitted

    DECLARE @Query VARCHAR(8000) =''
    DECLARE @Manufacturer_Query VARCHAR(200) = ''
    DECLARE @SearchText1 varchar(8000)

    select @SearchText1=dbo.Splitor_part(@SearchText, ' ')

    IF(@ManufacturerIDs <> '')
        BEGIN
            SET @ManufacturerIDs = '' + REPLACE(@ManufacturerIDs,',',''',''') + ''
            SET @Manufacturer_Query = 'AND (comp.CompanyID IN ('''+@ManufacturerIDs+'''))'
        END



    SET @Query ='SELECT  COUNT(DISTINCT prod.ProductID)
                    FROM
    (
     select   distinct pd.*
     from
            (select
            ProductID
            ,ManufacturerID
            ,SampleUrl
            ,VideoFilePath
            ,DataSheet
            ,ImageFilePath
            from product (nolock)
            where ' + @SearchText1 + '
            )pd
             outer apply    (SELECT * FROM Split('''+@SearchText+''','' '')) AS search_term
            ) prod
            INNER JOIN [dbo].[Company] comp
                ON prod.ManufacturerID=comp.CompanyID
            LEFT JOIN [dbo].[InventorySettings] inv
                ON inv.CompanyID=prod.ManufacturerID
                    WHERE comp.IsActive = ''1''
                        AND comp.CompanyStatusID=''1''
                        AND (ISNULL(prod.SampleUrl, '''') <> ''''
                            OR ISNULL(prod.VideoFilePath,'''') <> ''''
                            OR ISNULL(inv.MafSpecURL,'''') <> ''''
                            OR ISNULL(prod.DataSheet,'''') <>''''
                            OR ISNULL(prod.ImageFilePath,'''')<>'''' )'
                        + @Manufacturer_Query
        EXECUTE(@Query)
END
GO
----------------------------------------------------------------------------------------------------------
/****** Object:  StoredProcedure [dbo].[usp_GetProductTypeComp]    Script Date: 09/24/2011 22:13:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetProductTypeComp]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetProductTypeComp]
GO
/****** Object:  StoredProcedure [dbo].[usp_GetProductTypeComp]    Script Date: 09/24/2011 22:13:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetProductTypeComp]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[usp_GetProductTypeComp]
(
@ParentId  int,
@CompanyId int
)
AS
BEGIN
    set transaction isolation level read uncommitted
IF @CompanyId=0
BEGIN
SELECT ProductTypeId,ParentId,TypeDescription,
(SELECT count(*) FROM ProductType WHERE ParentId=PT.ProductTypeId)
childnodecount FROM ProductType PT WHERE parentID = @ParentId    AND IsActive =1 AND PT.StatusID=1 AND PT.TypeDescription<>''Services''
ORDER BY TypeDescription
END
ELSE
BEGIN
SELECT PT.ProductTypeId,PT.ParentId,PT.TypeDescription,CPT.ProductTypeID,
(SELECT count(*) FROM ProductType WHERE ParentId=PT.ProductTypeId)
childnodecount FROM ProductType PT,CompanyProductType CPT
WHERE PT.parentID = @ParentId
AND PT.IsActive =1 AND CPT.IsActive=1 AND PT.StatusID=1
AND CPT.CompanyID=@CompanyId
AND CPT.ProductTypeID= PT.ProductTypeId AND PT.TypeDescription<>''Services'' group by PT.ProductTypeId,PT.ParentId,PT.TypeDescription,CPT.ProductTypeID
ORDER BY TypeDescription

END
END
'
END
GO
----------------------------------------------------------------------------------------------------------
/****** Object:  StoredProcedure [dbo].[usp_GetSearchProductTypeComp]    Script Date: 09/24/2011 22:19:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchProductTypeComp]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchProductTypeComp]
GO
/****** Object:  StoredProcedure [dbo].[usp_GetSearchProductTypeComp]    Script Date: 09/24/2011 22:19:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchProductTypeComp]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'




--------------------------------------------------------------------------
-- Name   : usp_GetSearchProductTypeComp Producttype
-- Description : This Procedure Will Get the Procucttype .
-- Arguments :
-- Returns  : None
-----------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetSearchProductTypeComp]
(

    @ParentId  int,
    @CompanyId int
)
AS
    set transaction isolation level read uncommitted
BEGIN
        IF @CompanyId=0
        BEGIN
            SELECT ProductTypeId,ParentId,TypeDescription,
            (SELECT count(*) FROM ProductType WHERE ParentId=PT.ProductTypeId)
            childnodecount FROM ProductType PT WHERE parentID = @ParentId AND IsActive =1 AND PT.TypeDescription<>''Services''
            ORDER BY TypeDescription
        END
        ELSE
        BEGIN

          IF Exists(Select * from (Select dbo.Get_CompanyTypeName(@CompanyId) as CompanyTypeName) as A where CompanyTypeName like ''%M%'')

            SELECT PT.ProductTypeId,PT.ParentId,PT.TypeDescription,CPT.ProductTypeID,
            (SELECT count(*) FROM ProductType WHERE ParentId=PT.ProductTypeId AND IsActive =1 )
            childnodecount,[dbo].[Get_ProductTypeCount](@CompanyId) as ProductTypeCount
            FROM CompanyProductType CPT
            INNER JOIN ProductType PT on CPT.ProductTypeID= PT.ProductTypeId
                AND PT.IsActive = 1 AND PT.StatusID = 1
            WHERE PT.parentID = @ParentId AND CPT.IsActive =1 AND CPT.CompanyID=@CompanyId AND PT.TypeDescription<>''Services''
             group by PT.ProductTypeId,PT.ParentId,PT.TypeDescription,CPT.ProductTypeID
            ORDER BY TypeDescription

           ELSE

            SELECT PT.ProductTypeId,PT.ParentId,PT.TypeDescription,CPT.ProductTypeID,
            (SELECT count(*) FROM ProductType WHERE ParentId=PT.ProductTypeId AND IsActive =1 )
            childnodecount,[dbo].[Get_ProductTypeCount](@CompanyId) as ProductTypeCount
            FROM CompanyProductType CPT
            INNER JOIN ProductType PT on CPT.ProductTypeID= PT.ProductTypeId
                AND PT.IsActive = 1 AND PT.StatusID = 1
            LEFT JOIN (Select Distinct PT.ProductTypeid from RegionAuthorization RA
               INNER JOIN CompanyProductType CPT on RA.MfrID = CPT.CompanyID AND CPT.IsActive = 1
               INNER JOIN ProductType PT on CPT.ProductTypeID = PT.ProducttypeID AND PT.IsActive = 1 AND PT.StatusID = 1
               WHERE RA.DistID = @CompanyID and RA.Publish = 1 and RA.IsActive = 1) as PB on PB.ProductTypeID = PT.ProducttypeID
            WHERE PT.parentID = @ParentId AND CPT.IsActive =1 AND CPT.CompanyID=@CompanyId
            and PB.ProductTypeID is not null AND PT.TypeDescription<>''Services''
             group by PT.ProductTypeId,PT.ParentId,PT.TypeDescription,CPT.ProductTypeID
            ORDER BY TypeDescription

        END
END


'
END
GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_CalculateSpend]    Script Date: 04/03/2012 13:05:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_CalculateSpend]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_CalculateSpend]
GO

/****** Object:  StoredProcedure [dbo].[usp_CalculateSpend]    Script Date: 04/03/2012 13:05:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:        Lalit Mehta, Mohit Garg
-- Create date: Mar 18, 2012; Mar 24, 2012
-- Description:    Get total money spent by Distributors for Manufacturer and Product ads (both online and print)
-- =============================================
CREATE PROCEDURE [dbo].[usp_CalculateSpend]
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    --clear current print and online amount values
    update RegionZoneStatus set Online_Amount = 0, Print_Amount = 0;

    -- get 10 last closed print editions
    SELECT
        top 10 EditionID, RegionID into #tblEdition
    FROM
        Editions e, MstEditionStatus es
    WHERE
        e.StatusID = es.StatusID
        and es.Description = 'Complete'
    ORDER BY PublicationDate DESC


    -- Mfr - Online Amount
    select
         ra.MfrDistID,
         aodre.RegionID as ZoneID,
         sum(aod.Price) as Online_Amount into #MfrOnline
    from
         AdOrder ao, AdOrderDetails aod,
         AdOrderDetailsRegionEdition aodre,
         SalesSectionType sst, RegionAuthorization ra
    where
        ao.AdOrderId = aod.AdOrderId
        and aod.SectionID = sst.SectionID
        and sst.SectionCode in ('M','X')
        and ao.StatusId in (3,4,5)
        and aod.ActivationDate <= GETDATE()
        and GETDATE()<=DATEADD(MM,aod.Duration,aod.ActivationDate)
        and aod.OrderType = 'O'
        and aodre.RegionID <> 0
        and aod.AdOrderDetailsId = aodre.AdOrderDetailsId
        and ao.CompanyId = ra.DistID
        and aod.PositionTitle = ra.MfrID
    group by aodre.RegionID,  ra.MfrDistID

    update rzs
        set rzs.Online_Amount = Mfr.Online_Amount
    from
        RegionZoneStatus rzs join #MfrOnline Mfr
            on rzs.MfrDistID = Mfr.MfrDistID
            and rzs.ZoneID = Mfr.ZoneID
            and rzs.RegionID in (1,2)

    drop table #MfrOnline

    -- Mfr - Print Amount

    select
         ra.MfrDistID,
         aodre.RegionID as ZoneID,
         sum(aod.price) as Print_Amount into #MfrPrint
    from
         AdOrder ao, AdOrderDetails aod,
         AdOrderDetailsRegionEdition aodre,
         SalesSectionType sst, RegionAuthorization ra,
         #tblEdition t
    where
        ao.AdOrderId = aod.AdOrderId
        and aod.SectionID = sst.SectionID
        and sst.SectionCode in ('M','X')
        and ao.StatusId in (3,4,5)
        and aod.OrderType = 'P'
        and aodre.RegionID <> 0
        and aod.AdOrderDetailsId = aodre.AdOrderDetailsId
        and ao.CompanyId = ra.DistID
        and aod.PositionTitle = ra.MfrID
        and t.EditionID = aodre.EditionID
    group by aodre.RegionID,  ra.MfrDistID

    update rzs
        set rzs.Print_Amount = Mfr.Print_Amount
    from
        RegionZoneStatus rzs join #MfrPrint Mfr
            on rzs.MfrDistID = Mfr.MfrDistID
            and rzs.ZoneID = Mfr.ZoneID
            and rzs.RegionID in (1,2)

 drop table #MfrPrint

    --clear current print and online amount values for Distributors Product Ads
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DistProdTypeSpend]') AND type in (N'U'))
DROP TABLE [dbo].[DistProdTypeSpend]

/****** Object:  Table [dbo].[DistProdTypeSpend]    Script Date: 03/21/2012 17:05:27 ******/
CREATE TABLE [dbo].[DistProdTypeSpend](
    [ProductTypeID] [int] NOT NULL,
    [DistID] [int] NOT NULL,
    --[RegionID] [int] NOT NULL,
    [ZoneID] [int] NOT NULL,
    [Online_Amount] [money] NULL,
    [Print_Amount] [money] NULL,
 )

-- ProductType Amount
    select
         aod.PositionTitle as ProductTypeId,
         ao.CompanyId as DistId,
         aodre.RegionID as ZoneID,
         sum(aod.Price) as Online_Amount,   -- ProductType - Online Amount
         0 as Print_Amount into #ProdTypeAmount
    from
         AdOrder ao, AdOrderDetails aod,
         AdOrderDetailsRegionEdition aodre,
         SalesSectionType sst, CompanyTypeMapping ctm
    where
        ao.AdOrderId = aod.AdOrderId
        and aod.SectionID = sst.SectionID
        and aod.AdOrderDetailsId = aodre.AdOrderDetailsId
        and ao.CompanyId = ctm.companyId
        and sst.SectionCode in ('P')
        and ao.StatusId in (3,4,5)
        and aod.ActivationDate <= GETDATE()
        and GETDATE()<=DATEADD(MM,aod.Duration,aod.ActivationDate)
        and aod.OrderType = 'O'
        and aodre.RegionID <> 0
        and ctm.companytypeid = 2
        and aod.Price > 0 and aod.PositionTitle is not null and aod.PositionTitle > 0
    group by aod.PositionTitle, ao.CompanyId, aodre.RegionID
    Union
    select
         aod.PositionTitle as ProductTypeId,
         ao.CompanyId as DistId,
         aodre.RegionID as ZoneID,
         0 as Online_Amount,
         sum(aod.price) as Print_Amount    -- ProductType - Print Amount
    from
         AdOrder ao, AdOrderDetails aod,
         AdOrderDetailsRegionEdition aodre,
         SalesSectionType sst, #tblEdition t, CompanyTypeMapping ctm
    where
        ao.AdOrderId = aod.AdOrderId
        and aod.SectionID = sst.SectionID
        and aod.AdOrderDetailsId = aodre.AdOrderDetailsId
        and t.EditionID = aodre.EditionID
        and ao.CompanyId = ctm.companyId
        and sst.SectionCode in ('P')
        and ao.StatusId in (3,4,5)
        and aod.OrderType = 'P'
        and aodre.RegionID <> 0
        and ctm.companytypeid = 2
        and aod.Price > 0 and aod.PositionTitle is not null and aod.PositionTitle > 0
    group by aod.PositionTitle, ao.CompanyId, aodre.RegionID ;

    insert into [DistProdTypeSpend] select ProductTypeId, DistId,
        ZoneID, sum(Online_Amount), sum(Print_Amount) from #ProdTypeAmount
    group by ProductTypeId, DistId, ZoneID

    drop table #tblEdition
    drop table #ProdTypeAmount

END


GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_ViewProofHeaderDetails]    Script Date: 03/20/2012 22:47:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_ViewProofHeaderDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_ViewProofHeaderDetails]
GO

/****** Object:  StoredProcedure [dbo].[usp_ViewProofHeaderDetails]    Script Date: 03/20/2012 22:47:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--Drop procedure ViewProofHeaderDetails

CREATE Procedure [dbo].[usp_ViewProofHeaderDetails]

@OrderId Int

AS

Begin
      set transaction isolation level read uncommitted
      SELECT top 1
       com.companyname as CompanyName,com.CompanyID,
      Max(CONVERT(VARCHAR(10), aso.ActivationDate,101)) as PostingDate,
       aso.Adorderid as OrderID,
       UC.UserId,
       (USR.FirstName + USR.LastName)as UserName,
       (USR.FirstName+USR.LastName)as AdProofContactName,
      ISNULL(CONVERT(VARCHAR(10), aom.AuthorizedDate,101),'')as ApprovalDate
       FROM AdJobFolderMaster a
        INNER JOIN AdOrderDetailsRegionEdition ad
           ON a.AdJobFolderId = ad.AdJobFolderId
        INNER JOIN AdOrderDetails aso
           ON aso.AdOrderDetailsId = ad.AdOrderDetailsId
        INNER JOIN AdOrder aom
           ON aom.AdOrderId = aso.AdOrderId
        INNER JOIN company com
           ON com.companyid = aom.companyid
         --INNER JOIN [USER] USR
         --ON aom.SalesPersonId = USR.UserId
         INNER JOIN UserContact UC
            ON aom.AddressProofId = UC .UserContactID
         INNER JOIN [USER] USR
            on uc.UserId=USR.UserId
         LEFT OUTER JOIN Mstadjobfolderstatus MstFldrSts
         on aom.StatusId=MstFldrSts.StatusId
        Where aso.Adorderid  =@OrderId
         group by com.companyname,com.CompanyID,aso.ActivationDate,aso.Adorderid,UC.UserId,
         USR.FirstName + USR.LastName,aom.AuthorizedDate
         order by PostingDate desc
End

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetAllCompanyListSuggestion]    Script Date: 03/20/2012 21:58:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAllCompanyListSuggestion]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAllCompanyListSuggestion]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetAllCompanyListSuggestion]    Script Date: 03/20/2012 21:58:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-------------------------------------------------------------------------
-- Author       : Ramesh Kmar
-- Name            : usp_GetCompanySuggestion
-- Description  : Get all company name from company table
-------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetAllCompanyListSuggestion]
(
 @PrefixText  varchar(300),
 @CompanyCount  int
)
AS
BEGIN
  DECLARE @strSQL Varchar(max)
  SELECT  @strSQL = ''
  set transaction isolation level read uncommitted
   SET @strSQL ='SELECT DISTINCT TOP '+CONVERT(varchar(9), @CompanyCount)+' C.CompanyName AS CompanyName ,C.CompanyID
  FROM  Company AS C,CompanyTypeMapping CTM
  WHERE C.CompanyName LIKE '''+@PrefixText+'%'' AND C.Isactive = 1 AND C.CompanyID = CTM.CompanyID AND C.CompanyStatusID = 1 order by C.CompanyName'

END
EXEC(@strSQL)


GO
----------------------------------------------------------------------------------------------------------
GO
/****** Object:  StoredProcedure [dbo].[usp_GetSalesOrderLookUp]    Script Date: 09/24/2011 22:16:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSalesOrderLookUp]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSalesOrderLookUp]
GO
/****** Object:  StoredProcedure [dbo].[usp_GetSalesOrderLookUp]    Script Date: 09/24/2011 22:16:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSalesOrderLookUp]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

-------------------------------------------------------------------
-- Name            : Siva Prakash D
-- Description    : Get Sales Order Look Up
-- Arguments    : None
-- Returns        : Returns the Sales Order details
--Example        : usp_GetSalesOrderLookUp ''A''
-------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetSalesOrderLookUp]
(
    @SearchText        varchar(100)
)
AS
BEGIN
            set transaction isolation level read uncommitted
    SELECT C.companyid, C.CompanyName,Ad.AdOrderNumber,Ad.GrossAmount,Ad.NetAmount,Ad.OrderDate,Ad.AdOrderId,U.SalesPersonCode,S.Description
    FROM
    AdOrder Ad INNER JOIN Company C ON Ad.CompanyId = C.CompanyId
    INNER JOIN [USER] U ON U.UserId = Ad.SalesPersonId
    INNER JOIN MstOrderStatus S ON Ad.StatusId = S.StatusID
    WHERE
    C.CompanyName LIKE @SearchText+''%''  and s.Description <> ''Revised Order''
    ORDER BY C.CompanyName, Ad.AdOrderId
END


'
END
GO

----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetPartSearchDistOrder]    Script Date: 03/30/2012 21:48:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetPartSearchDistOrder]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetPartSearchDistOrder]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetPartSearchDistOrder]    Script Date: 03/30/2012 21:48:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:        Lalit Mehta
-- Create date: Mar 22, 2012
-- Description:    Part Search - Get ordering of Distributors based on orders placed in the region
--[usp_GetPartSearchDistOrder] '','105552','121564'
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetPartSearchDistOrder]
    @UserRegionId varchar(100),
    @MfrId varchar(100),
    @PartNum varchar(100),
    @DistIds varchar(500)

    --execute [usp_GetPartSearchDistOrder] '','0',
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;
    Declare @SQL1 varChar(8000)
    DECLARE @IsEmptyRegionIDs varchar(1) = '0'
    --SET @UserRegionId = '1,2,3,4'
    SET @UserRegionId = '' + REPLACE(@UserRegionId,',',''',''') + ''

    --SET @DistIds = '100789,120020,104333,102617,139004'
    select items as DistributorID  into ##AllDistId from dbo.Split(@DistIds, ',')
    SET @DistIds = '''' + REPLACE(@DistIds,',',''',''') + ''''

    IF(@UserRegionId = '') BEGIN SET @IsEmptyRegionIDs = '1' END
    --DECLARE  @MfrId varchar(100) = '139801'
    set transaction isolation level read uncommitted

    SET @SQL1 =
    'select
        '''+@MfrId+''' as MfrId
        ,'''+@PartNum+''' as PartNum
        ,dist.CompanyName as DistributorName
        ,convert(varchar(20), dist.CompanyID) as DistributorID
        ,DistAuthStatus = CASE WHEN RZS.MaxAuth = 4 then 1 ELSE 0 END
        ,RZS.Total into ##temp
    from
        RegionAuthorization RA (NOLOCK)
        left join (
            select
                RZOS.MFRDistID,
                MAX(case when (AuthStatusID  = 2 and C.Trusted_Disty = 1) then 4 else AuthStatusID end) as MaxAuth,
                sum(Print_Amount+Online_Amount) as Total
            from
                RegionZoneStatus (nolock) RZOS,
                Company (nolock) C,
                RegionAuthorization (nolock) RA
            where
                RA.MfrDistID = RZOS.MfrDistID
                AND RA.DistID=C.CompanyID
                AND (RegionId in ('''+ @UserRegionId  +''') OR '''+@IsEmptyRegionIDs+''' = ''1'')
            group By RZOS.MfrDistID
        ) as RZS on RA.MfrDistID = RZS.MfrDistID
        left join Company dist on dist.CompanyID = ra.DistID
    where
        RA.MfrId = '+@MfrId+'
        and RA.DistID in('+@DistIds+')
    order By
        MaxAuth DESC, Total DESC, DistributorName'
    --print (@SQL1)
    execute (@SQL1)
    --1
    create table ##OrderDistId(did int identity(1,1), MfrId varchar(200), PartNum varchar(200), DistributorId varchar(200))
    insert into ##OrderDistId(MfrID, PartNum, DistributorID)
    select MfrID, PartNum, DistributorID from ##temp
    select * into ##temp2 from ##OrderDistId

    --2
    select @MfrId as MfrID, @PartNum as PartNum, DistributorID into ##AllDistIds from ##AllDistId
    --select * from ##AllDistIds


    insert into ##temp2(MfrId, PartNum, DistributorId)
    select ##AllDistIds.MfrID, ##AllDistIds.PartNum, ##AllDistIds.DistributorID
    from ##AllDistIds
    where ##AllDistIds.DistributorID not in (select DistributorID from ##OrderDistId)

    drop table ##AllDistId
    drop table ##AllDistIds
    drop table ##OrderDistId
    drop table ##temp

    select MfrId, PartNum, DistributorId from ##temp2 order by did


    drop table ##temp2
END

GO

----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetAllSalesAssignment1]    Script Date: 03/22/2012 11:20:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAllSalesAssignment1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAllSalesAssignment1]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetAllSalesAssignment1]    Script Date: 03/22/2012 11:20:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [dbo].[usp_GetAllSalesAssignment1] -- " 1 = 1  AND Company like 'dig%'"
(
 @SearchCondition Varchar(100)
)
AS
BEGIN
    set transaction isolation level read uncommitted

EXEC('SELECT * FROM
(
    SELECT C.CompanyID,RTRIM(LTRIM(C.CompanyName)) as Company,
    CAST(SA.SalesPerson_ID as varchar(50)) as SalesPerson_ID,
    U.FirstName+'' ''+ U.LastName AS UserName
    FROM  COMPANY C LEFT OUTER JOIN SalesAssignments SA ON C.CompanyID =SA.Company_ID and SA.END_Date is null
    LEFT OUTER JOIN [User] U on U.UserID = SA.SalesPerson_ID
    WHERE C.CompanyStatusID = 1 AND C.IsActive = 1 AND [dbo].[Get_CompanyTypeForSalesAssignment](C.CompanyID) = 1
) A WHERE ' + @SearchCondition + ' Order BY  Company ')

END
GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchDesignResourcesManu]    Script Date: 03/23/2012 21:47:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchDesignResourcesManu]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchDesignResourcesManu]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchDesignResourcesManu]    Script Date: 03/23/2012 21:47:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--------------------------------------------------------------------------
-- Name   : usp_GetSearchDesignResourcesManu Manufacturer DetailsPage
-- Description : This Procedure Will Get the Manufacturer Details.
-- Arguments :
-- Returns  : None
--------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetSearchDesignResourcesManu]  --106406 , 'kns40'
(
 @CompanyID  int,
 @PartNumber  varchar(50)
 )
AS
BEGIN
SET @PartNumber = CASE WHEN @PartNumber IS null then '' else @PartNumber end
SELECT
    prod.PartNumber
            ,prod.ProductID
            ,comp.CompanyName AS ManufacturerName
            ,comp.CompanyID
            ,CASE WHEN ISNULL(prod.DataSheet,'') <>'' AND ISNULL(prod.DataSheetTitle,'')<>'' THEN prod.DataSheetTitle ELSE
            CASE WHEN ISNULL(inv.MafSpecURL,'') <> '' AND ISNULL(inv.MafSpecTitle,'')<>'' THEN inv.MafSpecTitle ELSE 'Data Sheet' END END AS DataSheetTitle
            ,CASE WHEN ISNULL(prod.DataSheet,'') <> '' THEN prod.DataSheet ELSE
            CASE WHEN ISNULL(inv.MafSpecURL,'')<> '' THEN inv.MafSpecURL END END AS DataSheetLink
            ,dbo.ufn_BSK_CommaSaparatedResourceAppType (prod.ProductID) AS AppNote
            ,dbo.ufn_BSK_CommaSaparatedResourceSoftType (prod.ProductID) AS Software
            ,prod.SampleUrl
            ,prod.VideoFilePath
            ,prod.ImageFilePath
            FROM dbo.Product prod
 INNER JOIN dbo.Company comp ON comp.companyid = prod.manufacturerid and (prod.PartNumber = @PartNumber or @PartNumber = '')
 AND comp.IsActive = 1 AND comp.CompanyStatusID = 1
 LEFT JOIN InventorySettings Inv on Inv.CompanyID = prod.ManufacturerID
WHERE prod.IsActive = 1 AND prod.StatusID = 1 AND comp.companyid=@CompanyID
END
GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchPartDetails]    Script Date: 05/19/2012 13:10:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchPartDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchPartDetails]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchPartDetails]    Script Date: 05/19/2012 13:10:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--------------------------------------------------------------------------
-- Name   : [usp_GetSearchPartProductType] ManuDist Detailspage
-- Description : This Procedure Will Get the ManuDist Details.
-- Arguments : CompanyID, PartNumber
-- Returns  : List of Parts
--------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[usp_GetSearchPartDetails]
    (
        @companyid INT,
        @partnumber VARCHAR(50)
    )
AS
--DECLARE @CompanyID INT = 103569, @PartNumber VARCHAR(50) = '1287'

BEGIN
    SELECT dp.DistID AS DistributorID, p.ProductID, dp.InvID, pt.TypeDescription AS ProductType,
        c1.CompanyID AS ManufacturerID, c.CompanyName AS DistributorName, c1.CompanyName AS ManufacturerName, dp.ManufacturerCode AS DistManufacturerCode, c1.CompanyLogo,
        dp.PartNumber, dp.Uploaded, dp.QtyOnHand, dp.Price,
        ins.RFQCPID, ins.BuyPentonExpire, ins.BuyPentonURL1, ins.BuyPentonURL2, ins.BuyPentonURL3, ins.BuyPentonURL4, ins.BuyPentonURL5,
        cast(dp.Description as varchar(max)) AS ColumnDescription,
        IsNULL(RZS.MaxAuth, 0) AS MaxAuth
    FROM DistributorParts AS dp
    INNER JOIN ManufacturerCode_XRF AS xrf
        ON dp.DistID = xrf.DistributorId
        AND dp.ManufacturerCode = xrf.ManufacturerCode
        AND xrf.ManufacturerId = @CompanyID
    INNER JOIN RegionAuthorization AS ra
        ON ra.DistID = dp.DistID
        AND ra.MfrID = @CompanyID
    LEFT JOIN Company AS c
        ON c.isActive = 1
        AND c.companystatusid = 1
        AND c.CompanyID = dp.DistID
    LEFT JOIN Company AS c1
        ON c1.IsActive = 1
        AND c1.companystatusid = 1
        AND c1.CompanyID = xrf.ManufacturerId
    LEFT JOIN InventorySettings AS ins
        ON ins.DoNotPub = 0
        AND dp.DistID = ins.CompanyID
    LEFT JOIN (
                SELECT RZOS.MFRDistID, MAX(CASE WHEN (AuthStatusID  = 2 and C.Trusted_Disty=1) THEN 4 ELSE AuthStatusID END) AS MaxAuth
                FROM RegionZoneStatus (nolock) AS RZOS,
                        Company (nolock) AS C,
                        RegionAuthorization (nolock) AS RA
                WHERE  RA.MfrDistID = RZOS.MfrDistID
                        AND RA.MfrID=C.CompanyID
                GROUP BY RZOS.MfrDistID
              ) AS RZS
                ON ra.MfrDistID = RZS.MfrDistID
    LEFT JOIN Product AS p
        ON p.StatusID = 1
        AND dp.PartNumber = p.PartNumber
        AND xrf.ManufacturerId = p.ManufacturerID
    LEFT JOIN productType_XRF AS pt_xrf
        ON p.ManufacturerID = pt_xrf.ManufacturerID
        AND p.ProductType = pt_xrf.MfrProdTypeCode
    LEFT JOIN ProductType AS pt
        ON pt.IsActive = 1
        AND pt_xrf.ProductTypeID = pt.ProductTypeId
    WHERE [dbo].[RemoveSpecialCharacter](dp.PartNumber) = @PartNumber
    group by dp.DistID, p.ProductID, dp.InvID, pt.TypeDescription, dp.ManufacturerCode,
        c1.CompanyID, c.CompanyName, c1.CompanyName, c1.CompanyLogo,
        dp.PartNumber, dp.Uploaded, dp.QtyOnHand, dp.Price,
        ins.RFQCPID, ins.BuyPentonExpire, ins.BuyPentonURL1, ins.BuyPentonURL2, ins.BuyPentonURL3, ins.BuyPentonURL4, ins.BuyPentonURL5,
        cast(dp.Description as varchar(max)),
        IsNULL(RZS.MaxAuth, 0)

END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetAllPartSearchDistOrder]    Script Date: 03/28/2012 21:29:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAllPartSearchDistOrder]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAllPartSearchDistOrder]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetAllPartSearchDistOrder]    Script Date: 03/28/2012 21:29:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:        Lalit Mehta
-- Create date: Mar 25, 2012
-- Description:    Get all ordering of Distributors based on orders placed in the region
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetAllPartSearchDistOrder]
    @REGIONID varchar(100) = '',
    @MFRID1 varchar(100) = '',
    @PARTID1 varchar(100) = '',
    @DISTIDS1 varchar(500) = '',
    @MFRID2 varchar(100) = '',
    @PARTID2 varchar(100) = '',
    @DISTIDS2 varchar(500) = '',
    @MFRID3 varchar(100) = '',
    @PARTID3 varchar(100) = '',
    @DISTIDS3 varchar(500) = '',
    @MFRID4 varchar(100) = '',
    @PARTID4 varchar(100) = '',
    @DISTIDS4 varchar(500) = '',
    @MFRID5 varchar(100) = '',
    @PARTID5 varchar(100) = '',
    @DISTIDS5 varchar(500) = '',
    @MFRID6 varchar(100) = '',
    @PARTID6 varchar(100) = '',
    @DISTIDS6 varchar(500) = '',
    @MFRID7 varchar(100) = '',
    @PARTID7 varchar(100) = '',
    @DISTIDS7 varchar(500) = '',
    @MFRID8 varchar(100) = '',
    @PARTID8 varchar(100) = '',
    @DISTIDS8 varchar(500) = '',
    @MFRID9 varchar(100) = '',
    @PARTID9 varchar(100) = '',
    @DISTIDS9 varchar(500) = '',
    @MFRID10 varchar(100) = '',
    @PARTID10 varchar(100) = '',
    @DISTIDS10 varchar(500) = ''
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;
    set transaction isolation level read uncommitted

    IF (ISNULL(@MFRID1, '') <> '')
    BEGIN
        execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID1,@PARTID1,@DISTIDS1
    END
    IF (ISNULL(@MFRID2, '') <> '')
    BEGIN
        execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID2,@PARTID2,@DISTIDS2
    END
    IF (ISNULL(@MFRID3, '') <> '')
    BEGIN
        execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID3,@PARTID3,@DISTIDS3
    END
    IF (ISNULL(@MFRID4, '') <> '')
    BEGIN
        execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID4,@PARTID4,@DISTIDS4
    END
    IF (ISNULL(@MFRID5, '') <> '')
    BEGIN
        execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID5,@PARTID5,@DISTIDS5
    END
    IF (ISNULL(@MFRID6, '') <> '')
    BEGIN
        execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID6,@PARTID6,@DISTIDS6
    END
    IF (ISNULL(@MFRID7, '') <> '')
    BEGIN
        execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID7,@PARTID7,@DISTIDS7
    END
    IF (ISNULL(@MFRID8, '') <> '')
    BEGIN
        execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID8,@PARTID8,@DISTIDS8
    END
    IF (ISNULL(@MFRID9, '') <> '')
    BEGIN
        execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID9,@PARTID9,@DISTIDS9
    END
    IF (ISNULL(@MFRID10, '') <> '')
    BEGIN
        execute [dbo].[usp_GetPartSearchDistOrder] @REGIONID,@MFRID10,@PARTID10,@DISTIDS10
    END
END


GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_Rep_UnmappedMfrCodeByDist]    Script Date: 05/07/2012 01:15:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Rep_UnmappedMfrCodeByDist]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_Rep_UnmappedMfrCodeByDist]
GO

/****** Object:  StoredProcedure [dbo].[usp_Rep_UnmappedMfrCodeByDist]    Script Date: 05/07/2012 01:15:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

------------------------------------------------------------------
-- Name   : [usp_Rep_UnmappedMfrCodeByDist]
-- Author : Kartikeya Sinha
-- Created By : Kartikeya Sinha
-- Created On : 12 Sep 2011
-- Updated By : Fathima
-- Updated On : 05 Oct 2011
-- Description : lists of all Unmapped Manufacturer codes by distributor.
-- Arguments : None
-- Returns  : None
-------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_Rep_UnmappedMfrCodeByDist]

AS
BEGIN

select
    c.CompanyName as DistributorName,
    x.UnmappedManufacturerCodes
from Company c
inner join (
    select    d.DistId,
        count(distinct d.manufacturercode) as UnmappedManufacturerCodes
    from    DistributorParts D with(nolock)
    left outer join ManufacturerCode_XRF mcx with(nolock)
        on d.DistID=mcx.DistributorId
        and d.ManufacturerCode = mcx.ManufacturerCode
    where mcx.ManufacturerCode is null
    group by d.DistID
    ) x
    on c.CompanyID = x.DistID
where c.IsActive=1
order by c.CompanyName

END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetAllTopProductTypes]    Script Date: 05/17/2012 16:57:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAllTopProductTypes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetAllTopProductTypes]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetAllTopProductTypes]    Script Date: 05/17/2012 16:57:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetAllTopProductTypes]
AS
BEGIN
    Select
    ProductTypeID,
    ltrim(rtrim(TypeDescription)) as ProductType,
    CASE WHEN len(ltrim(rtrim(TypeDescription)))>15 THEN left(TypeDescription,12) + '...' ELSE TypeDescription END AS 'DisplayName',0
FROM
    ProductType
WHERE
    IsActive = 1 AND StatusID=1 AND ParentId=0
    and TypeDescription is not null
ORDER BY ProductType
END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchServiceName]    Script Date: 05/17/2012 17:08:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchServiceName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchServiceName]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchServiceName]    Script Date: 05/17/2012 17:08:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetSearchServiceName]
(
    @product_type_id INT,
    @service_name VARCHAR(100)
)

AS

--DECLARE @product_type_id INT = 168, @service_name VARCHAR(100) = 'powerboardassemblyinstallation'
IF EXISTS (
    SELECT pt.ProductTypeId, pt.TypeDescription AS ServiceName
    FROM dbo.ProductType AS pt
    WHERE pt.ProductTypeId = @product_type_id
)
BEGIN
    SELECT pt.ProductTypeId, pt.TypeDescription AS ServiceName
    FROM dbo.ProductType AS pt
    WHERE pt.ProductTypeId = @product_type_id
END
ELSE
BEGIN
    SELECT TOP 1 pt.ProductTypeId, pt.TypeDescription AS ServiceName
    FROM dbo.ProductType AS pt
    WHERE pt.IsServices = 1
        AND pt.IsActive = 1
        AND pt.StatusID = 1
        AND dbo.RemoveSpecialCharacter(pt.TypeDescription) = @service_name
    ORDER BY pt.TypeDescription
END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchAllProductTypes]    Script Date: 05/17/2012 17:22:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchAllProductTypes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchAllProductTypes]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchAllProductTypes]    Script Date: 05/17/2012 17:22:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE  PROCEDURE [dbo].[usp_GetSearchAllProductTypes]
AS
BEGIN
    set transaction isolation level read uncommitted
     SELECT TypeDescription AS ProductType,ProductTypeID,ParentID,
         [dbo].[Get_ProductTypePartCount](ProductTypeID) as PartNumber
     FROM ProductType AS pt
     WHERE IsActive = 1 AND StatusID=1 AND IsServices = 0
     ORDER BY ProductTypeID, ParentID

     SELECT ProductTypeID, TypeDescription AS ProductType, pt.ParentId
     FROM ProductType AS pt
     WHERE IsActive = 1 AND StatusID=1 AND IsServices = 1
     ORDER BY ProductTypeID, ParentID

END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetRelatedProducts]    Script Date: 05/19/2012 13:04:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetRelatedProducts]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetRelatedProducts]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetRelatedProducts]    Script Date: 05/19/2012 13:04:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetRelatedProducts]
(
    @product_type_id INT
)
AS
--DECLARE @product_type_id INT = 10

BEGIN

        SELECT parent_pt.TypeDescription, 'Parent' AS relationship, 1 AS data_set_order
        FROM dbo.ProductType AS pt
        INNER JOIN dbo.ProductType AS parent_pt
        ON pt.ParentId = parent_pt.ProductTypeId
        WHERE pt.ProductTypeId = @product_type_id

    UNION
        SELECT sibling_pt.TypeDescription, 'Sibling' AS relationship, 2 AS data_set_order
        FROM dbo.ProductType AS pt
        INNER JOIN dbo.ProductType AS sibling_pt
        ON pt.ParentId = sibling_pt.ParentId
        AND pt.ProductTypeId <> sibling_pt.ProductTypeId
        WHERE pt.ProductTypeId = @product_type_id

    UNION
        SELECT child_pt.TypeDescription, 'Child' AS relationship, 3 AS data_set_order
        FROM dbo.ProductType AS pt
        INNER JOIN dbo.ProductType AS child_pt
            ON pt.ProductTypeId = child_pt.ParentId
        WHERE pt.ProductTypeId = @product_type_id

    ORDER BY data_set_order, TypeDescription
END
GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchProductsDetails]    Script Date: 05/22/2012 17:32:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetSearchProductsDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetSearchProductsDetails]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetSearchProductsDetails]    Script Date: 05/22/2012 17:32:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--------------------------------------------------------------------------
-- Name   : usp_GetSearchProductsDetails Company DetailsPage
-- Description : This Procedure Will Get a comapnanies related product types
-- Arguments : Company ID
-- Returns  : None
--------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetSearchProductsDetails]
(
    @CompanyID  Int
    )
AS
BEGIN
    SET NOCOUNT ON;
select
    c.CompanyID
    , c.CompanyName
    , p.BookName
    , p.ProductTypeId
    , p.ParentId
from
    companyproducttype cpt
    inner join productType p
        on cpt.ProductTypeID = p.ProductTypeId
    inner join Company c
        on cpt.CompanyID = c.CompanyID
where
    cpt.CompanyID = @CompanyID
    and p.ParentId is not null
    and p.IsActive = 1
    and cpt.IsActive = 1
    and cpt.producttypeid not in
    (
        select distinct ParentId
        from
            companyproducttype cpt
            inner join productType p
                on cpt.ProductTypeID = p.ProductTypeId
        where
            cpt.CompanyID = @CompanyID
            and p.ParentId is not null
            and p.IsActive = 1
            and cpt.IsActive = 1
    )
    order by p.ParentId, p.ProductTypeId
END
BEGIN
    SET NOCOUNT ON;

   select count(*) as ProdCount
from
    companyproducttype cpt
    inner join productType p
        on cpt.ProductTypeID = p.ProductTypeId
    inner join Company c
        on cpt.CompanyID = c.CompanyID
where
    cpt.CompanyID = @CompanyID
    and p.ParentId is not null
    and p.IsActive = 1
    and cpt.IsActive = 1
    and cpt.producttypeid not in
    (
        select distinct ParentId
        from
            companyproducttype cpt
            inner join productType p
                on cpt.ProductTypeID = p.ProductTypeId
        where
            cpt.CompanyID = @CompanyID
            and p.ParentId is not null
            and p.IsActive = 1
            and cpt.IsActive = 1
    )
END


GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetCompanyUserFavorite]    Script Date: 05/24/2012 18:23:08 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetCompanyUserFavorite]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetCompanyUserFavorite]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetCompanyUserFavorite]    Script Date: 05/24/2012 18:23:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_GetCompanyUserFavorite]
(
    @company_id INT,
    @user_id INT,
    @is_favorite BIT OUTPUT
)

AS

BEGIN

--DECLARE @company_id INT = 103569, @user_id INT = 89226
    SET @is_favorite = 0

    DECLARE @ManufacturerFavTypeId INT, @VendorFavTypeId INT, @DistributorFavTypeId INT

    SET @ManufacturerFavTypeId = 1
    SET @DistributorFavTypeId = 2
    SET @VendorFavTypeId = 4

    IF EXISTS(
        SELECT *
        FROM dbo.UserFavorites AS uf
        INNER JOIN COMPANY AS c
            ON uf.TypeID = c.CompanyID
            AND uf.FavType IN (@ManufacturerFavTypeId,@DistributorFavTypeId,@VendorFavTypeId)
            AND c.CompanyStatusID = 1
        WHERE uf.UserID = @user_id
            AND c.CompanyID = @company_id
    )
        SET @is_favorite = 1
END

GO

----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[GetScheduleDate]    Script Date: 05/24/2012 20:15:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetScheduleDate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetScheduleDate]
GO

/****** Object:  StoredProcedure [dbo].[GetScheduleDate]    Script Date: 05/24/2012 20:15:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--------------------------------------------------------------------------
-- Created By : Md Shamim Ahmad
-- Created On : 14 Sep 2010
-- Description : Get all edition schedule date
-- Modified By : Lalbahadur
-- Modified On : 23 May 2012  for ticket#13239
--------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[GetScheduleDate]
@RegionID INT,
@Year CHAR(4)
AS
BEGIN
 SET NOCOUNT ON
 set transaction isolation level read uncommitted
 -- print @Year
 SELECT StartSellingDate,EditorialToArtDate,SendUpdateFormDate,PrintBindingDate,AdvCloseDate,
 SendBillingDate,CloseProductionDate,PublicationDate FROM EDITIONS WHERE RegionID = @RegionID AND [Year] = @Year
 SET NOCOUNT OFF
END

GO
----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_AddEdition]    Script Date: 05/24/2012 20:14:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_AddEdition]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_AddEdition]
GO

/****** Object:  StoredProcedure [dbo].[usp_AddEdition]    Script Date: 05/24/2012 20:14:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--------------------------------------------------------------------------
-- Created By : Md Shamim Ahmad
-- Created On : 14 Sep 2010
-- Description : Inser and update edition table
-- 0 - failure
-- 1 - add
-- 2 -updated
-- 3 -exist
-- Modified By : Lalbahadur
-- Modified On : 23 May 2012  for ticket#13239 to put the update flag as 2
--------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_AddEdition]

@EditionID INT,
@RegionID INT,
@StatusID INT,
@Year CHAR(4),
@Title VARCHAR(30),
@HeadingTitle VARCHAR(10),
@Comments TEXT,
@FolioSize INT,
@TotalNetRevenue MONEY,
@TotalDistribution INT,
@StartSellingDate DATETIME,
@EditorialToArtDate DATETIME,
@SendUpdateFormDate DATETIME,
@PrintBindingDate DATETIME,
@AdvCloseDate DATETIME,
@SendBillingDate DATETIME,
@CloseProductionDate DATETIME,
@PublicationDate DATETIME,
@CreatedBy INT ,
@AdJobTypeID VARCHAR(1),
@returnValue INT =0

AS

BEGIN TRY

 DECLARE @EditionLocID int
 SET @EditionLocID=0

IF @AdJobTypeID = 'O'
BEGIN
 IF EXISTS(SELECT RegionID FROM  [Editions] WHERE [Year]=@Year AND AdJobTypeID='O')
 BEGIN

 SELECT @EditionLocID=EditionID FROM  [Editions] WHERE [Year]=@Year AND AdJobTypeID='O'
 END
END

ELSE
BEGIN
 IF EXISTS(SELECT  RegionID FROM [Editions] WHERE RegionID=@RegionID AND [Year]=@Year AND AdJobTypeID='P')
  BEGIN
   SELECT @EditionLocID=EditionID FROM  [Editions] WHERE RegionID=@RegionID AND [Year]=@Year AND AdJobTypeID='P'
  END
END

IF @EditionLocID =0
BEGIN
   INSERT INTO [Editions]
   (
   RegionID,StatusID,[Year],Title,HeadingTitle,Comments,FolioSize,TotalNetRevenue,AdJobTypeID,
   TotalDistribution,StartSellingDate,EditorialToArtDate,SendUpdateFormDate,
   PrintBindingDate,AdvCloseDate,SendBillingDate,CloseProductionDate,PublicationDate,CreatedBy,CreatedOn
   )
   VALUES
   (
   @RegionID,@StatusID,@Year,@Title,@HeadingTitle,@Comments,@FolioSize,@TotalNetRevenue,@AdJobTypeID,
   @TotalDistribution,@StartSellingDate,@EditorialToArtDate,@SendUpdateFormDate,
   @PrintBindingDate,@AdvCloseDate,@SendBillingDate,@CloseProductionDate,@PublicationDate,@CreatedBy,GETDATE()

   )
   SET @returnValue = 1
END
ELSE
BEGIN
   UPDATE [Editions] SET
   StatusID   = @StatusID,
   Title    = @Title,
   HeadingTitle  = @HeadingTitle,
   Comments   = @Comments,
   FolioSize   = @FolioSize,
   TotalNetRevenue  = @TotalNetRevenue,
   TotalDistribution = @TotalDistribution,
   StartSellingDate = @StartSellingDate,
   EditorialToArtDate = @EditorialToArtDate,
   SendUpdateFormDate = @SendUpdateFormDate,
   PrintBindingDate = @PrintBindingDate,
   AdvCloseDate  = @AdvCloseDate,
   SendBillingDate  = @SendBillingDate,
   CloseProductionDate = @CloseProductionDate,
   PublicationDate  = @PublicationDate,
   UpdatedBy   = @CreatedBy,
   UpdatedOn   = GETDATE()
   WHERE EditionID=@EditionLocID

   SET @returnValue = 2
END
END TRY
BEGIN CATCH
SET @returnValue = 0
END CATCH
RETURN @returnValue
GO

----------------------------------------------------------------------------------------------------------
GO

/****** Object:  StoredProcedure [dbo].[usp_GetEditions]    Script Date: 05/24/2012 20:19:13 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetEditions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_GetEditions]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetEditions]    Script Date: 05/24/2012 20:19:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--------------------------------------------------------------------------
-- Created By : Lalbahadur Singh
-- Created On : 23 May 2012
-- Description : To get the edition table data
--------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetEditions] --4,'2014'
(
    @RegionID INT,
    @Year CHAR(4)
)
AS
BEGIN
  --select * from Editions order by UpdatedON
  SET NOCOUNT ON

   SELECT EditionID,
       RegionID,
       StatusID,
       [Year],
       Title,
       HeadingTitle,
       ISNULL(Comments,'') as Comments,
       ISNULL(FolioSize,'0') as FolioSize,
       TotalNetRevenue,
       TotalDistribution,
       ISNULL(StartSellingDate,'') as StartSellingDate,
       ISNULL(EditorialToArtDate,'') as EditorialToArtDate,
       ISNULL(SendUpdateFormDate,'') as SendUpdateFormDate,
       ISNULL(PrintBindingDate,'') as PrintBindingDate,
       ISNULL(AdvCloseDate,'') as AdvCloseDate,
       ISNULL(SendBillingDate,'') as SendBillingDate,
       ISNULL(CloseProductionDate,'') as CloseProductionDate,
       ISNULL(PublicationDate,'') as PublicationDate,
       UpdatedBy,
       UpdatedOn,
       AdJobTypeID FROM dbo.Editions
    WHERE RegionID = @RegionID AND [Year] = @Year AND AdJobTypeID='P'

  SET NOCOUNT OFF

END

GO
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------







