--------------------------------------------------------------------------------------------------------
---Update Script
--------------------------------------------------------------------------------------------------------
update Company set Clean_CompanyName = dbo.VK_RemoveSpecialChars(CompanyName) where CompanyName is not null and Clean_CompanyName is null
update Company set Clean_BookName = dbo.VK_RemoveSpecialChars(BookName) where BookName is not null and Clean_BookName is null
update Company set Clean_keywords = dbo.VK_RemoveSpecialChars(keywords) where keywords is not null and Clean_keywords is null
update Product set Clean_PartNumber = dbo.VK_RemoveSpecialChars(PartNumber) where PartNumber is not null and Clean_PartNumber is null
--------------------------------------------------------------------------------------------------------
EXEC USP_Load_intoDistributorPartSearch
--------------------------------------------------------------------------------------------------------
EXEC Load_Seelines_4Mfr
--------------------------------------------------------------------------------------------------------
--Inventory Related Update for Inventory Setting
UPDATE InventorySettings SET BuyPentonExpire=ISNULL(BuyPentonExpire,'1753-01-01 00:00:00.000'),
    DitPNSExpire=ISNULL(DitPNSExpire,'1753-01-01 00:00:00.000'),MafPNSExpire=ISNULL(MafPNSExpire,'1753-01-01 00:00:00.000')
GO

---------------------------------------------------------------------------------------------------------
-- updates committed by Kiran Sangoi (from ver 930)
----------------------------------------------------------------------------------------------------------------
Update InventorySettings SET CheckInvURL = 'http://' + CheckInvURL
where  CheckInvURL Not like 'http:%' and LTRIM(RTRIM(CheckInvURL)) <> ''

Update InventorySettings SET DitRefURL1 = 'http://' + DitRefURL1
where  DitRefURL1 Not like 'http:%'  and LTRIM(RTRIM(DitRefURL1)) <> ''

Update InventorySettings SET DitRefURL2 = 'http://' + DitRefURL2
where  DitRefURL2 Not like 'http:%'  and LTRIM(RTRIM(DitRefURL2)) <> ''

Update InventorySettings SET DitRefURL3 = 'http://' + DitRefURL3
where  DitRefURL3 Not like 'http:%'  and LTRIM(RTRIM(DitRefURL3)) <> ''

Update InventorySettings SET DitRefURL4 = 'http://' + DitRefURL4
where  DitRefURL4 Not like 'http:%'  and LTRIM(RTRIM(DitRefURL4)) <> ''

Update InventorySettings SET DitRefURL5 = 'http://' + DitRefURL5
where  DitRefURL5 Not like 'http:%'  and LTRIM(RTRIM(DitRefURL5)) <> ''

Update InventorySettings SET BuyPentonURL1 = 'http://' + BuyPentonURL1
where  BuyPentonURL1 Not like 'http:%'  and LTRIM(RTRIM(BuyPentonURL1)) <> ''

GO
----------------------------------------------------------------------------------------------------------------
update AdOrderDetails set ApplyDiscount = 0 where ApplyDiscount is null
update AdOrderDetails set OrderRegionId = '0' where OrderRegionId is null

GO
----------------------------------------------------------------------------------------------------------------
update AdOrderRegionEdition set GrossAmount = ISNULL(GrossAmount,0),
            NetAmount = ISNULL(netamount,0), SubTotal = ISNULL(subtotal,0)
            where GrossAmount is null or NetAmount is null or SubTotal is null

update AdOrder set GrossAmount = ISNULL(GrossAmount,0),
            NetAmount = ISNULL(netamount,0), NetAmountCancelled = ISNULL(NetAmountCancelled,0),
            DiscountRate = ISNULL(DiscountRate,0)
            where GrossAmount is null or NetAmount is null or NetAmountCancelled is null or DiscountRate is null

GO

----------------------------------------------------------------------------------------------------------------


/*
Fix for S-ESB-13522
Instead of Package the client is ok with script, so here is the script

*/

BEGIN TRAN



Update  InventorySettings
SET DitRefURL1 = 'http://www.electronicprecepts.com',
DitRefURL2 = 'http://electronicprecepts.com'
where CompanyID =  102217


Update  InventorySettings
SET DitRefURL1 = 'http://www.houseofbatteries.com',
MafRefURL1 = 'http://www.houseofbatteries.com'
where CompanyID =  103008

Update  InventorySettings
SET DitRefURL1 = 'http://www.inscoinc.com' where CompanyID =  103216

Update  InventorySettings
SET DitRefURL1 = 'http://4pkc.com',
DitRefURL2 = 'http://www.4pkc.com'
where CompanyID = 104806

Update  InventorySettings
SET DitRefURL1 = 'http://www.rainbowelectronics.com' where CompanyID =  105264

Update  InventorySettings
SET DitRefURL1 = 'http://www.rpaelect.com' where CompanyID =  105479

Update  InventorySettings
SET DitRefURL1 = 'http://www.pikpower.com'
,DitRefURL2 = 'http://www.echipsonline.com'
,DitRefURL3 = 'http://imail.vascent.com'
,DitRefURL4 = 'http://vascent.com'
  where CompanyID = 107902


Update  InventorySettings
SET DitRefURL1 = 'http://www.aboveboardelectronics.com' where CompanyID = 108585

Update  InventorySettings
SET DitRefURL1 = 'http://www.advantageelectricsupply.com' where CompanyID = 134586


Update  InventorySettings
SET DitRefURL1 = 'http://www.gauinc.com'
,DitRefURL2 = 'http://gauinc.com'  where CompanyID = 135192

Update  InventorySettings
SET DitRefURL1 = 'http://www.kregercomponents.com'
,DitRefURL2 = 'http://kregercomponents.com'  where CompanyID = 137076

Update  InventorySettings
SET DitRefURL1 = 'http://www.labrainc.com' where CompanyID = 142727

COMMIT


----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
--Fix for 11676 adding http for URL field -

Begin tran
Update Company SET URL = 'http://' + URL
where  URL Not like 'http:%' and LTRIM(RTRIM(URL)) <> ''

Commit

----------------------------------------------------------------------------------------------------------------
--14769
go
update SalesAssignments SET [Status]=1 where End_Date is null
update SalesAssignments SET [Status]=0 where End_Date is not null
go

----------------------------------------------------------------------------------------------------------------
--14801
-- This delete is needed to fix 14801. It can be removed before the next full datamigration
Delete from Seeline where seelinefrom='CM' or seelinefrom is null

----------------------------------------------------------------------------------------------------------------
-- 20924
-- This cursor needs to be run to update the AdOrderRegionEdition table with gross, net, and sub total amounts
-- This process takes up to an hour
DECLARE @ad_order_id INT

DECLARE AdOrderCursor CURSOR FAST_FORWARD FOR
SELECT DISTINCT AO.AdOrderId
FROM AdOrder AO

OPEN AdOrderCursor

FETCH NEXT FROM AdOrderCursor INTO @ad_order_id
WHILE @@FETCH_STATUS = 0
BEGIN
	EXEC usp_AdOrderGrossNetAmount @ad_order_id, 160 --Guarantee Line Limit from web.config

	IF (@@ERROR <> 0) BREAK
	
	FETCH NEXT FROM AdOrderCursor INTO @ad_order_id
END

CLOSE AdOrderCursor
DEALLOCATE AdOrderCursor
-----------------------------------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------------------------------
-- 22816
update dbo.RegionAuthorization set Publish = 0  where DistId in (12849,	16679,	12865,	16687,	12881,	12883,	16324,	12900,	12903,	12906,	12929,	12935,	16692,	16787,	16960,	12990,	13013,	13027,	13029,	13034,	16387,	16836,	16237,	13121,	16347,	13154,	16572,	13226,	12852,	13238,	13252,	16736,	13282,	16210,	13328,	16420,	16886,	13418,	16328,	13466,	13566,	13570,	16979,	16976,	16678,	13581,	13602,	13608,	14448,	13646,	16244,	16277,	13713,	13723,	13740,	14575,	13757,	13773,	13779,	13177,	13787,	16184,	13831,	16685,	16768,	13894,	12860,	16138,	13906,	13929,	16551,	16937,	16872,	16166,	16592,	14080,	14099,	16590,	14121,	14128,	14164,	16674,	16106,	16689,	14255,	16683,	16286,	14283,	14286,	16929,	14299,	16460,	14333,	14353,	14361,	14368,	16606,	14379,	16309,	14382,	14383,	14385,	14445,	16518,	14449,	16559,	16817,	14476,	14477,	14480,	16362,	14527,	14532,	14536,	14571,	14587,	16847,	14697,	16682,	14704,	14713,	14717,	16368,	16953,	14759,	14768,	16643,	16591,	14835,	14853,	14864,	14890,	14912,	14931,	16475,	14991,	16094,	15014,	15016,	16980,	16409,	15026,	15030,	15045,	15059,	16962,	15081,	16672,	15106,	16142,	15177,	15204,	15214,	15222,	15223,	16322,	15259,	15280,	16676,	15334,	15338,	15370,	16156,	16285,	15612,	16635,	15491,	15496,	16091,	16677,	16393,	15504,	16499,	15510,	15519,	16675,	16307,	15553,	15558,	15601,	15561,	16476,	15566,	15569,	16831,	15665,	16391,	15684,	15689,	16462,	16432,	13636,	16190,	15760,	15764,	16844,	16740,	16367,	16248,	15824,	15857,	15865,	15867,	15868,	15870,	16799,	16451,	16912,	16329,	15930,	16640,	15951,	16746,	15970,	15982,	16862,	16493,	16290)

----------------------------------------------------------------------------------------------------------------
-- 24049
UPDATE dp
SET PartNumber = ''
FROM DistributorParts dp
WHERE dp.PartNumber IS NULL

UPDATE dp
SET ManufacturerCode = ''
FROM DistributorParts dp
WHERE dp.ManufacturerCode IS NULL

UPDATE dp
SET BatchCode = ''
FROM DistributorParts dp
WHERE dp.BatchCode IS NULL

UPDATE dp
SET BatchCode = ''
FROM DistributorParts dp
WHERE dp.BatchCode = '0'
